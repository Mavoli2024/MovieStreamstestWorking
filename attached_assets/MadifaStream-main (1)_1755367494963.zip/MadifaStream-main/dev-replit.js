#!/usr/bin/env node

/**
 * Replit-specific development server
 * This script runs both frontend and backend servers for Replit environment
 * without breaking local or Vercel deployments
 */

import { spawn } from 'child_process';
import { config } from 'dotenv';

// Load environment variables
config();

console.log('🚀 Starting MadifaStream for Replit...\n');

// Start backend server
console.log('📦 Building backend...');
const buildBackend = spawn('npm', ['run', 'build:server'], {
  stdio: 'inherit',
  shell: true
});

buildBackend.on('close', (code) => {
  if (code !== 0) {
    console.error('❌ Backend build failed');
    process.exit(1);
  }
  
  console.log('✅ Backend built successfully\n');
  console.log('🖥️  Starting backend server on port 5001...');
  
  const backend = spawn('node', ['dist/server/server/server.js'], {
    stdio: 'inherit',
    shell: true,
    env: {
      ...process.env,
      PORT: '5001',
      NODE_ENV: 'development'
    }
  });
  
  backend.on('error', (err) => {
    console.error('❌ Backend server error:', err);
  });
  
  // Give backend time to start
  setTimeout(() => {
    console.log('🌐 Starting frontend server on port 5173...\n');
    
    const frontend = spawn('npm', ['run', 'dev'], {
      stdio: 'inherit',
      shell: true,
      env: {
        ...process.env,
        PORT: '5173'
      }
    });
    
    frontend.on('error', (err) => {
      console.error('❌ Frontend server error:', err);
    });
    
    console.log('\n✅ MadifaStream is running!');
    console.log('🌐 Frontend: http://localhost:5173');
    console.log('🖥️  Backend API: http://localhost:5001');
    console.log('\nPress Ctrl+C to stop all servers\n');
  }, 3000);
});

// Handle graceful shutdown
process.on('SIGINT', () => {
  console.log('\n👋 Shutting down servers...');
  process.exit(0);
});