import { logger } from "../../server/utils/logger.js";
/**
 * Direct Bunny CDN Content Sync Script
 * 
 * This script directly synchronizes content from Bunny CDN to Supabase
 * Run with: npx tsx scripts/direct-sync.ts
 */

import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';
import fetch from 'node-fetch';

// Initialize Supabase client with environment variables
const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ''; // Using service role for admin operations

// Bunny CDN configuration
const BUNNY_API_KEY = process.env.BUNNY_API_KEY || '';
const BUNNY_LIBRARY_ID = process.env.BUNNY_LIBRARY_ID || '';
const BUNNY_CDN_HOSTNAME = process.env.BUNNY_CDN_HOSTNAME || `vz-${BUNNY_LIBRARY_ID}.b-cdn.net`;

// Validate environment variables
if (!supabaseUrl || !supabaseKey) {
  logger.error('Error: SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not set in .env file');
  process.exit(1);
}

if (!BUNNY_API_KEY || !BUNNY_LIBRARY_ID) {
  logger.error('Error: BUNNY_API_KEY or BUNNY_LIBRARY_ID not set in .env file');
  process.exit(1);
}

logger.info('Environment variables loaded:');
logger.info(`- SUPABASE_URL: ${supabaseUrl ? 'Set' : 'Not set'}`);
logger.info(`- SUPABASE_SERVICE_ROLE_KEY: ${supabaseKey ? 'Set' : 'Not set'}`);
logger.info(`- BUNNY_API_KEY: ${BUNNY_API_KEY ? 'Set' : 'Not set'}`);
logger.info(`- BUNNY_LIBRARY_ID: ${BUNNY_LIBRARY_ID ? 'Set' : 'Not set'}`);
logger.info(`- BUNNY_CDN_HOSTNAME: ${BUNNY_CDN_HOSTNAME}`);

const supabase = createClient(supabaseUrl, supabaseKey);

// Type definitions
interface BunnyVideoMetadata {
  guid: string;
  title: string;
  dateUploaded: string;
  views: number;
  length: number;
  status: number;
  thumbnailFileName: string;
  thumbnailUrl: string;
  directPlayUrl: string;
  storageSize: number;
  availableResolutions: string[];
  encodeProgress: number;
  collection?: string;
  collectionId?: string;
}

interface BunnyCollection {
  videoLibraryId: number;
  guid: string;
  name: string;
  videoCount: number;
  totalSize: number;
  previewVideoIds: string | null;
  previewImageUrls: string[];
}

// Helper functions
async function getCollections(): Promise<BunnyCollection[]> {
  try {
    logger.info('Fetching collections from Bunny CDN...');
    const response = await fetch(
      `https://video.bunnycdn.com/library/${BUNNY_LIBRARY_ID}/collections`, 
      {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'AccessKey': BUNNY_API_KEY
        }
      }
    );
    
    if (!response.ok) {
      logger.error('Error fetching collections:', response.statusText);
      return [];
    }
    
    const data = await response.json() as { items: BunnyCollection[] };
    logger.info(`Found ${data.items.length} collections`);
    return data.items;
  } catch (error) {
    logger.error('Error fetching collections:', error);
    return [];
  }
}

async function getVideosInCollection(collectionId: string): Promise<BunnyVideoMetadata[]> {
  try {
    logger.info(`Fetching videos for collection ID: ${collectionId}`);
    const response = await fetch(
      `https://video.bunnycdn.com/library/${BUNNY_LIBRARY_ID}/videos?collection=${collectionId}&itemsPerPage=100`, 
      {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'AccessKey': BUNNY_API_KEY
        }
      }
    );
    
    if (!response.ok) {
      logger.error('Error fetching collection videos:', response.statusText);
      return [];
    }
    
    const data = await response.json() as { items: BunnyVideoMetadata[] };
    logger.info(`Found ${data.items.length} videos in collection`);
    return data.items;
  } catch (error) {
    logger.error('Error fetching collection videos:', error);
    return [];
  }
}

// Main sync function
async function syncBunnyContent() {
  logger.info('Starting Bunny CDN content sync...');
  
  try {
    // Get all collections from Bunny CDN
    const collections = await getCollections();
    
    // Track statistics
    let totalCollections = 0;
    let totalVideos = 0;
    
    // Process each collection
    for (const collection of collections) {
      logger.info(`\nProcessing collection: ${collection.name}`);
      totalCollections++;
      
      // Check if we already have a category for this collection
      let categoryId = null;
      const { data: existingCategories, error: categoryError } = await supabase
        .from('categories')
        .select('id, name, description')
        .eq('name', collection.name)
        .limit(1);
      
      if (categoryError) {
        logger.error('Error checking for existing category:', categoryError);
        continue;
      }
      
      const existingCategory = existingCategories && existingCategories.length > 0 ? existingCategories[0] : null;
      
      if (existingCategory) {
        logger.info(`  Category already exists (ID: ${existingCategory.id})`);
        categoryId = existingCategory.id;
      } else {
        // Create a new category
        logger.info(`  Creating new category for: ${collection.name}`);
        const { data: insertResult, error: insertError } = await supabase
          .from('categories')
          .insert({
            name: collection.name,
            description: `${collection.name} from Bunny CDN library`
          })
          .select();
          
        if (insertError) {
          logger.error('Error creating category:', insertError);
          continue;
        }
        
        if (insertResult && insertResult.length > 0) {
          categoryId = insertResult[0].id;
          logger.info(`  Created category ID: ${categoryId}`);
        }
      }
      
      // Skip if we couldn't get a category ID
      if (!categoryId) {
        logger.warn(`  Skipping collection - couldn't get category ID`);
        continue;
      }
      
      // Get videos in this collection
      logger.info(`  Fetching videos for collection: ${collection.name}`);
      const videos = await getVideosInCollection(collection.guid);
      logger.info(`  Found ${videos.length} videos`);
      
      // Skip thumbnail update as the categories table doesn't have thumbnailUrl column
      
      // Process each video
      for (const video of videos) {
        totalVideos++;
        
        const videoUrl = `https://${BUNNY_CDN_HOSTNAME}/${video.guid}/playlist.m3u8`;
        
        // Check if we already have this video by bunny_video_id
        const { data: existingVideos, error: videoError } = await supabase
          .from('videos')
          .select('id, views')
          .eq('bunny_video_id', video.guid)
          .limit(1);
          
        if (videoError) {
          logger.error('Error checking for existing video:', videoError);
          continue;
        }
        
        const existingVideo = existingVideos && existingVideos.length > 0 ? existingVideos[0] : null;
        
        if (existingVideo) {
          logger.info(`  Updating existing video: ${video.title}`);
          // Update existing video
          const { error: updateError } = await supabase
            .from('videos')
            .update({
              title: video.title,
              views: video.views || existingVideo.views,
              duration: video.length,
              metadata_json: JSON.stringify(video),
              storage_size: video.storageSize || null,
              available_resolutions: video.availableResolutions ? JSON.stringify(video.availableResolutions) : null,
              encode_progress: video.encodeProgress || 100 // Assume 100% if not specified
            })
            .eq('id', existingVideo.id);
            
          if (updateError) {
            logger.error(`  Error updating video ${video.title}:`, updateError);
          }
        } else {
          logger.info(`  Creating new video: ${video.title}`);
          // Insert new video
          const { error: insertError } = await supabase
            .from('videos')
            .insert({
              title: video.title,
              description: video.title, // Use title as description if none provided
              thumbnail_url: video.thumbnailUrl || `/api/bunny/thumbnail/${video.guid}`,
              video_url: videoUrl,
              trailer_url: null,
              release_year: new Date(video.dateUploaded).getFullYear(),
              duration: video.length,
              age_rating: 'PG', // Default
              genres: [],  // Default empty array
              cast_members: [],    // Default empty array
              director: '',
              is_trailer: collection.name.toLowerCase().includes('trailer'),
              collection_id: collection.guid,
              collection_name: collection.name,
              views: video.views || 0,
              metadata_json: JSON.stringify(video),
              is_premium: false, // Set all to non-premium for now
              bunny_video_id: video.guid,
              bunny_library_id: process.env.BUNNY_LIBRARY_ID,
              storage_size: video.storageSize || null,
              available_resolutions: video.availableResolutions ? JSON.stringify(video.availableResolutions) : null,
              encode_progress: video.encodeProgress || 100 // Assume 100% if not specified
            });
            
          if (insertError) {
            logger.error(`  Error creating video ${video.title}:`, insertError);
          }
        }
      }
    }
    
    logger.info('\nSync complete!');
    logger.info(`Processed ${totalCollections} collections and ${totalVideos} videos`);
    
  } catch (error) {
    logger.error('Error syncing Bunny content:', error);
    if (error instanceof Error) {
      logger.error(error.stack);
    }
  }
}

// Override console methods to ensure output is visible
const originalConsoleLog = console.log;
const originalConsoleError = console.error;
const originalConsoleWarn = console.warn;

console.log = function(...args) {
  originalConsoleLog(...args);
  process.stdout.write(args.join(' ') + '\n');
};

console.error = function(...args) {
  originalConsoleError(...args);
  process.stderr.write(args.join(' ') + '\n');
};

console.warn = function(...args) {
  originalConsoleWarn(...args);
  process.stderr.write(args.join(' ') + '\n');
};

// Run the sync function
syncBunnyContent().catch(error => {
  logger.error('Unhandled error in sync process:', error);
  process.exit(1);
});

// Write directly to stdout as a last resort
process.stdout.write('Script execution started\n');

