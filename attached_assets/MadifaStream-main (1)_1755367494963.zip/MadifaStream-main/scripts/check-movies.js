/**
 * Check Videos in Database
 * 
 * This script checks if videos have been successfully synced to the database
 */

import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';

// Initialize Supabase client with environment variables
const supabaseUrl = process.env.SUPABASE_URL || '';
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || ''; // Using service role for admin operations

if (!supabaseUrl || !supabaseKey) {
  console.log('Error: SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not set in .env file');
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function checkVideos() {
  console.log('Checking videos in database...');
  
  try {
    // Count total videos
    const { data: videoCount, error: countError } = await supabase
      .from('videos')
      .select('count');
      
    if (countError) {
      console.log('Error counting videos:', countError);
    } else {
      console.log(`Total videos in database: ${videoCount[0]?.count || 0}`);
    }
    
    // Get a sample of videos to verify metadata
    const { data: videos, error: videosError } = await supabase
      .from('videos')
      .select('id, title, videoUrl, storageSize, availableResolutions, encodeProgress, categoryId')
      .limit(5);
      
    if (videosError) {
      console.log('Error fetching videos:', videosError);
    } else {
      console.log('\nSample videos:');
      videos.forEach(video => {
        console.log(`- ID: ${video.id}, Title: ${video.title}`);
        console.log(`  Storage Size: ${video.storageSize || 'Not set'}`);
        console.log(`  Available Resolutions: ${video.availableResolutions || 'Not set'}`);
        console.log(`  Encode Progress: ${video.encodeProgress || 'Not set'}`);
        console.log(`  Category ID: ${video.categoryId}`);
        console.log('');
      });
    }
    
    // Check categories
    const { data: categories, error: categoriesError } = await supabase
      .from('categories')
      .select('id, name, thumbnailUrl');
      
    if (categoriesError) {
      console.log('Error fetching categories:', categoriesError);
    } else {
      console.log('\nCategories:');
      categories.forEach(category => {
        console.log(`- ID: ${category.id}, Name: ${category.name}`);
        console.log(`  Thumbnail: ${category.thumbnailUrl || 'Not set'}`);
      });
    }
    
  } catch (error) {
    console.log('Error checking videos:', error);
  }
}

// Run the check
checkVideos().catch(console.error);
