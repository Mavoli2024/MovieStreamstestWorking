#!/usr/bin/env node

/**
 * Core Flow Audit Script
 * Tests all critical user journeys to ensure production readiness
 */

import { createClient } from '@supabase/supabase-js';
import { config } from 'dotenv';

config();

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

console.log('🔍 MadifaStream Core Flow Audit\n');

const supabase = createClient(supabaseUrl, supabaseKey);

// Test results
const results = {
  passed: 0,
  failed: 0,
  tests: []
};

function logTest(name, status, details = '') {
  const icon = status ? '✅' : '❌';
  console.log(`${icon} ${name}${details ? ': ' + details : ''}`);
  
  results.tests.push({ name, status, details });
  if (status) results.passed++;
  else results.failed++;
}

// Database Tests
async function testDatabase() {
  console.log('\n📊 Database Tests');
  
  try {
    // Test profiles table
    const { data: profiles, error: profilesError } = await supabase
      .from('profiles')
      .select('*')
      .limit(1);
    
    logTest('Profiles table accessible', !profilesError, profilesError?.message);
    
    // Test videos table
    const { data: videos, error: videosError } = await supabase
      .from('videos')
      .select('*')
      .limit(1);
    
    logTest('Videos table accessible', !videosError, videosError?.message);
    
    // Test subscriptions table
    const { data: subscriptions, error: subscriptionsError } = await supabase
      .from('subscriptions')
      .select('*')
      .limit(1);
    
    logTest('Subscriptions table accessible', !subscriptionsError, subscriptionsError?.message);
    
    // Test subscription_plans table
    const { data: plans, error: plansError } = await supabase
      .from('subscription_plans')
      .select('*');
    
    logTest('Subscription plans exist', !plansError && plans?.length > 0, `Found ${plans?.length || 0} plans`);
    
  } catch (error) {
    logTest('Database connection', false, error.message);
  }
}

// Run all tests
async function runAudit() {
  await testDatabase();
  
  // Summary
  console.log('\n📋 Audit Summary');
  console.log(`✅ Passed: ${results.passed}`);
  console.log(`❌ Failed: ${results.failed}`);
  console.log(`📊 Total: ${results.tests.length}`);
  
  const successRate = (results.passed / results.tests.length * 100).toFixed(1);
  console.log(`🎯 Success Rate: ${successRate}%`);
  
  if (results.failed === 0) {
    console.log('\n🎉 All tests passed! Ready for production deployment.');
  } else {
    console.log('\n⚠️  Some tests failed. Please review and fix issues before deployment.');
  }
}

runAudit().catch(error => {
  console.error('Audit failed:', error);
  process.exit(1);
});