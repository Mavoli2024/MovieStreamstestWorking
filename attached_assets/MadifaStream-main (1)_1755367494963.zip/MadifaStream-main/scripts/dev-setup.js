#!/usr/bin/env node

/**
 * Development Setup & Health Check
 * 
 * Validates the development environment and provides helpful information
 * for getting started with MadifaStream development.
 */

import { existsSync, readFileSync } from 'fs';
import { exec } from 'child_process';
import { promisify } from 'util';
import path from 'path';

const execAsync = promisify(exec);

// Color codes for console output
const colors = {
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  reset: '\x1b[0m',
  bold: '\x1b[1m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

async function checkNodeVersion() {
  try {
    const { stdout } = await execAsync('node --version');
    const version = stdout.trim();
    const majorVersion = parseInt(version.slice(1).split('.')[0]);
    
    if (majorVersion >= 20) {
      log(`✅ Node.js version: ${version}`, 'green');
      return true;
    } else {
      log(`❌ Node.js version: ${version} (requires >= 20.x)`, 'red');
      return false;
    }
  } catch (error) {
    log(`❌ Node.js not found`, 'red');
    return false;
  }
}

async function checkNpmVersion() {
  try {
    const { stdout } = await execAsync('npm --version');
    const version = stdout.trim();
    log(`✅ npm version: ${version}`, 'green');
    return true;
  } catch (error) {
    log(`❌ npm not found`, 'red');
    return false;
  }
}

function checkEnvironmentFile() {
  const envExists = existsSync('.env');
  const envExampleExists = existsSync('.env.example');
  
  if (envExists) {
    log(`✅ Environment file (.env) exists`, 'green');
    return true;
  } else if (envExampleExists) {
    log(`⚠️  Environment file (.env) missing - copy from .env.example`, 'yellow');
    return false;
  } else {
    log(`❌ No environment files found`, 'red');
    return false;
  }
}

function checkPackageJson() {
  try {
    const packageJson = JSON.parse(readFileSync('package.json', 'utf8'));
    const hasDevDeps = packageJson.devDependencies;
    const hasConcurrently = hasDevDeps && hasDevDeps.concurrently;
    const hasTsx = hasDevDeps && hasDevDeps.tsx;
    
    if (hasConcurrently && hasTsx) {
      log(`✅ Development dependencies installed`, 'green');
      return true;
    } else {
      log(`⚠️  Some development dependencies missing`, 'yellow');
      return false;
    }
  } catch (error) {
    log(`❌ Cannot read package.json`, 'red');
    return false;
  }
}

async function checkNodeModules() {
  const nodeModulesExists = existsSync('node_modules');
  if (nodeModulesExists) {
    log(`✅ Dependencies installed (node_modules exists)`, 'green');
    return true;
  } else {
    log(`❌ Dependencies not installed - run npm install`, 'red');
    return false;
  }
}

function checkProjectStructure() {
  const requiredDirs = ['client', 'server', 'shared', 'scripts'];
  const requiredFiles = ['vite.config.ts', 'server/server.ts', 'client/vite.config.ts'];
  
  let allGood = true;
  
  for (const dir of requiredDirs) {
    if (existsSync(dir)) {
      log(`✅ Directory exists: ${dir}`, 'green');
    } else {
      log(`❌ Missing directory: ${dir}`, 'red');
      allGood = false;
    }
  }
  
  for (const file of requiredFiles) {
    if (existsSync(file)) {
      log(`✅ File exists: ${file}`, 'green');
    } else {
      log(`❌ Missing file: ${file}`, 'red');
      allGood = false;
    }
  }
  
  return allGood;
}

async function checkPorts() {
  const ports = [5001, 5173];
  const portStatus = [];
  
  for (const port of ports) {
    try {
      if (process.platform === 'win32') {
        const { stdout } = await execAsync(`netstat -ano | findstr :${port}`);
        if (stdout.trim()) {
          portStatus.push({ port, status: 'occupied' });
        } else {
          portStatus.push({ port, status: 'free' });
        }
      } else {
        const { stdout } = await execAsync(`lsof -ti:${port}`);
        if (stdout.trim()) {
          portStatus.push({ port, status: 'occupied' });
        } else {
          portStatus.push({ port, status: 'free' });
        }
      }
    } catch {
      portStatus.push({ port, status: 'free' });
    }
  }
  
  let allFree = true;
  for (const { port, status } of portStatus) {
    if (status === 'free') {
      log(`✅ Port ${port} is available`, 'green');
    } else {
      log(`⚠️  Port ${port} is occupied (will be cleaned on dev start)`, 'yellow');
      allFree = false;
    }
  }
  
  return allFree;
}

function printDevelopmentCommands() {
  log('\n📋 Available Development Commands:', 'bold');
  log('');
  
  const commands = [
    { cmd: 'npm run dev', desc: 'Start full development environment (frontend + backend)' },
    { cmd: 'npm run dev:clean', desc: 'Clean development ports only' },
    { cmd: 'npm run dev:fresh', desc: 'Clean ports and start fresh development environment' },
    { cmd: 'npm run dev:client-only', desc: 'Start frontend development server only' },
    { cmd: 'npm run dev:server-only', desc: 'Start backend development server only' },
    { cmd: 'npm run build', desc: 'Build both frontend and backend for production' },
    { cmd: 'npm run test:all', desc: 'Run all tests (unit, component, e2e)' },
    { cmd: 'npm run lint', desc: 'Run linting on all files' },
    { cmd: 'npm run typecheck', desc: 'Run TypeScript type checking' },
    { cmd: 'npm run db:studio', desc: 'Open Drizzle database studio' },
    { cmd: 'npm run clean:all', desc: 'Clean all caches, ports, and build files' }
  ];
  
  for (const { cmd, desc } of commands) {
    log(`  ${colors.cyan}${cmd.padEnd(25)}${colors.reset} ${desc}`);
  }
  
  log('');
  log('🔗 Quick Links:', 'bold');
  log(`  Frontend: ${colors.blue}http://localhost:5173${colors.reset}`);
  log(`  Backend:  ${colors.blue}http://localhost:5001${colors.reset}`);
  log(`  API Docs: ${colors.blue}http://localhost:5001/api${colors.reset}`);
}

function printNextSteps(issues) {
  if (issues.length === 0) {
    log('\n🎉 Development environment is ready!', 'green');
    log('Run `npm run dev` to start development.', 'green');
    return;
  }
  
  log('\n🔧 Next Steps to Fix Issues:', 'yellow');
  log('');
  
  const solutions = {
    node: 'Install Node.js 20+ from https://nodejs.org/',
    npm: 'Install npm (usually comes with Node.js)',
    env: 'Copy .env.example to .env and configure your environment variables',
    deps: 'Run `npm install` to install dependencies',
    structure: 'Ensure you are in the correct MadifaStream project directory'
  };
  
  let step = 1;
  for (const issue of issues) {
    if (solutions[issue]) {
      log(`  ${step}. ${solutions[issue]}`);
      step++;
    }
  }
  
  log('');
  log('📖 For detailed setup instructions, see:', 'cyan');
  log('  - README.md');
  log('  - DEVELOPER_GUIDE.md');
}

async function main() {
  log('🚀 MadifaStream Development Environment Check', 'bold');
  log('='.repeat(50), 'cyan');
  log('');
  
  const issues = [];
  
  // Check system requirements
  log('🔍 Checking System Requirements...', 'yellow');
  if (!(await checkNodeVersion())) issues.push('node');
  if (!(await checkNpmVersion())) issues.push('npm');
  
  log('');
  
  // Check project setup
  log('🔍 Checking Project Setup...', 'yellow');
  if (!checkEnvironmentFile()) issues.push('env');
  if (!checkProjectStructure()) issues.push('structure');
  if (!(await checkNodeModules())) issues.push('deps');
  if (!checkPackageJson()) issues.push('deps');
  
  log('');
  
  // Check development environment
  log('🔍 Checking Development Environment...', 'yellow');
  await checkPorts();
  
  log('');
  
  // Print commands and next steps
  printDevelopmentCommands();
  printNextSteps(issues);
  
  if (issues.length === 0) {
    log('\n✨ Ready to build amazing streaming experiences!', 'green');
  }
}

main().catch(error => {
  log(`❌ Setup check failed: ${error.message}`, 'red');
  process.exit(1);
}); 