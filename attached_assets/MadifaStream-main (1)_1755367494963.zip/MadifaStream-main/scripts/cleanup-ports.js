#!/usr/bin/env node

/**
 * Port Cleanup Script
 * 
 * Kills processes running on our dedicated development ports:
 * - 5001: Backend server
 * - 5173, 5174, 5175: Frontend Vite dev server (tries multiple ports)
 * - 5000: Alternative backend port
 * 
 * This ensures clean development starts every time.
 */

import killPort from 'kill-port';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

// Our dedicated development ports
const PORTS = [
  5001, // Primary backend server
  5000, // Alternative backend port
  5173, // Primary frontend port
  5174, // Secondary frontend port (when 5173 is busy)
  5175, // Tertiary frontend port (when 5174 is busy)
];

async function killPortWindows(port) {
  try {
    // Find process using the port
    const { stdout } = await execAsync(`netstat -ano | findstr :${port}`);
    const lines = stdout.trim().split('\n');
    
    for (const line of lines) {
      const parts = line.trim().split(/\s+/);
      const pid = parts[parts.length - 1];
      
      if (pid && pid !== '0') {
        // Kill the process
        await execAsync(`taskkill /F /PID ${pid}`);
        console.log(`✅ Killed process ${pid} on port ${port}`);
        return true;
      }
    }
    return false;
  } catch {
    return false;
  }
}

async function cleanupPorts() {
  console.log('🧹 Cleaning up development ports...');
  
  const results = await Promise.allSettled(
    PORTS.map(async (port) => {
      try {
        // Try kill-port first
        await killPort(port);
        console.log(`✅ Freed port ${port}`);
        return { port, status: 'freed' };
              } catch {
        // Try Windows-specific method as fallback
        if (process.platform === 'win32') {
          const killed = await killPortWindows(port);
          if (killed) {
            return { port, status: 'freed' };
          }
        }
        
        // Port was likely not in use, which is fine
        console.log(`ℹ️  Port ${port} was not in use`);
        return { port, status: 'not_in_use' };
      }
    })
  );

  const freed = results.filter(r => r.status === 'fulfilled' && r.value.status === 'freed').length;
  const notInUse = results.filter(r => r.status === 'fulfilled' && r.value.status === 'not_in_use').length;
  const failed = results.filter(r => r.status === 'rejected').length;

  console.log(`\n📊 Port cleanup summary:`);
  console.log(`   ✅ Freed: ${freed} ports`);
  console.log(`   ℹ️  Not in use: ${notInUse} ports`);
  if (failed > 0) {
    console.log(`   ❌ Failed: ${failed} ports`);
  }
  
  console.log('🚀 Ready to start development servers!\n');
  
  // Wait a moment for ports to be fully released
  await new Promise(resolve => setTimeout(resolve, 1000));
}

// Handle errors gracefully
process.on('unhandledRejection', (error) => {
  console.error('❌ Port cleanup failed:', error.message);
  process.exit(1);
});

// Run the cleanup
cleanupPorts().catch((error) => {
  console.error('❌ Port cleanup failed:', error.message);
  process.exit(1);
}); 