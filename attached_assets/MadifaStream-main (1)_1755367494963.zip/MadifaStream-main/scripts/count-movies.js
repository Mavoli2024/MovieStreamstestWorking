/**
 * Simple video Count Script
 */

import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

console.log('Connecting to Supabase...');
const supabase = createClient(supabaseUrl, supabaseKey);

async function countVideos() {
  // Use a simple query to count videos
  const { count, error } = await supabase
    .from('videos')
    .select('*', { count: 'exact', head: true });
    
  if (error) {
    console.log('Error counting videos:', error.message);
  } else {
    console.log(`Total videos in database: ${count}`);
  }
  
  // Get a few video titles
  const { data: videos } = await supabase
    .from('videos')
    .select('title')
    .limit(5);
    
  if (videos && videos.length > 0) {
    console.log('\nSample video titles:');
    videos.forEach((video, index) => {
      console.log(`${index + 1}. ${video.title}`);
    });
  } else {
    console.log('No videos found in database.');
  }
}

countVideos()
  .then(() => console.log('Done!'))
  .catch(err => console.log('Error:', err.message));
