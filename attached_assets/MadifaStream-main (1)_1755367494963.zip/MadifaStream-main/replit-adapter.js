#!/usr/bin/env node

/**
 * Replit Adapter - Minimal changes for Replit compatibility
 * This wrapper ensures the app works in Replit without breaking Vercel/local dev
 */

import { spawn } from 'child_process';
import { createServer } from 'http';
import { config } from 'dotenv';

// Load environment variables
config();

const isReplit = process.env.REPL_ID || process.env.REPLIT_DOMAINS;

if (isReplit) {
  console.log('🔧 Detected Replit environment, applying temporary adaptations...');
  
  // For Replit, we need to bind to 0.0.0.0 and use port 5000 as expected
  const server = createServer((req, res) => {
    res.writeHead(302, { Location: 'http://localhost:5173' });
    res.end();
  });
  
  server.listen(5000, '0.0.0.0', () => {
    console.log('✅ Replit adapter listening on port 5000 (redirecting to Vite)');
  });
}

// Start the normal dev server
console.log('🚀 Starting Vite development server...');
const vite = spawn('npx', ['vite', '--host', '0.0.0.0'], {
  stdio: 'inherit',
  shell: true,
  cwd: process.cwd()
});

vite.on('error', (err) => {
  console.error('❌ Vite error:', err);
  process.exit(1);
});

// Start backend in parallel
setTimeout(() => {
  console.log('🖥️  Starting backend server...');
  
  // First build the backend
  const build = spawn('npm', ['run', 'build:server'], {
    stdio: 'inherit',
    shell: true
  });
  
  build.on('close', (code) => {
    if (code === 0) {
      const backend = spawn('node', ['dist/server/server/server.js'], {
        stdio: 'inherit',
        shell: true,
        env: {
          ...process.env,
          PORT: '5001'
        }
      });
      
      backend.on('error', (err) => {
        console.error('❌ Backend error:', err);
      });
    }
  });
}, 2000);

process.on('SIGINT', () => {
  console.log('\n👋 Shutting down...');
  process.exit(0);
});