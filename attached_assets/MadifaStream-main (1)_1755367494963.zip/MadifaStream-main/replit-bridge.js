// Replit port bridge - runs on expected port 5000 and redirects to actual ports
const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');

const app = express();
const PORT = 5000;

console.log('🔗 Replit port bridge starting...');

// Health check for Replit
app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    bridge: 'running',
    frontend: 'http://localhost:5173',
    backend: 'http://localhost:5001'
  });
});

// Proxy frontend requests to Vite
app.use('/', createProxyMiddleware({
  target: 'http://localhost:5173',
  changeOrigin: true,
  ws: true,
  onError: (err, req, res) => {
    if (res.headersSent) return;
    res.status(502).json({
      error: 'Frontend server not ready',
      message: 'Vite development server is starting. Please refresh in a moment.',
      frontend_url: 'http://localhost:5173',
      backend_url: 'http://localhost:5001'
    });
  }
}));

app.listen(PORT, '0.0.0.0', () => {
  console.log(`✅ Replit bridge running on port ${PORT}`);
  console.log(`   Proxying to frontend: http://localhost:5173`);
});

// Keep process alive
process.on('SIGTERM', () => {
  console.log('Bridge shutting down...');
  process.exit(0);
});