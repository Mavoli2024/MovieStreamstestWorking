import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'co.za.madifa.app',
  appName: 'Madifa',
  webDir: 'dist/public',
  server: {
    androidScheme: 'https',
    cleartext: true
  },
  android: {
    backgroundColor: '#2D1B4E',
    buildOptions: {
      keystorePath: 'madifa.keystore',
      keystoreAlias: 'madifa',
    }
  },
  ios: {
    backgroundColor: '#2D1B4E',
    contentInset: 'automatic',
    preferredContentMode: 'mobile',
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      launchAutoHide: true,
      backgroundColor: '#2D1B4E',
      androidSplashResourceName: 'splash',
      androidScaleType: 'CENTER_CROP',
      showSpinner: true,
      spinnerColor: '#FF8400',
      splashFullScreen: true,
      splashImmersive: true
    }
  }
};

export default config;
