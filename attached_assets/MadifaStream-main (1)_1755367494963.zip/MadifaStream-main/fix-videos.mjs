import { logger } from "./server/utils/logger.js";
import { createClient } from '@supabase/supabase-js';
import 'dotenv/config';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
const supabaseAnonKey = process.env.SUPABASE_ANON_KEY;

const supabase = createClient(supabaseUrl, supabaseServiceKey);
const supabaseAnon = createClient(supabaseUrl, supabaseAnonKey);

async function fixVideoPremiumStatus() {
  logger.info('🔧 Making some full movies public for demo purposes...');
  
  // Get all videos
  const { data: allVideos, error: fetchError } = await supabase
    .from('videos')
    .select('id, title, is_premium, is_trailer');
    
  if (fetchError) {
    logger.error('❌ Error fetching videos:', fetchError);
    return;
  }
  
  // Get full movies that are currently premium
  const premiumMovies = allVideos.filter(video => 
    video.is_premium === true && 
    video.is_trailer === false && 
    !video.title.toLowerCase().includes('trailer')
  );
  
  logger.info(`📊 Found ${premiumMovies.length} premium full movies:`);
  premiumMovies.forEach(movie => logger.info(`- ${movie.title}`));
  
  // Make 2 movies public for demo
  const moviesToMakePublic = premiumMovies.slice(0, 2);
  
  if (moviesToMakePublic.length > 0) {
    logger.info(`\n🔓 Making these movies public:`);
    moviesToMakePublic.forEach(movie => logger.info(`- ${movie.title}`));
    
    const { data: updatedVideos, error: updateError } = await supabase
      .from('videos')
      .update({ is_premium: false })
      .in('id', moviesToMakePublic.map(v => v.id))
      .select('id, title, is_premium');
      
    if (updateError) {
      logger.error('❌ Error updating videos:', updateError);
    } else {
      logger.info(`\n✅ Successfully updated ${updatedVideos.length} movies to be public`);
    }
  }
  
  // Now test if the API can see videos
  logger.info('\n🧪 Testing API access after changes...');
  
  const { data: publicVideos, error: testError } = await supabaseAnon
    .from('videos')
    .select('id, title, is_premium, is_trailer')
    .eq('status', 'published')
    .limit(10);
    
  if (testError) {
    logger.error('❌ API Test Error:', testError);
  } else {
    logger.info(`✅ API Test Success: Found ${publicVideos.length} accessible videos`);
    publicVideos.forEach(video => {
      logger.info(`- ${video.title} (Premium: ${video.is_premium})`);
    });
  }
}

fixVideoPremiumStatus(); 