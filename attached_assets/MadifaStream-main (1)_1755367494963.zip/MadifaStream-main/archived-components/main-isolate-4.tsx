import React from 'react';
import ReactDOM from 'react-dom/client';
import type {  HelmetProvider  } from 'react-helmet-async';

// Test component
function TestComponent() {
  return (
    <HelmetProvider>
      <div>
        <h1>Helmet Provider Test</h1>
        <p>Testing react-helmet-async provider</p>
        <p>Current time: {new Date().toISOString()}</p>
      </div>
    </HelmetProvider>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root')!);
root.render(
  <React.StrictMode>
    <TestComponent />
  </React.StrictMode>
); 