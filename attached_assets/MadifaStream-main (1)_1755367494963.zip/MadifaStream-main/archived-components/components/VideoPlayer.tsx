import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useWatchProgress } from '@/hooks/use-watch-progress.tsx';
import { api } from '@/lib/env';
import { cn } from '@/lib/utils';
import { logger } from '@shared/logger';
import { TIMEOUTS } from '@/constants/app-constants';

// Import only essential icons to reduce bundle size
import {
  Play, Pause, Volume2, VolumeX, Maximize, Settings,
  Loader2, AlertCircle, AlertTriangle, SkipBack, SkipForward
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { StarRating } from '@/components/rating/StarRating';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { CastManager } from './CastManager';

interface StreamingProfile {
  quality: string;
  bitrate: number;
  url: string;
  isDefault: boolean;
}

interface SubtitleTrack {
  language: string;
  label: string;
  src: string;
  isDefault: boolean;
}

interface NextUpVideo {
  id: string;
  title: string;
  thumbnail_url: string;
}

interface VideoPlayerProps {
  videoId: string;
  videoUrl?: string;
  title: string;
  onRatingChange?: (rating: number) => void;
  currentRating?: number;
  className?: string;
  poster?: string;
  streamingProfiles?: StreamingProfile[];
  subtitleTracks?: SubtitleTrack[];
  nextUp?: NextUpVideo;
  onComplete?: () => void;
  onSubscriptionError?: () => void;
  onError?: (message: string) => void;
  autoplay?: boolean;
  startTime?: number;
  variant?: 'default' | 'mobile' | 'cast' | 'preview';
}

type PlayerState = 'loading' | 'ready' | 'error' | 'invalid' | 'unauthorized';

/**
 * VideoPlayer - Modern, responsive video player with perfect control layout
 * Completely redesigned for optimal UX on all screen sizes
 */
export function VideoPlayer({
  videoId,
  videoUrl,
  title,
  onRatingChange,
  currentRating = 0,
  className,
  poster,
  streamingProfiles,
  subtitleTracks,
  nextUp,
  onComplete,
  onSubscriptionError,
  onError,
  autoplay = false,
  startTime = 0,
  variant = 'default'
}: VideoPlayerProps) {
  // Refs for DOM elements
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const progressBarRef = useRef<HTMLDivElement>(null);

  // Core state
  const [playerState, setPlayerState] = useState<PlayerState>('loading');
  const [streamUrl, setStreamUrl] = useState<string>('');
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [buffered, setBuffered] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(startTime);
  const [hasRestored, setHasRestored] = useState(false);
  const [isCasting, setIsCasting] = useState(false);
  
  // Mobile touch state
  const [touchStartX, setTouchStartX] = useState(0);
  const [lastTap, setLastTap] = useState(0);

  // Computed values
  const isSubscriptionError = useMemo(() => error === 'subscription_required', [error]);
  const canPlay = useMemo(() => playerState === 'ready' && streamUrl, [playerState, streamUrl]);
  const progressPercentage = duration > 0 ? Math.round((currentTime / duration) * 100) : 0;
  const isMobile = variant === 'mobile' || window.innerWidth < 768;

  // Progress saving
  const saveProgress = useCallback(async (time: number, completed: boolean = false) => {
    try {
      await fetch('/api/watch-progress', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({
          videoId,
          currentTime: time,
          duration,
          completed
        })
      });
    } catch (err) {
      // Silent fail for progress saving
    }
  }, [videoId, duration]);

  // Video controls
  const togglePlayPause = useCallback(async () => {
    if (!videoRef.current || !canPlay) return;
    
    try {
      if (isPlaying) {
        await videoRef.current.pause();
      } else {
        await videoRef.current.play();
      }
    } catch (err) {
      setError('Failed to control video playback');
    }
  }, [isPlaying, canPlay]);

  const handleSeek = useCallback((time: number) => {
    if (!videoRef.current || !canPlay) return;
    
    const clampedTime = Math.max(0, Math.min(time, duration));
    videoRef.current.currentTime = clampedTime;
    setCurrentTime(clampedTime);
  }, [duration, canPlay]);

  const handleVolumeChange = useCallback((newVolume: number) => {
    if (!videoRef.current) return;
    
    const clampedVolume = Math.max(0, Math.min(1, newVolume));
    videoRef.current.volume = clampedVolume;
    setVolume(clampedVolume);
    setIsMuted(clampedVolume === 0);
  }, []);

  const handleMuteToggle = useCallback(() => {
    if (!videoRef.current) return;
    
    const newMuted = !isMuted;
    videoRef.current.muted = newMuted;
    setIsMuted(newMuted);
  }, [isMuted]);

  const handleFullscreen = useCallback(async () => {
    if (!containerRef.current) return;
    
    try {
      if (isFullscreen) {
        await document.exitFullscreen();
      } else {
        await containerRef.current.requestFullscreen();
      }
    } catch (err) {
      // Fullscreen not supported or failed
    }
  }, [isFullscreen]);

  // Format time display
  const formatTime = useCallback((seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  }, []);

  // Video event handlers
  const handleLoadedMetadata = useCallback(() => {
    if (!videoRef.current) return;
    
    setDuration(videoRef.current.duration);
    setIsLoading(false);
    
    if (progress > 0 && !hasRestored) {
      videoRef.current.currentTime = progress;
      setCurrentTime(progress);
      setHasRestored(true);
    }
  }, [progress, hasRestored]);

  const handleTimeUpdate = useCallback(() => {
    if (!videoRef.current) return;
    
    const newTime = videoRef.current.currentTime;
    setCurrentTime(newTime);
    
    if (videoRef.current.buffered.length > 0) {
      const bufferedEnd = videoRef.current.buffered.end(videoRef.current.buffered.length - 1);
      setBuffered((bufferedEnd / duration) * 100);
    }
    
    if (newTime > 5) {
      saveProgress(newTime, false);
    }
  }, [duration, saveProgress]);

  const handlePlay = useCallback(() => setIsPlaying(true), []);
  const handlePause = useCallback(() => setIsPlaying(false), []);

  const handleEnded = useCallback(() => {
    setIsPlaying(false);
    saveProgress(duration, true);
    onComplete?.();
  }, [duration, saveProgress, onComplete]);

  const handleError = useCallback(() => {
    setError('Failed to load video');
    setPlayerState('error');
    onError?.('Failed to load video');
  }, [onError]);

  // Controls visibility
  const showControlsTemporarily = useCallback(() => {
    setShowControls(true);
    
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
  }, [isPlaying]);

  const handleMouseMove = useCallback(() => {
    if (!isMobile) {
      showControlsTemporarily();
    }
  }, [showControlsTemporarily, isMobile]);

  // Touch handlers for mobile
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    setTouchStartX(e.touches[0].clientX);
  }, []);

  const handleTouchEnd = useCallback((e: React.TouchEvent) => {
    const deltaX = e.changedTouches[0].clientX - touchStartX;
    const now = Date.now();
    
    if (now - lastTap < 300) {
      // Double tap to play/pause
      togglePlayPause();
    } else {
      // Single tap to show/hide controls
      setShowControls(!showControls);
    }
    setLastTap(now);
    
    // Swipe to seek
    if (Math.abs(deltaX) > 50) {
      const seekAmount = deltaX > 0 ? 10 : -10;
      handleSeek(currentTime + seekAmount);
    }
  }, [touchStartX, lastTap, togglePlayPause, showControls, currentTime, handleSeek]);

  // Keyboard controls
  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (!videoRef.current) return;
    
    switch (e.key) {
      case ' ':
      case 'k':
        e.preventDefault();
        togglePlayPause();
        break;
      case 'ArrowLeft':
        e.preventDefault();
        handleSeek(currentTime - 10);
        break;
      case 'ArrowRight':
        e.preventDefault();
        handleSeek(currentTime + 10);
        break;
      case 'm':
        e.preventDefault();
        handleMuteToggle();
        break;
      case 'f':
        e.preventDefault();
        handleFullscreen();
        break;
    }
  }, [currentTime, togglePlayPause, handleSeek, handleMuteToggle, handleFullscreen]);

  // Initialize player
  useEffect(() => {
    const initializePlayer = async () => {
      try {
        setPlayerState('loading');
        
        if (videoUrl) {
          setStreamUrl(videoUrl);
          setPlayerState('ready');
          return;
        }
        
        try {
          const videoResponse = await fetch(`/api/videos/public`);
          if (!videoResponse.ok) {
            throw new Error('Failed to fetch video list');
          }
          
          const videos = await videoResponse.json();
          const video = videos.find((v: any) => v.id === videoId);
          
          if (video?.video_url) {
            setStreamUrl(video.video_url);
            setPlayerState('ready');
            return;
          }
          
          throw new Error('Video not found or no stream URL available');
        } catch (fetchError) {
          try {
            const { createClient } = await import('@supabase/supabase-js');
            const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
            const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
            
            if (!supabaseUrl || !supabaseKey) {
              throw new Error('Supabase configuration missing');
            }
            
            const supabase = createClient(supabaseUrl, supabaseKey);
            const { data: video, error: supabaseError } = await supabase
              .from('videos')
              .select('video_url, is_premium, is_trailer')
              .eq('id', videoId)
              .single();
            
            if (supabaseError) {
              if (supabaseError.code === 'PGRST116') {
                throw new Error('Video not found');
              }
              throw new Error(`Database error: ${supabaseError.message}`);
            }
            
            if (!video?.video_url) {
              throw new Error('No video stream available');
            }
            
            if (video.is_premium && !video.is_trailer) {
              setError('subscription_required');
              setPlayerState('unauthorized');
              onSubscriptionError?.();
              return;
            }
            
            setStreamUrl(video.video_url);
            setPlayerState('ready');
          } catch (supabaseError) {
            throw new Error(`Failed to load video: ${supabaseError instanceof Error ? supabaseError.message : 'Unknown error'}`);
          }
        }
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : 'Failed to load video';
        setError(errorMessage);
        setPlayerState('error');
        onError?.(errorMessage);
        
        if (import.meta.env.DEV) {
          logger.error('Video player initialization error:', err);
        }
      }
    };

    if (videoId) {
      initializePlayer();
    }
  }, [videoId, videoUrl, onSubscriptionError, onError]);

  // Fullscreen change listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // Autoplay
  useEffect(() => {
    if (autoplay && canPlay && videoRef.current) {
      videoRef.current.play().catch(() => {
        // Auto-play failed, which is normal
      });
    }
  }, [autoplay, canPlay]);

  // Error state render
  const renderErrorState = () => {
    const getErrorIcon = () => {
      switch (playerState) {
        case 'unauthorized':
          return <AlertTriangle className="w-12 h-12 text-yellow-500" />;
        case 'error':
          return <AlertCircle className="w-12 h-12 text-red-500" />;
        default:
          return <AlertCircle className="w-12 h-12 text-gray-500" />;
      }
    };

    const getErrorTitle = () => {
      switch (playerState) {
        case 'unauthorized':
          return 'Subscription Required';
        case 'error':
          return 'Playback Error';
        default:
          return 'Loading Video';
      }
    };

    const getErrorMessage = () => {
      switch (playerState) {
        case 'unauthorized':
          return 'This content requires an active subscription to watch.';
        case 'error':
          return error || 'Unable to load video. Please try again.';
        default:
          return 'Preparing your video experience...';
      }
    };

    return (
      <div className="flex flex-col items-center justify-center h-full bg-black text-white p-8 text-center">
        {getErrorIcon()}
        <h3 className="text-xl font-semibold mt-4 mb-2">{getErrorTitle()}</h3>
        <p className="text-gray-300 mb-6 max-w-md">{getErrorMessage()}</p>
        
        {playerState === 'unauthorized' && (
          <Button
            onClick={() => onSubscriptionError?.()}
            className="bg-primary hover:bg-primary/90"
          >
            Get Subscription
          </Button>
        )}
        
        {playerState === 'error' && (
          <Button
            onClick={() => window.location.reload()}
            variant="outline"
            className="border-gray-600 text-white hover:bg-gray-800"
          >
            Retry
          </Button>
        )}
      </div>
    );
  };

  // Early return for non-ready states
  if (playerState !== 'ready' || !streamUrl) {
    return (
      <div className={cn('relative bg-black rounded-lg overflow-hidden aspect-video', className)}>
        {renderErrorState()}
      </div>
    );
  }

  return (
    <div 
      ref={containerRef}
      className={cn(
        'relative bg-black rounded-lg overflow-hidden group focus-within:ring-2 focus-within:ring-blue-500',
        'aspect-video w-full', // Force proper aspect ratio
        className
      )}
      role="application"
      aria-label={`Video player for ${title}`}
      onMouseMove={handleMouseMove}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onKeyDown={handleKeyDown}
      tabIndex={0}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        poster={poster}
        preload="metadata"
        playsInline
        crossOrigin="anonymous"
        onLoadedMetadata={handleLoadedMetadata}
        onTimeUpdate={handleTimeUpdate}
        onPlay={handlePlay}
        onPause={handlePause}
        onEnded={handleEnded}
        onVolumeChange={() => {
          if (videoRef.current) {
            setVolume(videoRef.current.volume);
            setIsMuted(videoRef.current.muted);
          }
        }}
        onError={handleError}
      >
        {streamUrl && <source src={streamUrl} type="application/x-mpegURL" />}
        
        {subtitleTracks?.map((track) => (
          <track
            key={track.language}
            kind="subtitles"
            src={track.src}
            srcLang={track.language}
            label={track.label}
            default={track.isDefault}
          />
        ))}
      </video>

      {/* Loading Overlay */}
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
        </div>
      )}

      {/* Controls Overlay - Modern Layout */}
      {(showControls || !isPlaying) && (
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/40">
          
          {/* Top Bar - Title and Cast */}
          <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between">
            <h3 className="text-white font-semibold text-lg truncate max-w-md">
              {title}
            </h3>
            <div className="flex items-center space-x-2">
              <CastManager
                videoUrl={streamUrl}
                videoTitle={title}
                videoPoster={poster}
                onCastStart={() => setIsCasting(true)}
                onCastEnd={() => setIsCasting(false)}
              />
            </div>
          </div>

          {/* Center Play Button - Large and Prominent */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <Button
              variant="ghost"
              size="lg"
              onClick={togglePlayPause}
              className="text-white hover:bg-white/20 w-20 h-20 rounded-full pointer-events-auto
                         bg-black/30 backdrop-blur-sm border border-white/20
                         transition-all duration-200 hover:scale-110"
              aria-label={isPlaying ? 'Pause video' : 'Play video'}
            >
              {isPlaying ? (
                <Pause className="w-10 h-10" />
              ) : (
                <Play className="w-10 h-10 ml-1" />
              )}
            </Button>
          </div>

          {/* Bottom Controls Bar - Separated Properly */}
          <div className="absolute bottom-0 left-0 right-0 p-4 space-y-3">
            
            {/* Progress Bar - Separate Row */}
            <div className="space-y-1">
              <div
                ref={progressBarRef}
                className="relative h-1.5 bg-white/20 rounded-full cursor-pointer group hover:h-2 transition-all"
                onClick={(e) => {
                  if (!progressBarRef.current) return;
                  const rect = progressBarRef.current.getBoundingClientRect();
                  const percentage = (e.clientX - rect.left) / rect.width;
                  handleSeek(percentage * duration);
                }}
                role="slider"
                aria-label="Video progress"
                aria-valuemin={0}
                aria-valuemax={duration}
                aria-valuenow={currentTime}
                tabIndex={0}
              >
                {/* Buffered Progress */}
                <div
                  className="absolute left-0 top-0 h-full bg-white/30 rounded-full"
                  style={{ width: `${buffered}%` }}
                />
                
                {/* Current Progress */}
                <div
                  className="absolute left-0 top-0 h-full bg-red-500 rounded-full"
                  style={{ width: `${progressPercentage}%` }}
                />
                
                {/* Progress Thumb */}
                <div
                  className="absolute top-1/2 transform -translate-y-1/2 w-4 h-4 bg-red-500 rounded-full 
                             opacity-0 group-hover:opacity-100 transition-opacity shadow-lg"
                  style={{ left: `calc(${progressPercentage}% - 8px)` }}
                />
              </div>
              
              {/* Time Display */}
              <div className="flex justify-between text-sm text-white">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* Control Buttons Row */}
            <div className="flex items-center justify-between">
              
              {/* Left Controls */}
              <div className="flex items-center space-x-2">
                {/* Skip Backward */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSeek(currentTime - 10)}
                  className="text-white hover:bg-white/20 p-2"
                  aria-label="Skip backward 10 seconds"
                >
                  <SkipBack className="w-5 h-5" />
                </Button>
                
                {/* Skip Forward */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleSeek(currentTime + 10)}
                  className="text-white hover:bg-white/20 p-2"
                  aria-label="Skip forward 10 seconds"
                >
                  <SkipForward className="w-5 h-5" />
                </Button>

                {/* Volume Controls - Desktop Only */}
                {!isMobile && (
                  <div className="flex items-center space-x-2 ml-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleMuteToggle}
                      className="text-white hover:bg-white/20 p-2"
                      aria-label={isMuted ? 'Unmute' : 'Mute'}
                    >
                      {isMuted ? (
                        <VolumeX className="w-5 h-5" />
                      ) : (
                        <Volume2 className="w-5 h-5" />
                      )}
                    </Button>
                    
                    <div className="w-20">
                      <Slider
                        value={[isMuted ? 0 : volume * 100]}
                        onValueChange={([value]) => handleVolumeChange(value / 100)}
                        max={100}
                        step={1}
                        className="cursor-pointer"
                        aria-label="Volume"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Right Controls */}
              <div className="flex items-center space-x-2">
                {/* Fullscreen */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleFullscreen}
                  className="text-white hover:bg-white/20 p-2"
                  aria-label={isFullscreen ? "Exit fullscreen" : "Enter fullscreen"}
                >
                  <Maximize className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Rating - Bottom Right Corner */}
      {onRatingChange && !isPlaying && (
        <div className="absolute bottom-4 right-4">
          <div className="bg-black/80 backdrop-blur-sm rounded-lg p-3 border border-white/20">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-white">Rate:</span>
              <StarRating
                rating={currentRating}
                onRatingChange={onRatingChange}
                size="sm"
              />
            </div>
          </div>
        </div>
      )}

      {/* Next Up Card */}
      {nextUp && !isPlaying && (
        <div className="absolute bottom-4 left-4 max-w-sm">
          <Card className="bg-black/80 backdrop-blur-sm text-white border-white/20">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <img
                  src={nextUp.thumbnail_url}
                  alt={nextUp.title}
                  className="w-16 h-12 object-cover rounded"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-gray-300 mb-1">Next up</p>
                  <p className="text-sm font-medium truncate">{nextUp.title}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
} 