import React, { useMemo, useCallback, useRef, useEffect } from 'react';
import { FixedSizeGrid as Grid } from 'react-window';
import { cn } from '@/lib/utils';
import { UnifiedVideoCard } from './unified-video-card';
import { usePerformanceMonitor } from '@/hooks/use-performance-monitor';
import type { Video } from '@/lib/supabase-api';

interface VirtualizedVideoGridProps {
  videos: Video[];
  columns?: number;
  itemHeight?: number;
  itemWidth?: number;
  className?: string;
  gap?: number;
  enablePerformanceMonitoring?: boolean;
  onVideoClick?: (video: Video) => void;
  onVideoInfo?: (video: Video) => void;
}

interface GridItemProps {
  columnIndex: number;
  rowIndex: number;
  style: React.CSSProperties;
  data: {
    videos: Video[];
    columns: number;
    gap: number;
    onVideoClick?: (video: Video) => void;
    onVideoInfo?: (video: Video) => void;
  };
}

const GridItem: React.FC<GridItemProps> = ({ columnIndex, rowIndex, style, data }) => {
  const { videos, columns, gap, onVideoClick, onVideoInfo } = data;
  const index = rowIndex * columns + columnIndex;
  const video = videos[index];

  if (!video) return null;

  return (
    <div
      style={{
        ...style,
        left: `${parseFloat(style.left as string) + gap / 2}px`,
        top: `${parseFloat(style.top as string) + gap / 2}px`,
        width: `${parseFloat(style.width as string) - gap}px`,
        height: `${parseFloat(style.height as string) - gap}px`,
      }}
    >
      <UnifiedVideoCard
        video={video}
        variant="grid"
        onPlay={() => onVideoClick?.(video)}
        onInfo={() => onVideoInfo?.(video)}
        className="h-full"
      />
    </div>
  );
};

export const VirtualizedVideoGrid: React.FC<VirtualizedVideoGridProps> = ({
  videos,
  columns = 4,
  itemHeight = 300,
  itemWidth = 280,
  className,
  gap = 16,
  enablePerformanceMonitoring = true,
  onVideoClick,
  onVideoInfo,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  const {
    metrics,
    measureComponentRender,
    isPerformanceMode,
  } = usePerformanceMonitor({
    enableVirtualScrolling: true,
    itemHeight,
    containerHeight: 600,
  });

  // Performance optimization: reduce columns in performance mode
  const adaptiveColumns = useMemo(() => {
    if (isPerformanceMode && columns > 2) {
      return Math.max(2, Math.floor(columns * 0.75));
    }
    return columns;
  }, [columns, isPerformanceMode]);

  // Calculate grid dimensions
  const { rowCount, containerWidth, containerHeight } = useMemo(() => {
    const rowCount = Math.ceil(videos.length / adaptiveColumns);
    const containerWidth = adaptiveColumns * itemWidth + (adaptiveColumns - 1) * gap;
    const containerHeight = Math.min(600, rowCount * itemHeight); // Max height of 600px
    
    return { rowCount, containerWidth, containerHeight };
  }, [videos.length, adaptiveColumns, itemWidth, itemHeight, gap]);

  // Grid data for react-window
  const gridData = useMemo(
    () => ({
      videos,
      columns: adaptiveColumns,
      gap,
      onVideoClick,
      onVideoInfo,
    }),
    [videos, adaptiveColumns, gap, onVideoClick, onVideoInfo]
  );

  // Measure render performance
  const endMeasure = measureComponentRender('VirtualizedVideoGrid');
  
  useEffect(() => {
    return endMeasure;
  }, [endMeasure]);

  const handleScroll = useCallback(({ scrollTop }: { scrollTop: number }) => {
    // Optional: Add scroll-based optimizations here
    if (enablePerformanceMonitoring && scrollTop > 0) {
      // Could implement additional performance tracking
    }
  }, [enablePerformanceMonitoring]);

  if (videos.length === 0) {
    return (
      <div className={cn("flex items-center justify-center py-12", className)}>
        <p className="text-gray-400 text-lg">No videos available</p>
      </div>
    );
  }

  return (
    <div 
      ref={containerRef}
      className={cn("relative", className)}
      style={{ width: containerWidth, height: containerHeight }}
    >
      {enablePerformanceMonitoring && import.meta.env.DEV && (
        <div className="absolute top-0 right-0 z-10 bg-black/50 text-white text-xs p-2 rounded-bl">
          FPS: {metrics.fps} | Memory: {metrics.memory}MB | Items: {videos.length}
          {isPerformanceMode && <span className="text-yellow-400"> [PERF MODE]</span>}
        </div>
      )}
      
      <Grid
        columnCount={adaptiveColumns}
        columnWidth={itemWidth}
        height={containerHeight}
        rowCount={rowCount}
        rowHeight={itemHeight}
        width={containerWidth}
        itemData={gridData}
        onScroll={handleScroll}
        overscanRowCount={1}
        overscanColumnCount={1}
      >
        {GridItem}
      </Grid>
    </div>
  );
};

// Higher-order component for automatic virtualization
export const AutoVirtualizedVideoGrid: React.FC<VirtualizedVideoGridProps> = (props) => {
  const { videos } = props;
  
  // Auto-enable virtualization for large lists
  const shouldVirtualize = videos.length > 20;
  
  if (!shouldVirtualize) {
    // For small lists, use regular grid for better UX
    return (
      <div className={cn("grid gap-4", props.className)} 
           style={{ 
             gridTemplateColumns: `repeat(${props.columns || 4}, 1fr)` 
           }}>
        {videos.map((video) => (
          <UnifiedVideoCard
            key={video.id}
            video={video}
            variant="grid"
            onPlay={() => props.onVideoClick?.(video)}
            onInfo={() => props.onVideoInfo?.(video)}
          />
        ))}
      </div>
    );
  }
  
  return <VirtualizedVideoGrid {...props} />;
}; 