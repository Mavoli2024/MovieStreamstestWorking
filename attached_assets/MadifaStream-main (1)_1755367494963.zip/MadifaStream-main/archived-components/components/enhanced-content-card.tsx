/**
 * Enhanced Content Card Component
 * 
 * Advanced video card with:
 * - Premium access indication
 * - Trailer/Full movie differentiation
 * - Custom thumbnail handling
 * - Quality indicators
 * - Progress tracking
 */

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '@/hooks/use-auth';
import { useSubscription } from '@/hooks/use-subscription';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import EnhancedVideoService, {
    type EnhancedVideoMetadata
} from '@/services/enhanced-video-service';
import {
    Check,
    ChevronRight,
    Crown,
    Eye,
    Play,
    Plus,
    Zap
} from 'lucide-react';
import React, { useState } from 'react';

interface EnhancedContentCardProps {
  video: EnhancedVideoMetadata;
  variant?: 'grid' | 'list' | 'hero';
  showProgress?: boolean;
  progress?: number; // 0-100
  watchProgress?: number; // alias for progress used by other components
  isInWatchlist?: boolean;
  onAddToWatchlist?: (videoId: string) => void;
  onRemoveFromWatchlist?: (videoId: string) => void;
  onPlay?: (videoId: string, playTrailer?: boolean) => void;
  className?: string;
}

export function EnhancedContentCard({
  video,
  variant = 'grid',
  showProgress = true,
  progress = 0,
  watchProgress,
  isInWatchlist = false,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onPlay,
  className
}: EnhancedContentCardProps) {
  const { user, _profile } = useAuth();
  const { hasPremiumAccess, canWatchFullContent } = useSubscription();
  const { toast } = useToast();
  const [_isHovered, _setIsHovered] = useState(false);
  const [thumbnailError, setThumbnailError] = useState(false);
  const [_retryCount, _setRetryCount] = useState(0);

  // PRODUCTION: Zero-tolerance thumbnail system - try multiple Bunny formats
  const getProductionThumbnailUrl = (): string => {
    const width = variant === 'hero' ? 1280 : variant === 'list' ? 320 : 480;
    const height = variant === 'hero' ? 720 : variant === 'list' ? 180 : 270;
    
    // Priority 1: Database URL (corrected thumbnails from Bunny API)
    if (video.thumbnail_url && !thumbnailError && 
        video.thumbnail_url.startsWith('http') && 
        !video.thumbnail_url.includes('undefined') &&
        !video.thumbnail_url.includes('localhost')) {
      return video.thumbnail_url;
    }
    
    // Priority 2: Bunny CDN alternatives (only if database URL failed)
    if (video.id) {
      return `/api/videos/${video.id}/thumbnail`;
    }
    
    return EnhancedVideoService.getThumbnailUrl(video);
  };

  const finalThumbnailUrl = getProductionThumbnailUrl();

  const handlePlay = (e?: React.MouseEvent) => {
    e?.stopPropagation(); // Prevent card's parent Link navigation
    if (!onPlay) return;

    if (canWatchFullContent) {
      onPlay(video.id, false);
      return;
    }
    
    // Show premium prompt BEFORE attempting to navigate / fetch trailer
    toast({
      title: "Premium Content",
      description: "This content requires a premium subscription. Upgrade to watch the full version. Trailers are always free.",
      action: (
        <Button variant="outline" size="sm" onClick={() => window.location.href = '/subscription'}>
          Upgrade
        </Button>
      ),
    });

    // Optional: if you *do* want trailer autoplay after the prompt, keep this line.
    // Otherwise, remove it to block any playback until subscribed.
    // onPlay(video.id, true);
  };

  const handleWatchlistToggle = () => {
    if (!user) {
      toast({
        title: "Sign In Required",
        description: "Please sign in to add videos to your watchlist.",
        variant: "destructive"
      });
      return;
    }

    if (isInWatchlist) {
      onRemoveFromWatchlist?.(video.id);
    } else {
      onAddToWatchlist?.(video.id);
    }
  };

  // IMPROVED: Professional time formatting (1:00:00 format)
  const formatDuration = (seconds: number | null): string => {
    if (!seconds) return '0:00';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getQualityBadge = () => {
    if (video.source_height) {
      if (video.source_height >= 2160) return '4K';
      if (video.source_height >= 1080) return '1080p';
      if (video.source_height >= 720) return '720p';
    }
    return 'HD';
  };

  // Hero variant
  if (variant === 'hero') {
    return (
      <div className={cn("relative h-96 lg:h-[500px] rounded-lg overflow-hidden", className)}>
        <img
          src={finalThumbnailUrl}
          alt={video.title}
          className="w-full h-full object-cover transition-opacity duration-300"
          onError={(e) => {
            if (import.meta.env.DEV) {
              console.warn(`Hero thumbnail failed for "${video.title}", trying fallback`);
            }
            setThumbnailError(true);
            // Try direct database URL first
            if (video.thumbnail_url && e.currentTarget.src !== video.thumbnail_url) {
              e.currentTarget.src = video.thumbnail_url;
              return;
            }
            // Generate placeholder
            const initials = video.title.split(' ').map(word => word[0]).join('').substring(0, 2).toUpperCase();
            const hue = Math.abs(video.title.split('').reduce((a, b) => a + b.charCodeAt(0), 0)) % 360;
            e.currentTarget.src = `data:image/svg+xml,${encodeURIComponent(`
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720">
                <defs><linearGradient id="g1" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style="stop-color:hsl(${hue}, 60%, 50%)" />
                  <stop offset="100%" style="stop-color:hsl(${hue}, 60%, 35%)" />
                </linearGradient></defs>
                <rect width="100%" height="100%" fill="url(#g1)"/>
                <text x="50%" y="45%" text-anchor="middle" fill="white" font-size="120" font-weight="bold">${initials}</text>
                <text x="50%" y="65%" text-anchor="middle" fill="rgba(255,255,255,0.8)" font-size="48">${video.title.length > 20 ? video.title.substring(0, 17) + '...' : video.title}</text>
              </svg>
            `)}`;
          }}
          onLoad={() => {
            setThumbnailError(false);
            _setRetryCount(0);
          }}
        />
        
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
        
        <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
          <div className="max-w-2xl">
            <div className="flex items-center gap-2 mb-3">
              {video.content_category === 'trailer' && (
                <Badge variant="secondary" className="bg-blue-600 text-white">
                  <Zap className="w-3 h-3 mr-1" />
                  Trailer
                </Badge>
              )}
              {video.is_premium && (
                <Badge variant="secondary" className="bg-gradient-to-r from-amber-500 to-orange-600 text-white">
                  <Crown className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              )}
              {getQualityBadge() && (
                <Badge variant="outline" className="border-white/40 text-white">
                  {getQualityBadge()}
                </Badge>
              )}
            </div>
            
            <h1 className="text-3xl lg:text-4xl font-bold text-white mb-3">{video.title}</h1>
            
            <p className="text-gray-200 text-base lg:text-lg mb-4 line-clamp-2">
              {video.description || "No description available"}
            </p>
            
            <div className="flex items-center gap-4 text-sm text-gray-300 mb-6">
              {video.release_year && <span className="font-medium">{video.release_year}</span>}
              {video.duration && <span className="font-medium">{formatDuration(video.duration)}</span>}
              {video.age_rating && <span className="px-2 py-1 bg-white/20 rounded text-xs">{video.age_rating}</span>}
              {video.views && (
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  {video.views.toLocaleString()} views
                </span>
              )}
            </div>
            
            <div className="flex items-center gap-3">
              <Button 
                size="lg" 
                onClick={(e) => handlePlay(e)}
                className="bg-white text-black hover:bg-gray-200 font-semibold px-6"
              >
                <Play className="w-5 h-5 mr-2" />
                {canWatchFullContent ? 'Play' : 'Watch Trailer'}
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                onClick={handleWatchlistToggle}
                className="border-white/30 text-white hover:bg-white/10 font-semibold px-6"
              >
                {isInWatchlist ? (
                  <>
                    <Check className="w-5 h-5 mr-2" />
                    In Watchlist
                  </>
                ) : (
                  <>
                    <Plus className="w-5 h-5 mr-2" />
                    Add to Watchlist
                  </>
                )}
              </Button>
              
              {/* FIXED: Only show upgrade button if user is NOT premium */}
              {video.is_premium && !hasPremiumAccess && (
                <Button 
                  variant="outline" 
                  size="lg"
                  onClick={() => window.location.href = '/subscription'}
                  className="border-amber-500 text-amber-500 hover:bg-amber-500/10 font-semibold px-6"
                >
                  <Crown className="w-5 h-5 mr-2" />
                  Upgrade to Watch
                </Button>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'list') {
    return (
      <Card 
        className={cn(
          "group cursor-pointer transition-all duration-200 hover:scale-[1.02] hover:shadow-lg border-0 bg-gray-900/50",
          className
        )}
        onClick={(e) => handlePlay(e)}
      >
        <CardContent className="p-0">
          <div className="flex">
            {/* Thumbnail */}
            <div className="relative w-48 h-28 flex-shrink-0">
              <img
                src={finalThumbnailUrl}
                alt={video.title}
                className="w-full h-full object-cover rounded-l-lg"
                onError={(e) => {
                  if (import.meta.env.DEV) {
                    console.warn(`List thumbnail failed for "${video.title}", trying fallback`);
                  }
                  setThumbnailError(true);
                  // Try direct database URL first
                  if (video.thumbnail_url && e.currentTarget.src !== video.thumbnail_url) {
                    e.currentTarget.src = video.thumbnail_url;
                    return;
                  }
                  // Generate placeholder
                  const initials = video.title.split(' ').map(word => word[0]).join('').substring(0, 2).toUpperCase();
                  const hue = Math.abs(video.title.split('').reduce((a, b) => a + b.charCodeAt(0), 0)) % 360;
                  e.currentTarget.src = `data:image/svg+xml,${encodeURIComponent(`
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 180">
                      <defs><linearGradient id="g3" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" style="stop-color:hsl(${hue}, 60%, 50%)" />
                        <stop offset="100%" style="stop-color:hsl(${hue}, 60%, 35%)" />
                      </linearGradient></defs>
                      <rect width="100%" height="100%" fill="url(#g3)"/>
                      <text x="50%" y="45%" text-anchor="middle" fill="white" font-size="30" font-weight="bold">${initials}</text>
                      <text x="50%" y="65%" text-anchor="middle" fill="rgba(255,255,255,0.8)" font-size="12">${video.title.length > 15 ? video.title.substring(0, 12) + '...' : video.title}</text>
                    </svg>
                  `)}`;
                }}
              />
              
              {/* Play Overlay */}
              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="bg-white/20 backdrop-blur-sm rounded-full p-2">
                  <Play className="w-6 h-6 text-white" fill="white" />
                </div>
              </div>
              
              {/* Duration */}
              {video.duration && (
                <Badge className="absolute bottom-2 right-2 bg-black/80 text-white text-xs font-mono">
                  {formatDuration(video.duration)}
                </Badge>
              )}
              
              {/* Progress Bar */}
              {showProgress && progress > 0 && (
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/50">
                  <div 
                    className="h-full bg-primary" 
                    style={{ width: `${progress}%` }}
                  />
                </div>
              )}
            </div>
            
            {/* Content */}
            <div className="flex-1 p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    {video.content_category === 'trailer' && (
                      <Badge variant="secondary" className="bg-blue-600 text-white text-xs">
                        Trailer
                      </Badge>
                    )}
                    {video.is_premium && (
                      <Badge variant="secondary" className="bg-gradient-to-r from-amber-500 to-orange-600 text-white text-xs">
                        <Crown className="w-3 h-3 mr-1" />
                        Premium
                      </Badge>
                    )}
                    {getQualityBadge() && (
                      <Badge variant="outline" className="text-xs border-gray-600 text-gray-300">
                        {getQualityBadge()}
                      </Badge>
                    )}
                  </div>
                  
                  <h3 className="font-semibold text-lg line-clamp-1 mb-1 text-white">
                    {video.title}
                  </h3>
                  
                  <p className="text-sm text-gray-400 line-clamp-2 mb-2">
                    {video.description || "No description available"}
                  </p>
                  
                  <div className="flex items-center gap-3 text-xs text-gray-500">
                    {video.release_year && <span className="font-medium">{video.release_year}</span>}
                    {video.views && (
                      <span className="flex items-center gap-1">
                        <Eye className="w-3 h-3" />
                        {video.views.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="flex items-center gap-2 ml-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleWatchlistToggle();
                    }}
                    className="text-gray-400 hover:text-white"
                  >
                    {isInWatchlist ? (
                      <Check className="w-4 h-4" />
                    ) : (
                      <Plus className="w-4 h-4" />
                    )}
                  </Button>
                  
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Grid variant with new design enhancements
  return (
    <Card
      className={cn(
        'group/card relative cursor-pointer overflow-hidden rounded-lg border-0 bg-slate-900/50 transition-all duration-300 ease-in-out',
        'hover:shadow-2xl hover:shadow-purple-500/10 hover:border-slate-700',
        className
      )}
      onClick={(e) => handlePlay(e)}
    >
      <div className="relative aspect-[16/9] w-full overflow-hidden">
        <img
          src={finalThumbnailUrl}
          alt={video.title}
          className="h-full w-full object-cover transition-transform duration-500 ease-in-out group-hover/card:scale-110"
          onError={(e) => {
            if (import.meta.env.DEV) {
              console.warn(`Grid thumbnail failed for "${video.title}", trying fallback`);
            }
            setThumbnailError(true);
            if (video.thumbnail_url && e.currentTarget.src !== video.thumbnail_url) {
              e.currentTarget.src = video.thumbnail_url;
              return;
            }
            const initials = video.title.split(' ').map(w => w[0]).join('').substring(0, 2).toUpperCase();
            const hue = Math.abs(video.title.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0)) % 360;
            e.currentTarget.src = `data:image/svg+xml,${encodeURIComponent(
              `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 480 270"><defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="hsl(${hue}, 50%, 40%)" /><stop offset="100%" stop-color="hsl(${hue}, 50%, 30%)" /></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="60" fill="white" font-weight="bold">${initials}</text></svg>`
            )}`;
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 opacity-0 transition-opacity duration-300 group-hover/card:opacity-100">
          <Play className="h-12 w-12 text-white drop-shadow-lg" fill="currentColor" />
        </div>
        
        <div className="absolute top-2 left-2 flex flex-col gap-1.5">
            {video.is_premium && <Badge className="border-none bg-gradient-to-r from-purple-500 to-indigo-600 text-xs font-bold text-white shadow-lg"><Crown size={12} className="mr-1.5"/>Premium</Badge>}
            {video.content_category === 'trailer' && <Badge className="border-slate-700 bg-slate-900/80 text-xs text-slate-300 backdrop-blur-sm">Trailer</Badge>}
        </div>
        
        <div className="absolute bottom-2 right-2 flex items-center gap-1.5 text-xs">
            {getQualityBadge() && <Badge variant="secondary" className="bg-black/60 font-medium text-white backdrop-blur-sm">{getQualityBadge()}</Badge>}
            {video.duration && <Badge className="font-mono bg-black/60 text-white backdrop-blur-sm">{formatDuration(video.duration)}</Badge>}
        </div>

        {showProgress && progress > 0 && (
          <div className="absolute bottom-0 left-0 h-1 w-full bg-slate-700/50">
            <div className="h-full bg-purple-500 transition-all" style={{ width: `${progress}%` }} />
          </div>
        )}
      </div>
      <div className="p-3">
        <div className="flex items-start justify-between">
            <h3 className="font-semibold text-sm text-slate-100 line-clamp-2 transition-colors duration-200 group-hover/card:text-purple-400">{video.title}</h3>
            <Button
              variant="ghost" size="icon"
              onClick={(e) => { e.stopPropagation(); handleWatchlistToggle(); }}
              className="ml-2 -mt-1 h-8 w-8 flex-shrink-0 rounded-full text-slate-400 opacity-0 transition-opacity group-hover/card:opacity-100 hover:bg-slate-800/50 hover:text-white"
            >
              {isInWatchlist ? <Check size={16} /> : <Plus size={16} />}
            </Button>
        </div>
        <div className="mt-1 flex items-center gap-2 text-xs text-slate-400">
            {video.release_year && <span>{video.release_year}</span>}
            {video.views && video.release_year && <span className="text-slate-600">&bull;</span>}
            {video.views && <span className="flex items-center gap-1"><Eye size={12}/>{video.views > 1000 ? `${(video.views / 1000).toFixed(0)}K` : video.views}</span>}
        </div>
      </div>
    </Card>
  );
}

export default EnhancedContentCard; 