import { createRoot } from "react-dom/client";
import React from "react";
import type {  UnifiedErrorBoundary  } from "./components/error-boundary/UnifiedErrorBoundary";

// Test imports one by one to isolate the culprit
import type {  AppErrorBoundary  } from '@/components/error-boundary/AppErrorBoundary';
import type {  ProfileProvider  } from '@/components/providers/profile-provider';
import type {  MainLayout  } from '@/components/layouts/MainLayout';
import { logger } from '../shared/logger.js';

// Step 5: Test MainLayout specifically (complex component with many dependencies)
function TestMainLayout() {
  return (
    <div>
      <div style={{ padding: '10px', background: '#fff3e0', marginBottom: '10px' }}>
        <strong>Isolation Test: Step 5 - Testing MainLayout</strong>
        <p>If this loads, MainLayout is NOT the issue.</p>
        <p>If this breaks, MainLayout IS the culprit!</p>
        <p>MainLayout is complex with navigation, footer, etc.</p>
      </div>
      
      <AppErrorBoundary
        onError={(error, errorInfo) => {
          logger.info('AppErrorBoundary caught error:', { arg1: error, arg2: errorInfo });
        }}
      >
        <ProfileProvider>
          <MainLayout>
            <div style={{ padding: '40px', background: '#f5f5f5', margin: '20px' }}>
              <h2>Test Content Inside MainLayout</h2>
              <p>This content is wrapped in AppErrorBoundary + ProfileProvider + MainLayout.</p>
              <p>MainLayout includes complex navigation, footer, and mobile menus.</p>
              <p>Current time: {new Date().toLocaleTimeString()}</p>
            </div>
          </MainLayout>
        </ProfileProvider>
      </AppErrorBoundary>
    </div>
  );
}

// Render with our proven-working error boundary
const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <UnifiedErrorBoundary errorType="generic" variant="detailed">
      <TestMainLayout />
    </UnifiedErrorBoundary>
  );
} else {
  logger.error('Root element not found');
} 