import { createRoot } from "react-dom/client";
import App from "./App";
import type {  UnifiedErrorBoundary  } from "./components/error-boundary/UnifiedErrorBoundary";
import { initPerformanceMonitoring, applyPerformanceOptimizations } from "./lib/performance-monitor";
import { initEnhancedPerformanceMonitoring } from "./lib/performance-monitor-enhanced";
import { preloadCriticalIcons } from "./lib/icons";
import { logger } from "@shared/logger";
import "./index.css";
import "./components/responsive-layout-fix.css";
import "./components/ui/player-fixes.css";

if (import.meta.env.DEV) {
  logger.info('=== MADIFASTREAM LOADING ===');
  logger.info('Environment check:', {
    VITE_SUPABASE_URL: import.meta.env.VITE_SUPABASE_URL ? 'PRESENT' : 'MISSING',
    VITE_SUPABASE_ANON_KEY: import.meta.env.VITE_SUPABASE_ANON_KEY ? 'PRESENT' : 'MISSING',
    VITE_BACKEND_API_URL: import.meta.env.VITE_BACKEND_API_URL,
    VITE_BUNNY_STREAM_LIBRARY_ID: import.meta.env.VITE_BUNNY_STREAM_LIBRARY_ID
  });
}

// Initialize performance monitoring and optimizations
if (typeof window !== 'undefined') {
  // Unregister any broken service workers causing console spam, but only in production
  if (process.env.NODE_ENV === 'production' && 'serviceWorker' in navigator) {
    navigator.serviceWorker.getRegistrations().then(function(registrations) {
      for (const registration of registrations) {
        registration.unregister().then(() => {
          if (import.meta.env.DEV) {
            logger.info('Service worker unregistered successfully');
          }
        });
      }
    });

    // Clear all service worker caches to prevent issues
    if ('caches' in window) {
      caches.keys().then(cacheNames => {
        return Promise.all(
          cacheNames.map(cacheName => {
            return caches.delete(cacheName);
          })
        );
      }).then(() => {
        if (import.meta.env.DEV) {
          logger.info('All service worker caches cleared');
        }
      });
    }
  }

  // Apply performance optimizations
  applyPerformanceOptimizations();
  
  // Preload critical icons
  preloadCriticalIcons();

  // Start performance monitoring after the app is loaded
  window.addEventListener('load', () => {
    setTimeout(() => {
      initPerformanceMonitoring();
      initEnhancedPerformanceMonitoring();
    }, 1000);
  });
}

// Custom error handler for error tracking
const handleError = (error: Error, errorInfo: React.ErrorInfo) => {
  // In production, send to error tracking service
  if (import.meta.env.DEV) {
    logger.error('Application error:', error, errorInfo);
  }
  // TODO: Add production error reporting
};

// Render the full React application with error boundary
createRoot(document.getElementById('root')!).render(
  <UnifiedErrorBoundary errorType="generic" variant="detailed">
    <App />
  </UnifiedErrorBoundary>
);
