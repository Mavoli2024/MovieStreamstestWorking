import { createRoot } from "react-dom/client";
import React from "react";
import type {  UnifiedErrorBoundary  } from "./components/error-boundary/UnifiedErrorBoundary";

// Test imports one by one to isolate the culprit
import type {  AppErrorBoundary  } from '@/components/error-boundary/AppErrorBoundary';
import type {  ProfileProvider  } from '@/components/providers/profile-provider';
import { logger } from '../shared/logger.js';

// Step 4: Test ProfileProvider specifically
function TestProfileProvider() {
  return (
    <div>
      <div style={{ padding: '10px', background: '#f3e5f5', marginBottom: '10px' }}>
        <strong>Isolation Test: Step 4 - Testing ProfileProvider</strong>
        <p>If this loads, ProfileProvider is NOT the issue.</p>
        <p>If this breaks, ProfileProvider IS the culprit!</p>
      </div>
      
      <AppErrorBoundary
        onError={(error, errorInfo) => {
          logger.info('AppErrorBoundary caught error:', { arg1: error, arg2: errorInfo });
        }}
      >
        <ProfileProvider>
          <div style={{ padding: '20px', background: '#f5f5f5' }}>
            <h2>Test Content Inside ProfileProvider</h2>
            <p>This content is wrapped in AppErrorBoundary + ProfileProvider.</p>
            <p>Current time: {new Date().toLocaleTimeString()}</p>
          </div>
        </ProfileProvider>
      </AppErrorBoundary>
    </div>
  );
}

// Render with our proven-working error boundary
const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <UnifiedErrorBoundary errorType="generic" variant="detailed">
      <TestProfileProvider />
    </UnifiedErrorBoundary>
  );
} else {
  logger.error('Root element not found');
} 