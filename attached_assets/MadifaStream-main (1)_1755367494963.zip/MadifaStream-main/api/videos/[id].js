// Simple console logger for serverless environment
const logger = {
  error: (...args) => console.error('[API Error]', ...args),
  info: (...args) => console.log('[API Info]', ...args),
  warn: (...args) => console.warn('[API Warn]', ...args)
};
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client from environment
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseServiceKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { id } = req.query;
    
    if (!id) {
      return res.status(400).json({ error: 'Video ID is required' });
    }

    // Get single video by ID using service role key (bypasses RLS)
    const { data: video, error } = await supabase
      .from('videos')
      .select(`
        id,
        title,
        description,
        thumbnail_url,
        video_url,
        trailer_url,
        duration,
        release_year,
        director,
        cast_members,
        genres,
        age_rating,
        is_premium,
        is_trailer,
        views,
        created_at,
        bunny_video_id,
        bunny_playback_id,
        encode_progress,
        available_resolutions,
        average_watch_time,
        total_watch_time
      `)
      .eq('id', id)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        return res.status(404).json({ error: 'Video not found' });
      }
      logger.error('Supabase error:', error);
      return res.status(500).json({ 
        error: 'Failed to fetch video', 
        details: error.message 
      });
    }

    if (!video) {
      return res.status(404).json({ error: 'Video not found' });
    }

    // Transform video data to ensure consistent format
    const transformedVideo = {
      ...video,
      // Ensure arrays are properly formatted
      genres: Array.isArray(video.genres) ? video.genres : [],
      cast_members: Array.isArray(video.cast_members) ? video.cast_members : [],
      // Ensure boolean values
      is_premium: Boolean(video.is_premium),
      is_trailer: Boolean(video.is_trailer),
      // Ensure numeric values
      views: parseInt(video.views) || 0,
      duration: parseInt(video.duration) || 0,
      release_year: parseInt(video.release_year) || new Date().getFullYear(),
    };

    res.status(200).json(transformedVideo);

  } catch (error) {
    logger.error('Video API Error:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      details: error.message 
    });
  }
}