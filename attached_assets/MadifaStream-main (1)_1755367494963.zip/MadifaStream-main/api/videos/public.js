// Simple console logger for serverless environment
const logger = {
  error: (...args) => console.error('[API Error]', ...args),
  info: (...args) => console.log('[API Info]', ...args),
  warn: (...args) => console.warn('[API Warn]', ...args)
};
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client from environment (do NOT commit keys)
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseServiceKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { cursor, limit = 20, search, genre } = req.query;
    const pageLimit = Math.min(parseInt(limit), 50); // Max 50 items per page

    let query = supabase
      .from('videos')
      .select(`
        id,
        title,
        description,
        thumbnail_url,
        video_url,
        trailer_url,
        duration,
        release_year,
        director,
        cast_members,
        genres,
        age_rating,
        is_premium,
        is_trailer,
        views,
        created_at,
        bunny_video_id,
        bunny_playback_id,
        encode_progress,
        available_resolutions,
        average_watch_time,
        total_watch_time
      `)
      .order('created_at', { ascending: false })
      .limit(pageLimit);

    // Apply cursor-based pagination
    if (cursor) {
      query = query.lt('created_at', cursor);
    }

    // Apply search filter
    if (search) {
      query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%`);
    }

    // Apply genre filter
    if (genre && genre !== 'all') {
      query = query.contains('genres', [genre]);
    }

    const { data: videos, error } = await query;

    if (error) {
      logger.error('Supabase error:', error);
      return res.status(500).json({ 
        error: 'Failed to fetch videos', 
        details: error.message 
      });
    }

    // Calculate next cursor
    const nextCursor = videos && videos.length === pageLimit 
      ? videos[videos.length - 1].created_at 
      : null;

    // Transform video data to ensure consistent format
    const transformedVideos = (videos || []).map(video => ({
      ...video,
      // Ensure arrays are properly formatted
      genres: Array.isArray(video.genres) ? video.genres : [],
      cast_members: Array.isArray(video.cast_members) ? video.cast_members : [],
      // Ensure boolean values
      is_premium: Boolean(video.is_premium),
      is_trailer: Boolean(video.is_trailer),
      // Ensure numeric values
      views: parseInt(video.views) || 0,
      duration: parseInt(video.duration) || 0,
      release_year: parseInt(video.release_year) || new Date().getFullYear(),
    }));

    res.status(200).json({
      items: transformedVideos,
      nextCursor,
      hasMore: Boolean(nextCursor),
      total: transformedVideos.length
    });

  } catch (error) {
    logger.error('Videos API Error:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      details: error.message 
    });
  }
}