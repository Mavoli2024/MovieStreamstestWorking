// Simple console logger for serverless environment
const logger = {
  error: (...args) => console.error('[API Error]', ...args),
  info: (...args) => console.log('[API Info]', ...args),
  warn: (...args) => console.warn('[API Warn]', ...args)
};
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client from environment
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseServiceKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { id } = req.query;
    
    if (!id) {
      return res.status(400).json({ error: 'Video ID is required' });
    }

    // Update view count using service role key (bypasses RLS)
    const { data, error } = await supabase
      .from('videos')
      .update({ 
        views: supabase.raw('COALESCE(views, 0) + 1'),
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select('views')
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        return res.status(404).json({ error: 'Video not found' });
      }
      logger.error('Supabase error updating view count:', error);
      return res.status(500).json({ 
        error: 'Failed to update view count', 
        details: error.message 
      });
    }

    res.status(200).json({
      success: true,
      views: data?.views || 0
    });

  } catch (error) {
    logger.error('View Count API Error:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      details: error.message 
    });
  }
}