// Simple console logger for serverless environment
const logger = {
  error: (...args) => console.error('[API Error]', ...args),
  info: (...args) => console.log('[API Info]', ...args),
  warn: (...args) => console.warn('[API Warn]', ...args)
};
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client from environment
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseServiceKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { id } = req.query;
    const { limit = 6 } = req.query;
    const pageLimit = Math.min(parseInt(limit), 12); // Max 12 related videos
    
    if (!id) {
      return res.status(400).json({ error: 'Video ID is required' });
    }

    // First, get the current video to find related content
    const { data: currentVideo, error: currentVideoError } = await supabase
      .from('videos')
      .select('genres, is_premium, is_trailer')
      .eq('id', id)
      .single();

    if (currentVideoError) {
      logger.error('Error fetching current video:', currentVideoError);
      return res.status(404).json({ error: 'Video not found' });
    }

    // Find related videos based on genre similarity
    let query = supabase
      .from('videos')
      .select(`
        id,
        title,
        description,
        thumbnail_url,
        video_url,
        trailer_url,
        duration,
        release_year,
        director,
        cast_members,
        genres,
        age_rating,
        is_premium,
        is_trailer,
        views,
        created_at
      `)
      .neq('id', id) // Exclude current video
      .order('views', { ascending: false })
      .limit(pageLimit);

    // If current video has genres, prioritize videos with similar genres
    if (currentVideo.genres && Array.isArray(currentVideo.genres) && currentVideo.genres.length > 0) {
      // Try to find videos that share genres
      query = query.overlaps('genres', currentVideo.genres);
    }

    const { data: relatedVideos, error } = await query;

    if (error) {
      logger.error('Supabase error fetching related videos:', error);
      return res.status(500).json({ 
        error: 'Failed to fetch related videos', 
        details: error.message 
      });
    }

    // If we don't have enough related videos based on genres, get more general recommendations
    let finalVideos = relatedVideos || [];
    
    if (finalVideos.length < pageLimit) {
      const { data: moreVideos, error: moreError } = await supabase
        .from('videos')
        .select(`
          id,
          title,
          description,
          thumbnail_url,
          video_url,
          trailer_url,
          duration,
          release_year,
          director,
          cast_members,
          genres,
          age_rating,
          is_premium,
          is_trailer,
          views,
          created_at
        `)
        .neq('id', id)
        .not('id', 'in', `(${finalVideos.map(v => v.id).join(',')})`)
        .order('created_at', { ascending: false })
        .limit(pageLimit - finalVideos.length);

      if (!moreError && moreVideos) {
        finalVideos = [...finalVideos, ...moreVideos];
      }
    }

    // Transform video data to ensure consistent format
    const transformedVideos = (finalVideos || []).map(video => ({
      ...video,
      // Ensure arrays are properly formatted
      genres: Array.isArray(video.genres) ? video.genres : [],
      cast_members: Array.isArray(video.cast_members) ? video.cast_members : [],
      // Ensure boolean values
      is_premium: Boolean(video.is_premium),
      is_trailer: Boolean(video.is_trailer),
      // Ensure numeric values
      views: parseInt(video.views) || 0,
      duration: parseInt(video.duration) || 0,
      release_year: parseInt(video.release_year) || new Date().getFullYear(),
    }));

    res.status(200).json({
      items: transformedVideos,
      total: transformedVideos.length
    });

  } catch (error) {
    logger.error('Related Videos API Error:', error);
    res.status(500).json({ 
      error: 'Internal server error', 
      details: error.message 
    });
  }
}