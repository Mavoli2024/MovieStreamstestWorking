// Serverless mirror of Express route: /api/signed-video-url
// Allows Vercel deployments to use the same endpoint
import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}

export default async function handler(req, res) {
  // CORS
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  if (req.method === 'OPTIONS') return res.status(200).end();

  if (req.method !== 'POST' && req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Auth: Bearer token required
    const authHeader = req.headers.authorization || '';
    if (!authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'Authentication required', code: 'AUTH_REQUIRED' });
    }
    const token = authHeader.slice(7);

    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const { data: userData, error: userError } = await supabase.auth.getUser(token);
    if (userError || !userData.user) {
      return res.status(401).json({ success: false, message: 'Invalid token', code: 'AUTH_INVALID' });
    }

    const videoId = req.method === 'GET' ? String(req.query.videoId || '') : req.body?.videoId;
    const expiresIn = req.method === 'GET' && req.query.expiresIn ? Number(req.query.expiresIn) : (req.body?.expiresIn || 3600);
    if (!videoId) {
      return res.status(400).json({ error: 'videoId is required' });
    }

    // Fetch video
    const { data: video, error: videoError } = await supabase
      .from('videos')
      .select('*')
      .eq('id', videoId)
      .single();
    if (videoError || !video) {
      return res.status(404).json({ error: 'Video not found' });
    }

    // Premium gating
    if (video.is_premium) {
      const { data: sub, error: subError } = await supabase
        .from('subscriptions')
        .select('is_active, end_date')
        .eq('user_id', userData.user.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      const active = sub && (sub.is_active || (sub.end_date && new Date(sub.end_date) > new Date()));
      if (subError || !active) {
        return res.status(403).json({ error: 'Premium subscription required', code: 'SUBSCRIPTION_REQUIRED' });
      }
    }

    // Sign Bunny URL if configured
    if (process.env.BUNNY_STREAM_SECURITY_KEY && video.video_url) {
      const expires = Math.floor(Date.now() / 1000) + Number(expiresIn || 3600);
      const url = new URL(video.video_url);
      const videoPath = url.pathname;
      const tokenPath = videoPath.substring(0, videoPath.lastIndexOf('/') + 1);
      const crypto = await import('crypto');
      const stringToSign = `${process.env.BUNNY_STREAM_SECURITY_KEY}${tokenPath}${expires}`;
      const tokenSig = crypto.createHash('sha256').update(stringToSign).digest('base64')
        .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+/g, '');
      const signedUrl = `${video.video_url}?token=${tokenSig}&token_path=${encodeURIComponent(tokenPath)}&expires=${expires}`;
      return res.status(200).json({ signedUrl, expires });
    }

    return res.status(200).json({ signedUrl: video.video_url, expires: Math.floor(Date.now() / 1000) + Number(expiresIn || 3600) });
  } catch (error) {
    console.error('signed-video-url error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}


