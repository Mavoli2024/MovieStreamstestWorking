import { logger } from "../../server/utils/logger.js";
export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Return hardcoded subscription plans
    const plans = [
      {
        id: 'free',
        name: 'Free',
        price: 0,
        currency: 'ZAR',
        duration_months: 0,
        features: [
          'Limited content access',
          'SD quality streaming',
          'Watch trailers for free',
          'Basic support'
        ],
        description: 'Perfect for getting started with Madifa',
        popular: false
      },
      {
        id: 'premium',
        name: 'Premium',
        price: 5900, // R59.00 in cents
        currency: 'ZAR',
        duration_months: 1,
        features: [
          'Full content library access',
          'HD quality streaming',
          'Download for offline viewing',
          'No advertisements',
          'Priority customer support',
          'Early access to new releases'
        ],
        description: 'Unlock the full Madifa experience',
        popular: true
      }
    ];

    res.status(200).json({
      success: true,
      plans
    });
  } catch (error) {
    logger.error('Error fetching subscription plans:', error);
    res.status(500).json({ 
      success: false, 
      error: 'Failed to fetch subscription plans' 
    });
  }
} 