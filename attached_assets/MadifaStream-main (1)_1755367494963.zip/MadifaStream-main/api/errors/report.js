/**
 * Vercel Serverless Function for Error Reporting
 * 
 * Mirrors the server route for error reporting in serverless environment
 */

import { z } from 'zod';

// Validation schema for error reports
const ErrorReportSchema = z.object({
  message: z.string().max(1000),
  stack: z.string().optional(),
  level: z.enum(['error', 'warning', 'info']),
  context: z.object({
    userId: z.string().optional(),
    sessionId: z.string().optional(),
    route: z.string().optional(),
    component: z.string().optional(),
    action: z.string().optional(),
    metadata: z.record(z.unknown()).optional()
  }).optional(),
  timestamp: z.string().transform(str => new Date(str)),
  userAgent: z.string(),
  url: z.string().url()
});

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  // Handle preflight OPTIONS request
  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      error: 'Method not allowed'
    });
  }

  try {
    // Validate the error report
    const errorReport = ErrorReportSchema.parse(req.body);
    
    // Extract client information
    const clientIP = req.headers['x-forwarded-for'] || req.connection?.remoteAddress || 'unknown';
    
    // Structure log data
    const logData = {
      type: 'client_error',
      level: errorReport.level,
      message: errorReport.message,
      stack: errorReport.stack,
      context: errorReport.context,
      client: {
        ip: clientIP,
        userAgent: errorReport.userAgent,
        url: errorReport.url,
        timestamp: errorReport.timestamp
      },
      server: {
        receivedAt: new Date(),
        function: 'error-report-vercel'
      }
    };

    // Log to console (Vercel will capture this)
    if (errorReport.level === 'error') {
      console.error('Client error report:', JSON.stringify(logData, null, 2));
    } else if (errorReport.level === 'warning') {
      console.warn('Client warning report:', JSON.stringify(logData, null, 2));
    } else {
      console.info('Client info report:', JSON.stringify(logData, null, 2));
    }

    // Send success response
    res.status(200).json({
      success: true,
      message: 'Error report received',
      reportId: `${Date.now()}-${Math.random().toString(36).substr(2, 6)}`
    });

  } catch (error) {
    // Handle validation or processing errors
    if (error instanceof z.ZodError) {
      console.warn('Invalid error report received:', {
        validationErrors: error.errors,
        clientIP: req.headers['x-forwarded-for'] || 'unknown',
        userAgent: req.headers['user-agent']
      });
      
      return res.status(400).json({
        success: false,
        error: 'Invalid error report format',
        details: error.errors
      });
    }

    // Log server-side processing errors
    console.error('Failed to process error report:', {
      error: error instanceof Error ? error.message : String(error),
      clientIP: req.headers['x-forwarded-for'] || 'unknown'
    });

    res.status(500).json({
      success: false,
      error: 'Failed to process error report'
    });
  }
}