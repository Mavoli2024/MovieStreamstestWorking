import { logger } from "../../server/utils/logger.js";
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client using environment variables (do NOT commit keys)
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseServiceKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    if (req.method === 'GET') {
      // Fetch all categories from the database
      const { data: categories, error } = await supabase
        .from('categories')
        .select('id, name, description')
        .order('name');

      if (error) {
        logger.error('Supabase error:', error);
        return res.status(500).json({ error: 'Failed to fetch categories', details: error.message });
      }

      // Return categories without video counts for now (video_categories table may not exist)
      res.status(200).json({
        categories: categories.map(category => ({
          ...category,
          videoCount: 0 // Placeholder - can be calculated later if needed
        }))
      });

    } else {
      res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    logger.error('Categories API Error:', error);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
} 