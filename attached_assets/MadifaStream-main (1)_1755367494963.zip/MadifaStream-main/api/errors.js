import { logger } from "../../server/utils/logger.js";
export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    if (req.method === 'POST') {
      // Log client-side errors
      const { error, context, userAgent, url, timestamp } = req.body;
      
      logger.error('Client Error Report:', {
        error,
        context,
        userAgent,
        url,
        timestamp: timestamp || new Date().toISOString()
      });

      // In a production environment, you might want to:
      // - Store errors in a database
      // - Send to error tracking service (Sentry, LogRocket, etc.)
      // - Send alerts for critical errors

      res.status(200).json({
        success: true,
        message: 'Error logged successfully'
      });
    } else if (req.method === 'GET') {
      // Return error status or health check
      res.status(200).json({
        success: true,
        message: 'Error logging service is operational'
      });
    } else {
      res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    logger.error('Error logging API error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
} 