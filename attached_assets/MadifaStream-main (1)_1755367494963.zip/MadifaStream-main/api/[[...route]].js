// Catch-all Vercel serverless function that mounts the compiled Express app
// This consolidates all API routes into a single function to fit Hobby plan limits
import app from '../dist/server/server/server.js';

// Export as default for Vercel
export default app;


