import { logger } from "../../server/utils/logger.js";
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client from environment (do NOT commit keys)
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    if (req.method === 'GET') {
      const { q, limit = 20, page = 1, type = 'all' } = req.query;

      if (!q || q.trim().length < 2) {
        return res.status(400).json({ error: 'Search query must be at least 2 characters long' });
      }

      const searchTerm = q.trim();
      const offset = (parseInt(page) - 1) * parseInt(limit);

      let query = supabase
        .from('videos')
        .select(`
          id,
          title,
          description,
          thumbnail_url,
          video_url,
          duration,
          release_year,
          director,
          cast_members,
          genres,
          age_rating,
          is_premium,
          is_trailer,
          views,
          created_at
        `)
        .eq('status', 'published');

      // Apply search filters
      if (type === 'trailers') {
        query = query.eq('is_trailer', true);
      } else if (type === 'movies') {
        query = query.eq('is_trailer', false);
      }

      // Search in title, description, director, and cast
      query = query.or(`
        title.ilike.%${searchTerm}%,
        description.ilike.%${searchTerm}%,
        director.ilike.%${searchTerm}%,
        cast_members.cs.{${searchTerm}}
      `);

      // Apply pagination and ordering
      query = query
        .order('views', { ascending: false })
        .range(offset, offset + parseInt(limit) - 1);

      const { data: videos, error } = await query;

      if (error) {
        logger.error('Search error:', error);
        return res.status(500).json({ error: 'Search failed', details: error.message });
      }

      // Get total count for pagination
      let countQuery = supabase
        .from('videos')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'published');

      if (type === 'trailers') {
        countQuery = countQuery.eq('is_trailer', true);
      } else if (type === 'movies') {
        countQuery = countQuery.eq('is_trailer', false);
      }

      countQuery = countQuery.or(`
        title.ilike.%${searchTerm}%,
        description.ilike.%${searchTerm}%,
        director.ilike.%${searchTerm}%,
        cast_members.cs.{${searchTerm}}
      `);

      const { count: totalCount } = await countQuery;

      // Transform data to match expected frontend format
      const transformedVideos = videos.map(video => ({
        id: video.id,
        title: video.title,
        description: video.description || 'No description available',
        thumbnailUrl: video.thumbnail_url,
        videoUrl: video.video_url,
        duration: video.duration,
        releaseYear: video.release_year,
        director: video.director,
        cast: video.cast_members || [],
        genres: video.genres || [],
        ageRating: video.age_rating,
        isPremium: video.is_premium,
        isTrailer: video.is_trailer,
        views: video.views || 0,
        createdAt: video.created_at,
        rating: 4.0 + Math.random() * 1.0 // Temporary until ratings are implemented
      }));

      res.status(200).json({
        query: searchTerm,
        results: transformedVideos,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: totalCount || 0,
          totalPages: Math.ceil((totalCount || 0) / parseInt(limit))
        },
        suggestions: [] // Could add search suggestions here later
      });

    } else {
      res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    logger.error('Search API Error:', error);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
} 