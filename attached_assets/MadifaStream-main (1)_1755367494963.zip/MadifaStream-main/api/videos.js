import { logger } from "../server/utils/logger.js";
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseServiceKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseServiceKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    if (req.method === 'GET') {
      const { page = 1, limit = 12, genre, search, featured, trending } = req.query;
      const offset = (parseInt(page) - 1) * parseInt(limit);

      let query = supabase
        .from('videos')
        .select(`
          id,
          title,
          description,
          thumbnail_url,
          video_url,
          trailer_url,
          duration,
          release_year,
          director,
          cast_members,
          genres,
          age_rating,
          is_premium,
          is_trailer,
          status,
          views,
          created_at,
          bunny_video_id,
          bunny_playback_id,
          encode_progress,
          available_resolutions,
          average_watch_time,
          total_watch_time
        `)
        .eq('status', 'published')
        .order('created_at', { ascending: false });

      // Apply filters
      if (genre && genre !== 'all') {
        query = query.contains('genres', [genre]);
      }

      if (search) {
        query = query.or(`title.ilike.%${search}%,description.ilike.%${search}%`);
      }

      if (featured === 'true') {
        // Get videos with highest views as featured
        query = query.order('views', { ascending: false });
      }

      if (trending === 'true') {
        // Get videos with most recent activity or highest views
        query = query.order('views', { ascending: false });
      }

      // Apply pagination
      query = query.range(offset, offset + parseInt(limit) - 1);

      const { data: videos, error, count } = await query;

      if (error) {
        logger.error('Supabase error:', error);
        return res.status(500).json({ error: 'Failed to fetch videos', details: error.message });
      }

      // Get total count for pagination
      const { count: totalCount } = await supabase
        .from('videos')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'published');

      // Transform data to match expected frontend format
      const transformedVideos = videos.map(video => ({
        id: video.id,
        title: video.title,
        description: video.description || 'No description available',
        thumbnailUrl: video.thumbnail_url,
        videoUrl: video.video_url,
        trailerUrl: video.trailer_url,
        duration: video.duration,
        releaseYear: video.release_year,
        director: video.director,
        cast: video.cast_members || [],
        genres: video.genres || [],
        ageRating: video.age_rating,
        isPremium: video.is_premium,
        isTrailer: video.is_trailer,
        views: video.views || 0,
        createdAt: video.created_at,
        bunnyVideoId: video.bunny_video_id,
        bunnyPlaybackId: video.bunny_playback_id,
        encodeProgress: video.encode_progress,
        availableResolutions: video.available_resolutions,
        averageWatchTime: video.average_watch_time,
        totalWatchTime: video.total_watch_time,
        rating: 4.2 + Math.random() * 0.8 // Temporary until ratings are implemented
      }));

      res.status(200).json({
        videos: transformedVideos,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          total: totalCount || 0,
          totalPages: Math.ceil((totalCount || 0) / parseInt(limit))
        }
      });

    } else {
      res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    logger.error('API Error:', error);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
} 