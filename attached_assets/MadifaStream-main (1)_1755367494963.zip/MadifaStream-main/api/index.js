// Keep for compatibility; delegate to catch-all handler
export { default } from './[[...route]].js';
