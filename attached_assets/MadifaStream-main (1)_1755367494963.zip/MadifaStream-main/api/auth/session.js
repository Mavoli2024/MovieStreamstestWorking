import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  try {
    if (req.method === 'GET') {
      // Extract authorization header
      const authHeader = req.headers.authorization;
      
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ 
          authenticated: false, 
          user: null, 
          error: 'No valid token provided' 
        });
      }

      const token = authHeader.substring(7); // Remove 'Bearer ' prefix

      // Verify the session with Supabase
      const { data: { user }, error: authError } = await supabase.auth.getUser(token);

      if (authError || !user) {
        return res.status(401).json({ 
          authenticated: false, 
          user: null, 
          error: authError?.message || 'Invalid token' 
        });
      }

      // Get user profile from the profiles table
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select(`
          id,
          username,
          display_name,
          avatar_url,
          role,
          subscription_status,
          subscription_expires_at,
          bio,
          social_links,
          preferences,
          avatar_color,
          location,
          website,
          date_of_birth,
          created_at,
          updated_at
        `)
        .eq('id', user.id)
        .single();

      if (profileError && profileError.code !== 'PGRST116') {
        console.error('Profile fetch error:', profileError);
        return res.status(500).json({ 
          authenticated: false, 
          user: null, 
          error: 'Failed to fetch user profile' 
        });
      }

      // Get user's subscription details if they have an active subscription
      let subscription = null;
      if (profile?.subscription_status === 'active') {
        const { data: subscriptionData } = await supabase
          .from('subscriptions')
          .select(`
            id,
            plan_id,
            start_date,
            end_date,
            is_active,
            subscription_plans (
              name,
              price,
              video_quality,
              max_devices,
              offline_downloads,
              max_downloads,
              duration_months,
              features
            )
          `)
          .eq('user_id', user.id)
          .eq('is_active', true)
          .single();

        subscription = subscriptionData;
      }

      // Transform user data to match expected frontend format
      const userData = {
        id: user.id,
        email: user.email,
        phone: user.phone,
        emailVerified: !!user.email_confirmed_at,
        phoneVerified: !!user.phone_confirmed_at,
        lastSignInAt: user.last_sign_in_at,
        createdAt: user.created_at,
        profile: profile ? {
          username: profile.username,
          displayName: profile.display_name,
          avatarUrl: profile.avatar_url,
          role: profile.role,
          subscriptionStatus: profile.subscription_status,
          subscriptionExpiresAt: profile.subscription_expires_at,
          bio: profile.bio,
          socialLinks: profile.social_links || {},
          preferences: profile.preferences || {},
          avatarColor: profile.avatar_color,
          location: profile.location,
          website: profile.website,
          dateOfBirth: profile.date_of_birth,
          createdAt: profile.created_at,
          updatedAt: profile.updated_at
        } : null,
        subscription: subscription ? {
          id: subscription.id,
          planId: subscription.plan_id,
          startDate: subscription.start_date,
          endDate: subscription.end_date,
          isActive: subscription.is_active,
          plan: subscription.subscription_plans
        } : null
      };

      res.status(200).json({
        authenticated: true,
        user: userData
      });

    } else if (req.method === 'POST') {
      // Handle sign-in
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ 
          error: 'Email and password are required' 
        });
      }

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) {
        return res.status(401).json({ 
          error: error.message 
        });
      }

      res.status(200).json({
        session: data.session,
        user: data.user
      });

    } else if (req.method === 'DELETE') {
      // Handle sign-out
      const authHeader = req.headers.authorization;
      
      if (authHeader && authHeader.startsWith('Bearer ')) {
        const token = authHeader.substring(7);
        await supabase.auth.admin.signOut(token);
      }

      res.status(200).json({ 
        message: 'Signed out successfully' 
      });

    } else {
      res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    console.error('Auth API Error:', error);
    res.status(500).json({ 
      authenticated: false, 
      user: null, 
      error: 'Internal server error' 
    });
  }
} 