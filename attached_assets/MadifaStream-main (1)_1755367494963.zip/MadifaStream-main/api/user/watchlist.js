import { logger } from "../../server/utils/logger.js";
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client from environment (do NOT commit keys)
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // Verify authentication
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.substring(7);

  try {
    // Verify the session with Supabase
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return res.status(401).json({ error: 'Invalid authentication token' });
    }

    if (req.method === 'GET') {
      // Get user's watchlist
      const { data: watchlist, error } = await supabase
        .from('watchlist')
        .select(`
          id,
          video_id,
          added_at,
          videos (
            id,
            title,
            description,
            thumbnail_url,
            duration,
            release_year,
            genres,
            is_premium,
            views
          )
        `)
        .eq('user_id', user.id)
        .order('added_at', { ascending: false });

      if (error) {
        logger.error('Watchlist fetch error:', error);
        return res.status(500).json({ error: 'Failed to fetch watchlist' });
      }

      const transformedWatchlist = watchlist.map(item => ({
        id: item.id,
        videoId: item.video_id,
        addedAt: item.added_at,
        video: {
          id: item.videos.id,
          title: item.videos.title,
          description: item.videos.description,
          thumbnailUrl: item.videos.thumbnail_url,
          duration: item.videos.duration,
          releaseYear: item.videos.release_year,
          genres: item.videos.genres || [],
          isPremium: item.videos.is_premium,
          views: item.videos.views || 0
        }
      }));

      res.status(200).json({
        watchlist: transformedWatchlist,
        count: transformedWatchlist.length
      });

    } else if (req.method === 'POST') {
      // Add video to watchlist
      const { videoId } = req.body;

      if (!videoId) {
        return res.status(400).json({ error: 'Video ID is required' });
      }

      // Check if video exists
      const { data: video, error: videoError } = await supabase
        .from('videos')
        .select('id, title')
        .eq('id', videoId)
        .eq('status', 'published')
        .single();

      if (videoError || !video) {
        return res.status(404).json({ error: 'Video not found' });
      }

      // Check if already in watchlist
      const { data: existing } = await supabase
        .from('watchlist')
        .select('id')
        .eq('user_id', user.id)
        .eq('video_id', videoId)
        .single();

      if (existing) {
        return res.status(409).json({ error: 'Video already in watchlist' });
      }

      // Add to watchlist
      const { data: newWatchlistItem, error: insertError } = await supabase
        .from('watchlist')
        .insert({
          user_id: user.id,
          video_id: videoId
        })
        .select()
        .single();

      if (insertError) {
        logger.error('Watchlist insert error:', insertError);
        return res.status(500).json({ error: 'Failed to add to watchlist' });
      }

      res.status(201).json({
        message: 'Video added to watchlist',
        item: {
          id: newWatchlistItem.id,
          videoId: newWatchlistItem.video_id,
          addedAt: newWatchlistItem.added_at
        }
      });

    } else if (req.method === 'DELETE') {
      // Remove video from watchlist
      const { videoId } = req.query;

      if (!videoId) {
        return res.status(400).json({ error: 'Video ID is required' });
      }

      const { error: deleteError } = await supabase
        .from('watchlist')
        .delete()
        .eq('user_id', user.id)
        .eq('video_id', videoId);

      if (deleteError) {
        logger.error('Watchlist delete error:', deleteError);
        return res.status(500).json({ error: 'Failed to remove from watchlist' });
      }

      res.status(200).json({
        message: 'Video removed from watchlist'
      });

    } else {
      res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    logger.error('Watchlist API Error:', error);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
} 