import { logger } from "../../server/utils/logger.js";
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client from environment (do NOT commit keys)
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // Verify authentication
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.substring(7);

  try {
    // Verify the session with Supabase
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return res.status(401).json({ error: 'Invalid authentication token' });
    }

    if (req.method === 'GET') {
      // Get user profile
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select(`
          id,
          username,
          display_name,
          avatar_url,
          role,
          subscription_status,
          subscription_expires_at,
          bio,
          social_links,
          preferences,
          avatar_color,
          location,
          website,
          date_of_birth,
          created_at,
          updated_at
        `)
        .eq('id', user.id)
        .single();

      if (profileError && profileError.code !== 'PGRST116') {
        logger.error('Profile fetch error:', profileError);
        return res.status(500).json({ error: 'Failed to fetch profile' });
      }

      // Get user's watch progress
      const { data: watchProgress } = await supabase
        .from('watch_progress')
        .select(`
          video_id,
          progress_seconds,
          completed,
          updated_at,
          videos (
            title,
            thumbnail_url,
            duration
          )
        `)
        .eq('user_id', user.id)
        .order('updated_at', { ascending: false })
        .limit(10);

      // Get user's watchlist
      const { data: watchlist } = await supabase
        .from('watchlist')
        .select(`
          video_id,
          added_at,
          videos (
            title,
            thumbnail_url,
            duration,
            is_premium
          )
        `)
        .eq('user_id', user.id)
        .order('added_at', { ascending: false });

      const profileData = {
        id: user.id,
        email: user.email,
        phone: user.phone,
        emailVerified: !!user.email_confirmed_at,
        phoneVerified: !!user.phone_confirmed_at,
        lastSignInAt: user.last_sign_in_at,
        createdAt: user.created_at,
        profile: profile ? {
          username: profile.username,
          displayName: profile.display_name,
          avatarUrl: profile.avatar_url,
          role: profile.role,
          subscriptionStatus: profile.subscription_status,
          subscriptionExpiresAt: profile.subscription_expires_at,
          bio: profile.bio,
          socialLinks: profile.social_links || {},
          preferences: profile.preferences || {},
          avatarColor: profile.avatar_color,
          location: profile.location,
          website: profile.website,
          dateOfBirth: profile.date_of_birth,
          createdAt: profile.created_at,
          updatedAt: profile.updated_at
        } : null,
        watchProgress: watchProgress || [],
        watchlist: watchlist || []
      };

      res.status(200).json(profileData);

    } else if (req.method === 'PUT') {
      // Update user profile
      const {
        username,
        displayName,
        bio,
        socialLinks,
        preferences,
        avatarColor,
        location,
        website,
        dateOfBirth
      } = req.body;

      // Validate required fields
      if (username && username.trim().length < 3) {
        return res.status(400).json({ error: 'Username must be at least 3 characters long' });
      }

      // Check if username is already taken (if provided)
      if (username) {
        const { data: existingUser } = await supabase
          .from('profiles')
          .select('id')
          .eq('username', username.trim())
          .neq('id', user.id)
          .single();

        if (existingUser) {
          return res.status(400).json({ error: 'Username is already taken' });
        }
      }

      // Prepare update data
      const updateData = {
        updated_at: new Date().toISOString()
      };

      if (username !== undefined) updateData.username = username.trim();
      if (displayName !== undefined) updateData.display_name = displayName;
      if (bio !== undefined) updateData.bio = bio;
      if (socialLinks !== undefined) updateData.social_links = socialLinks;
      if (preferences !== undefined) updateData.preferences = preferences;
      if (avatarColor !== undefined) updateData.avatar_color = avatarColor;
      if (location !== undefined) updateData.location = location;
      if (website !== undefined) updateData.website = website;
      if (dateOfBirth !== undefined) updateData.date_of_birth = dateOfBirth;

      // Update the profile
      const { data: updatedProfile, error: updateError } = await supabase
        .from('profiles')
        .update(updateData)
        .eq('id', user.id)
        .select()
        .single();

      if (updateError) {
        logger.error('Profile update error:', updateError);
        return res.status(500).json({ error: 'Failed to update profile' });
      }

      res.status(200).json({
        message: 'Profile updated successfully',
        profile: {
          username: updatedProfile.username,
          displayName: updatedProfile.display_name,
          bio: updatedProfile.bio,
          socialLinks: updatedProfile.social_links || {},
          preferences: updatedProfile.preferences || {},
          avatarColor: updatedProfile.avatar_color,
          location: updatedProfile.location,
          website: updatedProfile.website,
          dateOfBirth: updatedProfile.date_of_birth,
          updatedAt: updatedProfile.updated_at
        }
      });

    } else {
      res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    logger.error('Profile API Error:', error);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
} 