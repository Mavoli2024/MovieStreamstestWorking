import { logger } from "../../server/utils/logger.js";
import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client from environment (do NOT commit keys)
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!supabaseUrl || !supabaseKey) {
  throw new Error('SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY not configured');
}
const supabase = createClient(supabaseUrl, supabaseKey);

export default async function handler(req, res) {
  // Set CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  // Verify authentication
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.substring(7);

  try {
    // Verify the session with Supabase
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      return res.status(401).json({ error: 'Invalid authentication token' });
    }

    if (req.method === 'GET') {
      const { videoId } = req.query;

      if (videoId) {
        // Get progress for specific video
        const { data: progress, error } = await supabase
          .from('watch_progress')
          .select(`
            id,
            video_id,
            progress_seconds,
            completed,
            updated_at,
            videos (
              title,
              duration
            )
          `)
          .eq('user_id', user.id)
          .eq('video_id', videoId)
          .single();

        if (error && error.code !== 'PGRST116') {
          logger.error('Watch progress fetch error:', error);
          return res.status(500).json({ error: 'Failed to fetch watch progress' });
        }

        res.status(200).json({
          progress: progress ? {
            id: progress.id,
            videoId: progress.video_id,
            progressSeconds: progress.progress_seconds,
            completed: progress.completed,
            updatedAt: progress.updated_at,
            video: progress.videos
          } : null
        });
      } else {
        // Get all progress for user
        const { data: progressList, error } = await supabase
          .from('watch_progress')
          .select(`
            id,
            video_id,
            progress_seconds,
            completed,
            updated_at,
            videos (
              id,
              title,
              thumbnail_url,
              duration,
              release_year
            )
          `)
          .eq('user_id', user.id)
          .order('updated_at', { ascending: false })
          .limit(50);

        if (error) {
          logger.error('Watch progress list fetch error:', error);
          return res.status(500).json({ error: 'Failed to fetch watch progress' });
        }

        const transformedProgress = progressList.map(item => ({
          id: item.id,
          videoId: item.video_id,
          progressSeconds: item.progress_seconds,
          completed: item.completed,
          updatedAt: item.updated_at,
          video: {
            id: item.videos.id,
            title: item.videos.title,
            thumbnailUrl: item.videos.thumbnail_url,
            duration: item.videos.duration,
            releaseYear: item.videos.release_year
          }
        }));

        res.status(200).json({
          progress: transformedProgress,
          count: transformedProgress.length
        });
      }

    } else if (req.method === 'POST' || req.method === 'PUT') {
      // Update watch progress
      const { videoId, progressSeconds, completed = false } = req.body;

      if (!videoId || progressSeconds === undefined) {
        return res.status(400).json({ error: 'Video ID and progress seconds are required' });
      }

      // Validate progress seconds
      if (progressSeconds < 0) {
        return res.status(400).json({ error: 'Progress seconds cannot be negative' });
      }

      // Check if video exists
      const { data: video, error: videoError } = await supabase
        .from('videos')
        .select('id, duration')
        .eq('id', videoId)
        .eq('status', 'published')
        .single();

      if (videoError || !video) {
        return res.status(404).json({ error: 'Video not found' });
      }

      // Auto-complete if progress is near the end (95% or more)
      const completionThreshold = video.duration * 0.95;
      const isCompleted = completed || progressSeconds >= completionThreshold;

      // Check if progress already exists
      const { data: existingProgress } = await supabase
        .from('watch_progress')
        .select('id')
        .eq('user_id', user.id)
        .eq('video_id', videoId)
        .single();

      let result;
      if (existingProgress) {
        // Update existing progress
        const { data: updatedProgress, error: updateError } = await supabase
          .from('watch_progress')
          .update({
            progress_seconds: progressSeconds,
            completed: isCompleted,
            updated_at: new Date().toISOString()
          })
          .eq('id', existingProgress.id)
          .select()
          .single();

        if (updateError) {
          logger.error('Watch progress update error:', updateError);
          return res.status(500).json({ error: 'Failed to update watch progress' });
        }

        result = updatedProgress;
      } else {
        // Create new progress entry
        const { data: newProgress, error: insertError } = await supabase
          .from('watch_progress')
          .insert({
            user_id: user.id,
            video_id: videoId,
            progress_seconds: progressSeconds,
            completed: isCompleted
          })
          .select()
          .single();

        if (insertError) {
          logger.error('Watch progress insert error:', insertError);
          return res.status(500).json({ error: 'Failed to create watch progress' });
        }

        result = newProgress;
      }

      // If completed, also increment view count
      if (isCompleted && (!existingProgress || !existingProgress.completed)) {
        await supabase.rpc('increment_video_views', { video_id_param: videoId });
      }

      res.status(200).json({
        message: 'Watch progress updated successfully',
        progress: {
          id: result.id,
          videoId: result.video_id,
          progressSeconds: result.progress_seconds,
          completed: result.completed,
          updatedAt: result.updated_at
        }
      });

    } else {
      res.status(405).json({ error: 'Method not allowed' });
    }
  } catch (error) {
    logger.error('Watch Progress API Error:', error);
    res.status(500).json({ error: 'Internal server error', details: error.message });
  }
} 