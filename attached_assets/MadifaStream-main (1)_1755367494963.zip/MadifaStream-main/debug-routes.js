import { logger } from "./server/utils/logger.js";
// Debug script to test route mounting
import express from 'express';
import { createApiRouter } from './dist/server/server/routes/index.js';

const app = express();
app.use(express.json());

const router = createApiRouter();

// Simple route counting
logger.info('=== API Router Debug ===');
logger.info('Router stack length:', router?.stack?.length || 'No stack found');

if (router?.stack) {
  router.stack.forEach((layer, i) => {
    logger.info(`Layer ${i}:`, {
      name: layer.name,
      hasRoute: !!layer.route,
      hasHandle: !!layer.handle,
      regexp: layer.regexp?.toString() || 'No regexp'
    });
  });
}

app.use('/api', router);

logger.info('\n=== Testing individual route imports ===');
try {
  const authRoutes = await import('./dist/server/server/routes/auth.js');
  logger.info('✅ Auth routes imported successfully');
  logger.info('Auth router stack length:', authRoutes.default?.stack?.length || 'No stack');
  
  // Check individual auth routes
  if (authRoutes.default?.stack) {
    authRoutes.default.stack.forEach((layer, i) => {
      if (layer.route) {
        logger.info(`  Route ${i}: ${Object.keys(layer.route.methods).join(',').toUpperCase()} ${layer.route.path}`);
      }
    });
  }
} catch (error) {
  logger.info('❌ Auth routes import failed:', error.message);
}

try {
  const adminRoutes = await import('./dist/server/server/routes/admin-cleanup.js');
  logger.info('✅ Admin routes imported successfully'); 
  logger.info('Admin router stack length:', adminRoutes.default?.stack?.length || 'No stack');
  
  // Check individual admin routes  
  if (adminRoutes.default?.stack) {
    adminRoutes.default.stack.forEach((layer, i) => {
      if (layer.route) {
        logger.info(`  Route ${i}: ${Object.keys(layer.route.methods).join(',').toUpperCase()} ${layer.route.path}`);
      }
    });
  }
} catch (error) {
  logger.info('❌ Admin routes import failed:', error.message);
}

logger.info('\n=== Testing router layer regex patterns ===');
if (router?.stack) {
  router.stack.forEach((layer, i) => {
    if (layer.regexp) {
      const source = layer.regexp.source || 'No source';
      logger.info(`Layer ${i} regexp: ${source}`);
    }
  });
}