import react from '@vitejs/plugin-react-swc'
import path from "path"
import { defineConfig } from 'vite'

// Production-only Vite config - excludes @shared alias to avoid server-side dependencies
export default defineConfig({
  root: __dirname,
  appType: 'spa',
  base: '/',
  optimizeDeps: {
    include: [
      'react',
      'react-dom',
      '@supabase/supabase-js',
      '@tanstack/react-query',
      'lucide-react',
      'wouter',
      'react-hook-form'
    ],
    exclude: ['@capacitor/core', '@capacitor/app']
  },
  plugins: [
    react()
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
      "@shared": path.resolve(__dirname, "../shared"),
    },
  },
  define: {
    'process.env.NODE_ENV': JSON.stringify('production'),
  },
  envPrefix: [
    'VITE_',
    'SUPABASE_',
    'BUNNY_',
    'BACKEND_',
    'PAYFAST_',
    'APP_',
  ],
  build: {
    outDir: '../dist/public',
    emptyOutDir: true,
    sourcemap: false,
    target: 'es2020',
    minify: 'terser',
    assetsDir: 'assets',
    cssCodeSplit: true,
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
      },
    },
    rollupOptions: {
      output: {
        manualChunks: (id) => {
          // React ecosystem
          if (id.includes('react') || id.includes('react-dom') || id.includes('react-router')) {
            return 'react-vendor';
          }
          
          // Supabase and auth
          if (id.includes('@supabase') || id.includes('supabase-js')) {
            return 'supabase';
          }
          
          // UI libraries
          if (id.includes('@radix-ui') || id.includes('lucide-react') || id.includes('@headlessui')) {
            return 'ui-vendor';
          }
          
          // Query and state management
          if (id.includes('@tanstack/react-query') || id.includes('react-hook-form')) {
            return 'query-vendor';
          }
          
          // Video and media related
          if (id.includes('hls.js') || id.includes('video') || id.includes('media')) {
            return 'media-vendor';
          }
          
          // Mobile and Capacitor
          if (id.includes('@capacitor') || id.includes('capacitor')) {
            return 'mobile-vendor';
          }
          
          // Node modules
          if (id.includes('node_modules')) {
            return 'vendor';
          }
        },
        chunkFileNames: `assets/[name]-[hash].js`,
        assetFileNames: `assets/[name]-[hash].[ext]`,
      },
    },
    chunkSizeWarningLimit: 1000,
  },
  server: {
    port: 5173,
    host: true
  },
  preview: {
    port: 4321,
    host: true
  }
}) 