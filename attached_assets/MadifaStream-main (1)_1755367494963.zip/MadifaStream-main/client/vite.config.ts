import react from "@vitejs/plugin-react";
import path from "path";
import { defineConfig } from "vite";

// Load environment variables from .env files (handled by Vite automatically for VITE_ prefixes)
// For non-VITE_ prefixed variables used in this config, ensure they are set in the environment
// or use a package like dotenv if this config runs in a Node.js context before Vite processing.

// We will rely on Vite's built-in .env loading for VITE_ variables.
// For SUPABASE_URL and SUPABASE_ANON_KEY if used directly by server-side logic within Vite's config process,
// they would need to be available in the Node.js environment where Vite runs.

// The define block below will correctly pass VITE_ prefixed variables to client code.
// Ensure VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY, and VITE_SITE_URL are in your .env file.

export default defineConfig({
  plugins: [react()],
  root: './client',
  base: '/',
  build: {
    outDir: "../dist/public",
    emptyOutDir: true,
    sourcemap: false,
    minify: "terser",
    chunkSizeWarningLimit: 1000,
    rollupOptions: {
      output: {
        manualChunks: (id) => {
          // Keep React in main entry chunk to prevent loading issues
          if (id.includes('react') || id.includes('react-dom')) {
            return undefined; // Don't split React
          }
          
          // Bundle all vendor libraries together
          if (id.includes('node_modules')) {
            return 'vendor';
          }
        },
        chunkFileNames: 'assets/[name]-[hash].js',
        assetFileNames: 'assets/[name]-[hash].[ext]'
      }
    },
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
        pure_funcs: ['console.log', 'console.info', 'console.debug', 'console.warn']
      }
    }
  },
  define: {
    // These will be available in your client code
    "process.env.VITE_SUPABASE_URL": JSON.stringify(process.env.VITE_SUPABASE_URL),
    "process.env.VITE_SUPABASE_ANON_KEY": JSON.stringify(process.env.VITE_SUPABASE_ANON_KEY),
    "process.env.VITE_SITE_URL": JSON.stringify(process.env.VITE_SITE_URL),
  },
  server: {
    port: 5173,
    host: true,
    strictPort: true,
    proxy: {
      '/api': {
        target: 'http://127.0.0.1:5001',
        changeOrigin: true,
        secure: false,
      },
    },
  },
  preview: {
    port: 4173,
    host: true,
    strictPort: true,
  },
  optimizeDeps: {
    include: [
      'react',
      'react-dom',
      'wouter',
      '@supabase/supabase-js',
      'react-hook-form',
      '@hookform/resolvers',
      'lucide-react',
      'clsx',
      'tailwind-merge'
    ],
    exclude: [
      'axe-core'
    ]
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
      "@shared": path.resolve(__dirname, "./src/shared"),
    },
    dedupe: ['react', 'react-dom']
  }
}); 