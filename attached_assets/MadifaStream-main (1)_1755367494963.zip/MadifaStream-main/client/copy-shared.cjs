const fs = require('fs');
const path = require('path');

function copyDir(src, dest) {
  if (!fs.existsSync(dest)) {
    fs.mkdirSync(dest, { recursive: true });
  }
  
  const entries = fs.readdirSync(src, { withFileTypes: true });
  
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

try {
  // Try sibling "../shared" first; if not found (e.g. Vercel monorepo build),
  // check "../../shared" which is two levels up from `/vercel/path1`.
  const candidatePaths = [
    path.join(__dirname, '..', 'shared'),
    path.join(__dirname, '..', '..', 'shared')
  ];

  const sharedSrc = candidatePaths.find((p) => fs.existsSync(p));

  if (!sharedSrc) {
    throw new Error('Unable to locate "shared" directory. Checked: ' + candidatePaths.join(', '));
  }
  const sharedDest = path.join(__dirname, 'src', 'shared');
  
  console.log('Copying shared files...');
  console.log(`From: ${sharedSrc}`);
  console.log(`To: ${sharedDest}`);
  
  copyDir(sharedSrc, sharedDest);
  console.log('Shared files copied successfully!');
} catch (error) {
  console.error('Error copying shared files:', error);
  process.exit(1);
} 