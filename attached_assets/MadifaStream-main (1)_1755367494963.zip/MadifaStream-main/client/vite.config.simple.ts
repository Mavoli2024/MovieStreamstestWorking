import react from '@vitejs/plugin-react-swc'
import path from "path"
import { defineConfig } from 'vite'

// Minimal Vite config for deployment testing - removes complex optimizations that might cause issues
export default defineConfig({
  root: __dirname,
  appType: 'spa',
  base: '/',
  plugins: [
    react()
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
      "@shared": path.resolve(__dirname, "../shared"),
    },
  },
  define: {
    'process.env.NODE_ENV': JSON.stringify('production'),
  },
  envPrefix: [
    'VITE_',
    'SUPABASE_',
    'BUNNY_',
    'BACKEND_',
    'PAYFAST_',
    'APP_',
  ],
  build: {
    outDir: '../dist/public',
    emptyOutDir: true,
    target: 'es2020',
    minify: false, // Disable minification for debugging
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom'],
          'vendor': ['@supabase/supabase-js', '@tanstack/react-query', 'lucide-react', 'wouter']
        }
      }
    }
  }
}) 