import React from 'react';
import { createRoot } from 'react-dom/client';
import { UnifiedErrorBoundary } from "./components/error-boundary/UnifiedErrorBoundary";
import App from './App';
import './index.css';
import './styles/globals.css';
import { logger } from '@shared/logger';

// Test imports one by one to isolate the culprit
import {  AppErrorBoundary  } from '@/components/error-boundary/AppErrorBoundary';

// Step 3: Test AppErrorBoundary specifically (different from UnifiedErrorBoundary)
function TestAppErrorBoundary() {
  return (
    <div>
      <div style={{ padding: '10px', background: '#e3f2fd', marginBottom: '10px' }}>
        <strong>Isolation Test: Step 3 - Testing AppErrorBoundary</strong>
        <p>If this loads, AppErrorBoundary is NOT the issue.</p>
        <p>If this breaks, AppErrorBoundary IS the culprit!</p>
      </div>
      
      <AppErrorBoundary
        onError={(error, errorInfo) => {
          logger.info('AppErrorBoundary caught error:', { arg1: error, arg2: errorInfo });
        }}
      >
        <div style={{ padding: '20px', background: '#f5f5f5' }}>
          <h2>Test Content Inside AppErrorBoundary</h2>
          <p>This content is wrapped in AppErrorBoundary.</p>
          <p>Current time: {new Date().toLocaleTimeString()}</p>
        </div>
      </AppErrorBoundary>
    </div>
  );
}

// Render with our proven-working error boundary
const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <UnifiedErrorBoundary errorType="generic" variant="detailed">
      <TestAppErrorBoundary />
    </UnifiedErrorBoundary>
  );
} else {
  logger.error('Root element not found');
} 