import React, { createContext, useContext, useState, useCallback, ReactNode } from 'react';

// Display mode types
export type DisplayMode = 
  | 'grid-comfortable' 
  | 'grid-compact' 
  | 'grid-cozy'
  | 'list-detailed'
  | 'list-compact'
  | 'table-row'
  | 'masonry';

export type CardSize = 'small' | 'medium' | 'large';

export interface DisplayModeSettings {
  mode: DisplayMode;
  cardSize: CardSize;
  showViews: boolean;
  showRating: boolean;
  showGenres: boolean;
  showDuration: boolean;
  enableLazyLoading: boolean;
  enableHoverPreview: boolean;
  showActions: boolean;
  itemsPerRow?: number; // For grid modes
  enableVirtualScrolling: boolean;
}

export interface DisplayModeContextType {
  settings: DisplayModeSettings;
  updateSettings: (newSettings: Partial<DisplayModeSettings>) => void;
  setDisplayMode: (mode: DisplayMode) => void;
  setCardSize: (size: CardSize) => void;
  getGridColumns: () => number;
  getOptimalSettings: (mode: DisplayMode) => Partial<DisplayModeSettings>;
  presets: Record<string, DisplayModeSettings>;
  applyPreset: (presetName: string) => void;
}

// Default settings
const defaultSettings: DisplayModeSettings = {
  mode: 'grid-comfortable',
  cardSize: 'medium',
  showViews: true,
  showRating: true,
  showGenres: true,
  showDuration: true,
  enableLazyLoading: true,
  enableHoverPreview: true,
  showActions: true,
  enableVirtualScrolling: false,
};

// Predefined presets for different use cases
const presets: Record<string, DisplayModeSettings> = {
  'performance': {
    ...defaultSettings,
    mode: 'grid-compact',
    cardSize: 'small',
    showViews: false,
    showRating: false,
    showGenres: false,
    enableHoverPreview: false,
    enableVirtualScrolling: true,
  },
  'detailed': {
    ...defaultSettings,
    mode: 'list-detailed',
    cardSize: 'large',
    showViews: true,
    showRating: true,
    showGenres: true,
    enableHoverPreview: true,
  },
  'minimal': {
    ...defaultSettings,
    mode: 'grid-compact',
    cardSize: 'small',
    showViews: false,
    showRating: false,
    showGenres: false,
    showActions: false,
    enableHoverPreview: false,
  },
  'cozy': {
    ...defaultSettings,
    mode: 'grid-cozy',
    cardSize: 'large',
    showViews: true,
    showRating: true,
    showGenres: true,
    enableHoverPreview: true,
  },
  'table': {
    ...defaultSettings,
    mode: 'table-row',
    cardSize: 'small',
    showViews: true,
    showRating: true,
    showGenres: false,
    enableHoverPreview: false,
    enableVirtualScrolling: true,
  },
  'masonry': {
    ...defaultSettings,
    mode: 'masonry',
    cardSize: 'medium',
    showViews: true,
    showRating: true,
    showGenres: true,
    enableHoverPreview: true,
  }
};

// Optimal settings for each display mode
const optimalSettings: Record<DisplayMode, Partial<DisplayModeSettings>> = {
  'grid-comfortable': {
    cardSize: 'medium',
    showGenres: true,
    enableHoverPreview: true,
    itemsPerRow: 4,
  },
  'grid-compact': {
    cardSize: 'small',
    showGenres: false,
    enableHoverPreview: false,
    itemsPerRow: 6,
  },
  'grid-cozy': {
    cardSize: 'large',
    showGenres: true,
    enableHoverPreview: true,
    itemsPerRow: 3,
  },
  'list-detailed': {
    cardSize: 'large',
    showGenres: true,
    showViews: true,
    showRating: true,
    enableHoverPreview: true,
  },
  'list-compact': {
    cardSize: 'medium',
    showGenres: false,
    showViews: false,
    enableHoverPreview: false,
  },
  'table-row': {
    cardSize: 'small',
    showGenres: false,
    enableHoverPreview: false,
    enableVirtualScrolling: true,
  },
  'masonry': {
    cardSize: 'medium',
    showGenres: true,
    enableHoverPreview: true,
  },
};

const DisplayModeContext = createContext<DisplayModeContextType | undefined>(undefined);

export interface DisplayModeProviderProps {
  children: ReactNode;
  initialSettings?: Partial<DisplayModeSettings>;
}

export const DisplayModeProvider: React.FC<DisplayModeProviderProps> = ({ 
  children, 
  initialSettings = {} 
}) => {
  const [settings, setSettings] = useState<DisplayModeSettings>({
    ...defaultSettings,
    ...initialSettings,
  });

  const updateSettings = useCallback((newSettings: Partial<DisplayModeSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  const setDisplayMode = useCallback((mode: DisplayMode) => {
    const optimal = optimalSettings[mode];
    setSettings(prev => ({ 
      ...prev, 
      mode, 
      ...optimal 
    }));
  }, []);

  const setCardSize = useCallback((size: CardSize) => {
    setSettings(prev => ({ ...prev, cardSize: size }));
  }, []);

  const getGridColumns = useCallback((): number => {
    const { mode, cardSize } = settings;
    
    if (!mode.startsWith('grid')) return 1;
    
    // Base columns by mode
    let baseColumns = optimalSettings[mode]?.itemsPerRow || 4;
    
    // Adjust by card size
    switch (cardSize) {
      case 'small':
        baseColumns += 2;
        break;
      case 'large':
        baseColumns = Math.max(2, baseColumns - 1);
        break;
      default:
        // medium - use base
        break;
    }
    
    return Math.min(8, Math.max(2, baseColumns));
  }, [settings]);

  const getOptimalSettings = useCallback((mode: DisplayMode) => {
    return optimalSettings[mode] || {};
  }, []);

  const applyPreset = useCallback((presetName: string) => {
    const preset = presets[presetName];
    if (preset) {
      setSettings(preset);
    }
  }, []);

  const value: DisplayModeContextType = {
    settings,
    updateSettings,
    setDisplayMode,
    setCardSize,
    getGridColumns,
    getOptimalSettings,
    presets,
    applyPreset,
  };

  return (
    <DisplayModeContext.Provider value={value}>
      {children}
    </DisplayModeContext.Provider>
  );
};

export const useDisplayMode = (): DisplayModeContextType => {
  const context = useContext(DisplayModeContext);
  if (context === undefined) {
    throw new Error('useDisplayMode must be used within a DisplayModeProvider');
  }
  return context;
};

// Hook for responsive grid columns based on screen size
export const useResponsiveColumns = () => {
  const { getGridColumns, settings } = useDisplayMode();
  
  const getResponsiveColumns = useCallback(() => {
    const baseColumns = getGridColumns();
    
    // Responsive breakpoints
    const width = typeof window !== 'undefined' ? window.innerWidth : 1200;
    
    if (width < 640) { // sm
      return Math.min(2, baseColumns);
    } else if (width < 768) { // md
      return Math.min(3, baseColumns);
    } else if (width < 1024) { // lg
      return Math.min(4, Math.max(2, baseColumns - 1));
    } else if (width < 1280) { // xl
      return Math.min(5, baseColumns);
    } else { // 2xl
      return Math.min(6, baseColumns);
    }
  }, [getGridColumns]);

  return getResponsiveColumns;
};

// Hook for conditional display settings based on mode
export const useDisplaySettings = () => {
  const { settings } = useDisplayMode();
  
  const isGridMode = settings.mode.startsWith('grid');
  const isListMode = settings.mode.startsWith('list');
  const isTableMode = settings.mode === 'table-row';
  const isMasonryMode = settings.mode === 'masonry';
  
  const shouldShowGenres = settings.showGenres && (isGridMode || isListMode || isMasonryMode);
  const shouldShowActions = settings.showActions && !isTableMode;
  const shouldEnableHover = settings.enableHoverPreview && !isTableMode;
  
  return {
    ...settings,
    isGridMode,
    isListMode,
    isTableMode,
    isMasonryMode,
    shouldShowGenres,
    shouldShowActions,
    shouldEnableHover,
  };
};

export default DisplayModeContext; 