/**
 * React Theme Context Provider
 * 
 * Provides theme state management and utilities throughout the application
 * using our centralized theme system and design tokens.
 */

import React, { createContext, useContext, useEffect, useState } from 'react';
import { ThemeMode, applyTheme, themeUtils } from '../styles/theme';

// Theme context type
interface ThemeContextType {
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
  isDark: boolean;
  toggleTheme: () => void;
}

// Create theme context
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// Theme provider props
interface ThemeProviderProps {
  children: React.ReactNode;
  defaultMode?: ThemeMode;
}

// Theme provider component
export const ThemeProvider: React.FC<ThemeProviderProps> = ({ 
  children, 
  defaultMode = 'system' 
}) => {
  const [mode, setMode] = useState<ThemeMode>(() => {
    // Get saved theme from localStorage
    const savedTheme = localStorage.getItem('theme-mode') as ThemeMode;
    return savedTheme || defaultMode;
  });

  const [isDark, setIsDark] = useState(() => {
    if (mode === 'system') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return mode === 'dark';
  });

  // Apply theme when mode changes
  useEffect(() => {
    applyTheme(mode);
    
    // Save to localStorage
    localStorage.setItem('theme-mode', mode);
    
    // Update isDark state
    setIsDark(themeUtils.isDarkMode());
  }, [mode]);

  // Listen for system theme changes
  useEffect(() => {
    if (mode === 'system') {
      const cleanup = themeUtils.watchSystemTheme((systemIsDark) => {
        setIsDark(systemIsDark);
        applyTheme('system');
      });
      
      return cleanup;
    }
  }, [mode]);

  // Toggle between light and dark themes
  const toggleTheme = () => {
    if (mode === 'system') {
      setMode('light');
    } else if (mode === 'light') {
      setMode('dark');
    } else {
      setMode('light');
    }
  };

  const value: ThemeContextType = {
    mode,
    setMode,
    isDark,
    toggleTheme,
  };

  return (
    <ThemeContext.Provider value={value}>
      {children}
    </ThemeContext.Provider>
  );
};

// Custom hook to use theme context
export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

// Theme toggle button component
export const ThemeToggle: React.FC<{ className?: string }> = ({ className = '' }) => {
  const { mode, setMode, isDark } = useTheme();

  const handleThemeChange = (newMode: ThemeMode) => {
    setMode(newMode);
  };

  return (
    <div className={`theme-toggle ${className}`}>
      <button
        onClick={() => handleThemeChange('light')}
        className={`p-2 rounded-md transition-colors ${
          mode === 'light' 
            ? 'bg-primary text-primary-foreground' 
            : 'bg-muted text-muted-foreground hover:bg-muted/80'
        }`}
        aria-label="Light theme"
        title="Light theme"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2.5a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0V3a.5.5 0 0 1 .5-.5zM7.5 6.5a.5.5 0 0 0 0 1h9a.5.5 0 0 0 0-1h-9zm-1.5 6a6 6 0 1 1 12 0 6 6 0 0 1-12 0z"/>
        </svg>
      </button>
      
      <button
        onClick={() => handleThemeChange('dark')}
        className={`p-2 rounded-md transition-colors ${
          mode === 'dark' 
            ? 'bg-primary text-primary-foreground' 
            : 'bg-muted text-muted-foreground hover:bg-muted/80'
        }`}
        aria-label="Dark theme"
        title="Dark theme"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9z"/>
        </svg>
      </button>
      
      <button
        onClick={() => handleThemeChange('system')}
        className={`p-2 rounded-md transition-colors ${
          mode === 'system' 
            ? 'bg-primary text-primary-foreground' 
            : 'bg-muted text-muted-foreground hover:bg-muted/80'
        }`}
        aria-label="System theme"
        title="System theme"
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
          <path d="M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6zM6 8v5h12V8H6z"/>
        </svg>
      </button>
    </div>
  );
};

// Utility component for theme-aware conditional rendering
export const ThemeAware: React.FC<{
  children: React.ReactNode;
  lightOnly?: boolean;
  darkOnly?: boolean;
}> = ({ children, lightOnly = false, darkOnly = false }) => {
  const { isDark } = useTheme();
  
  if (lightOnly && isDark) return null;
  if (darkOnly && !isDark) return null;
  
  return <>{children}</>;
};
