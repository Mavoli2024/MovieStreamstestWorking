import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Router } from 'wouter';
import { memoryLocation } from 'wouter/memory-location';
import { RouteGuard } from '@/components/navigation/RouteGuard';
import { useAuthStore } from '@/stores/authStore';
import { APP_ROUTES } from '@/lib/routes';

// Mock the auth store
vi.mock('@/stores/authStore', () => ({
  useAuthStore: vi.fn(),
}));

describe('Navigation Guards Integration Tests', () => {
  let queryClient: QueryClient;
  let mockAuthStore: any;

  beforeEach(() => {
    queryClient = new QueryClient({
      defaultOptions: {
        queries: { retry: false },
        mutations: { retry: false },
      },
    });
    
    mockAuthStore = {
      user: null,
      isLoading: false,
      error: null,
    };
    
    vi.mocked(useAuthStore).mockReturnValue(mockAuthStore);
  });

  const renderWithProviders = (component: React.ReactElement, initialPath = '/') => {
    const { hook } = memoryLocation({ path: initialPath });
    
    return render(
      <QueryClientProvider client={queryClient}>
        <Router hook={hook}>
          {component}
        </Router>
      </QueryClientProvider>
    );
  };

  describe('RouteGuard', () => {
    it('should redirect to auth when user is not authenticated', async () => {
      mockAuthStore.user = null;
      
      renderWithProviders(
        <RouteGuard
          requireAuth={true}
          redirectTo="/auth"
          fallback={<div>Loading...</div>}
        >
          <div>Protected Content</div>
        </RouteGuard>,
        '/profile'
      );

      await waitFor(() => {
        expect(screen.queryByText('Protected Content')).not.toBeInTheDocument();
      });
    });

    it('should show protected content when user is authenticated', async () => {
      mockAuthStore.user = { 
        id: '1', 
        email: 'test@example.com', 
        username: 'testuser' 
      };
      
      renderWithProviders(
        <RouteGuard
          requireAuth={true}
          redirectTo="/auth"
          fallback={<div>Loading...</div>}
        >
          <div>Protected Content</div>
        </RouteGuard>,
        '/profile'
      );

      await waitFor(() => {
        expect(screen.getByText('Protected Content')).toBeInTheDocument();
      });
    });

    it('should redirect authenticated users from auth pages', async () => {
      mockAuthStore.user = { 
        id: '1', 
        email: 'test@example.com', 
        username: 'testuser' 
      };
      
      renderWithProviders(
        <RouteGuard
          requireAuth={false}
          redirectTo="/home"
          fallback={<div>Loading...</div>}
        >
          <div>Auth Page</div>
        </RouteGuard>,
        '/auth'
      );

      await waitFor(() => {
        expect(screen.queryByText('Auth Page')).not.toBeInTheDocument();
      });
    });

    it('should show loading state when auth is loading', () => {
      mockAuthStore.isLoading = true;
      
      renderWithProviders(
        <RouteGuard
          requireAuth={true}
          redirectTo="/auth"
          fallback={<div>Loading...</div>}
        >
          <div>Protected Content</div>
        </RouteGuard>,
        '/profile'
      );

      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    it('should handle role-based access control', async () => {
      mockAuthStore.user = { 
        id: '1', 
        email: 'test@example.com', 
        username: 'testuser',
        role: 'user'
      };
      
      renderWithProviders(
        <RouteGuard
          requireAuth={true}
          requiredRole="admin"
          redirectTo="/unauthorized"
          fallback={<div>Loading...</div>}
        >
          <div>Admin Content</div>
        </RouteGuard>,
        '/admin'
      );

      await waitFor(() => {
        expect(screen.queryByText('Admin Content')).not.toBeInTheDocument();
      });
    });
  });

  describe('Route Configuration', () => {
    it('should have proper route configuration for protected routes', () => {
      const protectedRoutes = APP_ROUTES.filter(route => route.requireAuth);
      expect(protectedRoutes.some(route => route.path === '/profile' && route.requireAuth)).toBe(true);
      expect(protectedRoutes.some(route => route.path === '/my-list' && route.requireAuth)).toBe(true);
    });

    it('should have proper route configuration for public routes', () => {
      const publicRoutes = APP_ROUTES.filter(route => !route.requireAuth);
      expect(publicRoutes.some(route => route.path === '/' && !route.requireAuth)).toBe(true);
      expect(publicRoutes.some(route => route.path === '/auth' && !route.requireAuth)).toBe(true);
    });
  });
});
