import { describe, it, expect, beforeEach, vi } from 'vitest';
import { act, renderHook } from '@testing-library/react';
import { useAuthStore } from '@/stores/authStore';
import { useUIStore } from '@/stores/uiStore';
import { supabase } from '@/lib/supabase';

// Mock Supabase
vi.mock('@/lib/supabase', () => ({
  supabase: {
    auth: {
      signInWithPassword: vi.fn(),
      signUp: vi.fn(),
      signOut: vi.fn(),
      getSession: vi.fn(),
      onAuthStateChange: vi.fn(() => ({
        data: { subscription: { unsubscribe: vi.fn() } },
      })),
    },
  },
}));

describe('State Slices Integration Tests', () => {
  beforeEach(() => {
    // Reset stores before each test
    useAuthStore.getState().reset?.();
    useUIStore.getState().reset?.();
    vi.clearAllMocks();
  });

  describe('AuthStore', () => {
    it('should initialize with default state', () => {
      const { result } = renderHook(() => useAuthStore());
      
      expect(result.current.user).toBeNull();
      expect(result.current.isLoading).toBe(false);
      expect(result.current.error).toBeNull();
    });

    it('should handle login success', async () => {
      const mockUser = {
        id: '1',
        email: 'test@example.com',
        username: 'testuser',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
        confirmation_sent_at: null,
        recovery_sent_at: null,
        email_change_sent_at: null,
        new_email: null,
        new_phone: null,
        invited_at: null,
        action_link: null,
        email_confirmed_at: null,
        phone_confirmed_at: null,
        confirmed_at: null,
        last_sign_in_at: null,
        role: 'authenticated',
        updated_at: new Date().toISOString(),
        identities: [],
        factors: [],
        is_anonymous: false,
        phone: null
      };

      vi.mocked(supabase.auth.signInWithPassword).mockResolvedValue({
        data: { 
          user: mockUser, 
          session: { 
            access_token: 'token',
            refresh_token: 'refresh_token',
            expires_in: 3600,
            token_type: 'bearer',
            user: mockUser
          } 
        },
        error: null,
      });

      const { result } = renderHook(() => useAuthStore());

      await act(async () => {
        await result.current.login('test@example.com', 'password123');
      });

      expect(result.current.user).toEqual(mockUser);
      expect(result.current.isLoading).toBe(false);
      expect(result.current.error).toBeNull();
    });

    it('should handle login failure', async () => {
      const mockError = { 
        message: 'Invalid credentials',
        name: 'AuthError',
        code: 'invalid_credentials',
        status: 400,
        __isAuthError: true
      };

      vi.mocked(supabase.auth.signInWithPassword).mockResolvedValue({
        data: { user: null, session: null },
        error: mockError,
      });

      const { result } = renderHook(() => useAuthStore());

      await act(async () => {
        try {
          await result.current.login('test@example.com', 'wrongpassword');
        } catch (error) {
          // Expected to throw
        }
      });

      expect(result.current.user).toBeNull();
      expect(result.current.isLoading).toBe(false);
      expect(result.current.error).toEqual(mockError);
    });

    it('should handle register success', async () => {
      const mockUser = {
        id: '1',
        email: 'test@example.com',
        username: 'testuser',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
        confirmation_sent_at: null,
        recovery_sent_at: null,
        email_change_sent_at: null,
        new_email: null,
        new_phone: null,
        invited_at: null,
        action_link: null,
        email_confirmed_at: null,
        phone_confirmed_at: null,
        confirmed_at: null,
        last_sign_in_at: null,
        role: 'authenticated',
        updated_at: new Date().toISOString(),
        identities: [],
        factors: [],
        is_anonymous: false,
        phone: null
      };

      vi.mocked(supabase.auth.signUp).mockResolvedValue({
        data: { 
          user: mockUser, 
          session: { 
            access_token: 'token',
            refresh_token: 'refresh_token',
            expires_in: 3600,
            token_type: 'bearer',
            user: mockUser
          } 
        },
        error: null,
      });

      const { result } = renderHook(() => useAuthStore());

      await act(async () => {
        await result.current.register('test@example.com', 'password123');
      });

      expect(result.current.user).toEqual(mockUser);
      expect(result.current.isLoading).toBe(false);
      expect(result.current.error).toBeNull();
    });

    it('should handle logout', async () => {
      // First set a user
      const { result } = renderHook(() => useAuthStore());
      
      act(() => {
        result.current.setUser({
          id: '1',
          email: 'test@example.com',
          username: 'testuser',
        });
      });

      vi.mocked(supabase.auth.signOut).mockResolvedValue({
        error: null,
      });

      await act(async () => {
        await result.current.logout();
      });

      expect(result.current.user).toBeNull();
      expect(result.current.isLoading).toBe(false);
      expect(result.current.error).toBeNull();
    });
  });

  describe('UIStore', () => {
    it('should initialize with default state', () => {
      const { result } = renderHook(() => useUIStore());
      
      expect(result.current.theme).toBe('dark');
      expect(result.current.sidebar.isOpen).toBe(false);
      expect(result.current.modal.isOpen).toBe(false);
      expect(result.current.toast.items).toEqual([]);
      expect(result.current.loading.global).toBe(false);
    });

    it('should handle theme toggle', () => {
      const { result } = renderHook(() => useUIStore());

      act(() => {
        result.current.setTheme('light');
      });

      expect(result.current.theme).toBe('light');

      act(() => {
        result.current.toggleTheme();
      });

      expect(result.current.theme).toBe('dark');
    });

    it('should handle sidebar state', () => {
      const { result } = renderHook(() => useUIStore());

      act(() => {
        result.current.sidebar.open();
      });

      expect(result.current.sidebar.isOpen).toBe(true);

      act(() => {
        result.current.sidebar.close();
      });

      expect(result.current.sidebar.isOpen).toBe(false);

      act(() => {
        result.current.sidebar.toggle();
      });

      expect(result.current.sidebar.isOpen).toBe(true);
    });

    it('should handle modal state', () => {
      const { result } = renderHook(() => useUIStore());

      const modalData = { title: 'Test Modal', content: 'Test content' };

      act(() => {
        result.current.modal.open(modalData);
      });

      expect(result.current.modal.isOpen).toBe(true);
      expect(result.current.modal.data).toEqual(modalData);

      act(() => {
        result.current.modal.close();
      });

      expect(result.current.modal.isOpen).toBe(false);
      expect(result.current.modal.data).toBeNull();
    });

    it('should handle toast messages', () => {
      const { result } = renderHook(() => useUIStore());

      const toastMessage = {
        id: '1',
        message: 'Test message',
        type: 'success' as const,
      };

      act(() => {
        result.current.toast.add(toastMessage);
      });

      expect(result.current.toast.items).toContain(toastMessage);

      act(() => {
        result.current.toast.remove('1');
      });

      expect(result.current.toast.items).not.toContain(toastMessage);
    });

    it('should handle loading state', () => {
      const { result } = renderHook(() => useUIStore());

      act(() => {
        result.current.loading.setGlobal(true);
      });

      expect(result.current.loading.global).toBe(true);

      act(() => {
        result.current.loading.setGlobal(false);
      });

      expect(result.current.loading.global).toBe(false);

      act(() => {
        result.current.loading.setOperation('login', true);
      });

      expect(result.current.loading.operations.login).toBe(true);

      act(() => {
        result.current.loading.setOperation('login', false);
      });

      expect(result.current.loading.operations.login).toBe(false);
    });
  });

  describe('Store Integration', () => {
    it('should handle auth state changes affecting UI', async () => {
      const { result: authResult } = renderHook(() => useAuthStore());
      const { result: uiResult } = renderHook(() => useUIStore());

      // Mock successful login
      const mockUser = {
        id: '1',
        email: 'test@example.com',
        username: 'testuser',
        app_metadata: {},
        user_metadata: {},
        aud: 'authenticated',
        created_at: new Date().toISOString(),
        confirmation_sent_at: null,
        recovery_sent_at: null,
        email_change_sent_at: null,
        new_email: null,
        new_phone: null,
        invited_at: null,
        action_link: null,
        email_confirmed_at: null,
        phone_confirmed_at: null,
        confirmed_at: null,
        last_sign_in_at: null,
        role: 'authenticated',
        updated_at: new Date().toISOString(),
        identities: [],
        factors: [],
        is_anonymous: false,
        phone: null
      };
      
      vi.mocked(supabase.auth.signInWithPassword).mockResolvedValue({
        data: { 
          user: mockUser,
          session: { 
            access_token: 'token',
            refresh_token: 'refresh_token',
            expires_in: 3600,
            token_type: 'bearer',
            user: mockUser
          } 
        },
        error: null,
      });

      await act(async () => {
        await authResult.current.login('test@example.com', 'password123');
      });

      // UI should potentially close any auth modals
      expect(authResult.current.user).toBeTruthy();
      expect(authResult.current.isLoading).toBe(false);
    });

    it('should handle auth errors affecting UI notifications', async () => {
      const { result: authResult } = renderHook(() => useAuthStore());
      const { result: uiResult } = renderHook(() => useUIStore());

      const mockError = { 
        message: 'Invalid credentials',
        name: 'AuthError',
        code: 'invalid_credentials',
        status: 400,
        __isAuthError: true
      };

      vi.mocked(supabase.auth.signInWithPassword).mockResolvedValue({
        data: { user: null, session: null },
        error: mockError,
      });

      await act(async () => {
        try {
          await authResult.current.login('test@example.com', 'wrongpassword');
        } catch (error) {
          // Expected to throw
        }
      });

      expect(authResult.current.error).toEqual(mockError);
      expect(authResult.current.user).toBeNull();
    });
  });
});
