interface LogLevel {
  ERROR: 'error';
  WARN: 'warn';
  INFO: 'info';
  DEBUG: 'debug';
}

const LOG_LEVELS: LogLevel = {
  ERROR: 'error',
  WARN: 'warn',
  INFO: 'info',
  DEBUG: 'debug'
};

interface LogEntry {
  level: string;
  message: string;
  timestamp: string;
  data?: any;
  source?: string;
}

class ProductionLogger {
  private isProduction: boolean;
  private isDevelopment: boolean;

  constructor() {
    // Check both process.env and import.meta.env for compatibility
    this.isProduction = this.getNodeEnv() === 'production';
    this.isDevelopment = !this.isProduction;
  }

  private getNodeEnv(): string {
    // Server-side: use process.env
    if (typeof process !== 'undefined' && process.env && process.env.NODE_ENV) {
      return process.env.NODE_ENV;
    }
    
    // Default for environments where we can't detect
    return 'development';
  }

  private formatMessage(level: string, message: string, data?: any, source?: string): LogEntry {
    return {
      level,
      message,
      timestamp: new Date().toISOString(),
      data,
      source
    };
  }

  private logToConsole(entry: LogEntry): void {
    if (!this.isDevelopment) return;

    const prefix = `[${entry.level.toUpperCase()}] ${entry.timestamp}`;
    const fullMessage = entry.source ? `${prefix} [${entry.source}] ${entry.message}` : `${prefix} ${entry.message}`;

    switch (entry.level) {
      case LOG_LEVELS.ERROR:
        console.error(fullMessage, entry.data || '');
        break;
      case LOG_LEVELS.WARN:
        console.warn(fullMessage, entry.data || '');
        break;
      case LOG_LEVELS.INFO:
        console.log(fullMessage, entry.data || '');
        break;
      case LOG_LEVELS.DEBUG:
        console.debug(fullMessage, entry.data || '');
        break;
      default:
        console.log(fullMessage, entry.data || '');
    }
  }

  private logToService(entry: LogEntry): void {
    if (!this.isProduction) return;
    
    // In production, send to logging service (Sentry, LogRocket, etc.)
    // For now, we'll use a minimal approach that doesn't console.log
    // This can be extended to send to external logging services
    
    // Example: Send to Sentry or other monitoring service
    // if (window.Sentry) {
    //   window.Sentry.addBreadcrumb({
    //     message: entry.message,
    //     level: entry.level,
    //     data: entry.data
    //   });
    // }
  }

  error(message: string, data?: any, source?: string): void {
    const entry = this.formatMessage(LOG_LEVELS.ERROR, message, data, source);
    this.logToConsole(entry);
    this.logToService(entry);
  }

  warn(message: string, data?: any, source?: string): void {
    const entry = this.formatMessage(LOG_LEVELS.WARN, message, data, source);
    this.logToConsole(entry);
    this.logToService(entry);
  }

  info(message: string, data?: any, source?: string): void {
    const entry = this.formatMessage(LOG_LEVELS.INFO, message, data, source);
    this.logToConsole(entry);
    this.logToService(entry);
  }

  debug(message: string, data?: any, source?: string): void {
    const entry = this.formatMessage(LOG_LEVELS.DEBUG, message, data, source);
    this.logToConsole(entry);
    this.logToService(entry);
  }

  // Convenience methods for common patterns
  auth(message: string, data?: any): void {
    this.info(message, data, 'AUTH');
  }

  api(message: string, data?: any): void {
    this.info(message, data, 'API');
  }

  db(message: string, data?: any): void {
    this.info(message, data, 'DATABASE');
  }

  payment(message: string, data?: any): void {
    this.info(message, data, 'PAYMENT');
  }

  // Security-focused logging that sanitizes sensitive data
  secureLog(message: string, data?: any, source?: string): void {
    if (this.isProduction && data) {
      // In production, sanitize sensitive data
      const sanitizedData = this.sanitizeData(data);
      this.info(message, sanitizedData, source);
    } else {
      this.info(message, data, source);
    }
  }

  private sanitizeData(data: any): any {
    if (!data || typeof data !== 'object') return data;

    const sensitive = ['password', 'token', 'signature', 'key', 'secret', 'auth', 'cookie'];
    const sanitized = { ...data };

    Object.keys(sanitized).forEach(key => {
      const lowerKey = key.toLowerCase();
      if (sensitive.some(s => lowerKey.includes(s))) {
        sanitized[key] = '[REDACTED]';
      }
    });

    return sanitized;
  }
}

// Export singleton instance
export const logger = new ProductionLogger();

// Export for backwards compatibility and specific use cases
export default logger; 