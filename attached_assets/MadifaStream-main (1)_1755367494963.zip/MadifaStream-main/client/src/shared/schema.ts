import {
    bigint,
    boolean,
    integer,
    numeric,
    pgEnum,
    pgTable,
    smallint,
    text,
    timestamp,
    uuid
} from "drizzle-orm/pg-core";
import { createInsertSchema, createSelectSchema } from "drizzle-zod";

// Updated enum definitions to match existing database
export const userRoleEnum = pgEnum("user_role", ["user", "admin"]);
export const subscriptionStatusEnum = pgEnum("subscription_status", ["active", "inactive", "trialing"]);

// This 'profiles' table is the single source of truth for user data,
// linked one-to-one with Supabase's 'auth.users' table.
export const profiles = pgTable("profiles", {
  id: uuid("id").primaryKey(), // This 'id' is the foreign key to auth.users.id
  username: text("username").unique(),
  display_name: text("display_name"),
  avatar_url: text("avatar_url"),
  role: userRoleEnum("role").default("user").notNull(),
  // subscription_status: removed - derived from subscriptions table
  subscription_expires_at: timestamp("subscription_expires_at", { withTimezone: true }),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const videos = pgTable("videos", {
  id: uuid("id").primaryKey().defaultRandom(),
  user_id: uuid("user_id").references(() => profiles.id, { onDelete: 'set null' }), // Uploader
  title: text("title").notNull(),
  description: text("description"),
  thumbnail_url: text("thumbnail_url"),
  video_url: text("video_url"),
  trailer_url: text("trailer_url"),
  duration: integer("duration"),
  release_year: integer("release_year"),
  director: text("director"),
  cast_members: text("cast_members").array(),
  genres: text("genres").array(),
  age_rating: text("age_rating"),
  is_premium: boolean("is_premium").default(false),
  is_trailer: boolean("is_trailer").default(false),
  status: text("status"),
  views: integer("views").default(0),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow(),  // Bunny Stream specific fields
  bunny_video_id: text("bunny_video_id"),
  bunny_playback_id: text("bunny_playback_id"),
  bunny_guid: text("bunny_guid"),
  bunny_library_id: text("bunny_library_id"),
  collection_id: text("collection_id"),
  collection_name: text("collection_name"),
  source_height: integer("source_height"),
  source_width: integer("source_width"),
  source_framerate: numeric("source_framerate"),
  encode_progress: integer("encode_progress"),
  storage_size: bigint("storage_size", { mode: "number" }),
  raw_bunny_status: integer("raw_bunny_status"),
  metadata_json: text("metadata_json"),
  available_resolutions: text("available_resolutions"),
  average_watch_time: integer("average_watch_time"),
  total_watch_time: integer("total_watch_time"),
});

export const categories = pgTable("categories", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  description: text("description"),
});

export const subscription_plans = pgTable("subscription_plans", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  video_quality: text("video_quality").notNull(),
  max_devices: integer("max_devices").notNull(),
  offline_downloads: boolean("offline_downloads").notNull(),
  max_downloads: integer("max_downloads"),
  duration_months: integer("duration_months"),
  features: text("features").array(),
});

export const content_metrics = pgTable("content_metrics", {
  id: uuid("id").primaryKey().defaultRandom(),
  video_id: uuid("video_id").references(() => videos.id, { onDelete: "cascade" }),
  total_views: integer("total_views").default(0),
  total_watch_time: integer("total_watch_time").default(0),
  average_rating: numeric("average_rating", { precision: 3, scale: 2 }).default("0.00"),
  total_ratings: integer("total_ratings").default(0),
  completion_rate: numeric("completion_rate", { precision: 5, scale: 2 }).default("0.00"),
  trending: boolean("trending").default(false),
  featured_score: integer("featured_score").default(0),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const ratings = pgTable("ratings", {
  id: uuid("id").primaryKey().defaultRandom(),
  video_id: uuid("video_id").references(() => videos.id, { onDelete: "cascade" }),
  user_id: uuid("user_id").references(() => profiles.id, { onDelete: "cascade" }),
  rating: smallint("rating").notNull(), // CHECK constraint (1-5) will be in SQL
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const streaming_profiles = pgTable("streaming_profiles", {
  id: uuid("id").primaryKey().defaultRandom(),
  video_id: uuid("video_id").references(() => videos.id, { onDelete: "cascade" }),
  quality: text("quality").notNull(),
  stream_url: text("stream_url").notNull(),
  bitrate: integer("bitrate").notNull(),
  codec: text("codec"),
  file_size: bigint("file_size", { mode: "number" }),
  is_default: boolean("is_default").default(false),
});

export const subscriptions = pgTable("subscriptions", {
  id: uuid("id").primaryKey().defaultRandom(),
  user_id: uuid("user_id").references(() => profiles.id, { onDelete: "cascade" }).notNull(),
  plan_id: uuid("plan_id").references(() => subscription_plans.id).notNull(),
  start_date: timestamp("start_date", { withTimezone: true }).defaultNow(),
  end_date: timestamp("end_date", { withTimezone: true }),
  is_active: boolean("is_active").default(true),
  payment_reference: text("payment_reference"),
  subscription_token: text("subscription_token"),
  cancellation_reason: text("cancellation_reason"),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const payment_transactions = pgTable("payment_transactions", {
  id: uuid("id").primaryKey().defaultRandom(),
  user_id: uuid("user_id").references(() => profiles.id, { onDelete: "cascade" }).notNull(),
  subscription_id: uuid("subscription_id").references(() => subscriptions.id, { onDelete: "set null" }),
  plan_id: uuid("plan_id").references(() => subscription_plans.id, { onDelete: "set null" }),
  pf_payment_id: text("pf_payment_id"), // PayFast payment ID
  m_payment_id: text("m_payment_id"), // Merchant payment ID
  payment_status: text("payment_status"), // COMPLETE, FAILED, PENDING, etc.
  amount_gross: numeric("amount_gross", { precision: 10, scale: 2 }),
  amount_fee: numeric("amount_fee", { precision: 10, scale: 2 }),
  amount_net: numeric("amount_net", { precision: 10, scale: 2 }),
  item_name: text("item_name"),
  item_description: text("item_description"),
  name_first: text("name_first"),
  name_last: text("name_last"),
  email_address: text("email_address"),
  merchant_id: text("merchant_id"),
  signature: text("signature"),
  raw_payload: text("raw_payload"), // Store the entire webhook payload for debugging
  processed_at: timestamp("processed_at", { withTimezone: true }),
  created_at: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const video_categories = pgTable("video_categories", {
  id: uuid("id").primaryKey().defaultRandom(),
  video_id: uuid("video_id").references(() => videos.id, { onDelete: "cascade" }),
  category_id: uuid("category_id").references(() => categories.id, { onDelete: "cascade" }),
});

export const watch_progress = pgTable("watch_progress", {
  id: uuid("id").primaryKey().defaultRandom(),
  user_id: uuid("user_id").references(() => profiles.id, { onDelete: "cascade" }).notNull(),
  video_id: uuid("video_id").references(() => videos.id, { onDelete: "cascade" }).notNull(),
  progress_seconds: integer("progress_seconds"),
  completed: boolean("completed").default(false),
  updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const watchlist = pgTable("watchlist", {
  id: uuid("id").primaryKey().defaultRandom(),
  user_id: uuid("user_id").references(() => profiles.id, { onDelete: "cascade" }),
  video_id: uuid("video_id").references(() => videos.id, { onDelete: "cascade" }),
  added_at: timestamp("added_at", { withTimezone: true }).defaultNow(),
});

// Zod schemas for validation
export const insertProfileSchema = createInsertSchema(profiles);
export const selectProfileSchema = createSelectSchema(profiles);
export const insertVideoSchema = createInsertSchema(videos);
export const selectVideoSchema = createSelectSchema(videos);
export const insertWatchProgressSchema = createInsertSchema(watch_progress);
export const selectWatchProgressSchema = createSelectSchema(watch_progress);
export const insertStreamingProfileSchema = createInsertSchema(streaming_profiles);
export const insertCategorySchema = createInsertSchema(categories);
export const insertVideoCategorySchema = createInsertSchema(video_categories);
export const insertSubscriptionPlanSchema = createInsertSchema(subscription_plans);
export const selectSubscriptionPlanSchema = createSelectSchema(subscription_plans);
export const insertSubscriptionSchema = createInsertSchema(subscriptions);
export const selectSubscriptionSchema = createSelectSchema(subscriptions);

// Types for frontend
export type DBProfile = typeof profiles.$inferSelect;
export type Profile = DBProfile & {
  displayName?: string | null;
  avatarColor?: string | null;
  // Only add truly extra fields here
};
export type NewProfile = typeof profiles.$inferInsert;
export type DBVideo = typeof videos.$inferSelect;
export type Video = DBVideo & {
  duration_minutes?: number;
  cast?: string[] | string | null;
  // Only add truly extra fields here
};
export type NewVideo = typeof videos.$inferInsert;
export type Category = typeof categories.$inferSelect;
export type DBWatchProgress = typeof watch_progress.$inferSelect;
export type WatchProgress = DBWatchProgress & {
  progressSeconds?: number;
  progress?: number; // alias in some components
  // Only add truly extra fields here
};
export type NewWatchProgress = typeof watch_progress.$inferInsert;
export type DBWatchlist = typeof watchlist.$inferSelect;
export type Watchlist = DBWatchlist & {
  addedAt?: string;
  // Only add truly extra fields here
};
export type DBSubscriptionPlan = typeof subscription_plans.$inferSelect;
export type SubscriptionPlan = DBSubscriptionPlan & {
  // Only add truly extra fields here
};
export type NewSubscriptionPlan = typeof subscription_plans.$inferInsert;
export type DBSubscription = typeof subscriptions.$inferSelect;
export type Subscription = DBSubscription & {
  // Only add truly extra fields here
};
export type NewSubscription = typeof subscriptions.$inferInsert;
export type DBPaymentTransaction = typeof payment_transactions.$inferSelect;
export type PaymentTransaction = DBPaymentTransaction & {
  // Only add truly extra fields here
};
export type NewPaymentTransaction = typeof payment_transactions.$inferInsert;
export type Rating = typeof ratings.$inferSelect;
export type ContentMetrics = typeof content_metrics.$inferSelect;
export type StreamingProfile = typeof streaming_profiles.$inferSelect;
export type VideoCategory = typeof video_categories.$inferSelect;
export type User = Profile;

export const video = videos;
