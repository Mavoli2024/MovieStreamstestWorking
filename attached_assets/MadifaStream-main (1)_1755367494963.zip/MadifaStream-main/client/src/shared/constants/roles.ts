// shared/constants/roles.ts
export const ROLES = {
  USER: 'user',
  ADMIN: 'admin',
} as const;
 
export const STATUS = {
    ACTIVE: 'active',
    INACTIVE: 'inactive',
    TRIALING: 'trialing',
} as const; 