import React, { useEffect } from 'react';
import { QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { queryClient } from '../queries/queryClient';
import { useAuthStore } from '../stores/authStore';
import { useUIStore } from '../stores/uiStore';
import { ErrorBoundary } from '../components/ui/ErrorBoundary';
import { Toaster } from '../components/ui/toaster';
import { LoadingOverlay } from '../components/ui/LoadingOverlay';
import { OfflineIndicator } from '../components/ui/OfflineIndicator';
import { AuthProvider } from '../hooks/use-auth';
import { useAuthSync } from '../hooks/use-auth-sync';
import '../services/session-manager'; // Initialize session manager

interface AppProviderProps {
  children: React.ReactNode;
}

// Auth sync wrapper component to use the hook
const AuthSyncWrapper: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  useAuthSync(); // Initialize auth synchronization
  return <>{children}</>;
};

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const { globalLoading, networkStatus } = useUIStore();

  // Listen for auth state changes across tabs
  useEffect(() => {
    const bc = new BroadcastChannel('madifa-auth');
    
    const handleAuthMessage = (event: MessageEvent) => {
      if (event.data.type === 'LOGOUT') {
        // Refresh the page to ensure clean state
        window.location.reload();
      }
    };

    bc.addEventListener('message', handleAuthMessage);

    return () => {
      bc.removeEventListener('message', handleAuthMessage);
      bc.close();
    };
  }, []);

  // Handle network status changes
  useEffect(() => {
    const handleOnline = () => {
      useUIStore.getState().setNetworkStatus('online');
      // Invalidate queries when coming back online
      queryClient.invalidateQueries();
    };

    const handleOffline = () => {
      useUIStore.getState().setNetworkStatus('offline');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <AuthSyncWrapper>
            <div className="app-container">
              {children}
            
              {/* Global UI Components */}
              <Toaster />
              <LoadingOverlay show={globalLoading} />
              <OfflineIndicator show={networkStatus === 'offline'} />
              
              {/* Development Tools */}
              {import.meta.env.DEV && (
                <ReactQueryDevtools initialIsOpen={false} />
              )}
            </div>
          </AuthSyncWrapper>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
};

// Theme Provider for consistent theming
export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  useEffect(() => {
    // Apply theme class to body
    document.body.classList.add('madifa-theme');
    
    // Set CSS custom properties for theme
    const root = document.documentElement;
    root.style.setProperty('--primary-color', '#3b82f6');
    root.style.setProperty('--secondary-color', '#6b7280');
    root.style.setProperty('--accent-color', '#10b981');
    root.style.setProperty('--background-color', '#ffffff');
    root.style.setProperty('--surface-color', '#f9fafb');
    root.style.setProperty('--text-color', '#111827');
    root.style.setProperty('--border-color', '#e5e7eb');
    
    return () => {
      document.body.classList.remove('madifa-theme');
    };
  }, []);

  return <>{children}</>;
};

// Combined root provider
export const RootProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <ThemeProvider>
      <AppProvider>
        {children}
      </AppProvider>
    </ThemeProvider>
  );
};
