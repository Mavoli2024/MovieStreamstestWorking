import React from 'react';

interface QueryProviderProps {
  children: React.ReactNode;
}

// This is a lightweight wrapper around React Query
// The actual QueryClient is created in App.tsx
export function QueryProvider({ children }: QueryProviderProps) {
  return <>{children}</>;
} 