/**
 * UNIFIED ROUTING SYSTEM - SINGLE SOURCE OF TRUTH
 * 
 * This file replaces all other routing configurations to establish
 * a clear, consistent navigation philosophy across the application.
 * 
 * PHILOSOPHY:
 * - Single source of truth for all routes
 * - Consistent authentication patterns
 * - Clear route hierarchy and grouping
 * - Standardized parameter naming
 * - Explicit access control rules
 */

import React from 'react';

// Route definition interface
export interface UnifiedRouteDefinition {
  id: string;                    // Unique identifier
  path: string;                  // URL pattern
  name: string;                  // Human readable name
  title: string;                 // Page title for SEO
  description?: string;          // Meta description
  
  // Component loading
  component: React.LazyExoticComponent<any>;
  
  // Access control
  requiresAuth: boolean;         // Requires user to be logged in
  requiresSubscription?: boolean; // Requires active subscription
  adminOnly?: boolean;           // Admin access only
  roles?: string[];              // Specific role requirements
  
  // Route behavior
  exact?: boolean;               // Exact path match
  redirect?: string;             // Redirect to another route
  hidden?: boolean;              // Hide from navigation menus
  
  // SEO and metadata
  keywords?: string[];
  ogImage?: string;
  canonical?: string;
  
  // Navigation grouping
  group: 'public' | 'auth' | 'content' | 'user' | 'admin' | 'legal';
  category?: string;             // Sub-category for organization
}

// Lazy load all page components
const LandingPage = React.lazy(() => import('@/pages/landing-page'));
const HomePage = React.lazy(() => import('@/pages/modern-home-page').then(m => ({ default: m.ModernHomePage })));
const BrowsePage = React.lazy(() => import('@/pages/browse-page'));
const WatchPage = React.lazy(() => import('@/pages/watch-page'));
const SearchPage = React.lazy(() => import('@/pages/search-page'));
const DiscoverPage = React.lazy(() => import('@/pages/discover-content-page'));

const AuthPage = React.lazy(() => import('@/pages/auth-page'));
const ProfilePage = React.lazy(() => import('@/pages/profile-page'));
const SettingsPage = React.lazy(() => import('@/pages/settings-page'));
const WatchlistPage = React.lazy(() => import('@/pages/watchlist-page'));
const MyListPage = React.lazy(() => import('@/pages/my-list-page'));
const HistoryPage = React.lazy(() => import('@/pages/history-page'));
const SubscriptionPage = React.lazy(() => import('@/pages/subscription-page'));

const AdminPage = React.lazy(() => import('@/pages/admin-page'));
const PricingPage = React.lazy(() => import('@/pages/pricing-page'));
const PlansPage = React.lazy(() => import('@/pages/plans-page'));

const PaymentSuccessPage = React.lazy(() => import('@/pages/payment-success-page'));
const PaymentCancelPage = React.lazy(() => import('@/pages/payment-cancel-page'));

const TermsPage = React.lazy(() => import('@/pages/terms-page'));
const PrivacyPage = React.lazy(() => import('@/pages/privacy-page'));
const CookiesPage = React.lazy(() => import('@/pages/cookies-page'));
const AccessibilityPage = React.lazy(() => import('@/pages/accessibility-page'));
const SitemapPage = React.lazy(() => import('@/pages/sitemap-page'));
const FeedbackPage = React.lazy(() => import('@/pages/feedback-page'));
const NotFoundPage = React.lazy(() => import('@/pages/not-found-page'));

/**
 * UNIFIED ROUTE DEFINITIONS
 * 
 * Single source of truth for all application routes.
 * Organized by logical groups with clear access patterns.
 */
export const UNIFIED_ROUTES: UnifiedRouteDefinition[] = [
  // PUBLIC ROUTES - No authentication required
  {
    id: 'landing',
    path: '/',
    name: 'landing',
    title: 'MadifaStream - Premium South African Entertainment',
    description: 'Stream the best South African movies, series, and documentaries',
    component: LandingPage,
    requiresAuth: false,
    exact: true,
    group: 'public',
    category: 'entry',
    keywords: ['streaming', 'south african', 'movies', 'entertainment'],
  },
  
  {
    id: 'auth',
    path: '/auth',
    name: 'authentication',
    title: 'Sign In - MadifaStream',
    description: 'Sign in to your MadifaStream account',
    component: AuthPage,
    requiresAuth: false,
    group: 'auth',
    category: 'authentication',
  },
  
  {
    id: 'auth-callback',
    path: '/auth-callback',
    name: 'auth-callback',
    title: 'Processing Authentication - MadifaStream',
    description: 'Processing your authentication',
    component: React.lazy(() => import('@/pages/auth-callback')),
    requiresAuth: false,
    group: 'auth',
    category: 'authentication',
    hidden: true,
  },
  
  {
    id: 'pricing',
    path: '/pricing',
    name: 'pricing',
    title: 'Pricing Plans - MadifaStream',
    description: 'Choose your MadifaStream subscription plan',
    component: PlansPage,
    requiresAuth: false,
    group: 'public',
    category: 'commercial',
  },

  {
    id: 'plans',
    path: '/plans',
    name: 'plans',
    title: 'Subscription Plans - MadifaStream',
    description: 'View detailed pricing information for all subscription plans',
    component: PlansPage,
    requiresAuth: false,
    group: 'public',
    category: 'commercial',
  },

  // CONTENT ROUTES - Semi-public (browsable without auth, but enhanced with auth)
  {
    id: 'home',
    path: '/home',
    name: 'home',
    title: 'Home - MadifaStream',
    description: 'Discover trending content personalized for you',
    component: HomePage,
    requiresAuth: false, // Allow viewing without auth
    group: 'content',
    category: 'discovery',
  },
  
  {
    id: 'browse',
    path: '/browse',
    name: 'browse',
    title: 'Browse Content - MadifaStream',
    description: 'Browse all available movies and series',
    component: BrowsePage,
    requiresAuth: false, // Allow browsing without auth for discovery
    group: 'content',
    category: 'discovery',
  },
  
  {
    id: 'browse-category',
    path: '/browse/:category',
    name: 'browse-category',
    title: 'Browse Category - MadifaStream',
    description: 'Browse content by category',
    component: BrowsePage,
    requiresAuth: false,
    group: 'content',
    category: 'discovery',
  },
  
  {
    id: 'search',
    path: '/search',
    name: 'search',
    title: 'Search - MadifaStream',
    description: 'Search for movies, series and documentaries',
    component: SearchPage,
    requiresAuth: false,
    group: 'content',
    category: 'discovery',
  },
  
  {
    id: 'discover',
    path: '/discover',
    name: 'discover',
    title: 'Discover - MadifaStream',
    description: 'Discover new content tailored to your preferences',
    component: DiscoverPage,
    requiresAuth: false,
    group: 'content',
    category: 'discovery',
  },
  
  // WATCH ROUTES - Authentication required for premium content
  {
    id: 'watch',
    path: '/watch/:id',
    name: 'watch',
    title: 'Watch - MadifaStream',
    description: 'Stream your selected content',
    component: WatchPage,
    requiresAuth: true, // Required for watch functionality
    group: 'content',
    category: 'playback',
  },

  // USER ROUTES - Authentication required
  {
    id: 'profile',
    path: '/profile',
    name: 'profile',
    title: 'My Profile - MadifaStream',
    description: 'Manage your profile and preferences',
    component: ProfilePage,
    requiresAuth: true,
    group: 'user',
    category: 'account',
  },
  
  {
    id: 'settings',
    path: '/settings',
    name: 'settings',
    title: 'Settings - MadifaStream',
    description: 'Configure your account settings and preferences',
    component: SettingsPage,
    requiresAuth: true,
    group: 'user',
    category: 'account',
  },
  
  {
    id: 'watchlist',
    path: '/watchlist',
    name: 'watchlist',
    title: 'My Watchlist - MadifaStream',
    description: 'Your saved movies and series',
    component: WatchlistPage,
    requiresAuth: true,
    group: 'user',
    category: 'collections',
  },
  
  {
    id: 'my-list',
    path: '/my-list',
    name: 'my-list',
    title: 'My List - MadifaStream',
    description: 'Your saved movies and series',
    component: MyListPage,
    requiresAuth: true,
    group: 'user',
    category: 'collections',
  },
  
  {
    id: 'list',
    path: '/list',
    name: 'list',
    title: 'My List - MadifaStream',
    description: 'Your saved movies and series',
    component: MyListPage,
    requiresAuth: true,
    group: 'user',
    category: 'collections',
  },
  
  {
    id: 'history',
    path: '/history',
    name: 'history',
    title: 'Watch History - MadifaStream',
    description: 'Your recently watched content',
    component: HistoryPage,
    requiresAuth: true,
    group: 'user',
    category: 'collections',
  },
  
  {
    id: 'subscription',
    path: '/subscription',
    name: 'subscription',
    title: 'Subscription - MadifaStream',
    description: 'Manage your subscription and billing',
    component: SubscriptionPage,
    requiresAuth: true,
    group: 'user',
    category: 'billing',
  },

  // PAYMENT ROUTES - Authentication required
  {
    id: 'payment-success',
    path: '/payment/success',
    name: 'payment-success',
    title: 'Payment Successful - MadifaStream',
    description: 'Your payment has been processed successfully',
    component: PaymentSuccessPage,
    requiresAuth: true,
    group: 'user',
    category: 'billing',
    hidden: true,
  },
  
  {
    id: 'payment-cancel',
    path: '/payment/cancel',
    name: 'payment-cancel',
    title: 'Payment Cancelled - MadifaStream',
    description: 'Your payment has been cancelled',
    component: PaymentCancelPage,
    requiresAuth: true,
    group: 'user',
    category: 'billing',
    hidden: true,
  },

  // ADMIN ROUTES - Admin authentication required
  {
    id: 'admin',
    path: '/admin',
    name: 'admin',
    title: 'Admin Dashboard - MadifaStream',
    description: 'Administrative control panel',
    component: AdminPage,
    requiresAuth: true,
    adminOnly: true,
    group: 'admin',
    category: 'management',
    hidden: true,
  },

  // LEGAL ROUTES - Public access
  {
    id: 'terms',
    path: '/terms',
    name: 'terms',
    title: 'Terms of Service - MadifaStream',
    description: 'Terms and conditions of using MadifaStream',
    component: TermsPage,
    requiresAuth: false,
    group: 'legal',
    category: 'compliance',
  },
  
  {
    id: 'privacy',
    path: '/privacy',
    name: 'privacy',
    title: 'Privacy Policy - MadifaStream',
    description: 'How we protect and use your personal information',
    component: PrivacyPage,
    requiresAuth: false,
    group: 'legal',
    category: 'compliance',
  },
  
  {
    id: 'cookies',
    path: '/cookies',
    name: 'cookies',
    title: 'Cookie Policy - MadifaStream',
    description: 'Information about our use of cookies',
    component: CookiesPage,
    requiresAuth: false,
    group: 'legal',
    category: 'compliance',
  },
  
  {
    id: 'accessibility',
    path: '/accessibility',
    name: 'accessibility',
    title: 'Accessibility Statement - MadifaStream',
    description: 'Our commitment to digital accessibility',
    component: AccessibilityPage,
    requiresAuth: false,
    group: 'legal',
    category: 'compliance',
  },
  
  {
    id: 'sitemap',
    path: '/sitemap',
    name: 'sitemap',
    title: 'Sitemap - MadifaStream',
    description: 'Navigate through all pages on MadifaStream',
    component: SitemapPage,
    requiresAuth: false,
    group: 'legal',
    category: 'navigation',
    hidden: true,
  },
  
  {
    id: 'feedback',
    path: '/feedback',
    name: 'feedback',
    title: 'Feedback - MadifaStream',
    description: 'Share your feedback and suggestions',
    component: FeedbackPage,
    requiresAuth: false,
    group: 'legal',
    category: 'support',
  },

  // 404 ROUTE - Catch all
  {
    id: 'not-found',
    path: '/:rest*',
    name: 'not-found',
    title: '404 - Page Not Found - MadifaStream',
    description: 'The page you are looking for does not exist',
    component: NotFoundPage,
    requiresAuth: false,
    group: 'public',
    category: 'error',
    hidden: true,
  },
];

/**
 * ROUTE UTILITIES
 */
export const RouteUtils = {
  // Find route by ID
  findById: (id: string): UnifiedRouteDefinition | undefined => {
    return UNIFIED_ROUTES.find(route => route.id === id);
  },
  
  // Find route by path
  findByPath: (path: string): UnifiedRouteDefinition | undefined => {
    return UNIFIED_ROUTES.find(route => {
      if (route.exact) {
        return route.path === path;
      }
      return RouteUtils.matchPath(route.path, path);
    });
  },
  
  // Match path patterns (supports :param)
  matchPath: (pattern: string, path: string): boolean => {
    const patternParts = pattern.split('/');
    const pathParts = path.split('/');
    
    if (patternParts.length !== pathParts.length && !pattern.includes('*')) {
      return false;
    }
    
    return patternParts.every((part, index) => {
      if (part.startsWith(':')) return true; // Parameter match
      if (part.includes('*')) return true;   // Wildcard match
      return part === pathParts[index];
    });
  },
  
  // Get routes by group
  getByGroup: (group: UnifiedRouteDefinition['group']): UnifiedRouteDefinition[] => {
    return UNIFIED_ROUTES.filter(route => route.group === group);
  },
  
  // Get visible routes (not hidden)
  getVisible: (): UnifiedRouteDefinition[] => {
    return UNIFIED_ROUTES.filter(route => !route.hidden);
  },
  
  // Get public routes
  getPublic: (): UnifiedRouteDefinition[] => {
    return UNIFIED_ROUTES.filter(route => !route.requiresAuth);
  },
  
  // Get protected routes
  getProtected: (): UnifiedRouteDefinition[] => {
    return UNIFIED_ROUTES.filter(route => route.requiresAuth);
  },
  
  // Generate path with parameters
  generatePath: (routeId: string, params: Record<string, string>): string => {
    const route = RouteUtils.findById(routeId);
    if (!route) return '/';
    
    let path = route.path;
    Object.entries(params).forEach(([key, value]) => {
      path = path.replace(`:${key}`, value);
    });
    
    return path;
  },
  
  // Extract parameters from path
  extractParams: (pattern: string, path: string): Record<string, string> => {
    const params: Record<string, string> = {};
    const patternParts = pattern.split('/');
    const pathParts = path.split('/');
    
    patternParts.forEach((part, index) => {
      if (part.startsWith(':')) {
        const paramName = part.substring(1);
        params[paramName] = pathParts[index];
      }
    });
    
    return params;
  },
};

/**
 * DEPRECATED ROUTE ALIASES
 * 
 * For backward compatibility during migration.
 * These will be removed in a future version.
 */

// Legacy APP_ROUTES export for existing code
export const APP_ROUTES = UNIFIED_ROUTES;

// Legacy route names mapping
export const LEGACY_ROUTES = {
  '/video/:id': '/watch/:id',  // Redirect video routes to watch
  '/my-list': '/watchlist',     // Redirect my-list to watchlist
};

/**
 * ROUTE ACCESS VALIDATION
 */
export const RouteAccess = {
  canAccess: (route: UnifiedRouteDefinition, user: any): boolean => {
    // Check authentication requirement
    if (route.requiresAuth && !user) {
      return false;
    }
    
    // Check admin requirement
    if (route.adminOnly && !user?.isAdmin) {
      return false;
    }
    
    // Check role requirements
    if (route.roles && route.roles.length > 0) {
      const userRoles = user?.roles || [];
      return route.roles.some(role => userRoles.includes(role));
    }
    
    // Check subscription requirement
    if (route.requiresSubscription && !user?.hasActiveSubscription) {
      return false;
    }
    
    return true;
  },
  
  getRedirectFor: (route: UnifiedRouteDefinition, user: any): string => {
    if (!route.requiresAuth) return route.path;
    
    if (!user) return '/auth';
    
    if (route.adminOnly && !user?.isAdmin) return '/';
    
    if (route.requiresSubscription && !user?.hasActiveSubscription) {
      return '/pricing';
    }
    
    return route.path;
  },
};