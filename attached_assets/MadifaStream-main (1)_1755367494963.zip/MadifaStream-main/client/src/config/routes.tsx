/**
 * Route Configuration
 * 
 * Centralized route management with:
 * - Lazy loading for code splitting
 * - Route-level error boundaries
 * - Authentication guards
 * - Loading states
 * - 404 handling
 */

import React, { Suspense, lazy } from 'react';
import { Route, Switch, Redirect } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { AppErrorBoundary } from '@/components/error-boundary/AppErrorBoundary';
import { Loader2 } from 'lucide-react';

// Lazy load pages for code splitting
const HomePage = lazy(() => import('@/pages/modern-home-page').then(m => ({ default: m.ModernHomePage })));
const BrowsePage = lazy(() => import('@/pages/browse-page'));
const WatchPage = lazy(() => import('@/pages/watch-page'));
const ProfilePage = lazy(() => import('@/pages/profile-page'));
const AuthPage = lazy(() => import('@/pages/auth-page'));
const PricingPage = lazy(() => import('@/pages/pricing-page'));
const AdminPage = lazy(() => import('@/pages/admin-page'));
const WatchlistPage = lazy(() => import('@/pages/watchlist-page'));
const HistoryPage = lazy(() => import('@/pages/history-page'));
const SettingsPage = lazy(() => import('@/pages/settings-page'));
const NotFoundPage = lazy(() => import('@/pages/not-found-page'));

// Loading component
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center">
    <Loader2 className="w-8 h-8 animate-spin text-primary" />
  </div>
);

// Route wrapper with error boundary
interface RouteWrapperProps {
  children: React.ReactNode;
  requireAuth?: boolean;
  requireAdmin?: boolean;
}

function RouteWrapper({ children, requireAuth, requireAdmin }: RouteWrapperProps) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <PageLoader />;
  }

  if (requireAuth && !user) {
    return <Redirect to="/auth" />;
  }

  if (requireAdmin && user?.role !== 'admin') {
    return <Redirect to="/" />;
  }

  return (
    <AppErrorBoundary>
      <Suspense fallback={<PageLoader />}>
        {children}
      </Suspense>
    </AppErrorBoundary>
  );
}

// Route configuration
export interface RouteConfig {
  path: string;
  component: React.LazyExoticComponent<any>;
  exact?: boolean;
  requireAuth?: boolean;
  requireAdmin?: boolean;
  title?: string;
}

export const routes: RouteConfig[] = [
  {
    path: '/',
    component: HomePage,
    exact: true,
    requireAuth: false,
    title: 'Home',
  },
  {
    path: '/browse',
    component: BrowsePage,
    title: 'Browse',
  },
  {
    path: '/browse/:category',
    component: BrowsePage,
    title: 'Browse Category',
  },
  {
    path: '/watch/:id',
    component: WatchPage,
    title: 'Watch',
  },
  {
    path: '/video/:id',
    component: WatchPage,
    title: 'Video Details',
  },
  {
    path: '/profile',
    component: ProfilePage,
    requireAuth: true,
    title: 'Profile',
  },
  {
    path: '/auth',
    component: AuthPage,
    requireAuth: false,
    title: 'Sign In',
  },
  {
    path: '/pricing',
    component: PricingPage,
    title: 'Pricing',
  },
  {
    path: '/my-list',
    component: WatchlistPage,
    requireAuth: true,
    title: 'My List',
  },
  {
    path: '/watchlist',
    component: WatchlistPage,
    requireAuth: true,
    title: 'Watchlist',
  },
  {
    path: '/history',
    component: HistoryPage,
    requireAuth: true,
    title: 'Watch History',
  },
  {
    path: '/settings',
    component: SettingsPage,
    requireAuth: true,
    title: 'Settings',
  },
  {
    path: '/admin',
    component: AdminPage,
    requireAuth: true,
    requireAdmin: true,
    title: 'Admin Dashboard',
  },
  {
    path: '/admin/:section',
    component: AdminPage,
    requireAuth: true,
    requireAdmin: true,
    title: 'Admin',
  },
];

// Routes component
// Legacy alias for integration tests expecting APP_ROUTES
export const APP_ROUTES: RouteConfig[] = routes.map(r => ({
  ...r,
  // Ensure requireAuth is always a boolean for test filters
  requireAuth: !!r.requireAuth,
}));

export function Routes() {
  return (
    <Switch>
      {routes.map((route) => (
        <Route key={route.path} path={route.path}>
          <RouteWrapper
            requireAuth={route.requireAuth}
            requireAdmin={route.requireAdmin}
          >
            <route.component />
          </RouteWrapper>
        </Route>
      ))}
      
      {/* 404 fallback */}
      <Route path="*">
        <RouteWrapper>
          <NotFoundPage />
        </RouteWrapper>
      </Route>
    </Switch>
  );
}

// Navigation guard hook
export function useNavigationGuard() {
  const { user } = useAuth();

  const canAccess = (path: string): boolean => {
    const route = routes.find(r => r.path === path);
    
    if (!route) return true;
    
    if (route.requireAuth && !user) return false;
    if (route.requireAdmin && user?.role !== 'admin') return false;
    
    return true;
  };

  return { canAccess };
} 