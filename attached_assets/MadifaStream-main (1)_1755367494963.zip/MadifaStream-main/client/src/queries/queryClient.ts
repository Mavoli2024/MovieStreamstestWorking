import { QueryClient } from '@tanstack/react-query';
import { toast } from '../stores/uiStore';

// Create a query client with optimized defaults
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Stale time: 5 minutes - data considered fresh for 5 minutes
      staleTime: 5 * 60 * 1000,
      
      // Cache time: 10 minutes - data kept in cache for 10 minutes after last use
      gcTime: 10 * 60 * 1000,
      
      // Retry configuration
      retry: (failureCount, error) => {
        // Don't retry on 4xx errors (client errors)
        if (error && typeof error === 'object' && 'status' in error) {
          const status = error.status as number;
          if (status >= 400 && status < 500) {
            return false;
          }
        }
        
        // Retry up to 3 times for other errors
        return failureCount < 3;
      },
      
      // Retry delay with exponential backoff
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
      
      // Refetch on window focus for important queries
      refetchOnWindowFocus: true,
      
      // Refetch on network reconnect
      refetchOnReconnect: true,
    },
    
    mutations: {
      // Retry mutations once on failure
      retry: 1,
      
      // Error handling for mutations
      onError: (error, variables, context) => {
        console.error('Mutation error:', error);
        
        // Show toast notification for mutation errors
        if (error && typeof error === 'object' && 'message' in error) {
          toast.error(
            'Action failed',
            error.message as string,
            {
              duration: 0, // Don't auto-dismiss error toasts
              dismissible: true,
            }
          );
        }
      },
      
      // Success handling for mutations
      onSuccess: (data, variables, context) => {
        // Show success toast for successful mutations
        if (context && typeof context === 'object' && 'successMessage' in context) {
          toast.success(
            'Success',
            context.successMessage as string,
            {
              duration: 3000,
            }
          );
        }
      },
    },
  },
});

// Query keys factory for consistent key management
export const queryKeys = {
  // User related queries
  user: {
    all: ['user'] as const,
    profile: (userId: string) => ['user', 'profile', userId] as const,
    preferences: (userId: string) => ['user', 'preferences', userId] as const,
    subscription: (userId: string) => ['user', 'subscription', userId] as const,
    watchHistory: (userId: string) => ['user', 'watchHistory', userId] as const,
    watchlist: (userId: string) => ['user', 'watchlist', userId] as const,
  },
  
  // Video related queries
  videos: {
    all: ['videos'] as const,
    lists: () => ['videos', 'lists'] as const,
    list: (filters: any) => ['videos', 'list', filters] as const,
    detail: (videoId: string) => ['videos', 'detail', videoId] as const,
    recommendations: (videoId: string) => ['videos', 'recommendations', videoId] as const,
    search: (query: string, filters?: any) => ['videos', 'search', query, filters] as const,
    trending: (timeframe?: string) => ['videos', 'trending', timeframe] as const,
    byCategory: (categoryId: string) => ['videos', 'category', categoryId] as const,
    byCreator: (creatorId: string) => ['videos', 'creator', creatorId] as const,
  },
  
  // Categories
  categories: {
    all: ['categories'] as const,
    list: () => ['categories', 'list'] as const,
    detail: (categoryId: string) => ['categories', 'detail', categoryId] as const,
  },
  
  // Watch progress
  watchProgress: {
    all: ['watchProgress'] as const,
    video: (videoId: string, userId: string) => ['watchProgress', 'video', videoId, userId] as const,
    user: (userId: string) => ['watchProgress', 'user', userId] as const,
  },
  
  // Ratings
  ratings: {
    all: ['ratings'] as const,
    video: (videoId: string) => ['ratings', 'video', videoId] as const,
    user: (userId: string) => ['ratings', 'user', userId] as const,
  },
  
  // Collections
  collections: {
    all: ['collections'] as const,
    list: () => ['collections', 'list'] as const,
    detail: (collectionId: string) => ['collections', 'detail', collectionId] as const,
    videos: (collectionId: string) => ['collections', 'videos', collectionId] as const,
  },
  
  // Admin queries
  admin: {
    all: ['admin'] as const,
    users: (filters?: any) => ['admin', 'users', filters] as const,
    videos: (filters?: any) => ['admin', 'videos', filters] as const,
    analytics: (timeframe?: string) => ['admin', 'analytics', timeframe] as const,
    subscriptions: () => ['admin', 'subscriptions'] as const,
  },
};

// Cache invalidation helpers
export const invalidateQueries = {
  // User data
  userProfile: (userId: string) => {
    queryClient.invalidateQueries({ queryKey: queryKeys.user.profile(userId) });
  },
  
  userWatchlist: (userId: string) => {
    queryClient.invalidateQueries({ queryKey: queryKeys.user.watchlist(userId) });
  },
  
  userWatchHistory: (userId: string) => {
    queryClient.invalidateQueries({ queryKey: queryKeys.user.watchHistory(userId) });
  },
  
  // Video data
  videosList: () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.videos.lists() });
  },
  
  videoDetail: (videoId: string) => {
    queryClient.invalidateQueries({ queryKey: queryKeys.videos.detail(videoId) });
  },
  
  videoRecommendations: (videoId: string) => {
    queryClient.invalidateQueries({ queryKey: queryKeys.videos.recommendations(videoId) });
  },
  
  // Watch progress
  watchProgress: (videoId: string, userId: string) => {
    queryClient.invalidateQueries({ 
      queryKey: queryKeys.watchProgress.video(videoId, userId) 
    });
  },
  
  // Search results
  searchResults: () => {
    queryClient.invalidateQueries({ 
      queryKey: ['videos', 'search'] 
    });
  },
  
  // All user data (for logout)
  allUserData: () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.user.all });
    queryClient.invalidateQueries({ queryKey: queryKeys.watchProgress.all });
    queryClient.invalidateQueries({ queryKey: queryKeys.ratings.all });
  },
};

// Prefetch helpers for better UX
export const prefetchQueries = {
  videoDetail: (videoId: string) => {
    queryClient.prefetchQuery({
      queryKey: queryKeys.videos.detail(videoId),
      staleTime: 5 * 60 * 1000, // 5 minutes
    });
  },
  
  videoRecommendations: (videoId: string) => {
    queryClient.prefetchQuery({
      queryKey: queryKeys.videos.recommendations(videoId),
      staleTime: 10 * 60 * 1000, // 10 minutes
    });
  },
  
  userWatchlist: (userId: string) => {
    queryClient.prefetchQuery({
      queryKey: queryKeys.user.watchlist(userId),
      staleTime: 2 * 60 * 1000, // 2 minutes
    });
  },
};

// Optimistic update helpers
export const optimisticUpdates = {
  // Add to watchlist optimistically
  addToWatchlist: (userId: string, videoId: string, videoData: any) => {
    const queryKey = queryKeys.user.watchlist(userId);
    
    queryClient.setQueryData(queryKey, (old: any) => {
      if (!old) return [videoData];
      return [...old, videoData];
    });
  },
  
  // Remove from watchlist optimistically
  removeFromWatchlist: (userId: string, videoId: string) => {
    const queryKey = queryKeys.user.watchlist(userId);
    
    queryClient.setQueryData(queryKey, (old: any) => {
      if (!old) return [];
      return old.filter((item: any) => item.video_id !== videoId);
    });
  },
  
  // Update watch progress optimistically
  updateWatchProgress: (videoId: string, userId: string, progress: number) => {
    const queryKey = queryKeys.watchProgress.video(videoId, userId);
    
    queryClient.setQueryData(queryKey, (old: any) => ({
      ...old,
      progress,
      updated_at: new Date().toISOString(),
    }));
  },
  
  // Update video rating optimistically
  updateVideoRating: (videoId: string, rating: number) => {
    const queryKey = queryKeys.videos.detail(videoId);
    
    queryClient.setQueryData(queryKey, (old: any) => ({
      ...old,
      user_rating: rating,
      updated_at: new Date().toISOString(),
    }));
  },
};

// Background sync for offline support
export const backgroundSync = {
  // Sync critical data when coming back online
  syncOnReconnect: () => {
    queryClient.resumePausedMutations();
    queryClient.invalidateQueries();
  },
  
  // Pause queries when offline
  pauseQueries: () => {
    queryClient.getQueryCache().getAll().forEach(query => {
      if (query.state.status === 'pending') {
        query.cancel();
      }
    });
  },
};

// Network status integration
if (typeof window !== 'undefined') {
  window.addEventListener('online', backgroundSync.syncOnReconnect);
  window.addEventListener('offline', backgroundSync.pauseQueries);
}
