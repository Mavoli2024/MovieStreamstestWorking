import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";
import { GlobalErrorBoundary } from './components/error-boundary/GlobalErrorBoundary';

// Make React globally available (fix for production bundling)
if (typeof window !== 'undefined') {
  (window as any).React = React;
  (window as any).ReactDOM = ReactDOM;
  
  // React internals check removed - not needed for modern React
}

// Simple frontend logger (fallback since shared logger is server-side)
const logger = {
  info: (msg: string, data?: any) => console.log(`[INFO] ${msg}`, data?.arg1 || ''),
  error: (msg: string, data?: any) => console.error(`[ERROR] ${msg}`, data?.arg1 || ''),
  warn: (msg: string, data?: any) => console.warn(`[WARN] ${msg}`, data?.arg1 || ''),
  debug: (msg: string, data?: any) => console.debug(`[DEBUG] ${msg}`, data?.arg1 || '')
};

// Enhanced error handling for React initialization
function initializeApp() {
  const rootElement = document.getElementById('root');
  
  if (!rootElement) {
    logger.error('Root element not found');
    return;
  }

  try {
    // Verify React is properly loaded
    if (!React || !React.Children || !ReactDOM.createRoot) {
      throw new Error('React dependencies not properly loaded');
    }

    logger.info('✅ React loaded successfully');
    logger.info('✅ React.Children available:', { arg1: !!React.Children });
    logger.info('✅ createRoot available:', { arg1: !!ReactDOM.createRoot });
    
    // Create React root
    const root = ReactDOM.createRoot(rootElement);
    logger.info('✅ React root created successfully');
    
    // Render the app
    root.render(
      <GlobalErrorBoundary>
        <App />
      </GlobalErrorBoundary>
    );
    logger.info('✅ App rendered successfully');
    
  } catch (error) {
    logger.error('❌ React initialization failed:', { arg1: error });
    
    // Fallback error display
    rootElement.innerHTML = `
      <div style="
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        background: #000;
        color: #fff;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        text-align: center;
        padding: 20px;
      ">
        <div>
          <h1 style="font-size: 2rem; margin-bottom: 1rem;">Loading Error</h1>
          <p style="margin-bottom: 2rem;">Unable to load MadifaStream. Please refresh the page.</p>
          <button onclick="location.reload()" style="
            background: #dc2626;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            font-size: 1rem;
            cursor: pointer;
          ">
            Refresh Page
          </button>
        </div>
      </div>
    `;
  }
}

// Wait for DOM to be ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeApp);
} else {
  initializeApp();
}