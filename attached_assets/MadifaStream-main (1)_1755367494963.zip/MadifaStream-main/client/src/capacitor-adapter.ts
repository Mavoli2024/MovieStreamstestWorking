import { logger } from '@shared/logger';
/**
 * Capacitor adapter functions
 * Provides utilities for detecting and configuring the Capacitor environment
 */

// Type declarations for Capacitor
interface StatusBarInfo {
  height: number;
}

interface StatusBarPlugin {
  getInfo(): Promise<StatusBarInfo>;
  setStyle(options: { style: string }): Promise<void>;
}

interface CapacitorPlugins {
  StatusBar?: StatusBarPlugin;
}

declare global {
  interface Window {
    Capacitor?: {
      isNative?: boolean;
      isNativePlatform?: () => boolean;
      getPlatform?: () => 'ios' | 'android' | 'web';
      convertFileSrc?: (path: string) => string;
      Plugins?: CapacitorPlugins;
    };
  }
}

/**
 * Check if app is running in a Capacitor native environment
 */
export function isCapacitorEnvironment(): boolean {
  if (typeof window === 'undefined') return false;
  
  // Check if Capacitor is available
  return !!(
    window.Capacitor && 
    (window.Capacitor.isNative === true || 
     (typeof window.Capacitor.isNativePlatform === 'function' && 
      window.Capacitor.isNativePlatform()))
  );
}

/**
 * Get current platform (ios, android, or web)
 */
export function getPlatform(): 'ios' | 'android' | 'web' {
  if (typeof window === 'undefined') return 'web';
  
  if (window.Capacitor && typeof window.Capacitor.getPlatform === 'function') {
    return window.Capacitor.getPlatform();
  }
  
  return 'web';
}

/**
 * Apply safe area insets for iOS devices with notches
 */
export function applySafeAreaInsets(): void {
  if (typeof document === 'undefined') return;
  
  // Only apply on iOS
  if (getPlatform() !== 'ios') return;
  
  // Add CSS variables for safe area insets
  const root = document.documentElement;
  
  // If StatusBar plugin is available, get status bar height
  if (window.Capacitor?.Plugins?.StatusBar) {
    window.Capacitor.Plugins.StatusBar.getInfo()
      .then((info: StatusBarInfo) => {
        root.style.setProperty('--safe-area-top', `${info.height}px`);
      })
      .catch((err: Error) => {
        // eslint-disable-next-line no-console
        logger.error('Failed to get status bar info', { arg1: err });
      });
  }
  
  // Default safe area values if plugins aren't available
  root.style.setProperty('--safe-area-top', 'env(safe-area-inset-top, 0px)');
  root.style.setProperty('--safe-area-right', 'env(safe-area-inset-right, 0px)');
  root.style.setProperty('--safe-area-bottom', 'env(safe-area-inset-bottom, 0px)');
  root.style.setProperty('--safe-area-left', 'env(safe-area-inset-left, 0px)');
}

/**
 * Setup Capacitor environment
 */
export function setupCapacitorEnvironment(): void {
  if (!isCapacitorEnvironment()) return;
  
  // Add Capacitor-specific class to body
  if (typeof document !== 'undefined') {
    document.body.classList.add('capacitor-app');
    document.body.classList.add(`platform-${getPlatform()}`);
  }
  
  // Apply safe area insets
  applySafeAreaInsets();
}

/**
 * Initialize Capacitor and its plugins
 */
export function initializeCapacitor(): void {
  if (!isCapacitorEnvironment()) return;
  
  // Set up environment classes and insets
  setupCapacitorEnvironment();
  
  // Configure status bar for iOS
  if (getPlatform() === 'ios' && window.Capacitor?.Plugins?.StatusBar) {
    window.Capacitor.Plugins.StatusBar.setStyle({ style: 'DARK' });
  }
  
  // eslint-disable-next-line no-console
  logger.info('Capacitor initialized on platform:', { arg1: getPlatform() });
}

/**
 * Convert a file path to a path that can be used in a web context
 */
export function convertFileSrc(path: string): string {
  if (typeof window === 'undefined') return path;
  
  if (window.Capacitor?.convertFileSrc) {
    return window.Capacitor.convertFileSrc(path);
  }
  
  return path;
}