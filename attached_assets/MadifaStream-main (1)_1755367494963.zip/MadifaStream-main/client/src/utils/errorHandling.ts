/**
 * Error Handling Utilities
 * 
 * Provides comprehensive error handling, logging, and recovery utilities
 * for robust application behavior and better user experience.
 */

// Error types
export enum ErrorType {
  NETWORK = 'NETWORK',
  AUTHENTICATION = 'AUTHENTICATION',
  AUTHORIZATION = 'AUTHORIZATION',
  VALIDATION = 'VALIDATION',
  API = 'API',
  VIDEO_PLAYBACK = 'VIDEO_PLAYBACK',
  STORAGE = 'STORAGE',
  UNKNOWN = 'UNKNOWN',
}

// Error severity levels
export enum ErrorSeverity {
  LOW = 'LOW',
  MEDIUM = 'MEDIUM',
  HIGH = 'HIGH',
  CRITICAL = 'CRITICAL',
}

// Base error interface
export interface AppError {
  type: ErrorType;
  severity: ErrorSeverity;
  message: string;
  code?: string;
  details?: any;
  timestamp: number;
  userId?: string;
  context?: string;
  recoverable?: boolean;
}

// Error recovery strategies
export interface ErrorRecovery {
  canRecover: boolean;
  strategy?: 'retry' | 'fallback' | 'redirect' | 'ignore';
  action?: () => Promise<void> | void;
  retryCount?: number;
  maxRetries?: number;
}

// Error handler configuration
export interface ErrorHandlerConfig {
  enableLogging?: boolean;
  enableReporting?: boolean;
  enableNotifications?: boolean;
  reportingEndpoint?: string;
  retryAttempts?: number;
  retryDelay?: number;
}

// Default configuration
const DEFAULT_CONFIG: ErrorHandlerConfig = {
  enableLogging: true,
  enableReporting: true,
  enableNotifications: true,
  retryAttempts: 3,
  retryDelay: 1000,
};

// Error handler class
export class ErrorHandler {
  private config: ErrorHandlerConfig;
  private errors: AppError[] = [];
  private maxStoredErrors = 100;

  constructor(config: ErrorHandlerConfig = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.setupGlobalHandlers();
  }

  // Setup global error handlers
  private setupGlobalHandlers(): void {
    // Handle unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      this.handleError({
        type: ErrorType.UNKNOWN,
        severity: ErrorSeverity.HIGH,
        message: 'Unhandled promise rejection',
        details: event.reason,
        timestamp: Date.now(),
        recoverable: false,
      });
    });

    // Handle global errors
    window.addEventListener('error', (event) => {
      this.handleError({
        type: ErrorType.UNKNOWN,
        severity: ErrorSeverity.HIGH,
        message: event.message,
        details: {
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno,
          error: event.error,
        },
        timestamp: Date.now(),
        recoverable: false,
      });
    });
  }

  // Main error handling method
  public handleError(error: AppError, recovery?: ErrorRecovery): void {
    // Store error
    this.storeError(error);

    // Log error
    if (this.config.enableLogging) {
      this.logError(error);
    }

    // Report error
    if (this.config.enableReporting) {
      this.reportError(error);
    }

    // Show notification
    if (this.config.enableNotifications && error.severity !== ErrorSeverity.LOW) {
      this.showErrorNotification(error);
    }

    // Handle recovery
    if (recovery) {
      this.handleRecovery(error, recovery);
    }
  }

  // Store error in memory
  private storeError(error: AppError): void {
    this.errors.unshift(error);
    if (this.errors.length > this.maxStoredErrors) {
      this.errors = this.errors.slice(0, this.maxStoredErrors);
    }
  }

  // Log error to console
  private logError(error: AppError): void {
    const logLevel = this.getLogLevel(error.severity);
    const message = `[${error.type}] ${error.message}`;
    
    console[logLevel](message, {
      severity: error.severity,
      code: error.code,
      details: error.details,
      timestamp: new Date(error.timestamp).toISOString(),
      context: error.context,
    });
  }

  // Get appropriate log level
  private getLogLevel(severity: ErrorSeverity): 'log' | 'warn' | 'error' {
    switch (severity) {
      case ErrorSeverity.LOW:
        return 'log';
      case ErrorSeverity.MEDIUM:
        return 'warn';
      case ErrorSeverity.HIGH:
      case ErrorSeverity.CRITICAL:
        return 'error';
      default:
        return 'log';
    }
  }

  // Report error to external service
  private async reportError(error: AppError): Promise<void> {
    if (!this.config.reportingEndpoint) return;

    try {
      await fetch(this.config.reportingEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          error,
          userAgent: navigator.userAgent,
          url: window.location.href,
          timestamp: Date.now(),
        }),
      });
    } catch (reportingError) {
      console.error('Failed to report error:', reportingError);
    }
  }

  // Show user notification
  private showErrorNotification(error: AppError): void {
    const message = this.getUserFriendlyMessage(error);
    
    // This would integrate with your notification system
    // For now, we'll just log it
    console.info('Error notification:', message);
  }

  // Get user-friendly error message
  private getUserFriendlyMessage(error: AppError): string {
    switch (error.type) {
      case ErrorType.NETWORK:
        return 'Network connection issue. Please check your internet connection.';
      case ErrorType.AUTHENTICATION:
        return 'Authentication failed. Please log in again.';
      case ErrorType.AUTHORIZATION:
        return 'You don\'t have permission to perform this action.';
      case ErrorType.VALIDATION:
        return 'Invalid input. Please check your data and try again.';
      case ErrorType.API:
        return 'Server error. Please try again later.';
      case ErrorType.VIDEO_PLAYBACK:
        return 'Video playback error. Please try refreshing the page.';
      case ErrorType.STORAGE:
        return 'Storage error. Please clear your browser cache.';
      default:
        return 'An unexpected error occurred. Please try again.';
    }
  }

  // Handle error recovery
  private async handleRecovery(error: AppError, recovery: ErrorRecovery): Promise<void> {
    if (!recovery.canRecover) return;

    try {
      switch (recovery.strategy) {
        case 'retry':
          await this.retryOperation(recovery);
          break;
        case 'fallback':
          if (recovery.action) {
            await recovery.action();
          }
          break;
        case 'redirect':
          window.location.href = '/error';
          break;
        case 'ignore':
          // Do nothing, just log
          break;
      }
    } catch (recoveryError) {
      console.error('Recovery failed:', recoveryError);
    }
  }

  // Retry operation with exponential backoff
  private async retryOperation(recovery: ErrorRecovery): Promise<void> {
    const maxRetries = recovery.maxRetries || this.config.retryAttempts || 3;
    let retryCount = recovery.retryCount || 0;

    if (retryCount >= maxRetries) {
      console.error('Max retries exceeded');
      return;
    }

    const delay = (this.config.retryDelay || 1000) * Math.pow(2, retryCount);
    
    setTimeout(async () => {
      try {
        if (recovery.action) {
          await recovery.action();
        }
      } catch (error) {
        await this.retryOperation({
          ...recovery,
          retryCount: retryCount + 1,
        });
      }
    }, delay);
  }

  // Get stored errors
  public getErrors(): AppError[] {
    return [...this.errors];
  }

  // Clear stored errors
  public clearErrors(): void {
    this.errors = [];
  }

  // Get errors by type
  public getErrorsByType(type: ErrorType): AppError[] {
    return this.errors.filter(error => error.type === type);
  }

  // Get errors by severity
  public getErrorsBySeverity(severity: ErrorSeverity): AppError[] {
    return this.errors.filter(error => error.severity === severity);
  }
}

// Create global error handler instance
export const globalErrorHandler = new ErrorHandler();

// Utility functions for common error scenarios
export const errorUtils = {
  // Handle API errors
  handleApiError: (error: any, context?: string): void => {
    const appError: AppError = {
      type: ErrorType.API,
      severity: ErrorSeverity.MEDIUM,
      message: error.message || 'API request failed',
      code: error.code || error.status,
      details: error.response?.data || error,
      timestamp: Date.now(),
      context,
      recoverable: true,
    };

    globalErrorHandler.handleError(appError, {
      canRecover: true,
      strategy: 'retry',
      maxRetries: 3,
    });
  },

  // Handle network errors
  handleNetworkError: (error: any, context?: string): void => {
    const appError: AppError = {
      type: ErrorType.NETWORK,
      severity: ErrorSeverity.HIGH,
      message: 'Network connection failed',
      details: error,
      timestamp: Date.now(),
      context,
      recoverable: true,
    };

    globalErrorHandler.handleError(appError, {
      canRecover: true,
      strategy: 'retry',
      maxRetries: 5,
    });
  },

  // Handle authentication errors
  handleAuthError: (error: any, context?: string): void => {
    const appError: AppError = {
      type: ErrorType.AUTHENTICATION,
      severity: ErrorSeverity.HIGH,
      message: 'Authentication failed',
      details: error,
      timestamp: Date.now(),
      context,
      recoverable: true,
    };

    globalErrorHandler.handleError(appError, {
      canRecover: true,
      strategy: 'redirect',
      action: () => {
        window.location.href = '/login';
      },
    });
  },

  // Handle video playback errors
  handleVideoError: (error: any, context?: string): void => {
    const appError: AppError = {
      type: ErrorType.VIDEO_PLAYBACK,
      severity: ErrorSeverity.MEDIUM,
      message: 'Video playback failed',
      details: error,
      timestamp: Date.now(),
      context,
      recoverable: true,
    };

    globalErrorHandler.handleError(appError, {
      canRecover: true,
      strategy: 'fallback',
      action: () => {
        // Try lower quality or different format
        console.log('Trying fallback video quality');
      },
    });
  },

  // Handle validation errors
  handleValidationError: (errors: any[], context?: string): void => {
    const appError: AppError = {
      type: ErrorType.VALIDATION,
      severity: ErrorSeverity.LOW,
      message: 'Validation failed',
      details: errors,
      timestamp: Date.now(),
      context,
      recoverable: true,
    };

    globalErrorHandler.handleError(appError);
  },

  // Create custom error
  createError: (
    type: ErrorType,
    severity: ErrorSeverity,
    message: string,
    details?: any,
    context?: string
  ): AppError => ({
    type,
    severity,
    message,
    details,
    timestamp: Date.now(),
    context,
    recoverable: true,
  }),
};

// Error boundary hook for React components
export const useErrorBoundary = () => {
  const reportError = (error: Error, errorInfo?: any) => {
    const appError: AppError = {
      type: ErrorType.UNKNOWN,
      severity: ErrorSeverity.HIGH,
      message: error.message,
      details: {
        stack: error.stack,
        errorInfo,
      },
      timestamp: Date.now(),
      recoverable: false,
    };

    globalErrorHandler.handleError(appError);
  };

  return { reportError };
};
