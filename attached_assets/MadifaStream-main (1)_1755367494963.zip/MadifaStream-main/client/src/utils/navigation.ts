/**
 * Navigation and Route Management Utilities
 * 
 * Provides enhanced navigation handling, route management, and URL utilities
 * for better user experience and application state management.
 */

import { Router } from 'wouter';

// Route definitions
export interface RouteDefinition {
  path: string;
  name: string;
  title: string;
  description?: string;
  requiresAuth?: boolean;
  roles?: string[];
  component?: React.ComponentType<any>;
  exact?: boolean;
  children?: RouteDefinition[];
  validate?: () => { valid: boolean; redirectTo?: string; message?: string };
  preload?: () => Promise<void>;
  meta?: {
    keywords?: string[];
    ogImage?: string;
    canonical?: string;
  };
}

// Navigation state
export interface NavigationState {
  currentPath: string;
  previousPath: string | null;
  history: string[];
  canGoBack: boolean;
  canGoForward: boolean;
}

// Application routes
export const APP_ROUTES: RouteDefinition[] = [
  {
    path: '/',
    name: 'home',
    title: 'Home',
    description: 'Discover trending movies and TV shows',
    requiresAuth: false,
  },
  {
    path: '/browse',
    name: 'browse',
    title: 'Browse',
    description: 'Browse all available content',
    requiresAuth: true,
  },
  {
    path: '/search',
    name: 'search',
    title: 'Search',
    description: 'Search for movies and TV shows',
    requiresAuth: false,
  },
  {
    path: '/watch/:id',
    name: 'watch',
    title: 'Watch',
    description: 'Watch video content',
    requiresAuth: true,
  },
  {
    path: '/profile',
    name: 'profile',
    title: 'Profile',
    description: 'User profile and settings',
    requiresAuth: true,
  },
  {
    path: '/watchlist',
    name: 'watchlist',
    title: 'My Watchlist',
    description: 'Your saved movies and shows',
    requiresAuth: true,
  },
  {
    path: '/history',
    name: 'history',
    title: 'Watch History',
    description: 'Your recently watched content',
    requiresAuth: true,
  },
  {
    path: '/settings',
    name: 'settings',
    title: 'Settings',
    description: 'Application settings and preferences',
    requiresAuth: true,
  },
  {
    path: '/login',
    name: 'login',
    title: 'Login',
    description: 'Sign in to your account',
    requiresAuth: false,
  },
  {
    path: '/register',
    name: 'register',
    title: 'Register',
    description: 'Create a new account',
    requiresAuth: false,
  },
  {
    path: '/404',
    name: 'notFound',
    title: '404 - Page Not Found',
    description: 'The page you are looking for does not exist',
    requiresAuth: false,
  },
];

// Navigation utility class
export class NavigationManager {
  private history: string[] = [];
  private currentIndex: number = -1;
  private maxHistorySize: number = 50;

  constructor() {
    this.initialize();
  }

  // Initialize navigation manager
  private initialize(): void {
    // Add current page to history
    this.addToHistory(window.location.pathname);
    
    // Listen for popstate events
    window.addEventListener('popstate', this.handlePopState.bind(this));
  }

  // Handle browser back/forward
  private handlePopState(event: PopStateEvent): void {
    const path = window.location.pathname;
    this.addToHistory(path);
  }

  // Add path to history
  private addToHistory(path: string): void {
    // Remove everything after current index
    this.history = this.history.slice(0, this.currentIndex + 1);
    
    // Add new path if it's different from current
    if (this.history[this.currentIndex] !== path) {
      this.history.push(path);
      this.currentIndex++;
      
      // Limit history size
      if (this.history.length > this.maxHistorySize) {
        this.history.shift();
        this.currentIndex--;
      }
    }
  }

  // Navigate to path
  public navigate(path: string, replace: boolean = false): void {
    if (replace) {
      window.history.replaceState(null, '', path);
    } else {
      window.history.pushState(null, '', path);
      this.addToHistory(path);
    }
  }

  // Go back in history
  public goBack(): boolean {
    if (this.canGoBack()) {
      window.history.back();
      return true;
    }
    return false;
  }

  // Go forward in history
  public goForward(): boolean {
    if (this.canGoForward()) {
      window.history.forward();
      return true;
    }
    return false;
  }

  // Check if can go back
  public canGoBack(): boolean {
    return this.currentIndex > 0;
  }

  // Check if can go forward
  public canGoForward(): boolean {
    return this.currentIndex < this.history.length - 1;
  }

  // Get current navigation state
  public getNavigationState(): NavigationState {
    return {
      currentPath: window.location.pathname,
      previousPath: this.history[this.currentIndex - 1] || null,
      history: [...this.history],
      canGoBack: this.canGoBack(),
      canGoForward: this.canGoForward(),
    };
  }

  // Get current route definition
  public getCurrentRoute(): RouteDefinition | null {
    const currentPath = window.location.pathname;
    return this.findRoute(currentPath);
  }

  // Find route by path
  public findRoute(path: string): RouteDefinition | null {
    return APP_ROUTES.find(route => {
      if (route.exact) {
        return route.path === path;
      }
      return this.matchPath(route.path, path);
    }) || null;
  }

  // Match path with route pattern
  public matchPath(pattern: string, path: string): boolean {
    const patternParts = pattern.split('/');
    const pathParts = path.split('/');
    
    if (patternParts.length !== pathParts.length) {
      return false;
    }
    
    return patternParts.every((part, index) => {
      if (part.startsWith(':')) {
        return true; // Parameter match
      }
      return part === pathParts[index];
    });
  }

  // Extract parameters from path
  public extractParams(pattern: string, path: string): Record<string, string> {
    const params: Record<string, string> = {};
    const patternParts = pattern.split('/');
    const pathParts = path.split('/');
    
    patternParts.forEach((part, index) => {
      if (part.startsWith(':')) {
        const paramName = part.substring(1);
        params[paramName] = pathParts[index];
      }
    });
    
    return params;
  }

  // Get breadcrumbs for current path
  public getBreadcrumbs(): Array<{ name: string; path: string; title: string }> {
    const currentPath = window.location.pathname;
    const pathParts = currentPath.split('/').filter(Boolean);
    const breadcrumbs: Array<{ name: string; path: string; title: string }> = [];
    
    // Add home
    breadcrumbs.push({
      name: 'home',
      path: '/',
      title: 'Home',
    });
    
    // Build breadcrumbs from path parts
    let currentPathBuilder = '';
    pathParts.forEach((part, index) => {
      currentPathBuilder += `/${part}`;
      const route = this.findRoute(currentPathBuilder);
      
      if (route) {
        breadcrumbs.push({
          name: route.name,
          path: currentPathBuilder,
          title: route.title,
        });
      }
    });
    
    return breadcrumbs;
  }
}

// Create global navigation manager
export const navigationManager = new NavigationManager();

// URL utility functions
export const urlUtils = {
  // Build URL with query parameters
  buildUrl: (path: string, params?: Record<string, any>): string => {
    if (!params) return path;
    
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        searchParams.append(key, String(value));
      }
    });
    
    const queryString = searchParams.toString();
    return queryString ? `${path}?${queryString}` : path;
  },

  // Parse query parameters
  parseQuery: (search?: string): Record<string, string> => {
    const params: Record<string, string> = {};
    const searchParams = new URLSearchParams(search || window.location.search);
    
    searchParams.forEach((value, key) => {
      params[key] = value;
    });
    
    return params;
  },

  // Get current query parameters
  getCurrentQuery: (): Record<string, string> => {
    return urlUtils.parseQuery();
  },

  // Update query parameters
  updateQuery: (updates: Record<string, any>, replace: boolean = false): void => {
    const currentParams = urlUtils.getCurrentQuery();
    const newParams = { ...currentParams, ...updates };
    
    // Remove undefined/null values
    Object.keys(newParams).forEach(key => {
      if (newParams[key] === undefined || newParams[key] === null) {
        delete newParams[key];
      }
    });
    
    const newUrl = urlUtils.buildUrl(window.location.pathname, newParams);
    navigationManager.navigate(newUrl, replace);
  },

  // Remove query parameters
  removeQuery: (keys: string[]): void => {
    const currentParams = urlUtils.getCurrentQuery();
    keys.forEach(key => delete currentParams[key]);
    
    const newUrl = urlUtils.buildUrl(window.location.pathname, currentParams);
    navigationManager.navigate(newUrl, true);
  },

  // Get path without query parameters
  getPathname: (): string => {
    return window.location.pathname;
  },

  // Check if current path matches pattern
  isCurrentPath: (pattern: string): boolean => {
    const route = navigationManager.findRoute(pattern);
    return !!route && navigationManager.matchPath(pattern, window.location.pathname);
  },

  // Generate path with parameters
  generatePath: (pattern: string, params: Record<string, string>): string => {
    let path = pattern;
    Object.entries(params).forEach(([key, value]) => {
      path = path.replace(`:${key}`, value);
    });
    return path;
  },
};

// Navigation helpers
export const navigationHelpers = {
  // Navigate to home
  goHome: (): void => {
    navigationManager.navigate('/');
  },

  // Navigate to login
  goToLogin: (returnUrl?: string): void => {
    const loginUrl = returnUrl 
      ? urlUtils.buildUrl('/login', { returnUrl })
      : '/login';
    navigationManager.navigate(loginUrl);
  },

  // Navigate to video watch page
  goToWatch: (videoId: string): void => {
    navigationManager.navigate(`/watch/${videoId}`);
  },

  // Navigate to search with query
  goToSearch: (query?: string): void => {
    const searchUrl = query 
      ? urlUtils.buildUrl('/search', { q: query })
      : '/search';
    navigationManager.navigate(searchUrl);
  },

  // Navigate to browse with filters
  goToBrowse: (filters?: Record<string, any>): void => {
    const browseUrl = urlUtils.buildUrl('/browse', filters);
    navigationManager.navigate(browseUrl);
  },

  // Navigate to profile
  goToProfile: (): void => {
    navigationManager.navigate('/profile');
  },

  // Navigate to watchlist
  goToWatchlist: (): void => {
    navigationManager.navigate('/watchlist');
  },

  // Navigate to history
  goToHistory: (): void => {
    navigationManager.navigate('/history');
  },

  // Navigate to settings
  goToSettings: (): void => {
    navigationManager.navigate('/settings');
  },

  // Navigate back or to fallback
  goBackOrFallback: (fallbackPath: string = '/'): void => {
    if (!navigationManager.goBack()) {
      navigationManager.navigate(fallbackPath);
    }
  },

  // Check if user can access route
  canAccessRoute: (route: RouteDefinition, userRoles?: string[]): boolean => {
    if (!route.requiresAuth) return true;
    
    // Check authentication (implement your auth logic here)
    const isAuthenticated = true; // Placeholder
    if (!isAuthenticated) return false;
    
    // Check roles if specified
    if (route.roles && route.roles.length > 0) {
      return route.roles.some(role => userRoles?.includes(role));
    }
    
    return true;
  },

  // Get route title for page
  getPageTitle: (route?: RouteDefinition): string => {
    if (!route) return 'Page Not Found';
    return route.title;
  },
};
