/**
 * SEO Meta Generation Utilities
 * 
 * Provides utilities for generating SEO meta tags, Open Graph tags,
 * Twitter Card tags, and structured data for better search engine visibility.
 */

import { SupportedLanguage, DEFAULT_LANGUAGE, routingUtils } from './i18n';

// SEO configuration
export interface SEOConfig {
  siteName: string;
  siteUrl: string;
  defaultTitle: string;
  titleTemplate: string;
  defaultDescription: string;
  defaultImage: string;
  defaultImageAlt: string;
  twitterHandle: string;
  facebookAppId?: string;
  themeColor: string;
  backgroundColor: string;
}

// Page metadata
export interface PageMetadata {
  title?: string;
  description?: string;
  keywords?: string[];
  image?: string;
  imageAlt?: string;
  canonicalUrl?: string;
  publishedTime?: string;
  modifiedTime?: string;
  author?: string;
  section?: string;
  tags?: string[];
  type?: 'website' | 'article' | 'video' | 'profile';
  videoUrl?: string;
  videoDuration?: number;
  videoDescription?: string;
  noIndex?: boolean;
  noFollow?: boolean;
}

// Default SEO configuration
export const DEFAULT_SEO_CONFIG: SEOConfig = {
  siteName: 'MadifaStream',
  siteUrl: 'https://madifastream.com',
  defaultTitle: 'MadifaStream - Premium Video Streaming Platform',
  titleTemplate: '%s | MadifaStream',
  defaultDescription: 'Discover and stream premium movies, TV shows, and original content on MadifaStream. Your ultimate entertainment destination.',
  defaultImage: '/images/og-image.jpg',
  defaultImageAlt: 'MadifaStream - Premium Video Streaming Platform',
  twitterHandle: '@MadifaStream',
  facebookAppId: undefined,
  themeColor: '#3B82F6',
  backgroundColor: '#1F2937',
};

// Generate page title
export const generateTitle = (
  pageTitle?: string,
  config: SEOConfig = DEFAULT_SEO_CONFIG
): string => {
  if (!pageTitle) return config.defaultTitle;
  return config.titleTemplate.replace('%s', pageTitle);
};

// Generate canonical URL
export const generateCanonicalUrl = (
  path: string,
  language: SupportedLanguage = DEFAULT_LANGUAGE,
  config: SEOConfig = DEFAULT_SEO_CONFIG
): string => {
  // Simple localization for now - just use the path as-is
  const localizedPath = path;
  return `${config.siteUrl}${localizedPath}`;
};

// Generate meta tags
export const generateMetaTags = (
  metadata: PageMetadata,
  language: SupportedLanguage = DEFAULT_LANGUAGE,
  config: SEOConfig = DEFAULT_SEO_CONFIG
): Array<{ name?: string; property?: string; content: string }> => {
  const tags: Array<{ name?: string; property?: string; content: string }> = [];

  // Basic meta tags
  tags.push(
    { name: 'description', content: metadata.description || config.defaultDescription },
    { name: 'author', content: metadata.author || config.siteName },
    { name: 'language', content: language },
    { name: 'theme-color', content: config.themeColor },
    { name: 'msapplication-TileColor', content: config.backgroundColor }
  );

  // Keywords
  if (metadata.keywords && metadata.keywords.length > 0) {
    tags.push({ name: 'keywords', content: metadata.keywords.join(', ') });
  }

  // Robots
  const robotsDirectives: string[] = [];
  if (metadata.noIndex) robotsDirectives.push('noindex');
  if (metadata.noFollow) robotsDirectives.push('nofollow');
  if (robotsDirectives.length === 0) robotsDirectives.push('index', 'follow');
  tags.push({ name: 'robots', content: robotsDirectives.join(', ') });

  // Open Graph tags
  tags.push(
    { property: 'og:title', content: generateTitle(metadata.title, config) },
    { property: 'og:description', content: metadata.description || config.defaultDescription },
    { property: 'og:type', content: metadata.type || 'website' },
    { property: 'og:site_name', content: config.siteName },
    { property: 'og:locale', content: language },
    { property: 'og:image', content: metadata.image || config.defaultImage },
    { property: 'og:image:alt', content: metadata.imageAlt || config.defaultImageAlt }
  );

  // Canonical URL
  if (metadata.canonicalUrl) {
    tags.push({ property: 'og:url', content: metadata.canonicalUrl });
  }

  // Article-specific tags
  if (metadata.type === 'article') {
    if (metadata.publishedTime) {
      tags.push({ property: 'article:published_time', content: metadata.publishedTime });
    }
    if (metadata.modifiedTime) {
      tags.push({ property: 'article:modified_time', content: metadata.modifiedTime });
    }
    if (metadata.author) {
      tags.push({ property: 'article:author', content: metadata.author });
    }
    if (metadata.section) {
      tags.push({ property: 'article:section', content: metadata.section });
    }
    if (metadata.tags) {
      metadata.tags.forEach(tag => {
        tags.push({ property: 'article:tag', content: tag });
      });
    }
  }

  // Video-specific tags
  if (metadata.type === 'video' && metadata.videoUrl) {
    tags.push(
      { property: 'og:video', content: metadata.videoUrl },
      { property: 'og:video:type', content: 'video/mp4' }
    );
    if (metadata.videoDuration) {
      tags.push({ property: 'og:video:duration', content: metadata.videoDuration.toString() });
    }
    if (metadata.videoDescription) {
      tags.push({ property: 'og:video:description', content: metadata.videoDescription });
    }
  }

  // Twitter Card tags
  tags.push(
    { name: 'twitter:card', content: metadata.type === 'video' ? 'player' : 'summary_large_image' },
    { name: 'twitter:site', content: config.twitterHandle },
    { name: 'twitter:title', content: generateTitle(metadata.title, config) },
    { name: 'twitter:description', content: metadata.description || config.defaultDescription },
    { name: 'twitter:image', content: metadata.image || config.defaultImage },
    { name: 'twitter:image:alt', content: metadata.imageAlt || config.defaultImageAlt }
  );

  // Twitter video card
  if (metadata.type === 'video' && metadata.videoUrl) {
    tags.push(
      { name: 'twitter:player', content: metadata.videoUrl },
      { name: 'twitter:player:width', content: '1920' },
      { name: 'twitter:player:height', content: '1080' }
    );
  }

  // Facebook App ID
  if (config.facebookAppId) {
    tags.push({ property: 'fb:app_id', content: config.facebookAppId });
  }

  return tags;
};

// Generate hreflang links
export const generateHrefLangLinks = (
  currentPath: string,
  config: SEOConfig = DEFAULT_SEO_CONFIG
): Array<{ rel: string; hreflang: string; href: string }> => {
  // Simple implementation for now - just return current path for default language
  return [{
    rel: 'alternate',
    hreflang: 'en',
    href: `${config.siteUrl}${currentPath}`,
  }];
};

// Generate structured data (JSON-LD)
export const generateStructuredData = (
  metadata: PageMetadata,
  language: SupportedLanguage = DEFAULT_LANGUAGE,
  config: SEOConfig = DEFAULT_SEO_CONFIG
): object => {
  const baseStructure = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: config.siteName,
    url: config.siteUrl,
    description: config.defaultDescription,
    inLanguage: language,
  };

  // Website with search action
  if (metadata.type === 'website' || !metadata.type) {
    return {
      ...baseStructure,
      potentialAction: {
        '@type': 'SearchAction',
        target: `${config.siteUrl}/search?q={search_term_string}`,
        'query-input': 'required name=search_term_string',
      },
    };
  }

  // Article structure
  if (metadata.type === 'article') {
    return {
      '@context': 'https://schema.org',
      '@type': 'Article',
      headline: generateTitle(metadata.title, config),
      description: metadata.description || config.defaultDescription,
      image: metadata.image || config.defaultImage,
      author: {
        '@type': 'Person',
        name: metadata.author || config.siteName,
      },
      publisher: {
        '@type': 'Organization',
        name: config.siteName,
        logo: {
          '@type': 'ImageObject',
          url: `${config.siteUrl}/images/logo.png`,
        },
      },
      datePublished: metadata.publishedTime,
      dateModified: metadata.modifiedTime,
      mainEntityOfPage: {
        '@type': 'WebPage',
        '@id': metadata.canonicalUrl,
      },
    };
  }

  // Video structure
  if (metadata.type === 'video') {
    return {
      '@context': 'https://schema.org',
      '@type': 'VideoObject',
      name: generateTitle(metadata.title, config),
      description: metadata.videoDescription || metadata.description || config.defaultDescription,
      thumbnailUrl: metadata.image || config.defaultImage,
      contentUrl: metadata.videoUrl,
      uploadDate: metadata.publishedTime,
      duration: metadata.videoDuration ? `PT${metadata.videoDuration}S` : undefined,
      publisher: {
        '@type': 'Organization',
        name: config.siteName,
        logo: {
          '@type': 'ImageObject',
          url: `${config.siteUrl}/images/logo.png`,
        },
      },
    };
  }

  return baseStructure;
};

// SEO utilities for React components
export const seoUtils = {
  // Generate all meta tags for a page
  generatePageMeta: (
    metadata: PageMetadata,
    language: SupportedLanguage = DEFAULT_LANGUAGE,
    config: SEOConfig = DEFAULT_SEO_CONFIG
  ) => {
    const title = generateTitle(metadata.title, config);
    const canonicalUrl = metadata.canonicalUrl || generateCanonicalUrl(window.location.pathname, language, config);
    const metaTags = generateMetaTags({ ...metadata, canonicalUrl }, language, config);
    const hrefLangLinks = generateHrefLangLinks(window.location.pathname, config);
    const structuredData = generateStructuredData({ ...metadata, canonicalUrl }, language, config);

    return {
      title,
      metaTags,
      hrefLangLinks,
      structuredData,
      canonicalUrl,
    };
  },

  // Update document head with SEO meta
  updateDocumentHead: (
    metadata: PageMetadata,
    language: SupportedLanguage = DEFAULT_LANGUAGE,
    config: SEOConfig = DEFAULT_SEO_CONFIG
  ) => {
    const { title, metaTags, hrefLangLinks, structuredData, canonicalUrl } = seoUtils.generatePageMeta(
      metadata,
      language,
      config
    );

    // Update title
    document.title = title;

    // Remove existing meta tags
    const existingMetas = document.querySelectorAll('meta[data-seo]');
    existingMetas.forEach(meta => meta.remove());

    // Add new meta tags
    metaTags.forEach(({ name, property, content }) => {
      const meta = document.createElement('meta');
      meta.setAttribute('data-seo', 'true');
      if (name) meta.setAttribute('name', name);
      if (property) meta.setAttribute('property', property);
      meta.setAttribute('content', content);
      document.head.appendChild(meta);
    });

    // Update canonical link
    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.rel = 'canonical';
      document.head.appendChild(canonical);
    }
    canonical.href = canonicalUrl;

    // Remove existing hreflang links
    const existingHrefLang = document.querySelectorAll('link[rel="alternate"][hreflang]');
    existingHrefLang.forEach(link => link.remove());

    // Add new hreflang links
    hrefLangLinks.forEach(({ rel, hreflang, href }) => {
      const link = document.createElement('link');
      link.rel = rel;
      link.hreflang = hreflang;
      link.href = href;
      document.head.appendChild(link);
    });

    // Update structured data
    let structuredDataScript = document.querySelector('script[type="application/ld+json"][data-seo]') as HTMLScriptElement;
    if (!structuredDataScript) {
      structuredDataScript = document.createElement('script');
      (structuredDataScript as HTMLScriptElement).type = 'application/ld+json';
      structuredDataScript.setAttribute('data-seo', 'true');
      document.head.appendChild(structuredDataScript);
    }
    structuredDataScript.textContent = JSON.stringify(structuredData);
  },

  // Generate SEO-friendly URL slug
  generateSlug: (text: string): string => {
    return text
      .toLowerCase()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  },

  // Extract metadata from video object
  extractVideoMetadata: (video: any): PageMetadata => {
    return {
      title: video.title,
      description: video.description,
      type: 'video',
      image: video.thumbnail_url,
      videoUrl: video.video_url,
      videoDuration: video.duration,
      videoDescription: video.description,
      publishedTime: video.created_at,
      modifiedTime: video.updated_at,
      tags: video.tags || [],
    };
  },
};
