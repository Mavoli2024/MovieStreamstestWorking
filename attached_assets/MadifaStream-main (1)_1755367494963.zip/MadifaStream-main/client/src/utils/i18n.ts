// Simple i18n utility for MadifaStream
export type SupportedLanguage = 'en' | 'af';
export const DEFAULT_LANGUAGE: SupportedLanguage = 'en';

export const routingUtils = {
  getLocalizedPath: (path: string, language: SupportedLanguage = DEFAULT_LANGUAGE) => {
    if (language === DEFAULT_LANGUAGE) return path;
    return `/${language}${path}`;
  },
  
  getCurrentLanguage: (): SupportedLanguage => {
    // Simple language detection based on URL or browser
    const urlLang = window.location.pathname.split('/')[1] as SupportedLanguage;
    if (['en', 'af'].includes(urlLang)) return urlLang;
    
    // Fallback to browser language or default
    const browserLang = navigator.language.split('-')[0] as SupportedLanguage;
    return ['en', 'af'].includes(browserLang) ? browserLang : DEFAULT_LANGUAGE;
  }
};