/**
 * Class Name Utility
 * 
 * Utility for combining class names with conditional logic
 * and proper handling of Tailwind CSS classes.
 */

import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Combines class names with proper Tailwind CSS handling
 * Uses clsx for conditional logic and tailwind-merge for deduplication
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export default cn;
