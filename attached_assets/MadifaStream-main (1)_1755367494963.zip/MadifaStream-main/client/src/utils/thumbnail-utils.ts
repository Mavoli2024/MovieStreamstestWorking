/**
 * Unified thumbnail utilities for consistent image loading across the app
 */

import type { Database } from '@/types/database-generated.types';

type Video = Database['public']['Tables']['videos']['Row'];

/**
 * Get the best available thumbnail URL for a video
 * Handles multiple property names and fallbacks
 */
export function getVideoThumbnailUrl(video: Partial<Video> | any): string {
  // Check for various thumbnail property names
  const thumbnailUrl = 
    video.thumbnail_url || 
    video.thumbnailUrl || 
    video.poster_url || 
    video.posterUrl ||
    video.image_url ||
    video.imageUrl;

  if (thumbnailUrl) {
    // Handle Bunny CDN URLs
    if (thumbnailUrl.includes('b-cdn.net') || thumbnailUrl.includes('bunnycdn.com')) {
      return thumbnailUrl;
    }
    
    // Handle relative URLs
    if (thumbnailUrl.startsWith('/')) {
      return thumbnailUrl;
    }
    
    // Handle full URLs
    if (thumbnailUrl.startsWith('http')) {
      return thumbnailUrl;
    }
  }

  // Fallback to API endpoint if video has an ID
  if (video.id) {
    return `/api/videos/${video.id}/thumbnail`;
  }

  // Return a placeholder if nothing else works
  return generatePlaceholderThumbnail(video.title || 'Video');
}

/**
 * Generate a placeholder thumbnail as a data URL
 */
export function generatePlaceholderThumbnail(title: string): string {
  const firstLetter = title.charAt(0).toUpperCase() || 'V';
  const color = generateColorFromString(title);
  
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="320" height="180" viewBox="0 0 320 180">
      <rect width="320" height="180" fill="${color}" />
      <text x="160" y="90" font-family="Arial, sans-serif" font-size="48" fill="white" text-anchor="middle" dominant-baseline="middle">${firstLetter}</text>
    </svg>
  `;
  
  return `data:image/svg+xml;base64,${btoa(svg)}`;
}

/**
 * Generate a consistent color from a string
 */
function generateColorFromString(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  
  const hue = hash % 360;
  return `hsl(${hue}, 65%, 45%)`;
}

/**
 * Preload an image URL
 */
export function preloadImage(url: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve();
    img.onerror = () => reject(new Error(`Failed to load image: ${url}`));
    img.src = url;
  });
}

/**
 * Get optimized thumbnail URL with size parameters
 */
export function getOptimizedThumbnailUrl(
  url: string, 
  width?: number, 
  height?: number
): string {
  if (!url) return '';
  
  // For Bunny CDN URLs, add optimization parameters
  if (url.includes('b-cdn.net') || url.includes('bunnycdn.com')) {
    const separator = url.includes('?') ? '&' : '?';
    const params = [];
    if (width) params.push(`width=${width}`);
    if (height) params.push(`height=${height}`);
    params.push('quality=85'); // Good quality/size balance
    
    return params.length ? `${url}${separator}${params.join('&')}` : url;
  }
  
  return url;
}