// client/src/types/api-types.d.ts

declare namespace Api {
  interface Video {
    id: number | string;
    guid: string;
    title: string;
    description?: string;
    thumbnailUrl: string;
    hlsUrl?: string;
    duration?: number;
    createdAt: string;
    views?: number;
  }

  interface UserProfile {
    id: number | string;
    authId: string;
    username: string;
    email: string;
    displayName?: string;
    avatarUrl?: string;
    role: 'admin' | 'user';
  }

  interface UserSubscription {
    id: number;
    planName: string;
    status: 'active' | 'cancelled' | 'expired' | 'pending';
    startDate: string;
    endDate: string | null;
    autoRenew: boolean;
  }
} 