declare module 'wouter' {
  import * as React from 'react';
  // Minimal navigate helper
  export function useNavigate(): (to: string, options?: { replace?: boolean }) => void;

  // Current location and imperative navigation (same return tuple as useLocation())
  export function useLocation(): [
    string,
    (to: string, options?: { replace?: boolean }) => void
  ];

  // URL params helper. Generic defaults to Record<string, string>
  export function useParams<T extends Record<string, string> = Record<string, string>>(): T;

  // Simple redirect component (useful for declarative navigation)
  export const Redirect: React.FC<{ to: string }>;

  // Link wrapper component
  export const Link: React.FC<
    React.PropsWithChildren<{
      href?: string; // destination path (alias)
      to?: string; // destination path (preferred in v3 but optional for compatibility)
      className?: string;
      replace?: boolean;
      onClick?: React.MouseEventHandler;
    }>
  >;

  // Router components (minimal typings)
  export const Router: React.FC<React.PropsWithChildren<{ base?: string }>>;
  export const Route: React.FC<React.PropsWithChildren<{ path: string; component?: React.ComponentType<unknown> }>>;
  export const Switch: React.FC<React.PropsWithChildren<object>>;
} 