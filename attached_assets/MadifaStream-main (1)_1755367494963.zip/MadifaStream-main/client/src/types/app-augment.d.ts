declare global {
  interface ContentCollection {
    guid: string;
    previewVideoIds?: string[];
    name?: string;
  }
}

export {}; 