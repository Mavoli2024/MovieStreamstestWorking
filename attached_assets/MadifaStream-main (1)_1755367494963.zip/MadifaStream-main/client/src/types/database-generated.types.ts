export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      automation_logs: {
        Row: {
          booking_id: string
          created_at: string
          error: string | null
          event_type: string
          id: string
          metadata: string | null
          processed_at: string
          status: string
          triggered_by: string | null
        }
        Insert: {
          booking_id: string
          created_at?: string
          error?: string | null
          event_type: string
          id: string
          metadata?: string | null
          processed_at: string
          status: string
          triggered_by?: string | null
        }
        Update: {
          booking_id?: string
          created_at?: string
          error?: string | null
          event_type?: string
          id?: string
          metadata?: string | null
          processed_at?: string
          status?: string
          triggered_by?: string | null
        }
        Relationships: []
      }
      bookings: {
        Row: {
          business_id: string
          cancellation_reason: string | null
          cancelled_at: string | null
          cancelled_by: string | null
          completed_at: string | null
          confirmed_at: string | null
          created_at: string
          customer_email: string
          customer_id: string
          customer_name: string
          customer_phone: string | null
          deposit_amount: number | null
          duration: number
          end_time: string
          id: string
          internal_notes: string | null
          notes: string | null
          payment_method: string | null
          payment_reference: string | null
          payment_status: string
          scheduled_at: string
          service_id: string
          staff_id: string | null
          status: string
          total_amount: number
          updated_at: string
        }
        Insert: {
          business_id: string
          cancellation_reason?: string | null
          cancelled_at?: string | null
          cancelled_by?: string | null
          completed_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          customer_email: string
          customer_id: string
          customer_name: string
          customer_phone?: string | null
          deposit_amount?: number | null
          duration: number
          end_time: string
          id: string
          internal_notes?: string | null
          notes?: string | null
          payment_method?: string | null
          payment_reference?: string | null
          payment_status?: string
          scheduled_at: string
          service_id: string
          staff_id?: string | null
          status?: string
          total_amount: number
          updated_at?: string
        }
        Update: {
          business_id?: string
          cancellation_reason?: string | null
          cancelled_at?: string | null
          cancelled_by?: string | null
          completed_at?: string | null
          confirmed_at?: string | null
          created_at?: string
          customer_email?: string
          customer_id?: string
          customer_name?: string
          customer_phone?: string | null
          deposit_amount?: number | null
          duration?: number
          end_time?: string
          id?: string
          internal_notes?: string | null
          notes?: string | null
          payment_method?: string | null
          payment_reference?: string | null
          payment_status?: string
          scheduled_at?: string
          service_id?: string
          staff_id?: string | null
          status?: string
          total_amount?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bookings_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_service_id_fkey"
            columns: ["service_id"]
            isOneToOne: false
            referencedRelation: "services"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bookings_staff_id_fkey"
            columns: ["staff_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      bulk_operations: {
        Row: {
          completed_items: number | null
          created_at: string | null
          error_message: string | null
          id: string
          progress: number | null
          status: string
          total_items: number | null
          type: string
          updated_at: string | null
        }
        Insert: {
          completed_items?: number | null
          created_at?: string | null
          error_message?: string | null
          id?: string
          progress?: number | null
          status?: string
          total_items?: number | null
          type: string
          updated_at?: string | null
        }
        Update: {
          completed_items?: number | null
          created_at?: string | null
          error_message?: string | null
          id?: string
          progress?: number | null
          status?: string
          total_items?: number | null
          type?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      business_members: {
        Row: {
          business_id: string
          created_at: string
          id: string
          permissions: Json | null
          role: string
          updated_at: string
          user_id: string
        }
        Insert: {
          business_id: string
          created_at?: string
          id: string
          permissions?: Json | null
          role?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          business_id?: string
          created_at?: string
          id?: string
          permissions?: Json | null
          role?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "business_members_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "business_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      business_profiles: {
        Row: {
          auto_confirm: boolean
          booking_advance_days: number
          business_id: string
          cancellation_hours: number
          created_at: string
          deposit_percentage: number
          email_notifications: boolean
          employee_count: string | null
          facebook_url: string | null
          id: string
          instagram_url: string | null
          late_cancellation_fee: number
          linkedin_url: string | null
          registration_number: string | null
          requires_deposit: boolean
          sms_notifications: boolean
          tax_number: string | null
          twitter_url: string | null
          updated_at: string
          year_established: number | null
        }
        Insert: {
          auto_confirm?: boolean
          booking_advance_days?: number
          business_id: string
          cancellation_hours?: number
          created_at?: string
          deposit_percentage?: number
          email_notifications?: boolean
          employee_count?: string | null
          facebook_url?: string | null
          id: string
          instagram_url?: string | null
          late_cancellation_fee?: number
          linkedin_url?: string | null
          registration_number?: string | null
          requires_deposit?: boolean
          sms_notifications?: boolean
          tax_number?: string | null
          twitter_url?: string | null
          updated_at?: string
          year_established?: number | null
        }
        Update: {
          auto_confirm?: boolean
          booking_advance_days?: number
          business_id?: string
          cancellation_hours?: number
          created_at?: string
          deposit_percentage?: number
          email_notifications?: boolean
          employee_count?: string | null
          facebook_url?: string | null
          id?: string
          instagram_url?: string | null
          late_cancellation_fee?: number
          linkedin_url?: string | null
          registration_number?: string | null
          requires_deposit?: boolean
          sms_notifications?: boolean
          tax_number?: string | null
          twitter_url?: string | null
          updated_at?: string
          year_established?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "business_profiles_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: true
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      businesses: {
        Row: {
          active: boolean
          address: string | null
          average_rating: number | null
          business_type: string
          city: string | null
          clerk_org_id: string | null
          country: string | null
          created_at: string
          description: string | null
          email: string | null
          id: string
          industry: string | null
          name: string
          phone: string | null
          postal_code: string | null
          province: string | null
          subscription_status: string
          total_bookings: number
          total_reviews: number
          updated_at: string
          verified: boolean
          verified_at: string | null
          website: string | null
        }
        Insert: {
          active?: boolean
          address?: string | null
          average_rating?: number | null
          business_type?: string
          city?: string | null
          clerk_org_id?: string | null
          country?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          id: string
          industry?: string | null
          name: string
          phone?: string | null
          postal_code?: string | null
          province?: string | null
          subscription_status?: string
          total_bookings?: number
          total_reviews?: number
          updated_at?: string
          verified?: boolean
          verified_at?: string | null
          website?: string | null
        }
        Update: {
          active?: boolean
          address?: string | null
          average_rating?: number | null
          business_type?: string
          city?: string | null
          clerk_org_id?: string | null
          country?: string | null
          created_at?: string
          description?: string | null
          email?: string | null
          id?: string
          industry?: string | null
          name?: string
          phone?: string | null
          postal_code?: string | null
          province?: string | null
          subscription_status?: string
          total_bookings?: number
          total_reviews?: number
          updated_at?: string
          verified?: boolean
          verified_at?: string | null
          website?: string | null
        }
        Relationships: []
      }
      categories: {
        Row: {
          description: string | null
          id: string
          name: string
        }
        Insert: {
          description?: string | null
          id?: string
          name: string
        }
        Update: {
          description?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      content_calendar: {
        Row: {
          created_at: string | null
          date: string
          failed_count: number | null
          id: string
          published_count: number | null
          scheduled_count: number | null
        }
        Insert: {
          created_at?: string | null
          date: string
          failed_count?: number | null
          id?: string
          published_count?: number | null
          scheduled_count?: number | null
        }
        Update: {
          created_at?: string | null
          date?: string
          failed_count?: number | null
          id?: string
          published_count?: number | null
          scheduled_count?: number | null
        }
        Relationships: []
      }
      content_metrics: {
        Row: {
          average_rating: number | null
          completion_rate: number | null
          featured_score: number | null
          id: string
          total_ratings: number | null
          total_views: number | null
          total_watch_time: number | null
          trending: boolean | null
          updated_at: string | null
          video_id: string | null
        }
        Insert: {
          average_rating?: number | null
          completion_rate?: number | null
          featured_score?: number | null
          id?: string
          total_ratings?: number | null
          total_views?: number | null
          total_watch_time?: number | null
          trending?: boolean | null
          updated_at?: string | null
          video_id?: string | null
        }
        Update: {
          average_rating?: number | null
          completion_rate?: number | null
          featured_score?: number | null
          id?: string
          total_ratings?: number | null
          total_views?: number | null
          total_watch_time?: number | null
          trending?: boolean | null
          updated_at?: string | null
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "content_metrics_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      downloads: {
        Row: {
          created_at: string | null
          download_quality: string | null
          download_url: string | null
          expires_at: string
          file_size_bytes: number | null
          id: number
          progress: number | null
          status: string
          updated_at: string | null
          user_id: string
          video_id: string
        }
        Insert: {
          created_at?: string | null
          download_quality?: string | null
          download_url?: string | null
          expires_at?: string
          file_size_bytes?: number | null
          id?: number
          progress?: number | null
          status?: string
          updated_at?: string | null
          user_id: string
          video_id: string
        }
        Update: {
          created_at?: string | null
          download_quality?: string | null
          download_url?: string | null
          expires_at?: string
          file_size_bytes?: number | null
          id?: number
          progress?: number | null
          status?: string
          updated_at?: string | null
          user_id?: string
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "downloads_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_logs: {
        Row: {
          booking_id: string | null
          business_id: string | null
          channel: string
          content: string
          created_at: string
          id: string
          recipient: string
          sent_at: string
          status: string
          subject: string | null
        }
        Insert: {
          booking_id?: string | null
          business_id?: string | null
          channel: string
          content: string
          created_at?: string
          id: string
          recipient: string
          sent_at: string
          status: string
          subject?: string | null
        }
        Update: {
          booking_id?: string | null
          business_id?: string | null
          channel?: string
          content?: string
          created_at?: string
          id?: string
          recipient?: string
          sent_at?: string
          status?: string
          subject?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notification_logs_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      notification_preferences: {
        Row: {
          created_at: string | null
          download_complete: boolean | null
          id: string
          new_content: boolean | null
          recommendations: boolean | null
          subscription_reminders: boolean | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          download_complete?: boolean | null
          id?: string
          new_content?: boolean | null
          recommendations?: boolean | null
          subscription_reminders?: boolean | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          download_complete?: boolean | null
          id?: string
          new_content?: boolean | null
          recommendations?: boolean | null
          subscription_reminders?: boolean | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          booking_id: string | null
          business_id: string | null
          created_at: string
          id: string
          message: string
          read: boolean
          read_at: string | null
          title: string
          type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          booking_id?: string | null
          business_id?: string | null
          created_at?: string
          id: string
          message: string
          read?: boolean
          read_at?: string | null
          title: string
          type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          booking_id?: string | null
          business_id?: string | null
          created_at?: string
          id?: string
          message?: string
          read?: boolean
          read_at?: string | null
          title?: string
          type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "notifications_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notifications_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_transactions: {
        Row: {
          amount_fee: number | null
          amount_gross: number | null
          amount_net: number | null
          created_at: string | null
          email_address: string | null
          id: string
          item_description: string | null
          item_name: string | null
          m_payment_id: string | null
          merchant_id: string | null
          name_first: string | null
          name_last: string | null
          payment_status: string | null
          pf_payment_id: string | null
          plan_id: string | null
          processed_at: string | null
          raw_payload: string | null
          signature: string | null
          subscription_id: string | null
          user_id: string
        }
        Insert: {
          amount_fee?: number | null
          amount_gross?: number | null
          amount_net?: number | null
          created_at?: string | null
          email_address?: string | null
          id?: string
          item_description?: string | null
          item_name?: string | null
          m_payment_id?: string | null
          merchant_id?: string | null
          name_first?: string | null
          name_last?: string | null
          payment_status?: string | null
          pf_payment_id?: string | null
          plan_id?: string | null
          processed_at?: string | null
          raw_payload?: string | null
          signature?: string | null
          subscription_id?: string | null
          user_id: string
        }
        Update: {
          amount_fee?: number | null
          amount_gross?: number | null
          amount_net?: number | null
          created_at?: string | null
          email_address?: string | null
          id?: string
          item_description?: string | null
          item_name?: string | null
          m_payment_id?: string | null
          merchant_id?: string | null
          name_first?: string | null
          name_last?: string | null
          payment_status?: string | null
          pf_payment_id?: string | null
          plan_id?: string | null
          processed_at?: string | null
          raw_payload?: string | null
          signature?: string | null
          subscription_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "payment_transactions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_transactions_subscription_id_fkey"
            columns: ["subscription_id"]
            isOneToOne: false
            referencedRelation: "subscriptions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "payment_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      payments: {
        Row: {
          amount: number
          bookingId: string | null
          createdAt: string
          currency: string
          id: string
          paymentMethod: string | null
          status: string
          transactionId: string | null
          type: string
          updatedAt: string
        }
        Insert: {
          amount: number
          bookingId?: string | null
          createdAt?: string
          currency?: string
          id: string
          paymentMethod?: string | null
          status?: string
          transactionId?: string | null
          type?: string
          updatedAt?: string
        }
        Update: {
          amount?: number
          bookingId?: string | null
          createdAt?: string
          currency?: string
          id?: string
          paymentMethod?: string | null
          status?: string
          transactionId?: string | null
          type?: string
          updatedAt?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_bookingId_fkey"
            columns: ["bookingId"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_color: string | null
          avatar_url: string | null
          bio: string | null
          created_at: string | null
          date_of_birth: string | null
          display_name: string | null
          id: string
          location: string | null
          preferences: Json | null
          role: Database["public"]["Enums"]["user_role"]
          social_links: Json | null
          subscription_expires_at: string | null
          subscription_status: Database["public"]["Enums"]["subscription_status"]
          updated_at: string | null
          username: string | null
          website: string | null
        }
        Insert: {
          avatar_color?: string | null
          avatar_url?: string | null
          bio?: string | null
          created_at?: string | null
          date_of_birth?: string | null
          display_name?: string | null
          id: string
          location?: string | null
          preferences?: Json | null
          role?: Database["public"]["Enums"]["user_role"]
          social_links?: Json | null
          subscription_expires_at?: string | null
          subscription_status?: Database["public"]["Enums"]["subscription_status"]
          updated_at?: string | null
          username?: string | null
          website?: string | null
        }
        Update: {
          avatar_color?: string | null
          avatar_url?: string | null
          bio?: string | null
          created_at?: string | null
          date_of_birth?: string | null
          display_name?: string | null
          id?: string
          location?: string | null
          preferences?: Json | null
          role?: Database["public"]["Enums"]["user_role"]
          social_links?: Json | null
          subscription_expires_at?: string | null
          subscription_status?: Database["public"]["Enums"]["subscription_status"]
          updated_at?: string | null
          username?: string | null
          website?: string | null
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          created_at: string | null
          endpoint: string
          id: string
          subscription: Json
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          endpoint: string
          id?: string
          subscription: Json
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          endpoint?: string
          id?: string
          subscription?: Json
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      ratings: {
        Row: {
          created_at: string | null
          id: string
          rating: number
          updated_at: string | null
          user_id: string | null
          video_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          rating: number
          updated_at?: string | null
          user_id?: string | null
          video_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          rating?: number
          updated_at?: string | null
          user_id?: string | null
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ratings_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ratings_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      reviews: {
        Row: {
          approved: boolean
          booking_id: string
          business_id: string
          comment: string | null
          created_at: string
          customer_id: string
          featured: boolean
          id: string
          rating: number
          responded_at: string | null
          response: string | null
          title: string | null
          updated_at: string
        }
        Insert: {
          approved?: boolean
          booking_id: string
          business_id: string
          comment?: string | null
          created_at?: string
          customer_id: string
          featured?: boolean
          id: string
          rating: number
          responded_at?: string | null
          response?: string | null
          title?: string | null
          updated_at?: string
        }
        Update: {
          approved?: boolean
          booking_id?: string
          business_id?: string
          comment?: string | null
          created_at?: string
          customer_id?: string
          featured?: boolean
          id?: string
          rating?: number
          responded_at?: string | null
          response?: string | null
          title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "reviews_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: true
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "reviews_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      scheduled_content: {
        Row: {
          category: string | null
          created_at: string | null
          description: string | null
          id: string
          is_premium: boolean | null
          scheduled_date: string
          status: string
          tags: Json | null
          thumbnail_url: string | null
          title: string
          updated_at: string | null
          video_id: string
          video_url: string
        }
        Insert: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_premium?: boolean | null
          scheduled_date: string
          status?: string
          tags?: Json | null
          thumbnail_url?: string | null
          title: string
          updated_at?: string | null
          video_id: string
          video_url: string
        }
        Update: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          is_premium?: boolean | null
          scheduled_date?: string
          status?: string
          tags?: Json | null
          thumbnail_url?: string | null
          title?: string
          updated_at?: string | null
          video_id?: string
          video_url?: string
        }
        Relationships: []
      }
      scheduled_notifications: {
        Row: {
          booking_id: string | null
          business_id: string | null
          channel: string
          created_at: string
          error: string | null
          id: string
          recipient: string
          scheduled_for: string
          sent_at: string | null
          status: string
          template_type: string
          updated_at: string
          variables: string
        }
        Insert: {
          booking_id?: string | null
          business_id?: string | null
          channel: string
          created_at?: string
          error?: string | null
          id: string
          recipient: string
          scheduled_for: string
          sent_at?: string | null
          status?: string
          template_type: string
          updated_at?: string
          variables: string
        }
        Update: {
          booking_id?: string | null
          business_id?: string | null
          channel?: string
          created_at?: string
          error?: string | null
          id?: string
          recipient?: string
          scheduled_for?: string
          sent_at?: string | null
          status?: string
          template_type?: string
          updated_at?: string
          variables?: string
        }
        Relationships: [
          {
            foreignKeyName: "scheduled_notifications_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      services: {
        Row: {
          buffer_time: number
          business_id: string
          category: string | null
          created_at: string
          currency: string
          deposit_amount: number | null
          description: string | null
          duration: number
          id: string
          instant_booking: boolean
          is_active: boolean
          max_bookings_per_day: number | null
          name: string
          online_booking: boolean
          price: number
          requires_deposit: boolean
          updated_at: string
        }
        Insert: {
          buffer_time?: number
          business_id: string
          category?: string | null
          created_at?: string
          currency?: string
          deposit_amount?: number | null
          description?: string | null
          duration: number
          id: string
          instant_booking?: boolean
          is_active?: boolean
          max_bookings_per_day?: number | null
          name: string
          online_booking?: boolean
          price: number
          requires_deposit?: boolean
          updated_at?: string
        }
        Update: {
          buffer_time?: number
          business_id?: string
          category?: string | null
          created_at?: string
          currency?: string
          deposit_amount?: number | null
          description?: string | null
          duration?: number
          id?: string
          instant_booking?: boolean
          is_active?: boolean
          max_bookings_per_day?: number | null
          name?: string
          online_booking?: boolean
          price?: number
          requires_deposit?: boolean
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "services_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
      streaming_profiles: {
        Row: {
          bitrate: number
          codec: string | null
          file_size: number | null
          id: string
          is_default: boolean | null
          quality: string
          stream_url: string
          video_id: string | null
        }
        Insert: {
          bitrate: number
          codec?: string | null
          file_size?: number | null
          id?: string
          is_default?: boolean | null
          quality: string
          stream_url: string
          video_id?: string | null
        }
        Update: {
          bitrate?: number
          codec?: string | null
          file_size?: number | null
          id?: string
          is_default?: boolean | null
          quality?: string
          stream_url?: string
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "streaming_profiles_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_plans: {
        Row: {
          duration_months: number | null
          features: string[] | null
          id: string
          max_devices: number
          max_downloads: number | null
          name: string
          offline_downloads: boolean
          price: number
          video_quality: string
        }
        Insert: {
          duration_months?: number | null
          features?: string[] | null
          id?: string
          max_devices: number
          max_downloads?: number | null
          name: string
          offline_downloads: boolean
          price: number
          video_quality: string
        }
        Update: {
          duration_months?: number | null
          features?: string[] | null
          id?: string
          max_devices?: number
          max_downloads?: number | null
          name?: string
          offline_downloads?: boolean
          price?: number
          video_quality?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          cancellation_reason: string | null
          created_at: string | null
          end_date: string | null
          id: string
          is_active: boolean | null
          payment_reference: string | null
          plan_id: string | null
          start_date: string | null
          subscription_token: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          cancellation_reason?: string | null
          created_at?: string | null
          end_date?: string | null
          id?: string
          is_active?: boolean | null
          payment_reference?: string | null
          plan_id?: string | null
          start_date?: string | null
          subscription_token?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          cancellation_reason?: string | null
          created_at?: string | null
          end_date?: string | null
          id?: string
          is_active?: boolean | null
          payment_reference?: string | null
          plan_id?: string | null
          start_date?: string | null
          subscription_token?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_download_settings: {
        Row: {
          auto_download_next_episode: boolean | null
          created_at: string | null
          download_quality: string | null
          max_downloads: number | null
          updated_at: string | null
          user_id: string
          wifi_only: boolean | null
        }
        Insert: {
          auto_download_next_episode?: boolean | null
          created_at?: string | null
          download_quality?: string | null
          max_downloads?: number | null
          updated_at?: string | null
          user_id: string
          wifi_only?: boolean | null
        }
        Update: {
          auto_download_next_episode?: boolean | null
          created_at?: string | null
          download_quality?: string | null
          max_downloads?: number | null
          updated_at?: string | null
          user_id?: string
          wifi_only?: boolean | null
        }
        Relationships: []
      }
      user_interactions: {
        Row: {
          action_type: string
          created_at: string | null
          id: string
          metadata: Json | null
          source: string | null
          user_id: string
          video_id: string
        }
        Insert: {
          action_type: string
          created_at?: string | null
          id?: string
          metadata?: Json | null
          source?: string | null
          user_id: string
          video_id: string
        }
        Update: {
          action_type?: string
          created_at?: string | null
          id?: string
          metadata?: Json | null
          source?: string | null
          user_id?: string
          video_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_interactions_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      user_notifications: {
        Row: {
          action_url: string | null
          created_at: string | null
          id: string
          message: string
          read_at: string | null
          title: string
          type: string
          user_id: string | null
        }
        Insert: {
          action_url?: string | null
          created_at?: string | null
          id?: string
          message: string
          read_at?: string | null
          title: string
          type: string
          user_id?: string | null
        }
        Update: {
          action_url?: string | null
          created_at?: string | null
          id?: string
          message?: string
          read_at?: string | null
          title?: string
          type?: string
          user_id?: string | null
        }
        Relationships: []
      }
      user_recommendation_cache: {
        Row: {
          expires_at: string | null
          generated_at: string | null
          id: string
          metadata: Json | null
          reasons: string[] | null
          recommendation_type: string
          scores: number[] | null
          user_id: string
          video_ids: string[]
        }
        Insert: {
          expires_at?: string | null
          generated_at?: string | null
          id?: string
          metadata?: Json | null
          reasons?: string[] | null
          recommendation_type: string
          scores?: number[] | null
          user_id: string
          video_ids: string[]
        }
        Update: {
          expires_at?: string | null
          generated_at?: string | null
          id?: string
          metadata?: Json | null
          reasons?: string[] | null
          recommendation_type?: string
          scores?: number[] | null
          user_id?: string
          video_ids?: string[]
        }
        Relationships: []
      }
      user_viewing_history: {
        Row: {
          completed_at: string | null
          created_at: string | null
          id: string
          session_duration: number | null
          updated_at: string | null
          user_id: string
          video_id: string
          watch_percentage: number | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string | null
          id?: string
          session_duration?: number | null
          updated_at?: string | null
          user_id: string
          video_id: string
          watch_percentage?: number | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string | null
          id?: string
          session_duration?: number | null
          updated_at?: string | null
          user_id?: string
          video_id?: string
          watch_percentage?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "user_viewing_history_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      video_categories: {
        Row: {
          category_id: string | null
          id: string
          video_id: string | null
        }
        Insert: {
          category_id?: string | null
          id?: string
          video_id?: string | null
        }
        Update: {
          category_id?: string | null
          id?: string
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "video_categories_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "video_categories_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      videos: {
        Row: {
          age_rating: string | null
          available_resolutions: string | null
          average_watch_time: number | null
          bunny_guid: string | null
          bunny_library_id: string | null
          bunny_playback_id: string | null
          bunny_video_id: string | null
          cast_members: string[] | null
          collection_id: string | null
          collection_name: string | null
          created_at: string | null
          description: string | null
          director: string | null
          duration: number | null
          encode_progress: number | null
          genres: string[] | null
          id: string
          is_premium: boolean | null
          is_trailer: boolean | null
          metadata_json: string | null
          raw_bunny_status: number | null
          release_year: number | null
          source_framerate: number | null
          source_height: number | null
          source_width: number | null
          status: string | null
          storage_size: number | null
          thumbnail_url: string | null
          title: string
          total_watch_time: number | null
          trailer_url: string | null
          updated_at: string | null
          user_id: string | null
          video_url: string | null
          views: number | null
        }
        Insert: {
          age_rating?: string | null
          available_resolutions?: string | null
          average_watch_time?: number | null
          bunny_guid?: string | null
          bunny_library_id?: string | null
          bunny_playback_id?: string | null
          bunny_video_id?: string | null
          cast_members?: string[] | null
          collection_id?: string | null
          collection_name?: string | null
          created_at?: string | null
          description?: string | null
          director?: string | null
          duration?: number | null
          encode_progress?: number | null
          genres?: string[] | null
          id?: string
          is_premium?: boolean | null
          is_trailer?: boolean | null
          metadata_json?: string | null
          raw_bunny_status?: number | null
          release_year?: number | null
          source_framerate?: number | null
          source_height?: number | null
          source_width?: number | null
          status?: string | null
          storage_size?: number | null
          thumbnail_url?: string | null
          title: string
          total_watch_time?: number | null
          trailer_url?: string | null
          updated_at?: string | null
          user_id?: string | null
          video_url?: string | null
          views?: number | null
        }
        Update: {
          age_rating?: string | null
          available_resolutions?: string | null
          average_watch_time?: number | null
          bunny_guid?: string | null
          bunny_library_id?: string | null
          bunny_playback_id?: string | null
          bunny_video_id?: string | null
          cast_members?: string[] | null
          collection_id?: string | null
          collection_name?: string | null
          created_at?: string | null
          description?: string | null
          director?: string | null
          duration?: number | null
          encode_progress?: number | null
          genres?: string[] | null
          id?: string
          is_premium?: boolean | null
          is_trailer?: boolean | null
          metadata_json?: string | null
          raw_bunny_status?: number | null
          release_year?: number | null
          source_framerate?: number | null
          source_height?: number | null
          source_width?: number | null
          status?: string | null
          storage_size?: number | null
          thumbnail_url?: string | null
          title?: string
          total_watch_time?: number | null
          trailer_url?: string | null
          updated_at?: string | null
          user_id?: string | null
          video_url?: string | null
          views?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "videos_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      watch_progress: {
        Row: {
          completed: boolean | null
          id: string
          progress_seconds: number | null
          updated_at: string | null
          user_id: string | null
          video_id: string | null
        }
        Insert: {
          completed?: boolean | null
          id?: string
          progress_seconds?: number | null
          updated_at?: string | null
          user_id?: string | null
          video_id?: string | null
        }
        Update: {
          completed?: boolean | null
          id?: string
          progress_seconds?: number | null
          updated_at?: string | null
          user_id?: string | null
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "watch_progress_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "watch_progress_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      watchlist: {
        Row: {
          added_at: string | null
          id: string
          user_id: string | null
          video_id: string | null
        }
        Insert: {
          added_at?: string | null
          id?: string
          user_id?: string | null
          video_id?: string | null
        }
        Update: {
          added_at?: string | null
          id?: string
          user_id?: string | null
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "watchlist_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "watchlist_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      working_hours: {
        Row: {
          business_id: string
          close_time: string | null
          closed: boolean
          day_of_week: string
          id: string
          open_time: string | null
        }
        Insert: {
          business_id: string
          close_time?: string | null
          closed?: boolean
          day_of_week: string
          id: string
          open_time?: string | null
        }
        Update: {
          business_id?: string
          close_time?: string | null
          closed?: boolean
          day_of_week?: string
          id?: string
          open_time?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "working_hours_business_id_fkey"
            columns: ["business_id"]
            isOneToOne: false
            referencedRelation: "businesses"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      cleanup_expired_downloads: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      cleanup_expired_recommendations: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      cleanup_expired_subscriptions: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      cleanup_old_bulk_operations: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      cleanup_old_notifications: {
        Args: Record<PropertyKey, never>
        Returns: undefined
      }
      fn_is_premium: {
        Args: { uid: string }
        Returns: boolean
      }
      generate_unique_username: {
        Args: { email_input: string }
        Returns: string
      }
      get_current_user_profile: {
        Args: Record<PropertyKey, never>
        Returns: {
          avatar_color: string | null
          avatar_url: string | null
          bio: string | null
          created_at: string | null
          date_of_birth: string | null
          display_name: string | null
          id: string
          location: string | null
          preferences: Json | null
          role: Database["public"]["Enums"]["user_role"]
          social_links: Json | null
          subscription_expires_at: string | null
          subscription_status: Database["public"]["Enums"]["subscription_status"]
          updated_at: string | null
          username: string | null
          website: string | null
        }[]
      }
      increment_video_views: {
        Args: { video_id_param: string }
        Returns: undefined
      }
      process_scheduled_content: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      process_successful_payment: {
        Args: {
          p_user_id: string
          p_plan_id: string
          p_payment_reference: string
          p_duration_months?: number
        }
        Returns: Json
      }
      record_video_view: {
        Args: { p_user: string; p_video: string; p_pct?: number }
        Returns: undefined
      }
      update_download_progress: {
        Args: { download_id: number; new_progress: number }
        Returns: boolean
      }
    }
    Enums: {
      subscription_status: "active" | "inactive" | "trialing"
      user_role: "user" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      subscription_status: ["active", "inactive", "trialing"],
      user_role: ["user", "admin"],
    },
  },
} as const

// Type aliases for app compatibility
export type Video = Tables<'videos'>
export type Profile = Tables<'profiles'>
export type Subscription = Tables<'subscriptions'>
export type SubscriptionPlan = Tables<'subscription_plans'>
export type Download = Tables<'downloads'>
export type UserRole = Enums<'user_role'>
export type SubscriptionStatus = Enums<'subscription_status'>
