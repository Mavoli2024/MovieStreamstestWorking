export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  graphql_public: {
    Tables: {
      [_ in never]: never
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      graphql: {
        Args: {
          operationName?: string
          query?: string
          variables?: Json
          extensions?: Json
        }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
  public: {
    Tables: {
      categories: {
        Row: {
          description: string | null
          id: string
          name: string
        }
        Insert: {
          description?: string | null
          id?: string
          name: string
        }
        Update: {
          description?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      content_metrics: {
        Row: {
          average_rating: number | null
          completion_rate: number | null
          featured_score: number | null
          id: string
          total_ratings: number | null
          total_views: number | null
          total_watch_time: number | null
          trending: boolean | null
          updated_at: string | null
          video_id: string | null
        }
        Insert: {
          average_rating?: number | null
          completion_rate?: number | null
          featured_score?: number | null
          id?: string
          total_ratings?: number | null
          total_views?: number | null
          total_watch_time?: number | null
          trending?: boolean | null
          updated_at?: string | null
          video_id?: string | null
        }
        Update: {
          average_rating?: number | null
          completion_rate?: number | null
          featured_score?: number | null
          id?: string
          total_ratings?: number | null
          total_views?: number | null
          total_watch_time?: number | null
          trending?: boolean | null
          updated_at?: string | null
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "content_metrics_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string | null
          display_name: string | null
          id: string
          updated_at: string | null
          username: string | null
          role: string | null
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          id: string
          updated_at?: string | null
          username?: string | null
          role?: string | null
        }
        Update: {
          avatar_url?: string | null
          created_at?: string | null
          display_name?: string | null
          id?: string
          updated_at?: string | null
          username?: string | null
          role?: string | null
        }
        Relationships: []
      }
      ratings: {
        Row: {
          created_at: string | null
          id: string
          rating: number
          updated_at: string | null
          user_id: string | null
          video_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          rating: number
          updated_at?: string | null
          user_id?: string | null
          video_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          rating?: number
          updated_at?: string | null
          user_id?: string | null
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ratings_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "ratings_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      streaming_profiles: {
        Row: {
          bitrate: number
          codec: string | null
          file_size: number | null
          id: string
          is_default: boolean | null
          quality: string
          stream_url: string
          video_id: string | null
        }
        Insert: {
          bitrate: number
          codec?: string | null
          file_size?: number | null
          id?: string
          is_default?: boolean | null
          quality: string
          stream_url: string
          video_id?: string | null
        }
        Update: {
          bitrate?: number
          codec?: string | null
          file_size?: number | null
          id?: string
          is_default?: boolean | null
          quality?: string
          stream_url?: string
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "streaming_profiles_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_plans: {
        Row: {
          duration_months: number | null
          features: string[]
          id: string
          max_devices: number
          max_downloads: number | null
          name: string
          offline_downloads: boolean
          price: number
          video_quality: string
        }
        Insert: {
          duration_months?: number | null
          features: string[]
          id?: string
          max_devices: number
          max_downloads?: number | null
          name: string
          offline_downloads: boolean
          price: number
          video_quality: string
        }
        Update: {
          duration_months?: number | null
          features?: string[]
          id?: string
          max_devices?: number
          max_downloads?: number | null
          name?: string
          offline_downloads?: boolean
          price?: number
          video_quality?: string
        }
        Relationships: []
      }
      subscriptions: {
        Row: {
          cancellation_reason: string | null
          created_at: string | null
          end_date: string | null
          id: string
          is_active: boolean | null
          payment_reference: string | null
          plan_id: string | null
          start_date: string | null
          subscription_token: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          cancellation_reason?: string | null
          created_at?: string | null
          end_date?: string | null
          id?: string
          is_active?: boolean | null
          payment_reference?: string | null
          plan_id?: string | null
          start_date?: string | null
          subscription_token?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          cancellation_reason?: string | null
          created_at?: string | null
          end_date?: string | null
          id?: string
          is_active?: boolean | null
          payment_reference?: string | null
          plan_id?: string | null
          start_date?: string | null
          subscription_token?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "subscriptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      video_categories: {
        Row: {
          category_id: string | null
          id: string
          video_id: string | null
        }
        Insert: {
          category_id?: string | null
          id?: string
          video_id?: string | null
        }
        Update: {
          category_id?: string | null
          id?: string
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "video_categories_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "video_categories_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      videos: {
        Row: {
          age_rating: string | null
          available_resolutions: string | null
          average_watch_time: number | null
          bunny_guid: string | null
          bunny_playback_id: string | null
          bunny_video_id: string | null
          cast_members: string[] | null
          collection_id: string | null
          collection_name: string | null
          created_at: string | null
          description: string | null
          director: string | null
          duration: number | null
          encode_progress: number | null
          genres: string[] | null
          id: string
          is_premium: boolean | null
          is_trailer: boolean | null
          metadata_json: string | null
          raw_bunny_status: number | null
          release_year: number | null
          source_framerate: number | null
          source_height: number | null
          source_width: number | null
          status: string | null
          storage_size: number | null
          thumbnail_url: string | null
          title: string
          total_watch_time: number | null
          trailer_url: string | null
          updated_at: string | null
          user_id: string | null
          video_url: string | null
          views: number | null
        }
        Insert: {
          age_rating?: string | null
          available_resolutions?: string | null
          average_watch_time?: number | null
          bunny_guid?: string | null
          bunny_playback_id?: string | null
          bunny_video_id?: string | null
          cast_members?: string[] | null
          collection_id?: string | null
          collection_name?: string | null
          created_at?: string | null
          description?: string | null
          director?: string | null
          duration?: number | null
          encode_progress?: number | null
          genres?: string[] | null
          id?: string
          is_premium?: boolean | null
          is_trailer?: boolean | null
          metadata_json?: string | null
          raw_bunny_status?: number | null
          release_year?: number | null
          source_framerate?: number | null
          source_height?: number | null
          source_width?: number | null
          status?: string | null
          storage_size?: number | null
          thumbnail_url?: string | null
          title: string
          total_watch_time?: number | null
          trailer_url?: string | null
          updated_at?: string | null
          user_id?: string | null
          video_url?: string | null
          views?: number | null
        }
        Update: {
          age_rating?: string | null
          available_resolutions?: string | null
          average_watch_time?: number | null
          bunny_guid?: string | null
          bunny_playback_id?: string | null
          bunny_video_id?: string | null
          cast_members?: string[] | null
          collection_id?: string | null
          collection_name?: string | null
          created_at?: string | null
          description?: string | null
          director?: string | null
          duration?: number | null
          encode_progress?: number | null
          genres?: string[] | null
          id?: string
          is_premium?: boolean | null
          is_trailer?: boolean | null
          metadata_json?: string | null
          raw_bunny_status?: number | null
          release_year?: number | null
          source_framerate?: number | null
          source_height?: number | null
          source_width?: number | null
          status?: string | null
          storage_size?: number | null
          thumbnail_url?: string | null
          title?: string
          total_watch_time?: number | null
          trailer_url?: string | null
          updated_at?: string | null
          user_id?: string | null
          video_url?: string | null
          views?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "videos_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      watch_progress: {
        Row: {
          completed: boolean | null
          id: string
          progress_seconds: number | null
          updated_at: string | null
          user_id: string | null
          video_id: string | null
        }
        Insert: {
          completed?: boolean | null
          id?: string
          progress_seconds?: number | null
          updated_at?: string | null
          user_id?: string | null
          video_id?: string | null
        }
        Update: {
          completed?: boolean | null
          id?: string
          progress_seconds?: number | null
          updated_at?: string | null
          user_id?: string | null
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "watch_progress_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "watch_progress_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
      watchlist: {
        Row: {
          added_at: string | null
          id: string
          user_id: string | null
          video_id: string | null
        }
        Insert: {
          added_at?: string | null
          id?: string
          user_id?: string | null
          video_id?: string | null
        }
        Update: {
          added_at?: string | null
          id?: string
          user_id?: string | null
          video_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "watchlist_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "watchlist_video_id_fkey"
            columns: ["video_id"]
            isOneToOne: false
            referencedRelation: "videos"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  graphql_public: {
    Enums: {},
  },
  public: {
    Enums: {},
  },
} as const 