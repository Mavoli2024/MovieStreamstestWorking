import type { Database as GeneratedDatabase } from './database.types';

export type Database = GeneratedDatabase;

// Convenient re-exports
export type VideoRow = Database['public']['Tables']['videos']['Row'];
export type ProfileRow = Database['public']['Tables']['profiles']['Row'];
export type Profile = ProfileRow; 