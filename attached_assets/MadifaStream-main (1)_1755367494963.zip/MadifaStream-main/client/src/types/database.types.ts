export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      videos: {
        Row: {
          id: string;
          title: string;
          description: string;
          thumbnail_url: string;
          video_url: string;
          videoUrl?: string;
          trailer_url: string | null;
          trailerUrl?: string | null;
          release_year: number;
          duration_minutes: number;
          duration?: number;
          age_rating: string;
          genres: string[];
          cast: string | null;
          cast_members?: string[];
          director: string | null;
          created_at: string;
          updated_at: string;
          is_trailer: boolean;
          collection_id: string | null;
          collection_name: string | null;
          views?: number;
          metadata_json: string;
          is_premium: boolean;
          isPremium?: boolean;
          category_id: string | null;
          categoryId?: string | null;
          status: string;
          source_height?: number;
          source_width?: number;
        };
        Insert: {
          id?: string;
          title: string;
          description?: string | null;
          thumbnail_url?: string | null;
          video_url?: string | null;
          trailer_url?: string | null;
          release_year?: number;
          duration_minutes?: number | null;
          age_rating?: string;
          genres?: string[];
          cast?: string[] | string | null;
          director?: string | null;
          is_trailer?: boolean;
          collection_id?: string | null;
          collection_name?: string | null;
          views?: number;
          metadata_json?: string;
          is_premium?: boolean;
          category_id?: string | null;
          status?: string;
        };
        Update: Partial<Database['public']['Tables']['videos']['Row']>;
      };
      categories: {
        Row: {
          id: string;
          name: string;
        };
      };
      watch_progress: {
        Row: {
          id: string;
          user_id: string;
          video_id: string;
          progress: number;
          updated_at: string;
        };
      };
      watchlist: {
        Row: {
          id: string;
          user_id: string;
          video_id: string;
          added_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          video_id: string;
          added_at?: string;
        };
        Update: Partial<Database['public']['Tables']['watchlist']['Row']>;
      };
      profiles: {
        Row: {
          id: string;
          username: string | null;
          display_name: string | null;
          avatar_url: string | null;
          avatar_color?: string | null;
          avatarColor?: string | null;
          displayName?: string | null;
          name?: string | null;
          role?: string;
          subscription_status?: 'active' | 'inactive' | 'trialing';
          created_at: string | null;
          updated_at: string | null;
        };
      };
      subscription_plans: {
        Row: {
          id: string;
          name: string;
          price: string | number;
          price_cents?: number;
          video_quality: string;
          videoQuality?: string;
          max_devices: number;
          maxDevices?: number;
          offline_downloads: boolean;
          offlineDownloads?: boolean;
          max_downloads: number | null;
          maxDownloads?: number | null;
          duration_months: number | null;
          features: string[] | null;
        };
      };
      subscriptions: {
        Row: {
          id: string;
          user_id: string;
          plan_id: string;
          start_date: string | null;
          startDate?: string | null;
          end_date: string | null;
          endDate?: string | null;
          is_active: boolean | null;
          isActive?: boolean | null;
          payment_reference: string | null;
          subscription_token: string | null;
          cancellation_reason: string | null;
          created_at: string | null;
          updated_at: string | null;
        };
      };
      ratings: {
        Row: {
          id: string;
          video_id: string;
          user_id: string;
          rating: number;
          created_at: string | null;
          updated_at: string | null;
        };
      };
      content_metrics: {
        Row: {
          id: string;
          video_id: string;
          total_views: number;
          total_watch_time: number;
          average_rating: string;
          total_ratings: number;
          completion_rate: string;
          trending: boolean;
          featured_score: number;
          updated_at: string | null;
        };
      };
      streaming_profiles: {
        Row: {
          id: string;
          video_id: string;
          quality: string;
          stream_url: string;
          bitrate: number;
          codec: string | null;
          file_size: number | null;
          is_default: boolean;
        };
      };
    }
    Views: object
    Functions: object
    Enums: object
    CompositeTypes: object
  }
}

export type SubscriptionPlan = Database['public']['Tables']['subscription_plans']['Row'];
export type Subscription = Database['public']['Tables']['subscriptions']['Row'];
export type WatchProgress = Database['public']['Tables']['watch_progress']['Row'];
export type Watchlist = Database['public']['Tables']['watchlist']['Row'];
