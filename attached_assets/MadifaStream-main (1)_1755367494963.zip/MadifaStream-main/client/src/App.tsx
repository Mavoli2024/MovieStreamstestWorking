/**
 * Main App Component
 * 
 * Production-grade app setup with:
 * - Global error boundaries
 * - Route configuration
 * - Theme support
 * - Toast notifications
 * - Performance monitoring
 */

import React, { useEffect } from 'react';
import { HelmetProvider } from 'react-helmet-async';
import { ThemeProvider } from '@/components/theme-provider';
import { RootProvider } from '@/providers/AppProvider';
import { UnifiedRouter } from '@/components/routing/UnifiedRouter';
import { logger } from '@shared/logger';

// Component loading is now handled by the unified routing system

// Performance monitoring
function initializePerformanceMonitoring() {
  // Initialize performance monitoring
  import('web-vitals').then(({ onCLS, onFCP, onLCP, onTTFB }) => {
    onCLS((metric) => logger.info('CLS metric', { metric }));
    onFCP((metric) => logger.info('FCP metric', { metric }));
    onLCP((metric) => logger.info('LCP metric', { metric }));
    onTTFB((metric) => logger.info('TTFB metric', { metric }));
  }).catch(() => {
    // Web vitals not available
  });
}

// Routing is now handled by the UnifiedRouter component

export default function App() {
  useEffect(() => {
    // Log app initialization
    logger.info('MadifaStream initialized', {
      version: import.meta.env.VITE_APP_VERSION || '1.0.0',
      environment: import.meta.env.MODE,
    });

    // Setup service worker for offline support (disabled in development)
    if ('serviceWorker' in navigator && import.meta.env.PROD) {
      navigator.serviceWorker.register('/sw.js').catch((error) => {
        console.error('Service worker registration failed:', error);
      });
    }
  }, []);

  return (
    <HelmetProvider>
      <ThemeProvider defaultTheme="dark" storageKey="madifa-theme">
        <RootProvider>
          <UnifiedRouter />
        </RootProvider>
      </ThemeProvider>
    </HelmetProvider>
  );
}
