/**
 * Centralized Theme System for MadifaStream
 * 
 * This file provides theme utilities and generates CSS custom properties
 * from our design tokens for consistent theming across the application.
 */

import { designTokens } from './design-tokens';

// Theme modes
export type ThemeMode = 'light' | 'dark' | 'system';

// Light theme configuration
export const lightTheme = {
  colors: {
    background: 'hsl(0, 0%, 100%)',
    foreground: 'hsl(240, 10%, 3.9%)',
    card: 'hsl(0, 0%, 100%)',
    'card-foreground': 'hsl(240, 10%, 3.9%)',
    popover: 'hsl(0, 0%, 100%)',
    'popover-foreground': 'hsl(240, 10%, 3.9%)',
    primary: 'hsl(221, 83%, 53%)',
    'primary-foreground': 'hsl(0, 0%, 100%)',
    secondary: 'hsl(240, 4.8%, 95.9%)',
    'secondary-foreground': 'hsl(240, 5.9%, 10%)',
    muted: 'hsl(240, 4.8%, 95.9%)',
    'muted-foreground': 'hsl(240, 3.8%, 46.1%)',
    accent: 'hsl(240, 4.8%, 95.9%)',
    'accent-foreground': 'hsl(240, 5.9%, 10%)',
    destructive: 'hsl(0, 84.2%, 60.2%)',
    'destructive-foreground': 'hsl(0, 0%, 100%)',
    border: 'hsl(240, 5.9%, 90%)',
    input: 'hsl(240, 5.9%, 90%)',
    ring: 'hsl(221, 83%, 53%)',
    'chart-1': 'hsl(12, 76%, 61%)',
    'chart-2': 'hsl(173, 58%, 39%)',
    'chart-3': 'hsl(197, 37%, 24%)',
    'chart-4': 'hsl(43, 74%, 66%)',
    'chart-5': 'hsl(27, 87%, 67%)',
  },
  radius: '0.5rem',
};

// Dark theme configuration
export const darkTheme = {
  colors: {
    background: 'hsl(240, 10%, 3.9%)',
    foreground: 'hsl(0, 0%, 98%)',
    card: 'hsl(240, 10%, 3.9%)',
    'card-foreground': 'hsl(0, 0%, 98%)',
    popover: 'hsl(240, 10%, 3.9%)',
    'popover-foreground': 'hsl(0, 0%, 98%)',
    primary: 'hsl(221, 83%, 53%)',
    'primary-foreground': 'hsl(0, 0%, 100%)',
    secondary: 'hsl(240, 3.7%, 15.9%)',
    'secondary-foreground': 'hsl(0, 0%, 98%)',
    muted: 'hsl(240, 3.7%, 15.9%)',
    'muted-foreground': 'hsl(240, 5%, 64.9%)',
    accent: 'hsl(240, 3.7%, 15.9%)',
    'accent-foreground': 'hsl(0, 0%, 98%)',
    destructive: 'hsl(0, 62.8%, 30.6%)',
    'destructive-foreground': 'hsl(0, 0%, 98%)',
    border: 'hsl(240, 3.7%, 15.9%)',
    input: 'hsl(240, 3.7%, 15.9%)',
    ring: 'hsl(221, 83%, 53%)',
    'chart-1': 'hsl(220, 70%, 50%)',
    'chart-2': 'hsl(160, 60%, 45%)',
    'chart-3': 'hsl(30, 80%, 55%)',
    'chart-4': 'hsl(280, 65%, 60%)',
    'chart-5': 'hsl(340, 75%, 55%)',
  },
  radius: '0.5rem',
};

// Theme type - using a more flexible structure
export type Theme = {
  colors: Record<string, string>;
  radius: string;
};

// Get current theme based on mode
export const getTheme = (mode: ThemeMode): Theme => {
  if (mode === 'system') {
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    return prefersDark ? darkTheme : lightTheme;
  }
  return mode === 'dark' ? darkTheme : lightTheme;
};

// Generate CSS custom properties from theme
export const generateCSSCustomProperties = (theme: Theme): string => {
  const cssVars: string[] = [];
  
  // Add color variables
  Object.entries(theme.colors).forEach(([key, value]) => {
    cssVars.push(`  --${key}: ${value};`);
  });
  
  // Add design token variables
  Object.entries(designTokens.spacing).forEach(([key, value]) => {
    cssVars.push(`  --spacing-${key}: ${value};`);
  });
  
  Object.entries(designTokens.borderRadius).forEach(([key, value]) => {
    cssVars.push(`  --radius-${key}: ${value};`);
  });
  
  Object.entries(designTokens.shadows).forEach(([key, value]) => {
    cssVars.push(`  --shadow-${key}: ${value};`);
  });
  
  Object.entries(designTokens.zIndex).forEach(([key, value]) => {
    cssVars.push(`  --z-${key}: ${value};`);
  });
  
  // Add typography variables
  cssVars.push(`  --font-sans: ${designTokens.typography.fontFamily.sans.join(', ')};`);
  cssVars.push(`  --font-mono: ${designTokens.typography.fontFamily.mono.join(', ')};`);
  cssVars.push(`  --font-display: ${designTokens.typography.fontFamily.display.join(', ')};`);
  
  // Add animation variables
  Object.entries(designTokens.animations.duration).forEach(([key, value]) => {
    cssVars.push(`  --duration-${key}: ${value};`);
  });
  
  Object.entries(designTokens.animations.easing).forEach(([key, value]) => {
    cssVars.push(`  --easing-${key}: ${value};`);
  });
  
  // Add radius from theme
  cssVars.push(`  --radius: ${theme.radius};`);
  
  return `:root {\n${cssVars.join('\n')}\n}`;
};

// Apply theme to document
export const applyTheme = (mode: ThemeMode) => {
  const theme = getTheme(mode);
  const cssVars = generateCSSCustomProperties(theme);
  
  // Remove existing theme style
  const existingStyle = document.getElementById('theme-vars');
  if (existingStyle) {
    existingStyle.remove();
  }
  
  // Create new style element
  const style = document.createElement('style');
  style.id = 'theme-vars';
  style.textContent = cssVars;
  document.head.appendChild(style);
  
  // Update HTML class for theme
  document.documentElement.classList.remove('light', 'dark');
  document.documentElement.classList.add(mode === 'system' ? 'system' : mode);
  
  // Set data attribute for theme
  document.documentElement.setAttribute('data-theme', mode);
};

// Theme utilities
export const themeUtils = {
  // Get CSS variable value
  getCSSVar: (name: string): string => {
    return getComputedStyle(document.documentElement).getPropertyValue(`--${name}`).trim();
  },
  
  // Set CSS variable value
  setCSSVar: (name: string, value: string): void => {
    document.documentElement.style.setProperty(`--${name}`, value);
  },
  
  // Get current theme mode
  getCurrentTheme: (): ThemeMode => {
    const theme = document.documentElement.getAttribute('data-theme') as ThemeMode;
    return theme || 'light';
  },
  
  // Check if dark mode is active
  isDarkMode: (): boolean => {
    const theme = themeUtils.getCurrentTheme();
    if (theme === 'system') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return theme === 'dark';
  },
  
  // Listen for system theme changes
  watchSystemTheme: (callback: (isDark: boolean) => void): (() => void) => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => callback(e.matches);
    
    mediaQuery.addEventListener('change', handler);
    
    return () => mediaQuery.removeEventListener('change', handler);
  },
};

// Color manipulation utilities
export const colorUtils = {
  // Convert HSL to RGB
  hslToRgb: (h: number, s: number, l: number): [number, number, number] => {
    h /= 360;
    s /= 100;
    l /= 100;
    
    const hue2rgb = (p: number, q: number, t: number): number => {
      if (t < 0) t += 1;
      if (t > 1) t -= 1;
      if (t < 1/6) return p + (q - p) * 6 * t;
      if (t < 1/2) return q;
      if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
      return p;
    };
    
    if (s === 0) {
      return [l, l, l]; // achromatic
    }
    
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;
    const r = hue2rgb(p, q, h + 1/3);
    const g = hue2rgb(p, q, h);
    const b = hue2rgb(p, q, h - 1/3);
    
    return [Math.round(r * 255), Math.round(g * 255), Math.round(b * 255)];
  },
  
  // Parse HSL string
  parseHSL: (hsl: string): [number, number, number] => {
    const match = hsl.match(/hsl\((\d+),\s*(\d+)%,\s*(\d+)%\)/);
    if (!match) throw new Error('Invalid HSL format');
    
    return [parseInt(match[1]), parseInt(match[2]), parseInt(match[3])];
  },
  
  // Generate color variations
  generateColorVariations: (baseColor: string, steps: number = 9): string[] => {
    const [h, s, l] = colorUtils.parseHSL(baseColor);
    const variations: string[] = [];
    
    for (let i = 0; i < steps; i++) {
      const lightness = Math.max(5, Math.min(95, l + (i - Math.floor(steps / 2)) * 10));
      variations.push(`hsl(${h}, ${s}%, ${lightness}%)`);
    }
    
    return variations;
  },
};
