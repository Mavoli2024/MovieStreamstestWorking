// Ultra-minimal React test - no external dependencies
import React from 'react';
import { createRoot } from 'react-dom/client';

// Simple test component
const TestApp = () => {
  return (
    <div style={{ 
      padding: '40px', 
      fontFamily: 'Arial, sans-serif',
      backgroundColor: '#f0f0f0',
      minHeight: '100vh'
    }}>
      <h1 style={{ color: '#2d3748', marginBottom: '20px' }}>
        🎉 Madifa Stream - Test Version
      </h1>
      <p style={{ marginBottom: '10px' }}>
        ✅ React is working correctly!
      </p>
      <p style={{ marginBottom: '10px' }}>
        Environment: {process.env.NODE_ENV || 'unknown'}
      </p>
      <p style={{ marginBottom: '10px' }}>
        Site URL: {process.env.VITE_SITE_URL || 'not set'}
      </p>
      <p style={{ marginBottom: '10px' }}>
        React Version: {React.version}
      </p>
      <p style={{ marginBottom: '20px' }}>
        Timestamp: {new Date().toISOString()}
      </p>
      <button 
        onClick={() => alert('Button clicked!')}
        style={{
          background: '#3182ce',
          color: 'white',
          border: 'none',
          padding: '10px 20px',
          borderRadius: '4px',
          cursor: 'pointer'
        }}
      >
        Test Interaction
      </button>
    </div>
  );
};

// Initialize app
const rootElement = document.getElementById('root');
if (rootElement) {
  const root = createRoot(rootElement);
  root.render(<TestApp />);
  console.log('✅ Test app rendered successfully');
} else {
  console.error('❌ Root element not found');
}