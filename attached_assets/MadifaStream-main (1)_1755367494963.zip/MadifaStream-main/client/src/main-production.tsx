import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { GlobalErrorBoundary } from './components/error-boundary/GlobalErrorBoundary';

// Simple production logger
const logger = {
  info: (msg: string, data?: any) => console.log(`[INFO] ${msg}`, data || ''),
  error: (msg: string, data?: any) => console.error(`[ERROR] ${msg}`, data || ''),
  warn: (msg: string, data?: any) => console.warn(`[WARN] ${msg}`, data || ''),
  debug: (msg: string, data?: any) => console.debug(`[DEBUG] ${msg}`, data || '')
};

// Make React globally available
(window as any).React = React;

function initializeApp() {
  const rootElement = document.getElementById('root');
  
  if (!rootElement) {
    logger.error('Root element not found');
    return;
  }

  try {
    logger.info('Initializing React app...');
    
    const root = createRoot(rootElement);
    
    root.render(
      <GlobalErrorBoundary>
        <App />
      </GlobalErrorBoundary>
    );
    
    logger.info('App rendered successfully');
    
  } catch (error) {
    logger.error('React initialization failed:', error);
    
    // Fallback display
    rootElement.innerHTML = `
      <div style="padding: 40px; font-family: Arial, sans-serif; max-width: 600px; margin: 50px auto; background: #fff; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); color: #333;">
        <h1 style="color: #e53e3e; margin-bottom: 20px;">Application Failed to Load</h1>
        <p>Error: ${error instanceof Error ? error.message : 'Unknown error'}</p>
        <button onclick="window.location.reload()" style="background: #3182ce; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer;">Refresh Page</button>
      </div>
    `;
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeApp);
} else {
  initializeApp();
}