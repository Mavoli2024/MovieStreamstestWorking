/**
 * Centralized color palette for MadifaStream
 */

export const colors = {
  // Brand colors
  primary: {
    red: '#E50914',      // Netflix-style red
    darkRed: '#B20710',  // Darker red for hover states
    lightRed: '#F40612', // Lighter red for accents
  },

  // Profile avatar colors
  profile: {
    red: '#E50914',
    blue: '#0073e6',
    green: '#2ecc71',
    purple: '#9b59b6',
    orange: '#f39c12',
    crimson: '#e74c3c',
    teal: '#1abc9c',
    indigo: '#6c5ce7',
    pink: '#fd79a8',
    yellow: '#fdcb6e',
  },

  // UI colors
  background: {
    primary: '#141414',   // Main dark background
    secondary: '#1a1a1a', // Slightly lighter dark
    card: '#2a2a2a',      // Card backgrounds
    modal: '#333333',     // Modal backgrounds
  },

  text: {
    primary: '#ffffff',   // Primary text
    secondary: '#b3b3b3', // Secondary text
    muted: '#808080',     // Muted text
    disabled: '#666666',  // Disabled text
  },

  border: {
    primary: '#404040',   // Primary borders
    secondary: '#606060', // Secondary borders
    focus: '#E50914',     // Focus borders
  },

  status: {
    success: '#2ecc71',   // Success states
    warning: '#f39c12',   // Warning states
    error: '#e74c3c',     // Error states
    info: '#3498db',      // Info states
  },

  // Gradient combinations
  gradients: {
    primary: 'linear-gradient(135deg, #E50914 0%, #B20710 100%)',
    dark: 'linear-gradient(135deg, #141414 0%, #1a1a1a 100%)',
    card: 'linear-gradient(135deg, #2a2a2a 0%, #333333 100%)',
  },
} as const;

// Profile colors array for easy iteration
export const profileColors = Object.values(colors.profile);

// Helper function to get profile color by index
export const getProfileColor = (index: number): string => {
  return profileColors[index % profileColors.length];
};

// Helper function to get random profile color
export const getRandomProfileColor = (): string => {
  return profileColors[Math.floor(Math.random() * profileColors.length)];
};

// CSS custom properties for use in Tailwind config
export const cssVariables = {
  '--color-primary-red': colors.primary.red,
  '--color-primary-dark-red': colors.primary.darkRed,
  '--color-primary-light-red': colors.primary.lightRed,
  '--color-background-primary': colors.background.primary,
  '--color-background-secondary': colors.background.secondary,
  '--color-background-card': colors.background.card,
  '--color-text-primary': colors.text.primary,
  '--color-text-secondary': colors.text.secondary,
  '--color-border-primary': colors.border.primary,
} as const;