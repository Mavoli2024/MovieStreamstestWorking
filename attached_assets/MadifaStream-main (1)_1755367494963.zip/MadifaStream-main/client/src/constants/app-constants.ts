/**
 * Application Constants
 * Centralized location for all magic numbers, timeouts, and configuration values
 */

// =============================================================================
// TIMEOUTS & DELAYS
// =============================================================================

export const TIMEOUTS = {
  // UI Timeouts
  CONTROLS_HIDE_DELAY: 3000, // Hide video controls after 3 seconds
  TOAST_DISPLAY_DURATION: 3000, // Toast notification duration
  DEBOUNCE_SEARCH: 300, // Search input debounce
  THROTTLE_SCROLL: 100, // Scroll event throttling
  
  // Network Timeouts
  API_REQUEST_TIMEOUT: 30000, // 30 seconds for API requests
  VIDEO_LOAD_TIMEOUT: 45000, // 45 seconds for video loading
  HEALTH_CHECK_TIMEOUT: 10000, // 10 seconds for health checks
  
  // Authentication
  TOKEN_REFRESH_MARGIN: 60000, // Refresh token 1 minute before expiry
  SESSION_CHECK_INTERVAL: 300000, // Check session every 5 minutes
  
  // Performance
  IDLE_CALLBACK_TIMEOUT: 5000, // Maximum idle callback wait time
  INTERSECTION_OBSERVER_DEBOUNCE: 150, // Lazy loading debounce
} as const;

// =============================================================================
// RETRY & BACKOFF SETTINGS
// =============================================================================

export const RETRY_CONFIG = {
  MAX_RETRIES: 3,
  INITIAL_DELAY: 1000, // 1 second
  BACKOFF_MULTIPLIER: 2,
  MAX_DELAY: 30000, // 30 seconds max
  
  // Video-specific retries
  VIDEO_RETRY_ATTEMPTS: 5,
  VIDEO_RETRY_DELAY: 2000,
  
  // API retry configuration
  API_RETRY_STATUS_CODES: [429, 500, 502, 503, 504],
} as const;

// =============================================================================
// UI/UX CONSTANTS
// =============================================================================

export const UI_CONFIG = {
  // Touch targets (WCAG compliance)
  MIN_TOUCH_TARGET_SIZE: 44, // 44x44px minimum
  
  // Animation durations
  ANIMATION_DURATION_FAST: 150,
  ANIMATION_DURATION_NORMAL: 250,
  ANIMATION_DURATION_SLOW: 400,
  
  // Mobile optimizations
  MOBILE_ANIMATION_DURATION: 200,
  
  // Video player
  VOLUME_STEP: 0.05, // 5% volume steps
  SEEK_STEP_SMALL: 10, // 10 seconds
  SEEK_STEP_LARGE: 60, // 1 minute
  
  // Pagination
  DEFAULT_PAGE_SIZE: 20,
  INFINITE_SCROLL_THRESHOLD: 200, // px from bottom
  
  // Image optimization
  BLUR_DATA_URL: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAABAAEDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAv/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/8QAFQEBAQAAAAAAAAAAAAAAAAAAAAX/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCdABmX/9k=',
} as const;

// =============================================================================
// PERFORMANCE THRESHOLDS
// =============================================================================

export const PERFORMANCE_THRESHOLDS = {
  // Web Vitals (based on Core Web Vitals)
  LCP_GOOD: 2500, // Largest Contentful Paint (ms)
  LCP_POOR: 4000,
  
  INP_GOOD: 200, // Interaction to Next Paint (ms)
  INP_POOR: 500,
  
  CLS_GOOD: 0.1, // Cumulative Layout Shift
  CLS_POOR: 0.25,
  
  FCP_GOOD: 1800, // First Contentful Paint (ms)
  FCP_POOR: 3000,
  
  TTFB_GOOD: 800, // Time to First Byte (ms)
  TTFB_POOR: 1800,
  
  // Custom app thresholds
  BUNDLE_SIZE_WARNING: 500 * 1024, // 500KB
  BUNDLE_SIZE_ERROR: 1024 * 1024, // 1MB
  
  DOM_NODES_WARNING: 1000,
  DOM_NODES_ERROR: 1500,
} as const;

// =============================================================================
// STORAGE & CACHING
// =============================================================================

export const STORAGE_CONFIG = {
  // Cache durations (in seconds)
  CACHE_DURATION_SHORT: 300, // 5 minutes
  CACHE_DURATION_MEDIUM: 3600, // 1 hour
  CACHE_DURATION_LONG: 86400, // 24 hours
  CACHE_DURATION_WEEK: 604800, // 7 days
  
  // Local storage keys
  STORAGE_KEYS: {
    USER_PREFERENCES: 'madifa_user_preferences',
    VIDEO_PROGRESS: 'madifa_video_progress',
    DOWNLOAD_SETTINGS: 'madifa_download_settings',
    THEME_PREFERENCE: 'madifa_theme',
    VOLUME_SETTING: 'madifa_volume',
    QUALITY_PREFERENCE: 'madifa_quality',
  },
  
  // Offline storage limits
  MAX_OFFLINE_STORAGE: 5 * 1024 * 1024 * 1024, // 5GB
  STORAGE_WARNING_THRESHOLD: 0.8, // 80% of max storage
} as const;

// =============================================================================
// VIDEO STREAMING
// =============================================================================

export const VIDEO_CONFIG = {
  // Quality levels
  QUALITY_LEVELS: {
    AUTO: 'auto',
    UHD_4K: '2160p',
    FULL_HD: '1080p',
    HD: '720p',
    SD: '480p',
    LOW: '360p',
  },
  
  // Bitrate thresholds (kbps)
  BITRATE_THRESHOLDS: {
    UHD_4K: 15000,
    FULL_HD: 8000,
    HD: 4000,
    SD: 2000,
    LOW: 1000,
  },
  
  // Buffer settings
  BUFFER_SIZE_TARGET: 30, // seconds
  BUFFER_SIZE_MAX: 60, // seconds
  BUFFER_SIZE_MIN: 10, // seconds
  
  // HLS settings
  HLS_FRAGMENT_DURATION: 6, // seconds
  HLS_PLAYLIST_LENGTH: 5, // number of fragments
  
  // Subtitle settings
  SUBTITLE_FONT_SIZES: [12, 14, 16, 18, 20, 24],
  SUBTITLE_DEFAULT_SIZE: 16,
} as const;

// =============================================================================
// NETWORK & API
// =============================================================================

export const NETWORK_CONFIG = {
  // Connection types for adaptive streaming
  CONNECTION_TYPES: {
    FAST: 'fast', // 4G, WiFi
    MEDIUM: 'medium', // 3G
    SLOW: 'slow', // 2G, slow connections
  },
  
  // Bandwidth thresholds (Mbps)
  BANDWIDTH_THRESHOLDS: {
    FAST: 5,
    MEDIUM: 1.5,
    SLOW: 0.5,
  },
  
  // Request concurrency limits
  MAX_CONCURRENT_DOWNLOADS: 3,
  MAX_CONCURRENT_API_REQUESTS: 6,
  
  // Rate limiting
  RATE_LIMIT_REQUESTS_PER_MINUTE: 100,
  RATE_LIMIT_WINDOW: 60000, // 1 minute
} as const;

// =============================================================================
// ENVIRONMENT DEFAULTS
// =============================================================================

export const ENV_DEFAULTS = {
  // API endpoints
  PRODUCTION_API_URL: 'https://www.madifa.co.za',
  DEVELOPMENT_API_URL: 'http://localhost:5001',
  
  // Ports
  DEV_SERVER_PORT: 5173,
  PRODUCTION_SERVER_PORT: 5001,
  
  // Feature flags
  ENABLE_ANALYTICS: true,
  ENABLE_ERROR_REPORTING: true,
  ENABLE_PERFORMANCE_MONITORING: true,
} as const;

// =============================================================================
// VALIDATION RULES
// =============================================================================

export const VALIDATION_RULES = {
  // User input limits
  MAX_USERNAME_LENGTH: 50,
  MIN_USERNAME_LENGTH: 3,
  MAX_EMAIL_LENGTH: 254,
  MIN_PASSWORD_LENGTH: 8,
  MAX_PASSWORD_LENGTH: 128,
  
  // Content limits
  MAX_COMMENT_LENGTH: 1000,
  MAX_REVIEW_LENGTH: 2000,
  MAX_TITLE_LENGTH: 100,
  MAX_DESCRIPTION_LENGTH: 500,
  
  // File upload limits
  MAX_AVATAR_SIZE: 2 * 1024 * 1024, // 2MB
  MAX_THUMBNAIL_SIZE: 5 * 1024 * 1024, // 5MB
  
  // Video metadata
  MAX_VIDEO_DURATION: 180 * 60, // 3 hours in seconds
  MIN_VIDEO_DURATION: 30, // 30 seconds
} as const;

// =============================================================================
// ERROR CODES
// =============================================================================

export const ERROR_CODES = {
  // Authentication errors
  AUTH_TOKEN_EXPIRED: 'AUTH_TOKEN_EXPIRED',
  AUTH_INVALID_CREDENTIALS: 'AUTH_INVALID_CREDENTIALS',
  AUTH_SESSION_REQUIRED: 'AUTH_SESSION_REQUIRED',
  
  // Network errors
  NETWORK_ERROR: 'NETWORK_ERROR',
  TIMEOUT_ERROR: 'TIMEOUT_ERROR',
  RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
  
  // Video errors
  VIDEO_NOT_FOUND: 'VIDEO_NOT_FOUND',
  VIDEO_UNAVAILABLE: 'VIDEO_UNAVAILABLE',
  VIDEO_ENCODING_ERROR: 'VIDEO_ENCODING_ERROR',
  
  // Payment errors
  PAYMENT_REQUIRED: 'PAYMENT_REQUIRED',
  SUBSCRIPTION_EXPIRED: 'SUBSCRIPTION_EXPIRED',
  PAYMENT_FAILED: 'PAYMENT_FAILED',
} as const;

// =============================================================================
// RESPONSIVE BREAKPOINTS
// =============================================================================

export const BREAKPOINTS = {
  XS: 320,
  SM: 640,
  MD: 768,
  LG: 1024,
  XL: 1280,
  XXL: 1536,
} as const;

// =============================================================================
// EXPORT UTILITY FUNCTIONS
// =============================================================================

/**
 * Get API base URL based on environment
 */
export const getApiBaseUrl = (): string => {
  // In production/Vercel deployment, use the same domain for API calls
  if (import.meta.env.PROD || typeof window !== 'undefined') {
    // Check if we're in browser environment
    if (typeof window !== 'undefined') {
      // Use current domain for API calls in production
      return window.location.origin;
    }
  }
  
  // Fallback for development or SSR
  return import.meta.env.VITE_BACKEND_API_URL || 
    (import.meta.env.PROD ? '' : ENV_DEFAULTS.DEVELOPMENT_API_URL);
};

/**
 * Get timeout value by key with fallback
 */
export const getTimeout = (key: keyof typeof TIMEOUTS, fallback?: number): number => {
  return TIMEOUTS[key] ?? fallback ?? 5000;
};

/**
 * Check if connection is fast enough for high quality streaming
 */
export const isFastConnection = (): boolean => {
  if (!('connection' in navigator)) return true;
  
  const connection = (navigator as any).connection;
  if (!connection) return true;
  
  const downlink = connection.downlink || 10; // Default to 10 Mbps if unknown
  return downlink >= NETWORK_CONFIG.BANDWIDTH_THRESHOLDS.FAST;
};

/**
 * Get recommended video quality based on connection speed
 */
export const getRecommendedQuality = (): string => {
  if (!('connection' in navigator)) return VIDEO_CONFIG.QUALITY_LEVELS.HD;
  
  const connection = (navigator as any).connection;
  if (!connection) return VIDEO_CONFIG.QUALITY_LEVELS.HD;
  
  const downlink = connection.downlink || 5;
  
  if (downlink >= NETWORK_CONFIG.BANDWIDTH_THRESHOLDS.FAST) {
    return VIDEO_CONFIG.QUALITY_LEVELS.FULL_HD;
  } else if (downlink >= NETWORK_CONFIG.BANDWIDTH_THRESHOLDS.MEDIUM) {
    return VIDEO_CONFIG.QUALITY_LEVELS.HD;
  } else {
    return VIDEO_CONFIG.QUALITY_LEVELS.SD;
  }
}; 