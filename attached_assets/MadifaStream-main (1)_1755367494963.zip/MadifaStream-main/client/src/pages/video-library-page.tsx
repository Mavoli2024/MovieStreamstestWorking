import {  MainLayout  } from "@/components/layouts/MainLayout";
import {  Button  } from "@/components/ui/button";
import {  Input  } from "@/components/ui/input";
import {  LoadingSpinner  } from "@/components/ui/loading-spinner";
import {  Select, SelectContent, SelectItem, SelectTrigger, SelectValue  } from "@/components/ui/select";
import { useVideos } from "@/hooks/use-videos";
import { useWatchlist } from "@/hooks/use-watchlist";
import { Video } from "@/lib/supabase-api";
import { formatDuration } from "@/lib/utils";
import {  UploadCloud, Grid, List, Grid3x3, Layout, Columns3, Table, Settings  } from "lucide-react";
import { useState, useMemo, memo } from "react";
import { useLocation } from "wouter";
import { DisplayModeProvider, useDisplayMode, type DisplayMode } from "@/contexts/display-mode-context";
import {  EnhancedVideoCard  } from "@/components/video/enhanced-video-card";

// Display Mode Selector Component
const LibraryDisplayModeSelector = memo(() => {
  const { settings, setDisplayMode, applyPreset } = useDisplayMode();
  
  const displayModeOptions = [
    { value: 'grid-comfortable', label: 'Comfortable Grid', icon: Grid },
    { value: 'grid-compact', label: 'Compact Grid', icon: Grid3x3 },
    { value: 'grid-cozy', label: 'Cozy Grid', icon: Layout },
    { value: 'list-detailed', label: 'Detailed List', icon: List },
    { value: 'list-compact', label: 'Compact List', icon: Columns3 },
    { value: 'table-row', label: 'Table View', icon: Table },
  ] as const;

  const presetOptions = [
    { value: 'performance', label: 'Performance' },
    { value: 'detailed', label: 'Detailed' },
    { value: 'minimal', label: 'Minimal' },
    { value: 'cozy', label: 'Cozy' },
    { value: 'table', label: 'Table' },
  ];

  return (
    <div className="flex items-center gap-2">
      {/* Quick Mode Buttons */}
      <div className="flex items-center bg-muted rounded-lg p-1">
        {displayModeOptions.slice(0, 3).map(({ value, label, icon: Icon }) => (
          <Button
            key={value}
            variant={settings.mode === value ? "default" : "ghost"}
            size="sm"
            onClick={() => setDisplayMode(value as DisplayMode)}
            className="px-3"
            title={label}
          >
            <Icon size={16} />
          </Button>
        ))}
      </div>

      {/* All Options Dropdown */}
      <Select value={settings.mode} onValueChange={(value) => setDisplayMode(value as DisplayMode)}>
        <SelectTrigger className="w-36">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {displayModeOptions.map(({ value, label, icon: Icon }) => (
            <SelectItem key={value} value={value}>
              <div className="flex items-center gap-2">
                <Icon size={16} />
                {label}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Preset Dropdown */}
      <Select onValueChange={applyPreset}>
        <SelectTrigger className="w-28">
          <SelectValue placeholder="Preset" />
        </SelectTrigger>
        <SelectContent>
          {presetOptions.map(({ value, label }) => (
            <SelectItem key={value} value={value}>
              {label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
});

// Enhanced Video Display Component for Library
const LibraryVideoDisplay = memo(({ videos, onPlay }: {
  videos: Video[];
  onPlay: (video: Video) => void;
}) => {
  const { settings, getGridColumns } = useDisplayMode();
  const { watchlist, addToWatchlist, removeFromWatchlist } = useWatchlist();
  
  // Create watchlist set for quick lookups
  const watchlistSet = useMemo(() => 
    new Set(watchlist?.map((w: { video_id: string }) => w.video_id) || []), 
    [watchlist]
  );

  // Table View for large datasets - perfect for library management
  if (settings.mode === 'table-row') {
    return (
      <div className="bg-card rounded-lg border overflow-hidden">
        <div className="grid grid-cols-[auto_1fr_auto_auto_auto_auto] gap-4 p-4 border-b font-medium text-sm text-muted-foreground">
          <div></div>
          <div>Title</div>
          <div>Duration</div>
          <div>Upload Date</div>
          <div>Status</div>
          <div>Actions</div>
        </div>
        <div className="divide-y">
          {videos.map((video) => (
            <EnhancedVideoCard
              key={video.id}
              video={video}
              variant="table-row"
              onPlay={() => onPlay(video)}
              isInWatchlist={watchlistSet.has(video.id)}
              onAddToWatchlist={() => addToWatchlist.mutate(video.id)}
              onRemoveFromWatchlist={() => removeFromWatchlist.mutate(video.id)}
              showViews={true}
              showRating={true}
              showGenres={true}
              showDuration={true}
              showActions={true}
            />
          ))}
        </div>
      </div>
    );
  }

  // List Views - good for detailed management
  if (settings.mode.startsWith('list')) {
    return (
      <div className="space-y-4">
        {videos.map((video) => (
          <EnhancedVideoCard
            key={video.id}
            video={video}
            variant={settings.mode as any}
            size={settings.cardSize}
            onPlay={() => onPlay(video)}
            isInWatchlist={watchlistSet.has(video.id)}
            onAddToWatchlist={() => addToWatchlist.mutate(video.id)}
            onRemoveFromWatchlist={() => removeFromWatchlist.mutate(video.id)}
            showViews={true}
            showRating={true}
            showGenres={true}
            showDuration={true}
            showActions={true}
          />
        ))}
      </div>
    );
  }

  // Grid Views - traditional library view
  const columns = getGridColumns();
  return (
    <div 
      className="grid gap-6 auto-rows-max"
      style={{ 
        gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))`,
      }}
    >
      {videos.map((video) => (
        <EnhancedVideoCard
          key={video.id}
          video={video}
          variant={settings.mode as any}
          size={settings.cardSize}
          onPlay={() => onPlay(video)}
          isInWatchlist={watchlistSet.has(video.id)}
          onAddToWatchlist={() => addToWatchlist.mutate(video.id)}
          onRemoveFromWatchlist={() => removeFromWatchlist.mutate(video.id)}
          showViews={true}
          showRating={true}
          showGenres={true}
          showDuration={true}
          showActions={true}
          enableLazyLoading={settings.enableLazyLoading}
        />
      ))}
    </div>
  );
});

/**
 * Enhanced Video Library Page with sophisticated display modes
 */
function VideoLibraryPageContent() {
  const [searchQuery, setSearchQuery] = useState("");
  const [, setLocation] = useLocation();

  const { data: videosData, isLoading, error } = useVideos();
  // Flatten pages from infinite query into a simple array of videos
  const videos: Video[] = Array.isArray(videosData)
    ? videosData
    : [];

  const filteredVideos = videos.filter((video: Video) =>
    video.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const totalVideos = filteredVideos.length;
  const totalDuration = filteredVideos.reduce((total: number, video: Video) => total + (video.duration || 0), 0);
  const totalDurationFormatted = formatDuration(totalDuration);

  let totalMegabytes = 0;
  filteredVideos.forEach((video: Video) => {
    const isHD = video.title?.toLowerCase().includes('720p') || video.title?.toLowerCase().includes('1080p');
    const qualityMultiplier = isHD ? 1.5 : 1;
    totalMegabytes += Math.round(((video.duration || 0) / 60) * 100 * qualityMultiplier);
  });
  const totalGigabytes = (totalMegabytes / 1024).toFixed(2);

  const getTotalViews = () => {
    return filteredVideos.length * 5;
  };

  const totalViews = getTotalViews();

  if (isLoading) return <LoadingSpinner />;
  // Ensure error is an instance of Error before accessing message
  if (error) return <div className="text-red-500 p-4">Error loading videos: {error instanceof Error ? error.message : String(error)}</div>;

  return (
    <>
      <div className="container mx-auto px-4 py-8 pb-20">
        {/* Header with Enhanced Controls */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Video Library</h1>
            <p className="text-muted-foreground">Manage your uploaded video content with advanced display options.</p>
          </div>
          
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full lg:w-auto">
            <Input
              type="search"
              placeholder="Search videos..."
              className="w-full sm:w-64 form-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <LibraryDisplayModeSelector />
            <Button variant="outline" size="icon" onClick={() => setLocation("/upload")} title="Upload New Video">
              <UploadCloud className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card p-4 rounded-lg shadow border">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Total Videos</h3>
            <p className="text-2xl font-bold">{totalVideos}</p>
          </div>
          <div className="bg-card p-4 rounded-lg shadow border">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Total Duration</h3>
            <p className="text-2xl font-bold">{totalDurationFormatted}</p>
          </div>
          <div className="bg-card p-4 rounded-lg shadow border">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Est. Storage</h3>
            <p className="text-2xl font-bold">{totalGigabytes} GB</p>
          </div>
          <div className="bg-card p-4 rounded-lg shadow border">
            <h3 className="text-sm font-medium text-muted-foreground mb-1">Total Views</h3>
            <p className="text-2xl font-bold">{totalViews}</p>
          </div>
        </div>

        {/* Content Display */}
        {isLoading ? (
          <LoadingSpinner />
        ) : (
          <>
            {filteredVideos.length === 0 ? (
              <div className="bg-card p-8 rounded-md text-center border">
                <div className="text-6xl mb-4">📹</div>
                <h3 className="text-xl font-medium mb-2">No videos found</h3>
                <p className="text-muted-foreground mb-4">
                  {searchQuery ? `Your search for "${searchQuery}" did not match any videos.` : "Upload your first video to get started!"}
                </p>
                {searchQuery ? (
                  <Button variant="outline" onClick={() => setSearchQuery("")} className="mt-4">
                    Clear Search
                  </Button>
                ) : (
                  <Button onClick={() => setLocation("/upload")} className="mt-4">
                    <UploadCloud className="mr-2 h-4 w-4" /> Upload Video
                  </Button>
                )}
              </div>
            ) : (
              <LibraryVideoDisplay 
                videos={filteredVideos} 
                onPlay={(video) => setLocation(`/watch/${video.id}`)}
              />
            )}
          </>
        )}
      </div>
    </>
  );
}

const VideoLibraryPage = () => {
  return (
    <DisplayModeProvider initialSettings={{ mode: 'grid-compact', cardSize: 'medium' }}>
      <VideoLibraryPageContent />
    </DisplayModeProvider>
  );
};

export default VideoLibraryPage;