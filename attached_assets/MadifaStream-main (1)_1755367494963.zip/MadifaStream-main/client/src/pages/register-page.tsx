// Redirect legacy /register route to unified auth page
import { useEffect } from 'react';
import { useLocation } from 'wouter';

export default function RegisterPage() {
  const [_, navigate] = useLocation();
  useEffect(() => {
    navigate('/auth?tab=register');
  }, [navigate]);
  return null;
}