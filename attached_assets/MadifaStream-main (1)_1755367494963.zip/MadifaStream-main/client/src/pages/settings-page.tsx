import {  AdaptiveLayout  } from "@/components/layouts/AdaptiveLayout";
import {  Card, CardContent, CardDescription, CardHeader, CardTitle  } from "@/components/ui/card";
import {  Button  } from "@/components/ui/button";
import {  Switch  } from "@/components/ui/switch";
import {  Label  } from "@/components/ui/label";
import {  Separator  } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import {  Bell, Shield, Monitor, Smartphone, Download, Globe  } from "lucide-react";
import {  Helmet  } from "react-helmet-async";

export default function SettingsPage() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState(true);
  const [autoplay, setAutoplay] = useState(true);
  const [hdStreaming, setHdStreaming] = useState(true);
  const [downloadQuality, setDownloadQuality] = useState(true);

  return (
    <>
      <Helmet>
        <title>Settings - MadifaStream</title>
        <meta name="description" content="Manage your MadifaStream account settings and preferences" />
      </Helmet>
      
      <AdaptiveLayout>
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="space-y-6">
            {/* Header */}
            <div>
              <h1 className="text-3xl font-bold text-white">Settings</h1>
              <p className="text-gray-400 mt-2">Manage your account preferences and settings</p>
            </div>

            {/* Account Settings */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Shield className="h-5 w-5" />
                  Account Settings
                </CardTitle>
                <CardDescription>
                  Manage your account information and security
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-white">Email</Label>
                    <p className="text-gray-400 text-sm mt-1">{user?.email}</p>
                  </div>
                  <div>
                    <Label className="text-white">Account Type</Label>
                    <p className="text-gray-400 text-sm mt-1">Premium Subscriber</p>
                  </div>
                </div>
                <Separator className="bg-gray-800" />
                <div className="flex flex-col sm:flex-row gap-2">
                  <Button variant="outline" className="border-gray-700 text-white">
                    Change Password
                  </Button>
                  <Button variant="outline" className="border-gray-700 text-white">
                    Update Email
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Notifications */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Bell className="h-5 w-5" />
                  Notifications
                </CardTitle>
                <CardDescription>
                  Choose what notifications you want to receive
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-white">Email Notifications</Label>
                    <p className="text-gray-400 text-sm">Receive updates about new content and features</p>
                  </div>
                  <Switch
                    checked={notifications}
                    onCheckedChange={setNotifications}
                  />
                </div>
                <Separator className="bg-gray-800" />
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-white">Push Notifications</Label>
                    <p className="text-gray-400 text-sm">Get notified about downloads and recommendations</p>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>

            {/* Playback Settings */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Monitor className="h-5 w-5" />
                  Playback Settings
                </CardTitle>
                <CardDescription>
                  Configure your video streaming preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-white">Autoplay Next Episode</Label>
                    <p className="text-gray-400 text-sm">Automatically play the next episode in a series</p>
                  </div>
                  <Switch
                    checked={autoplay}
                    onCheckedChange={setAutoplay}
                  />
                </div>
                <Separator className="bg-gray-800" />
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-white">HD Streaming</Label>
                    <p className="text-gray-400 text-sm">Stream in high definition when available</p>
                  </div>
                  <Switch
                    checked={hdStreaming}
                    onCheckedChange={setHdStreaming}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Download Settings */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Download className="h-5 w-5" />
                  Download Settings
                </CardTitle>
                <CardDescription>
                  Manage offline download preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label className="text-white">High Quality Downloads</Label>
                    <p className="text-gray-400 text-sm">Download videos in the highest available quality</p>
                  </div>
                  <Switch
                    checked={downloadQuality}
                    onCheckedChange={setDownloadQuality}
                  />
                </div>
                <Separator className="bg-gray-800" />
                <div>
                  <Label className="text-white">Download Location</Label>
                  <p className="text-gray-400 text-sm mt-1">Videos are stored locally on your device</p>
                  <Button variant="outline" className="border-gray-700 text-white mt-2" size="sm">
                    Manage Storage
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Device Settings */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Smartphone className="h-5 w-5" />
                  Device Management
                </CardTitle>
                <CardDescription>
                  Manage devices connected to your account
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-800/50 rounded-lg">
                    <div>
                      <p className="text-white font-medium">This Device</p>
                      <p className="text-gray-400 text-sm">Current browser session</p>
                    </div>
                    <span className="text-green-500 text-sm">Active</span>
                  </div>
                  <Button variant="outline" className="border-gray-700 text-white w-full">
                    Sign Out All Devices
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Language & Region */}
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Globe className="h-5 w-5" />
                  Language & Region
                </CardTitle>
                <CardDescription>
                  Set your preferred language and region
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-white">Display Language</Label>
                  <p className="text-gray-400 text-sm mt-1">English (South Africa)</p>
                </div>
                <div>
                  <Label className="text-white">Region</Label>
                  <p className="text-gray-400 text-sm mt-1">South Africa</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </AdaptiveLayout>
    </>
  );
} 