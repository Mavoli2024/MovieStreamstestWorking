import React, { useState, memo, useMemo, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { VideoDetailModal } from "@/components/video-detail-modal";
import { RobustVideoGrid } from "@/components/video/RobustVideoGrid";
import { RobustErrorBoundary } from "@/components/error-boundary/RobustErrorBoundary";
import { RobustLoadingState, InlineLoading } from "@/components/ui/robust-loading";
import { useRobustVideos } from "@/hooks/use-robust-data";
import { useWatchlist } from "@/hooks/use-watchlist";
import { useAuth } from "@/hooks/use-auth";
import { AuthModal } from "@/components/auth-modal";
import { SubscriptionModal } from "@/components/subscription-modal";
import { Search, X, Filter, Grid, Crown, Play, Calendar, Star, RefreshCw } from "lucide-react";
import { Helmet } from "react-helmet-async";
import type { Database } from "@/types/database-generated.types";
import { logger } from '@shared/logger';

type Video = Database['public']['Tables']['videos']['Row'];

interface FilterChipProps {
  label: string;
  isActive: boolean;
  onClick: () => void;
  count?: number;
}

const FilterChip = memo(function FilterChip({ 
  label, 
  isActive, 
  onClick, 
  count 
}: FilterChipProps) {
  return (
    <Button
      variant={isActive ? "default" : "outline"}
      size="sm"
      onClick={onClick}
      className={`flex items-center gap-2 transition-all duration-200 ${
        isActive ? 'bg-primary text-primary-foreground shadow-md' : 'hover:bg-gray-100'
      }`}
    >
      {label}
      {count !== undefined && (
        <Badge variant="secondary" className="ml-1 text-xs">
          {count}
        </Badge>
      )}
    </Button>
  );
});

interface RobustBrowsePageProps {
  className?: string;
}

export function RobustBrowsePage({ className = '' }: RobustBrowsePageProps) {
  const { user } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [showPremiumOnly, setShowPremiumOnly] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [retryAttempts, setRetryAttempts] = useState(0);

  // Robust data fetching with error handling
  const {
    data: videos,
    loading,
    error,
    refetch,
    retryCount,
    isRetrying,
  } = useRobustVideos({
    onError: (error) => {
      logger.error('Failed to load videos on browse page:', error);
      setRetryAttempts(prev => prev + 1);
    },
    onSuccess: (data) => {
      logger.info(`Browse page loaded ${data?.length || 0} videos successfully`);
      setRetryAttempts(0); // Reset on success
    },
  });

  const { addToWatchlist, removeFromWatchlist, isInWatchlist } = useWatchlist();

  // Data validation and filtering with error resilience
  const processedVideos = useMemo(() => {
    if (!videos || !Array.isArray(videos)) {
      logger.warn('Invalid videos data received:', videos);
      return [];
    }

    return videos.filter((video: Video) => {
      // Validate video object
      if (!video || typeof video !== 'object' || !video.id) {
        logger.warn('Invalid video object detected:', video);
        return false;
      }

      // Search filter
      if (searchTerm) {
        const searchLower = searchTerm.toLowerCase();
        const title = (video.title || '').toLowerCase();
        const description = (video.description || '').toLowerCase();
        const category = (video.category || '').toLowerCase();
        
        if (!title.includes(searchLower) && 
            !description.includes(searchLower) && 
            !category.includes(searchLower)) {
          return false;
        }
      }

      // Category filter
      if (selectedCategory !== "all" && video.category !== selectedCategory) {
        return false;
      }

      // Premium filter
      if (showPremiumOnly && !video.is_premium) {
        return false;
      }

      return true;
    });
  }, [videos, searchTerm, selectedCategory, showPremiumOnly]);

  // Safe sorting with error handling
  const sortedVideos = useMemo(() => {
    if (!processedVideos || processedVideos.length === 0) return [];

    try {
      return [...processedVideos].sort((a, b) => {
        switch (sortBy) {
          case "newest":
            const dateA = new Date(a.created_at || 0).getTime();
            const dateB = new Date(b.created_at || 0).getTime();
            return dateB - dateA;
          
          case "oldest":
            const oldDateA = new Date(a.created_at || 0).getTime();
            const oldDateB = new Date(b.created_at || 0).getTime();
            return oldDateA - oldDateB;
          
          case "title":
            return (a.title || '').localeCompare(b.title || '');
          
          case "rating":
            return (b.rating || 0) - (a.rating || 0);
          
          case "duration":
            return (b.duration || 0) - (a.duration || 0);
          
          default:
            return 0;
        }
      });
    } catch (error) {
      logger.error('Error sorting videos:', error);
      return processedVideos; // Return unsorted on error
    }
  }, [processedVideos, sortBy]);

  // Safe category extraction
  const categories = useMemo(() => {
    if (!videos || !Array.isArray(videos)) return [];
    
    try {
      const categoryMap = new Map<string, number>();
      
      videos.forEach((video: Video) => {
        const category = video?.category;
        if (category && typeof category === 'string') {
          categoryMap.set(category, (categoryMap.get(category) || 0) + 1);
        }
      });
      
      return Array.from(categoryMap.entries()).map(([name, count]) => ({
        name,
        count,
      }));
    } catch (error) {
      logger.error('Error extracting categories:', error);
      return [];
    }
  }, [videos]);

  // Video interaction handlers with error boundaries
  const handleVideoClick = async (video: Video) => {
    try {
      if (!video?.id) {
        throw new Error('Invalid video selected');
      }

      logger.info(`Video selected: ${video.id} - ${video.title}`);
      
      if (video.is_premium && !user) {
        setShowAuthModal(true);
        return;
      }
      
      setSelectedVideo(video);
    } catch (error) {
      logger.error('Error handling video click:', error);
    }
  };

  const handleVideoPlay = async (video: Video) => {
    try {
      if (!video?.id) {
        throw new Error('Invalid video for playback');
      }

      logger.info(`Attempting to play video: ${video.id} - ${video.title}`);
      
      if (video.is_premium && !user) {
        setShowAuthModal(true);
        return;
      }
      
      // Navigate to video player or open modal
      window.location.href = `/watch/${video.id}`;
    } catch (error) {
      logger.error('Error playing video:', error);
    }
  };

  const handleWatchlistToggle = async (video: Video) => {
    try {
      if (!user) {
        setShowAuthModal(true);
        return;
      }

      if (!video?.id) {
        throw new Error('Invalid video for watchlist');
      }

      if (isInWatchlist(video.id)) {
        await removeFromWatchlist(video.id);
        logger.info(`Removed from watchlist: ${video.id}`);
      } else {
        await addToWatchlist(video.id);
        logger.info(`Added to watchlist: ${video.id}`);
      }
    } catch (error) {
      logger.error('Error toggling watchlist:', error);
    }
  };

  const handleClearSearch = () => {
    setSearchTerm("");
  };

  const handleRetry = () => {
    logger.info('User initiated retry for browse page');
    refetch();
  };

  // Clear filters handler
  const handleClearFilters = () => {
    setSearchTerm("");
    setSelectedCategory("all");
    setSortBy("newest");
    setShowPremiumOnly(false);
  };

  const hasActiveFilters = searchTerm || selectedCategory !== "all" || showPremiumOnly;
  const isEmpty = !loading && !error && sortedVideos.length === 0;

  return (
    <RobustErrorBoundary level="page">
      <div className={`container mx-auto px-4 py-6 space-y-6 ${className}`}>
        <Helmet>
          <title>Browse Content - Madifa Films</title>
          <meta name="description" content="Browse our extensive collection of African movies, series, and documentaries." />
        </Helmet>

        {/* Header Section */}
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <h1 className="text-3xl font-bold text-white">Browse Content</h1>
            
            {/* Retry Button for errors */}
            {error && (
              <Button
                onClick={handleRetry}
                variant="outline"
                size="sm"
                disabled={isRetrying}
                className="flex items-center gap-2"
              >
                {isRetrying ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Retrying...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-4 h-4" />
                    Retry ({retryCount}/3)
                  </>
                )}
              </Button>
            )}
          </div>

          {/* Search and Filters */}
          <RobustErrorBoundary level="component">
            <div className="flex flex-col lg:flex-row gap-4">
              {/* Search */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search videos, categories..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-10 bg-gray-800 border-gray-700 text-white"
                />
                {searchTerm && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleClearSearch}
                    className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-700"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>

              {/* Sort */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-full lg:w-48 bg-gray-800 border-gray-700 text-white">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Newest First
                    </div>
                  </SelectItem>
                  <SelectItem value="oldest">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Oldest First
                    </div>
                  </SelectItem>
                  <SelectItem value="title">Title A-Z</SelectItem>
                  <SelectItem value="rating">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4" />
                      Highest Rated
                    </div>
                  </SelectItem>
                  <SelectItem value="duration">Longest First</SelectItem>
                </SelectContent>
              </Select>

              {/* Premium Filter */}
              <Button
                variant={showPremiumOnly ? "default" : "outline"}
                onClick={() => setShowPremiumOnly(!showPremiumOnly)}
                className="flex items-center gap-2"
              >
                <Crown className="w-4 h-4" />
                Premium Only
              </Button>
            </div>
          </RobustErrorBoundary>

          {/* Category Filters */}
          <RobustErrorBoundary level="component">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                  <Filter className="w-5 h-5" />
                  Categories
                </h3>
                {hasActiveFilters && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleClearFilters}
                    className="text-gray-400 hover:text-white"
                  >
                    Clear Filters
                  </Button>
                )}
              </div>
              
              <div className="flex flex-wrap gap-2">
                <FilterChip
                  label="All"
                  isActive={selectedCategory === "all"}
                  onClick={() => setSelectedCategory("all")}
                  count={videos?.length || 0}
                />
                {categories.map((category) => (
                  <FilterChip
                    key={category.name}
                    label={category.name}
                    isActive={selectedCategory === category.name}
                    onClick={() => setSelectedCategory(category.name)}
                    count={category.count}
                  />
                ))}
              </div>
            </div>
          </RobustErrorBoundary>

          {/* Results Summary */}
          {!loading && !error && (
            <div className="flex items-center justify-between text-sm text-gray-400">
              <span>
                {sortedVideos.length} video{sortedVideos.length !== 1 ? 's' : ''} found
                {hasActiveFilters && ' (filtered)'}
              </span>
              {isRetrying && (
                <InlineLoading loading={true} className="text-blue-400" />
              )}
            </div>
          )}
        </div>

        {/* Video Grid */}
        <RobustLoadingState
          loading={loading}
          error={error}
          onRetry={handleRetry}
          isEmpty={isEmpty}
          emptyMessage={
            hasActiveFilters
              ? "No videos match your current filters. Try adjusting your search criteria."
              : "No videos available at the moment. Please check back later."
          }
          retryCount={retryCount}
          loadingMessage={isRetrying ? 'Retrying...' : 'Loading videos...'}
        >
          <RobustErrorBoundary level="component">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
              {sortedVideos.map((video) => (
                <RobustErrorBoundary key={video.id} level="component">
                  <div
                    className="cursor-pointer transform transition-transform hover:scale-105"
                    onClick={() => handleVideoClick(video)}
                  >
                    {/* You can replace this with your existing video card component */}
                    <div className="bg-gray-800 rounded-lg overflow-hidden shadow-lg">
                      <div className="aspect-video bg-gray-700 relative">
                        {video.thumbnail_url ? (
                          <img
                            src={video.thumbnail_url}
                            alt={video.title}
                            className="w-full h-full object-cover"
                            loading="lazy"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-gray-400">
                            <Play className="w-12 h-12" />
                          </div>
                        )}
                        {video.is_premium && (
                          <Badge className="absolute top-2 left-2 bg-yellow-500 text-black">
                            <Crown className="w-3 h-3 mr-1" />
                            Premium
                          </Badge>
                        )}
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold text-white line-clamp-2 mb-2">
                          {video.title || 'Untitled'}
                        </h3>
                        {video.description && (
                          <p className="text-gray-400 text-sm line-clamp-2 mb-2">
                            {video.description}
                          </p>
                        )}
                        <div className="flex items-center justify-between text-xs text-gray-500">
                          <span>{video.category || 'General'}</span>
                          {video.duration && (
                            <span>{Math.floor(video.duration / 60)}min</span>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </RobustErrorBoundary>
              ))}
            </div>
          </RobustErrorBoundary>
        </RobustLoadingState>

        {/* Modals */}
        {selectedVideo && (
          <VideoDetailModal
            video={selectedVideo}
            isOpen={!!selectedVideo}
            onClose={() => setSelectedVideo(null)}
            onPlay={() => handleVideoPlay(selectedVideo)}
            onWatchlistToggle={() => handleWatchlistToggle(selectedVideo)}
            isInWatchlist={isInWatchlist(selectedVideo.id)}
          />
        )}

        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
        />

        <SubscriptionModal
          isOpen={showSubscriptionModal}
          onClose={() => setShowSubscriptionModal(false)}
        />
      </div>
    </RobustErrorBoundary>
  );
}

export default RobustBrowsePage;