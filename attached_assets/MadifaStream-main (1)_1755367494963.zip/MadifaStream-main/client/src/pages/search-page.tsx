// MainLayout removed - now handled by UnifiedRouter
import {  Input  } from "@/components/ui/input";
import {  Loader2, Search, X  } from "lucide-react";
import {  Helmet  } from "react-helmet-async";
import { useState, useMemo } from "react";
import { useVideos } from "@/hooks/use-videos";
import {  VideoListCard  } from "@/components/video/unified-video-card";
import type { Database } from "@/types/database-generated.types";
import { useLocation } from "wouter";

type Video = Database['public']['Tables']['videos']['Row'];

export default function SearchPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const { data: videosData, isLoading: isLoadingVideos } = useVideos();
  const [, navigate] = useLocation();

  const allVideos = useMemo(() => videosData || [], [videosData]);

  const filteredVideos = useMemo(() => {
    if (!searchTerm.trim()) return [];
    
    return allVideos.filter(video => 
      video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (video.description && video.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (video.genres && video.genres.some(genre => 
        genre.toLowerCase().includes(searchTerm.toLowerCase())
      ))
    );
  }, [allVideos, searchTerm]);

  const handlePlay = (video: Video) => {
    navigate(`/watch/${video.id}`);
  };

  return (
    <>
      <Helmet>
        <title>Search | Madifa Films</title>
      </Helmet>
      <div className="container mx-auto px-4 py-8">
        {/* Search Input */}
        <div className="relative mb-8 max-w-2xl mx-auto">
          <div className="absolute inset-y-0 left-0 flex items-center pl-4">
            <Search size={20} className="text-gray-400" />
          </div>
          <Input
            type="search"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search for movies, shows, genres..."
            className="pl-12 form-input h-14 text-lg rounded-full bg-background/50 border-2 border-border focus:border-primary"
            autoFocus
          />
          {searchTerm && (
            <button
              className="absolute inset-y-0 right-4 text-gray-400 hover:text-white"
              onClick={() => setSearchTerm("")}
            >
              <X size={20} />
            </button>
          )}
        </div>

        {/* Results */}
        <div className="mt-8">
          {isLoadingVideos && searchTerm && (
             <div className="flex justify-center items-center h-40">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
             </div>
          )}

          {!isLoadingVideos && searchTerm && filteredVideos.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-400 text-lg">No results found for "{searchTerm}".</p>
              <p className="text-gray-500 text-sm mt-2">Try searching for something else.</p>
            </div>
          )}

          {!isLoadingVideos && filteredVideos.length > 0 && (
            <div className="space-y-4 max-w-4xl mx-auto">
              {filteredVideos.map(video => (
                <VideoListCard
                  key={video.id}
                  video={video}
                  onPlay={handlePlay}
                />
              ))}
            </div>
          )}

          {!searchTerm && (
             <div className="text-center py-16">
                <Search size={48} className="mx-auto text-gray-600" />
                <h2 className="mt-4 text-2xl font-semibold text-gray-400">Search for Content</h2>
                <p className="mt-2 text-gray-500">Find your favorite movies and shows.</p>
             </div>
          )}
        </div>
      </div>
    </>
  );
} 