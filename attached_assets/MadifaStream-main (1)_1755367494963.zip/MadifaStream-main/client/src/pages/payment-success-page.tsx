import {  MainLayout  } from "@/components/layouts/MainLayout";
import { useAuth } from "@/hooks/use-auth";
import {  Button  } from "@/components/ui/button";
import { useQueryClient } from "@tanstack/react-query";
import {  Check, ChevronRight  } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";

export default function PaymentSuccessPage() {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [countdown, setCountdown] = useState(5);

  // Count-down and subscription query invalidation effect
  useEffect(() => {
    // Only run when user is authenticated and not loading
    if (isLoading || !user) return;

    // Invalidate queries to refetch user's profile and subscription status
    queryClient.invalidateQueries({ queryKey: ["profile"] }); // Ensure the latest profile is fetched
    queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate("/home");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isLoading, user, navigate, queryClient]);

  // Prevent rendering when auth is loading or user is not logged in
  if (isLoading) {
    return (
      <>
        <div className="flex items-center justify-center min-h-screen">
          <p>Loading...</p>
        </div>
      </>
    );
  }
  if (!user) {
    return (
      <>
        <div className="flex items-center justify-center min-h-screen">
          <p>Please log in to view this page.</p>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="container max-w-3xl mx-auto px-4 py-16">
        <div className="bg-card rounded-lg p-8 shadow-lg">
          <div className="flex flex-col items-center justify-center space-y-6 text-center">
            <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center">
              <Check className="w-10 h-10 text-white" />
            </div>

            <h1 className="text-3xl font-bold">Payment Successful!</h1>

            <p className="text-lg text-muted-foreground max-w-xl">
              Thank you for subscribing to Madifa. Your subscription has been activated and you now have full access to all our content.
            </p>

            <div className="border-t border-border w-full my-4 pt-6">
              <p className="text-muted-foreground mb-4">
                You will be redirected to the home page in {countdown} seconds...
              </p>

              <Button
                onClick={() => navigate("/home")}
                className="bg-primary hover:bg-red-700"
              >
                Go to Home Page <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}