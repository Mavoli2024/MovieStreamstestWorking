import {  MainLayout  } from "@/components/layouts/MainLayout";
import {  UnifiedVideoGrid  } from "@/components/video/unified-video-displays";
import { useWatchlist } from "@/hooks/use-watchlist";
import { useVideos } from "@/hooks/use-videos";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import {  Loader2, Heart, Plus, ArrowUpAZ, ArrowDownAZ, Clock, CalendarDays  } from "lucide-react";
import { useState, useMemo } from "react";
import {  Helmet  } from "react-helmet-async";
import {  Link  } from "wouter";
import {  Button  } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {  AuthModal  } from "@/components/auth-modal";
import {  SubscriptionModal  } from "@/components/subscription-modal";
import type { Database } from "@/types/database-generated.types";

type Video = Database['public']['Tables']['videos']['Row'];

export default function MyListPage() {
  const { user, checkSubscription } = useAuth();
  const { watchlist, removeFromWatchlist, isLoading: isLoadingWatchlist } = useWatchlist();
  const { data: videosData, isLoading: isLoadingVideos } = useVideos();
  const { toast } = useToast();

  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [videoToPlay, setVideoToPlay] = useState<Video | null>(null);
  const [sortBy, setSortBy] = useState<string>('added_desc');

  const allVideos = useMemo(() => videosData || [], [videosData]);

  // Convert watchlist to videos
  const watchlistVideos = useMemo(() => {
    if (!watchlist || watchlist.length === 0 || !allVideos.length) return [];
    
    const videoMap = new Map(allVideos.map(v => [v.id, v]));
    const items = watchlist
      .map((w: { video_id: string; added_at?: string }) => ({
        video: videoMap.get(w.video_id),
        added_at: (w as any).added_at || undefined,
      }))
      .filter((x) => !!x.video) as { video: Video; added_at?: string }[];

    // Apply sorting
    switch (sortBy) {
      case 'title_asc':
        items.sort((a, b) => a.video.title.localeCompare(b.video.title));
        break;
      case 'title_desc':
        items.sort((a, b) => b.video.title.localeCompare(a.video.title));
        break;
      case 'year_desc':
        items.sort((a, b) => (b.video.release_year || 0) - (a.video.release_year || 0));
        break;
      case 'year_asc':
        items.sort((a, b) => (a.video.release_year || 0) - (b.video.release_year || 0));
        break;
      case 'added_asc':
        items.sort((a, b) => new Date(a.added_at || 0).getTime() - new Date(b.added_at || 0).getTime());
        break;
      case 'added_desc':
      default:
        items.sort((a, b) => new Date(b.added_at || 0).getTime() - new Date(a.added_at || 0).getTime());
        break;
    }

    return items.map(x => x.video);
  }, [allVideos, watchlist]);

  const handlePlay = async (video: Video) => {
    if (video.is_trailer) {
      window.location.href = `/watch/${video.id}`;
      return;
    }

    if (!user) {
      setVideoToPlay(video);
      setShowAuthModal(true);
      return;
    }

    const hasSubscription = await checkSubscription();
    if (!hasSubscription) {
      setVideoToPlay(video);
      setShowSubscriptionModal(true);
      return;
    }

    window.location.href = `/watch/${video.id}`;
  };

  const handleRemove = (videoId: string) => {
    removeFromWatchlist.mutate(videoId);
  };

  const watchlistSet = useMemo(() => 
    new Set(watchlist?.map((w: { video_id: string }) => w.video_id) || []), 
    [watchlist]
  );

  if (!user) {
    return (
      <>
        <Helmet>
          <title>My List | Madifa Films</title>
        </Helmet>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <Heart className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h1 className="text-2xl font-bold mb-2">Sign in to see your list</h1>
            <p className="text-muted-foreground mb-6">
              Create a list of movies and shows you want to watch
            </p>
            <Button onClick={() => setShowAuthModal(true)}>
              Sign In
            </Button>
          </div>
        </div>
        {showAuthModal && (
          <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
        )}
      </>
    );
  }

  if (isLoadingWatchlist || isLoadingVideos) {
    return (
      <>
        <Helmet>
          <title>My List | Madifa Films</title>
        </Helmet>
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center min-h-[calc(100vh-200px)]">
            <div className="flex flex-col items-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
              <p className="text-muted-foreground">Loading your list...</p>
            </div>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>My List | Madifa Films</title>
        <meta name="description" content="Your personal watchlist of saved movies and shows on Madifa Films." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8 gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-2">My List</h1>
            <p className="text-muted-foreground">
              {watchlistVideos.length} {watchlistVideos.length === 1 ? 'title' : 'titles'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[200px]">
                <SelectValue placeholder="Sort" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="added_desc"><div className="flex items-center gap-2"><Clock className="h-4 w-4" /> Recently Added</div></SelectItem>
                <SelectItem value="added_asc"><div className="flex items-center gap-2"><Clock className="h-4 w-4" /> Oldest Added</div></SelectItem>
                <SelectItem value="title_asc"><div className="flex items-center gap-2"><ArrowUpAZ className="h-4 w-4" /> Title A-Z</div></SelectItem>
                <SelectItem value="title_desc"><div className="flex items-center gap-2"><ArrowDownAZ className="h-4 w-4" /> Title Z-A</div></SelectItem>
                <SelectItem value="year_desc"><div className="flex items-center gap-2"><CalendarDays className="h-4 w-4" /> Release Year (Newest)</div></SelectItem>
                <SelectItem value="year_asc"><div className="flex items-center gap-2"><CalendarDays className="h-4 w-4" /> Release Year (Oldest)</div></SelectItem>
              </SelectContent>
            </Select>
            <Link to="/browse">
              <Button variant="outline" className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Browse More
              </Button>
            </Link>
          </div>
        </div>

        {/* Content */}
        {watchlistVideos.length > 0 ? (
          <>
            <UnifiedVideoGrid
              videos={watchlistVideos}
              columns={5}
              onPlay={handlePlay}
              watchlist={watchlistSet}
              onRemoveFromWatchlist={handleRemove}
              className="mb-8"
            />
            
            {/* Tips Section */}
            <div className="bg-card/50 rounded-lg p-6 mt-12">
              <h3 className="text-lg font-semibold mb-2">Quick Tip</h3>
              <p className="text-muted-foreground">
                Add movies and shows to your list by clicking the "+" button on any title. 
                Your list syncs across all your devices.
              </p>
            </div>
          </>
        ) : (
          /* Empty State */
          <div className="text-center py-16">
            <Heart className="h-16 w-16 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-2xl font-bold mb-2">Your list is empty</h2>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Add movies and shows you want to watch by clicking the "+" button when browsing content.
            </p>
            <Link to="/browse">
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Browse Content
              </Button>
            </Link>
          </div>
        )}
      </div>

      {/* Modals */}
      {showAuthModal && (
        <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
      )}

      {showSubscriptionModal && videoToPlay && (
        <SubscriptionModal 
          isOpen={showSubscriptionModal} 
          onClose={() => setShowSubscriptionModal(false)} 
          videoId={videoToPlay.id}
        />
      )}
    </>
  );
} 