import { lazy, Suspense } from 'react';
import { Loader2 } from 'lucide-react';

const AdminDashboard = lazy(() => import("@/components/admin/admin-dashboard").then(module => ({ default: module.AdminDashboard })));
// MainLayout removed - now handled by UnifiedRouter
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";

export default function AdminPage() {
  const { user } = useAuth();

  // Check if user is authenticated
  if (!user) {
    return <Redirect to="/auth" />;
  }

  // For now, we'll allow any authenticated user to access admin
  // In production, you'd check for admin role in user metadata or profiles table
  // Example: if (user.user_metadata?.role !== 'admin') { return <Navigate to="/" replace />; }

  return (
    <>
      <div className="container mx-auto px-4 py-8">
        <Suspense fallback={
          <div className="flex items-center justify-center min-h-96">
            <div className="flex flex-col items-center">
              <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
              <p className="text-muted-foreground">Loading admin dashboard...</p>
            </div>
          </div>
        }>
          <AdminDashboard />
        </Suspense>
      </div>
    </>
  );
}