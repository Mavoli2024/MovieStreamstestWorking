import React from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useWatchlist } from '@/hooks/use-watchlist';
import {  ModernContentGrid  } from '@/components/content/ModernContentGrid';
import {  Button  } from '@/components/ui/button';
import {  Skeleton  } from '@/components/ui/skeleton';
import { useLocation } from 'wouter';
import {  Bookmark, ArrowLeft  } from 'lucide-react';

export default function WatchlistPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { data: watchlistData, isLoading, removeFromWatchlist } = useWatchlist();

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Sign in required</h2>
          <p className="text-muted-foreground mb-8">
            Please sign in to view your watchlist.
          </p>
          <Button onClick={() => navigate('/auth')}>
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-8 w-48 mb-8" />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="aspect-[2/3] w-full rounded-lg" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const watchlist = new Set(watchlistData?.map(item => item.video_id) || []);
  const videos = watchlistData?.map(item => ({
    id: item.video_id,
    title: `Video ${item.video_id}`,
    thumbnail_url: '',
  })) || [];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.history.back()}
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          
          <div className="flex items-center gap-3">
            <Bookmark className="h-6 w-6 text-primary" />
            <h1 className="text-3xl font-bold">My Watchlist</h1>
          </div>
        </div>

        {/* Content */}
        {videos.length > 0 ? (
          <ModernContentGrid
            items={videos}
            variant="grid"
            columns={5}
            onItemClick={(video) => navigate(`/watch/${video.id}`)}
            watchlist={watchlist}
            onRemoveFromWatchlist={(videoId) => removeFromWatchlist.mutate(videoId)}
          />
        ) : (
          <div className="text-center py-16">
            <Bookmark className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2">Your watchlist is empty</h2>
            <p className="text-muted-foreground mb-8">
              Add movies and shows to your watchlist to watch them later.
            </p>
            <Button onClick={() => navigate('/browse')}>
              Browse Content
            </Button>
          </div>
        )}
      </div>
    </div>
  );
} 