import { AdaptiveLayout } from "@/components/layouts/AdaptiveLayout";
import { Helmet } from "react-helmet-async";
import { Link } from "wouter";
import { ArrowLeft, Crown, Check, X, Star, Play, Download, Smartphone, Tv, Laptop, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { useSubscription } from "@/hooks/use-subscription";

export default function PlansPage() {
  const { user } = useAuth();
  const { hasPremiumAccess } = useSubscription();

  return (
    <AdaptiveLayout>
      <Helmet>
        <title>Pricing Plans | Madifa Films</title>
        <meta name="description" content="Choose your Madifa Films subscription plan. Stream premium South African content with flexible pricing options." />
      </Helmet>
      
      <div className="min-h-screen bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-8 max-w-6xl">
          {/* Header */}
          <div className="mb-12 text-center">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 mb-8">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            
            <div className="flex items-center justify-center gap-3 mb-6">
              <Crown className="w-10 h-10 text-primary" />
              <h1 className="text-5xl font-bold">Pricing Plans</h1>
            </div>
            
            <p className="text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
              Choose the perfect plan for your entertainment needs. Stream authentic South African stories with flexible subscription options.
            </p>
          </div>

          {/* Current Status Banner (for logged in users) */}
          {user && (
            <div className={`mb-8 p-4 rounded-lg text-center ${hasPremiumAccess ? 'bg-green-500/20 border border-green-500/50 text-green-300' : 'bg-amber-500/20 border border-amber-500/50 text-amber-300'}`}>
              <div className="flex items-center justify-center gap-2 mb-2">
                <Crown className={`w-5 h-5 ${hasPremiumAccess ? 'text-green-400' : 'text-amber-400'}`} />
                <p className="font-semibold">
                  {hasPremiumAccess ? 'You have Premium Access' : 'You are on the Free Tier'}
                </p>
              </div>
              <p className="text-sm">
                {hasPremiumAccess ? 'Enjoy unlimited streaming of all premium content!' : 'Upgrade to access the full library of premium content.'}
              </p>
            </div>
          )}

          {/* Pricing Cards */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
            {/* Free Tier */}
            <div className="bg-gray-800/50 p-8 rounded-2xl border border-gray-700 relative">
              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-2">Free Tier</h2>
                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-4xl font-bold">R0</span>
                  <span className="text-gray-400">/month</span>
                </div>
                <p className="text-gray-300">Perfect for discovering new content</p>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Access to trailers and previews</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Limited free content</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Browse the full catalog</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Create watchlist</span>
                </li>
                <li className="flex items-center gap-3">
                  <X className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <span className="text-gray-400">Premium content</span>
                </li>
                <li className="flex items-center gap-3">
                  <X className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <span className="text-gray-400">Download for offline viewing</span>
                </li>
                <li className="flex items-center gap-3">
                  <X className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <span className="text-gray-400">HD/4K streaming</span>
                </li>
              </ul>

              <Button 
                variant="outline" 
                className="w-full border-gray-600 text-white hover:bg-gray-700"
                disabled={user && !hasPremiumAccess}
              >
                {user && !hasPremiumAccess ? 'Current Plan' : 'Get Started Free'}
              </Button>
            </div>

            {/* Premium Plan */}
            <div className="bg-gradient-to-br from-primary/20 to-orange-500/20 p-8 rounded-2xl border-2 border-primary relative">
              {/* Popular Badge */}
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <div className="bg-primary text-white px-6 py-2 rounded-full text-sm font-semibold flex items-center gap-2">
                  <Star className="w-4 h-4" />
                  Most Popular
                </div>
              </div>

              <div className="mb-6">
                <h2 className="text-2xl font-bold mb-2">Premium Plan</h2>
                <div className="flex items-baseline gap-2 mb-4">
                  <span className="text-4xl font-bold text-primary">R59</span>
                  <span className="text-gray-400">/month</span>
                </div>
                <p className="text-gray-300">Complete access to all content</p>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span><strong>Everything in Free</strong></span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Unlimited streaming of all premium content</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>HD & 4K video quality</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Download for offline viewing</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Stream on all devices</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>No ads or interruptions</span>
                </li>
                <li className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                  <span>Cancel anytime</span>
                </li>
              </ul>

              {user ? (
                hasPremiumAccess ? (
                  <Button className="w-full bg-green-600 hover:bg-green-700" disabled>
                    <Check className="w-4 h-4 mr-2" />
                    Current Plan
                  </Button>
                ) : (
                  <Link href="/subscription">
                    <Button className="w-full bg-primary hover:bg-primary/90">
                      <Crown className="w-4 h-4 mr-2" />
                      Upgrade to Premium
                    </Button>
                  </Link>
                )
              ) : (
                <Link href="/auth?tab=register">
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    <Crown className="w-4 h-4 mr-2" />
                    Sign Up & Subscribe
                  </Button>
                </Link>
              )}
            </div>
          </div>

          {/* Feature Comparison */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-8">What's Included</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              <div className="text-center">
                <div className="bg-gray-800/50 p-6 rounded-lg mb-4">
                  <Play className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Premium Content</h3>
                  <p className="text-sm text-gray-400">Access to exclusive South African films and series</p>
                </div>
              </div>
              
              <div className="text-center">
                <div className="bg-gray-800/50 p-6 rounded-lg mb-4">
                  <Download className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Offline Downloads</h3>
                  <p className="text-sm text-gray-400">Download content to watch anywhere, anytime</p>
                </div>
              </div>
              
              <div className="text-center">
                <div className="bg-gray-800/50 p-6 rounded-lg mb-4">
                  <Smartphone className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Multi-Device</h3>
                  <p className="text-sm text-gray-400">Watch on phone, tablet, laptop, and smart TV</p>
                </div>
              </div>
              
              <div className="text-center">
                <div className="bg-gray-800/50 p-6 rounded-lg mb-4">
                  <Users className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="font-semibold mb-2">Family Friendly</h3>
                  <p className="text-sm text-gray-400">Multiple user profiles and parental controls</p>
                </div>
              </div>
            </div>
          </div>

          {/* Device Support */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-8">Watch Everywhere</h2>
            <p className="text-center text-gray-300 mb-8 max-w-2xl mx-auto">
              Enjoy your favorite South African content on any device. Start watching on one device and continue on another.
            </p>
            
            <div className="flex justify-center items-center gap-12 flex-wrap">
              <div className="text-center">
                <Smartphone className="w-16 h-16 text-gray-400 mx-auto mb-2" />
                <p className="text-sm">Mobile</p>
              </div>
              <div className="text-center">
                <Laptop className="w-16 h-16 text-gray-400 mx-auto mb-2" />
                <p className="text-sm">Computer</p>
              </div>
              <div className="text-center">
                <Tv className="w-16 h-16 text-gray-400 mx-auto mb-2" />
                <p className="text-sm">Smart TV</p>
              </div>
            </div>
          </div>

          {/* FAQ Section */}
          <div className="mb-16">
            <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              <div className="bg-gray-800/30 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-primary">Can I cancel anytime?</h3>
                <p className="text-gray-300 text-sm">
                  Yes! You can cancel your Premium subscription at any time through your account settings. You'll continue to have access until the end of your billing period.
                </p>
              </div>
              
              <div className="bg-gray-800/30 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-primary">What payment methods do you accept?</h3>
                <p className="text-gray-300 text-sm">
                  We accept all major credit cards, debit cards, and PayFast payments. All transactions are processed securely.
                </p>
              </div>
              
              <div className="bg-gray-800/30 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-primary">How many devices can I use?</h3>
                <p className="text-gray-300 text-sm">
                  With Premium, you can stream on multiple devices and create up to 5 user profiles for your family members.
                </p>
              </div>
              
              <div className="bg-gray-800/30 p-6 rounded-lg">
                <h3 className="font-semibold mb-3 text-primary">Is there a free trial?</h3>
                <p className="text-gray-300 text-sm">
                  Yes! You can always browse our catalog and watch trailers for free. Sign up to start exploring our content library today.
                </p>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="text-center bg-gradient-to-r from-primary/20 to-orange-500/20 p-8 rounded-2xl border border-primary/30">
            <h2 className="text-3xl font-bold mb-4">Ready to Start Streaming?</h2>
            <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
              Join thousands of South Africans enjoying authentic local storytelling. Choose your plan and start watching today.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              {user ? (
                !hasPremiumAccess && (
                  <Link href="/subscription">
                    <Button size="lg" className="bg-primary hover:bg-primary/90 px-8 py-3">
                      <Crown className="w-5 h-5 mr-2" />
                      Upgrade Now
                    </Button>
                  </Link>
                )
              ) : (
                <>
                  <Link href="/auth?tab=register">
                    <Button size="lg" className="bg-primary hover:bg-primary/90 px-8 py-3">
                      Start Free Trial
                    </Button>
                  </Link>
                  <Link href="/auth?tab=login">
                    <Button size="lg" variant="outline" className="px-8 py-3 border-gray-600 text-white hover:bg-gray-700">
                      Sign In
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdaptiveLayout>
  );
}