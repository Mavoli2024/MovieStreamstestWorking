import React, { useEffect, useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useAuthStore } from '@/stores/authStore';
import { useUnifiedNavigation, NavigationHelpers } from '@/components/routing/UnifiedRouter';
import { AdaptiveVideoPlayer } from '@/components/video/AdaptiveVideoPlayer';
import { ModernContentGrid } from '@/components/content/ModernContentGrid';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { apiService } from '@/services/api-service';
import { toast } from 'react-hot-toast';
import { ArrowLeft, Calendar, Clock, Star, Download, Share2, ThumbsUp, MessageSquare } from 'lucide-react';
import { logger } from '@shared/logger';

interface Video {
  id: string;
  title: string;
  description?: string;
  thumbnail_url?: string;
  video_url?: string;
  duration_minutes?: number;
  release_year?: number;
  rating?: number;
  genres?: string[];
  director?: string;
  cast?: string[];
  is_premium?: boolean;
  view_count?: number;
  bunny_video_id?: string;
  bunny_library_id?: string;
}

export default function WatchPage() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { user } = useAuthStore();
  const { navigateToPath } = useUnifiedNavigation();
  const [showAuthModal, setShowAuthModal] = useState(false);

  // Fetch video details
  const { data: video, isLoading, error } = useQuery({
    queryKey: ['video', id],
    queryFn: async () => {
      const response = await apiService.get<Video>(`/videos/${id}`);
      return response.data;
    },
    enabled: !!id,
    retry: 2, // Limit retries to prevent infinite loops
    refetchOnWindowFocus: false, // Don't refetch on window focus for video details
  });

  // Fetch related videos
  const { data: relatedVideos } = useQuery({
    queryKey: ['related-videos', id],
    queryFn: async () => {
      const response = await apiService.get<Video[]>(`/videos/${id}/related`);
      return response.data;
    },
    enabled: !!id,
    retry: 2, // Limit retries to prevent infinite loops
    refetchOnWindowFocus: false, // Don't refetch on window focus for related videos
  });

  // Update view count
  useEffect(() => {
    if (video?.id) {
      apiService.post(`/videos/${video.id}/view`).catch(() => {
        // Silent fail
      });
    }
  }, [video?.id]);

  // Handle video completion
  const handleVideoComplete = () => {
    toast.success('Thanks for watching!');
    
    // Auto-play next video if available
    if (relatedVideos && relatedVideos.length > 0) {
      setTimeout(() => {
        navigate(`/watch/${relatedVideos[0].id}`);
      }, 3000);
    }
  };

  // Handle subscription error
  const handleSubscriptionError = () => {
    if (!user) {
      setShowAuthModal(true);
    } else {
      navigate('/pricing');
    }
  };

  // Handle share
  const handleShare = async () => {
    const url = window.location.href;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: video?.title,
          text: video?.description,
          url,
        });
      } catch (err) {
        // User cancelled or error
      }
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(url);
      toast.success('Link copied to clipboard!');
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="aspect-video w-full max-w-6xl mx-auto rounded-lg" />
          <div className="max-w-6xl mx-auto mt-8 space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (error || !video) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Video not found</h2>
          <p className="text-muted-foreground mb-8">
            The video you're looking for doesn't exist or has been removed.
          </p>
          <Button onClick={() => navigateToPath(NavigationHelpers.goToHome())}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="container mx-auto px-4 py-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => window.history.back()}
            className="mb-2"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
        </div>
      </div>

      {/* Main content */}
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Video player */}
          <div className="mb-8">
            <AdaptiveVideoPlayer
              videoId={video.id}
              bunnyVideoId={video.bunny_video_id}
              bunnyLibraryId={video.bunny_library_id}
              title={video.title}
              thumbnail={video.thumbnail_url}
              isPremium={!!video.is_premium}
              onComplete={handleVideoComplete}
              onError={(error) => {
                logger.error('Video error:', { arg1: error });
                toast.error('Failed to play video');
              }}
              autoplay
            />
          </div>

          {/* Video info */}
          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {/* Title and metadata */}
              <div>
                <h1 className="text-3xl font-bold mb-4">{video.title}</h1>
                
                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-4">
                  {video.release_year && (
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span>{video.release_year}</span>
                    </div>
                  )}
                  
                  {video.duration_minutes && (
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{video.duration_minutes} min</span>
                    </div>
                  )}
                  
                  {video.rating && (
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span>{video.rating.toFixed(1)}</span>
                    </div>
                  )}
                  
                  {video.view_count && (
                    <span>{video.view_count.toLocaleString()} views</span>
                  )}
                </div>

                {/* Genres */}
                {video.genres && video.genres.length > 0 && (
                  <div className="flex flex-wrap gap-2 mb-4">
                    {video.genres.map((genre) => (
                      <Badge key={genre} variant="secondary">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex flex-wrap gap-3">
                  <Button variant="outline" size="sm" onClick={handleShare}>
                    <Share2 className="mr-2 h-4 w-4" />
                    Share
                  </Button>
                  
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Download
                  </Button>
                  
                  <Button variant="outline" size="sm">
                    <ThumbsUp className="mr-2 h-4 w-4" />
                    Like
                  </Button>
                </div>
              </div>

              {/* Description */}
              {video.description && (
                <div>
                  <h2 className="text-xl font-semibold mb-3">About</h2>
                  <p className="text-muted-foreground leading-relaxed">
                    {video.description}
                  </p>
                </div>
              )}

              {/* Cast & Crew */}
              {(video.director || video.cast) && (
                <div>
                  <h2 className="text-xl font-semibold mb-3">Cast & Crew</h2>
                  
                  {video.director && (
                    <p className="mb-2">
                      <span className="font-medium">Director:</span>{' '}
                      <span className="text-muted-foreground">{video.director}</span>
                    </p>
                  )}
                  
                  {video.cast && video.cast.length > 0 && (
                    <p>
                      <span className="font-medium">Cast:</span>{' '}
                      <span className="text-muted-foreground">
                        {video.cast.join(', ')}
                      </span>
                    </p>
                  )}
                </div>
              )}

              {/* Comments section placeholder */}
              <div>
                <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Comments
                </h2>
                <div className="bg-muted/50 rounded-lg p-8 text-center">
                  <p className="text-muted-foreground">
                    Comments are coming soon!
                  </p>
                </div>
              </div>
            </div>

            {/* Sidebar - Related videos */}
            <div className="lg:col-span-1">
              <h2 className="text-xl font-semibold mb-4">More Like This</h2>
              
              {relatedVideos && relatedVideos.length > 0 ? (
                <ModernContentGrid
                  items={relatedVideos}
                  variant="list"
                  columns={2}
                  className="gap-4"
                />
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  No related videos available
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Auth modal */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <div className="bg-background rounded-lg p-6 max-w-md w-full">
            <h3 className="text-xl font-semibold mb-4">Sign in to continue</h3>
            <p className="text-muted-foreground mb-6">
              This content requires a subscription. Please sign in or create an account to continue watching.
            </p>
            <div className="flex gap-3">
              <Button
                className="flex-1"
                onClick={() => navigateToPath(NavigationHelpers.goToAuth())}
              >
                Sign In
              </Button>
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setShowAuthModal(false)}
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
} 