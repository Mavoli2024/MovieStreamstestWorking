import {  AdaptiveLayout  } from "@/components/layouts/AdaptiveLayout";
import {  Helmet  } from "react-helmet-async";
import {  Link  } from "wouter";
import {  ArrowLeft, Shield  } from "lucide-react";
import {  Button  } from "@/components/ui/button";

export default function PrivacyPage() {
  return (
    <AdaptiveLayout>
      <Helmet>
        <title>Privacy Policy | Madifa Films</title>
        <meta name="description" content="Privacy Policy for Madifa Films - How we collect, use, and protect your personal information." />
      </Helmet>
      <div className="min-h-screen bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="flex items-center gap-3 mb-4">
              <Shield className="w-8 h-8 text-primary" />
              <h1 className="text-4xl font-bold">Privacy Policy</h1>
            </div>
            <p className="text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>
          </div>
          <div className="space-y-8">
            <p className="text-gray-300 leading-relaxed">
              At Madifa Films, we respect your privacy and are committed to protecting your personal information. 
              This Privacy Policy explains how we collect, use, and safeguard your data when you use our streaming platform.
            </p>
          </div>
        </div>
      </div>
    </AdaptiveLayout>
  );
}
