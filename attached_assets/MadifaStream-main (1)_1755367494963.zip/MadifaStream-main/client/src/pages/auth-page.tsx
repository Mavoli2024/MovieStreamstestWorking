import { SocialAuthButtons } from "@/components/auth/social-auth-buttons";
import { Logo } from "@/components/logo";
import { Button } from "@/components/ui/button";
import {
    Card,
    CardContent,
    CardDescription,
    CardFooter,
    CardHeader,
    CardTitle,
} from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { 
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle
} from "@/components/ui/dialog";
import {
    Form,
    FormControl,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { FormInput } from "@/components/form/form-input";
import { FormWrapper } from "@/components/form/form-wrapper";
import { useAuthStore } from "@/stores/authStore";
import { zodResolver } from "@hookform/resolvers/zod";
import { Eye, EyeOff } from "lucide-react";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Link, useLocation } from "wouter";
import { z } from "zod";

// Test users for easy login - COMMENTED OUT FOR PRODUCTION
/*
const testUsers = [
  { role: 'Admin', email: 'admin@madifa.com', password: 'password123' },
  { role: 'Premium User', email: 'premium@madifa.com', password: 'password123' },
  { role: 'Normal User', email: 'user@madifa.com', password: 'password123' },
];
*/

// Login form schema
const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required"),
  rememberMe: z.boolean().optional().default(false),
});

// Registration form schema - Remove username field
const registerSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(6, "Please confirm your password"),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"]
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [isLogin, setIsLogin] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { user, login, register, resetPassword, isLoading: authLoading } = useAuthStore();
  const [, _navigate] = useLocation();
  const [isResetModalOpen, setResetModalOpen] = useState(false);
  const [resetEmail, setResetEmail] = useState("");

  // Redirect if user is already logged in
  useEffect(() => {
    if (user) {
      _navigate("/home");
    }
  }, [user, _navigate]);

  // Login form
  const [rememberedEmail, setRememberedEmail] = useState<string>("");
  
  // State for showing/hiding password
  const [showPassword, setShowPassword] = useState(false);
  
  // Check for remembered email
  useEffect(() => {
    const savedEmail = localStorage.getItem('rememberedEmail');
    if (savedEmail) {
      setRememberedEmail(savedEmail);
    }
  }, []);
  
  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: rememberedEmail || "",
      password: "",
      rememberMe: !!rememberedEmail,
    },
  });

  // Registration form - Remove username from defaultValues
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      email: "",
      password: "",
      confirmPassword: "",
    },
    mode: "onChange",
  });

  // Detect ?tab=register or #register in URL on mount
  useEffect(() => {
    try {
      const url = new URL(window.location.href);
      const qpTab = url.searchParams.get('tab');
      const hashTab = url.hash.replace('#', '');
      const initialTab = qpTab || hashTab;
      if (initialTab === 'register') {
        setIsLogin(false);
      }
    } catch {
      // noop (URL parsing not critical)
    }
  }, []);

  // Reset forms when switching between login and register
  useEffect(() => {
    if (isLogin) {
      registerForm.reset({
        email: "",
        password: "",
        confirmPassword: "",
      });
    } else {
      loginForm.reset({
        email: rememberedEmail || "",
        password: "",
        rememberMe: !!rememberedEmail,
      });
    }
  }, [isLogin, registerForm, loginForm, rememberedEmail]);

  // Handle login submission
  const onLoginSubmit = async (data: LoginFormValues) => {
    setIsLoading(true);
    
    // Store email in localStorage if rememberMe is checked
    if (data.rememberMe) {
      localStorage.setItem('rememberedEmail', data.email);
    } else {
      localStorage.removeItem('rememberedEmail');
    }
    
    // Remove rememberMe from data before sending to API
    const { rememberMe, ...loginData } = data;
    
    try {
      await login(loginData.email, loginData.password);
      setIsLoading(false);
      _navigate("/home");
    } catch (error) {
      setIsLoading(false);
      console.error('Login failed:', error);
    }
  };

  // Handle registration submission - Remove username from mutation
  const onRegisterSubmit = async (data: RegisterFormValues) => {
    setIsLoading(true);
    const { confirmPassword, ...userData } = data;
    
    try {
      // Send only email and password - username will be generated on backend
      await register(userData.email, userData.password);
      setIsLoading(false);
      // Navigate to discovery page after successful registration
      _navigate("/home");
    } catch (error) {
      setIsLoading(false);
      console.error('Registration failed:', error);
    }
  };

  const handlePasswordReset = async () => {
    if (!resetEmail) {
      return;
    }
    setIsLoading(true);
    try {
      await resetPassword(resetEmail);
      setResetModalOpen(false);
    } catch {
      // Error is handled by the hook
    } finally {
      setIsLoading(false);
    }
  };

  // Function to handle quick login - COMMENTED OUT FOR PRODUCTION
  /*
  const handleQuickLogin = (user: typeof testUsers[0]) => {
    loginForm.setValue('email', user.email);
    loginForm.setValue('password', user.password);
  };
  */

  return (
    <div 
      className="min-h-screen w-full flex flex-col items-center justify-center p-4 bg-cover bg-center"
      style={{ backgroundImage: "url('/splash-screen.svg')" }}
    >
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
      <div className="relative z-10 w-full max-w-md space-y-6">        <div className="text-center">
          <Link href="/" className="inline-block mb-6">
            <Logo className="h-16 w-auto" />
          </Link>
          <h1 className="text-3xl font-bold text-white">
            {isLogin ? "Welcome Back to Madifa" : "Join Madifa Today"}
          </h1>
          <p className="text-gray-300 mt-2">
            {isLogin ? "Your portal to authentic Mzansi stories." : "Create your account to start streaming."}
          </p>
        </div>

        <Card className="bg-gray-900/80 border border-gray-700 text-white">
          <CardHeader>
            <CardTitle>{isLogin ? "Sign In" : "Create Account"}</CardTitle>
            <CardDescription className="text-gray-400">
              {isLogin ? "Enter your credentials to access your account." : "Fill in your details to get started."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLogin ? (
              <FormWrapper
                onSubmit={loginForm.handleSubmit(onLoginSubmit)}
                size="md"
              >
                <Form {...loginForm}>
                  <div className="space-y-6">
                    <FormInput
                      label="Email"
                      name="email"
                      type="email"
                      placeholder="you@example.com"
                      form={loginForm}
                    />

                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="form-label">Password</FormLabel>
                          <FormControl>
                            <div className="relative">
                              <Input 
                                {...field}
                                type={showPassword ? "text" : "password"} 
                                placeholder="••••••••" 
                                className="form-input"
                              />
                              <Button 
                                type="button" 
                                variant="ghost" 
                                size="icon" 
                                className="absolute right-0 top-0 h-full px-3 py-2 text-gray-400 hover:text-white"
                                onClick={() => setShowPassword(!showPassword)}
                              >
                                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                              </Button>
                            </div>
                          </FormControl>
                          <FormMessage className="form-error" />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex items-center justify-between">
                      <FormField
                        control={loginForm.control}
                        name="rememberMe"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                                id="remember-me"
                                className="h-4 w-4 border-gray-600 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                              />
                            </FormControl>
                            <FormLabel htmlFor="remember-me" className="text-sm font-medium text-gray-300 cursor-pointer">
                              Remember me
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                      <Button 
                        variant="link" 
                        type="button"
                        onClick={() => setResetModalOpen(true)}
                        className="p-0 h-auto text-sm text-primary hover:underline"
                      >
                        Forgot Password?
                      </Button>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full form-button-cta" 
                      disabled={isLoading || authLoading}
                    >
                      {(isLoading || authLoading) ? "Signing in..." : "Sign In"}
                    </Button>
                    
                    <div className="relative my-4">
                      <div className="absolute inset-0 flex items-center">
                        <span className="w-full border-t border-gray-700"></span>
                      </div>
                      <div className="relative flex justify-center text-xs uppercase">
                        <span className="bg-gray-900/60 px-2 text-gray-400">Or continue with</span>
                      </div>
                    </div>
                    <SocialAuthButtons />
                  </div>
                </Form>
              </FormWrapper>
            ) : (
              <FormWrapper
                onSubmit={registerForm.handleSubmit(onRegisterSubmit)}
                size="md"
              >
                <Form {...registerForm} key="register-form">
                  <div className="space-y-4">
                    <FormInput
                      label="Email Address"
                      name="email"
                      type="email"
                      placeholder="you@example.com"
                      form={registerForm}
                    />
                    <FormInput
                      label="Password"
                      name="password"
                      type="password"
                      placeholder="••••••••"
                      form={registerForm}
                      description="Password must be at least 6 characters."
                    />
                    <FormInput
                      label="Confirm Password"
                      name="confirmPassword"
                      type="password"
                      placeholder="••••••••"
                      form={registerForm}
                    />
                  </div>

                  <p className="text-xs text-gray-400 mt-6 px-2 text-center">
                    {isLogin ? (
                      <>
                        Don't have an account?{" "}
                        <Button variant="link" className="p-0 h-auto text-primary" onClick={() => setIsLogin(false)}>
                          Create one
                        </Button>
                      </>
                    ) : (
                      <>
                        Already have an account?{" "}
                        <Button variant="link" className="p-0 h-auto text-primary" onClick={() => setIsLogin(true)}>
                          Sign in
                        </Button>
                      </>
                    )}
                  </p>

                  <Button 
                    type="submit" 
                    className="w-full form-button-cta" 
                    disabled={isLoading || authLoading}
                  >
                    {(isLoading || authLoading) ? "Creating account..." : "Create Account"}
                  </Button>
                </Form>
              </FormWrapper>
            )}
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-sm text-gray-400">
              {isLogin ? (
                <>
                  Don't have an account?{" "}
                  <Button variant="link" className="p-0 h-auto text-primary" onClick={() => setIsLogin(false)}>
                    Create one
                  </Button>
                </>
              ) : (
                <>
                  Already have an account?{" "}
                  <Button variant="link" className="p-0 h-auto text-primary" onClick={() => setIsLogin(true)}>
                    Sign in
                  </Button>
                </>
              )}
            </p>
          </CardFooter>
        </Card>

        {/* Quick Login Buttons - Commented out for production
        <Card className="mt-6 bg-gray-900/60 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Quick Login</CardTitle>
            <CardDescription className="text-gray-400">For development & testing purposes.</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            {testUsers.map((user) => (
              <Button
                key={user.role}
                variant="outline"
                onClick={() => handleQuickLogin(user)}
                className="flex-grow text-white border-gray-600 hover:bg-gray-700 hover:text-white"
              >
                Login as {user.role}
              </Button>
            ))}
          </CardContent>
        </Card>
        */}
      </div>

      {/* Password Reset Modal */}
      <Dialog open={isResetModalOpen} onOpenChange={setResetModalOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 text-white">
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
            <DialogDescription className="text-gray-400">
              Enter your email address and we'll send you a link to reset your password.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <FormLabel htmlFor="reset-email" className="form-label">Email</FormLabel>
              <Input
                id="reset-email"
                type="email"
                placeholder="you@example.com"
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
                className="form-input"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setResetModalOpen(false)} className="border-gray-600 hover:bg-gray-700">Cancel</Button>
            <Button onClick={handlePasswordReset} disabled={isLoading} className="form-button-cta">
              {isLoading ? 'Sending...' : 'Send Reset Link'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
