import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import {  MainLayout  } from "@/components/layouts/MainLayout";
import {  Button  } from "@/components/ui/button";
import {  AlertTriangle, ChevronRight, RotateCcw  } from "lucide-react";

export default function PaymentCancelPage() {
  const [, navigate] = useLocation();
  const [countdown, setCountdown] = useState(10);

  // Auto-redirect after countdown
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          navigate("/home");
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, [navigate]);

  return (
    <>
      <div className="container max-w-3xl mx-auto px-4 py-16">
        <div className="bg-card rounded-lg p-8 shadow-lg">
          <div className="flex flex-col items-center justify-center space-y-6 text-center">
            <div className="w-20 h-20 bg-yellow-500 rounded-full flex items-center justify-center">
              <AlertTriangle className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-3xl font-bold">Payment Cancelled</h1>
            
            <p className="text-lg text-muted-foreground max-w-xl">
              Your payment process was cancelled. No charges have been made to your account.
              You can try again whenever you're ready.
            </p>
            
            <div className="border-t border-border w-full my-4 pt-6">
              <p className="text-muted-foreground mb-4">
                You will be redirected to the home page in {countdown} seconds...
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  onClick={() => navigate("/home")}
                  variant="outline"
                >
                  Go to Home Page <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
                
                <Button 
                  onClick={() => navigate("/subscription")}
                  className="bg-primary hover:bg-red-700"
                >
                  Try Again <RotateCcw className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}