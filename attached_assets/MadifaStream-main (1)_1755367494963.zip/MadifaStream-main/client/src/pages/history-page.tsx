import React from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useQuery } from '@tanstack/react-query';
import { apiService } from '@/services/api-service';
import {  ModernContentGrid  } from '@/components/content/ModernContentGrid';
import {  Button  } from '@/components/ui/button';
import {  Skeleton  } from '@/components/ui/skeleton';
import { useLocation } from 'wouter';
import {  History, ArrowLeft, Trash2  } from 'lucide-react';

export default function HistoryPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();

  const { data: history, isLoading } = useQuery({
    queryKey: ['viewing-history'],
    queryFn: async () => {
      const response = await apiService.get('/user/viewing-history');
      return response.data;
    },
    enabled: !!user,
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Sign in required</h2>
          <p className="text-muted-foreground mb-8">
            Please sign in to view your viewing history.
          </p>
          <Button onClick={() => navigate('/auth')}>
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-8 w-48 mb-8" />
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {Array.from({ length: 10 }).map((_, i) => (
              <div key={i} className="space-y-3">
                <Skeleton className="aspect-[2/3] w-full rounded-lg" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-3 w-1/2" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const videos = history?.map((item: { video_id: string; created_at: string; video: { id: string; title: string; thumbnail_url?: string; duration_minutes?: number; is_premium?: boolean; genres?: string[] } }) => ({
    id: item.video_id,
    title: item.video?.title || `Video ${item.video_id}`,
    thumbnail_url: item.video?.thumbnail_url || '',
    last_watched: item.created_at,
  })) || [];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => window.history.back()}
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            
            <div className="flex items-center gap-3">
              <History className="h-6 w-6 text-primary" />
              <h1 className="text-3xl font-bold">Viewing History</h1>
            </div>
          </div>

          {videos.length > 0 && (
            <Button variant="outline" size="sm">
              <Trash2 className="mr-2 h-4 w-4" />
              Clear History
            </Button>
          )}
        </div>

        {/* Content */}
        {videos.length > 0 ? (
          <ModernContentGrid
            items={videos}
            variant="grid"
            columns={5}
            onItemClick={(video) => navigate(`/watch/${video.id}`)}
          />
        ) : (
          <div className="text-center py-16">
            <History className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-2xl font-semibold mb-2">No viewing history</h2>
            <p className="text-muted-foreground mb-8">
              Your viewing history will appear here as you watch content.
            </p>
            <Button onClick={() => navigate('/browse')}>
              Browse Content
            </Button>
          </div>
        )}
      </div>
    </div>
  );
} 