import {  AdaptiveLayout  } from "@/components/layouts/AdaptiveLayout";
import {  Helmet  } from "react-helmet-async";
import {  Link  } from "wouter";
import {  ArrowLeft, MessageSquare, Mail, Phone, Clock, Send  } from "lucide-react";
import {  Button  } from "@/components/ui/button";
import {  Input  } from "@/components/ui/input";
import {  Textarea  } from "@/components/ui/textarea";
import {  Select, SelectContent, SelectItem, SelectTrigger, SelectValue  } from "@/components/ui/select";
import {  useState  } from "react";

export default function FeedbackPage() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    category: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // For now, just log the form data (in real app, send to backend)
    console.log('Feedback submitted:', formData);
    
    setSubmitStatus('success');
    setIsSubmitting(false);
    
    // Reset form after success
    setTimeout(() => {
      setFormData({ name: '', email: '', subject: '', category: '', message: '' });
      setSubmitStatus('idle');
    }, 3000);
  };

  return (
    <AdaptiveLayout>
      <Helmet>
        <title>Feedback & Contact | Madifa Films</title>
        <meta name="description" content="Contact Madifa Films - Send feedback, get support, or reach out to our team." />
      </Helmet>
      <div className="min-h-screen bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="flex items-center gap-3 mb-4">
              <MessageSquare className="w-8 h-8 text-primary" />
              <h1 className="text-4xl font-bold">Feedback & Contact</h1>
            </div>
            <p className="text-gray-400 leading-relaxed">
              We'd love to hear from you! Share your feedback, report issues, or get in touch with our team.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Contact Information */}
            <div className="lg:col-span-1 space-y-6">
              <div className="bg-gray-800/50 p-6 rounded-lg">
                <h2 className="text-xl font-semibold mb-4 text-primary">Get in Touch</h2>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-primary" />
                    <div>
                      <p className="font-medium">Email Support</p>
                      <a href="mailto:support@madifa.co.za" className="text-gray-300 hover:text-primary transition-colors">
                        support@madifa.co.za
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-primary" />
                    <div>
                      <p className="font-medium">Phone Support</p>
                      <a href="tel:+27111234567" className="text-gray-300 hover:text-primary transition-colors">
                        +27 11 123 4567
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="w-5 h-5 text-primary" />
                    <div>
                      <p className="font-medium">Response Time</p>
                      <p className="text-gray-300">Usually within 24 hours</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-primary/10 to-orange-500/10 p-6 rounded-lg border border-primary/20">
                <h3 className="font-semibold mb-2 text-primary">Quick Help</h3>
                <p className="text-gray-300 text-sm mb-3">
                  For faster support, please include your account email and describe the issue in detail.
                </p>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>• Technical issues with video playback</li>
                  <li>• Billing and subscription questions</li>
                  <li>• Content suggestions and feedback</li>
                  <li>• Accessibility concerns</li>
                </ul>
              </div>
            </div>

            {/* Feedback Form */}
            <div className="lg:col-span-2">
              <div className="bg-gray-800/30 p-6 rounded-lg">
                <h2 className="text-xl font-semibold mb-6">Send Us Your Feedback</h2>
                
                {submitStatus === 'success' && (
                  <div className="bg-green-500/20 border border-green-500/50 text-green-300 p-4 rounded-lg mb-6">
                    <p className="font-medium">Thank you for your feedback!</p>
                    <p className="text-sm">We'll get back to you soon.</p>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-2">
                        Name *
                      </label>
                      <Input
                        id="name"
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                        placeholder="Your full name"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-2">
                        Email *
                      </label>
                      <Input
                        id="email"
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                        placeholder="your@email.com"
                      />
                    </div>
                  </div>

                  <div>
                    <label htmlFor="category" className="block text-sm font-medium text-gray-300 mb-2">
                      Category *
                    </label>
                    <Select value={formData.category} onValueChange={(value) => handleInputChange('category', value)}>
                      <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                        <SelectValue placeholder="Select feedback category" />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-700 border-gray-600">
                        <SelectItem value="technical">Technical Issue</SelectItem>
                        <SelectItem value="billing">Billing & Subscription</SelectItem>
                        <SelectItem value="content">Content Feedback</SelectItem>
                        <SelectItem value="feature">Feature Request</SelectItem>
                        <SelectItem value="accessibility">Accessibility</SelectItem>
                        <SelectItem value="general">General Feedback</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label htmlFor="subject" className="block text-sm font-medium text-gray-300 mb-2">
                      Subject *
                    </label>
                    <Input
                      id="subject"
                      type="text"
                      required
                      value={formData.subject}
                      onChange={(e) => handleInputChange('subject', e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400"
                      placeholder="Brief description of your feedback"
                    />
                  </div>

                  <div>
                    <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-2">
                      Message *
                    </label>
                    <Textarea
                      id="message"
                      required
                      value={formData.message}
                      onChange={(e) => handleInputChange('message', e.target.value)}
                      className="bg-gray-700 border-gray-600 text-white placeholder:text-gray-400 min-h-[120px]"
                      placeholder="Please provide detailed feedback. Include any relevant information such as device type, browser, or specific steps that led to an issue."
                    />
                  </div>

                  <Button 
                    type="submit" 
                    disabled={isSubmitting || !formData.name || !formData.email || !formData.category || !formData.subject || !formData.message}
                    className="w-full bg-primary hover:bg-primary/90 disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></span>
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Send Feedback
                      </>
                    )}
                  </Button>
                </form>

                <div className="mt-6 pt-6 border-t border-gray-700">
                  <p className="text-sm text-gray-400">
                    By submitting this form, you agree that we may contact you regarding your feedback. 
                    We respect your privacy and will not share your information with third parties.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdaptiveLayout>
  );
}
