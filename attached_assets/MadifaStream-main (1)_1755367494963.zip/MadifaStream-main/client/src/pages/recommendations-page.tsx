import React, { useState, useMemo } from 'react';
import { useRecommendations } from '../hooks/use-recommendations';
import {  UnifiedVideoCarousel  } from '@/components/video/unified-video-displays';
import { useWatchlist } from '@/hooks/use-watchlist';
import { useAuth } from '@/hooks/use-auth';
import {  Skeleton  } from '../components/ui/skeleton';
import {  Alert, AlertDescription  } from '../components/ui/alert';
import {  TrendingUp, Sparkles, Heart, Clock, Zap  } from 'lucide-react';
import {  AuthModal  } from '@/components/auth-modal';
import {  SubscriptionModal  } from '@/components/subscription-modal';
import {  MainLayout  } from '@/components/layouts/MainLayout';
import { useLocation } from 'wouter';
import type { Database } from '@/types/database-generated.types';

type Video = Database['public']['Tables']['videos']['Row'];

export const RecommendationsPage: React.FC = () => {
  const { user, checkSubscription } = useAuth();
  const [, navigate] = useLocation();
  const { watchlist, addToWatchlist, removeFromWatchlist } = useWatchlist();
  
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [videoToPlay, setVideoToPlay] = useState<Video | null>(null);

  const {
    recommendations,
    trending,
    isLoadingRecommendations,
    isLoadingTrending,
    recommendationsError,
    getRecommendationsByCategory,
    recordInteraction
  } = useRecommendations();

  const recommendationCategories = getRecommendationsByCategory();

  // Convert watchlist to Set for performance
  const watchlistSet = useMemo(() => 
    new Set(watchlist?.map((w: { video_id: string }) => w.video_id) || []), 
    [watchlist]
  );

  const handlePlay = async (video: Video) => {
    recordInteraction(video.id, 'play', 'recommendations_page');
    
    if (video.is_trailer) {
      navigate(`/watch/${video.id}`);
      return;
    }

    if (!user) {
      setVideoToPlay(video);
      setShowAuthModal(true);
      return;
    }

    const hasSubscription = await checkSubscription();
    if (!hasSubscription) {
      setVideoToPlay(video);
      setShowSubscriptionModal(true);
      return;
    }

    navigate(`/watch/${video.id}`);
  };

  const handleAddToWatchlist = (videoId: string) => {
    addToWatchlist.mutate(videoId);
  };

  const handleRemoveFromWatchlist = (videoId: string) => {
    removeFromWatchlist.mutate(videoId);
  };

  const handleInfo = (video: Video) => {
    recordInteraction(video.id, 'view', 'recommendations_page');
    navigate(`/watch/${video.id}`);
  };

  return (
    <>
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="w-8 h-8 text-yellow-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
              Recommendations
            </h1>
          </div>
          <p className="text-gray-400 text-lg">
            Discover content tailored just for you
          </p>
        </div>

        {/* Error State */}
        {recommendationsError && (
          <Alert className="mb-6 border-red-800 bg-red-900/20">
            <AlertDescription className="text-red-400">
              Unable to load personalized recommendations. Please try again later.
            </AlertDescription>
          </Alert>
        )}

        {/* Trending Section */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <TrendingUp className="w-6 h-6 text-red-500" />
            <h2 className="text-2xl font-semibold">Trending Now</h2>
            <span className="text-sm text-gray-400 bg-red-900/30 px-2 py-1 rounded-full">
              Last 7 days
            </span>
          </div>
          
          {isLoadingTrending ? (
            <div className="flex gap-4 overflow-hidden">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="w-64 h-36 bg-gray-800 rounded-lg flex-shrink-0" />
              ))}
            </div>
                     ) : trending.length > 0 ? (
            <UnifiedVideoCarousel
              title=""
               videos={trending}
              watchlist={watchlistSet}
              onPlay={handlePlay}
              onAddToWatchlist={handleAddToWatchlist}
              onRemoveFromWatchlist={handleRemoveFromWatchlist}
              onInfo={handleInfo}
              showSeeMore={false}
              className="mb-8"
             />
          ) : (
            <div className="text-center py-12 text-gray-400">
              <TrendingUp className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No trending content available</p>
            </div>
          )}
        </div>

        {/* Personalized Recommendations */}
        {isLoadingRecommendations ? (
          <div className="space-y-8">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i}>
                <Skeleton className="w-48 h-8 bg-gray-800 mb-4" />
                <div className="flex gap-4 overflow-hidden">
                  {Array.from({ length: 6 }).map((_, j) => (
                    <Skeleton key={j} className="w-64 h-36 bg-gray-800 rounded-lg flex-shrink-0" />
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : Object.keys(recommendationCategories).length > 0 ? (
          <div className="space-y-12">
            {Object.entries(recommendationCategories).map(([categoryName, videos]) => {
              let icon;
              let colorClass = "text-blue-400";

              switch (categoryName) {
                case 'For You':
                  icon = <Heart className="w-6 h-6" />;
                  colorClass = "text-pink-400";
                  break;
                case 'Similar to What You Watched':
                  icon = <Zap className="w-6 h-6" />;
                  colorClass = "text-purple-400";
                  break;
                case 'Popular Picks':
                  icon = <TrendingUp className="w-6 h-6" />;
                  colorClass = "text-orange-400";
                  break;
                case 'New Releases':
                  icon = <Clock className="w-6 h-6" />;
                  colorClass = "text-green-400";
                  break;
                default:
                  icon = <Sparkles className="w-6 h-6" />;
              }

              return (
                <div key={categoryName}>
                  <div className="flex items-center gap-3 mb-6">
                    <span className={colorClass}>{icon}</span>
                    <h2 className="text-2xl font-semibold">{categoryName}</h2>
                    <span className="text-sm text-gray-400 bg-gray-800 px-2 py-1 rounded-full">
                      {videos.length} videos
                    </span>
                  </div>
                  
                  <UnifiedVideoCarousel
                    title=""
                     videos={videos}
                    watchlist={watchlistSet}
                    onPlay={handlePlay}
                    onAddToWatchlist={handleAddToWatchlist}
                    onRemoveFromWatchlist={handleRemoveFromWatchlist}
                    onInfo={handleInfo}
                    showSeeMore={false}
                    className="mb-8"
                   />
                  
                  {/* Show recommendation reasons for first few videos */}
                  {videos.slice(0, 3).some(v => v.reason) && (
                    <div className="mt-4 flex flex-wrap gap-2">
                      {videos.slice(0, 3).map((video, index) => (
                        video.reason && (
                          <span
                            key={index}
                            className="text-xs text-gray-400 bg-gray-800/50 px-2 py-1 rounded-full"
                          >
                            {video.title}: {video.reason}
                          </span>
                        )
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16">
            <Sparkles className="w-16 h-16 mx-auto mb-6 text-gray-600" />
            <h3 className="text-xl font-semibold mb-2">Building Your Recommendations</h3>
            <p className="text-gray-400 max-w-md mx-auto">
              Watch a few videos to help us understand your preferences and create personalized recommendations.
            </p>
            <button
              onClick={() => navigate('/discover')}
              className="mt-6 px-6 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors"
            >
              Start Watching
            </button>
          </div>
        )}

        {/* Algorithm Info */}
        <div className="mt-16 p-6 bg-gray-900/50 rounded-lg border border-gray-800">
          <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
            <Zap className="w-5 h-5 text-yellow-400" />
            How We Recommend
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-300">
            <div>
              <h4 className="font-medium text-white mb-2">Your Viewing History</h4>
              <p>We analyze what you watch, how much you watch, and what you enjoy to understand your preferences.</p>
            </div>
            <div>
              <h4 className="font-medium text-white mb-2">Content Similarity</h4>
              <p>We find videos with similar genres, directors, cast, and themes to content you've enjoyed.</p>
            </div>
            <div>
              <h4 className="font-medium text-white mb-2">Community Trends</h4>
              <p>We consider what's popular and trending among users with similar tastes.</p>
            </div>
          </div>
        </div>
      </div>

      {/* Modals */}
      {showAuthModal && (
        <AuthModal 
          isOpen={showAuthModal} 
          onClose={() => setShowAuthModal(false)} 
        />
      )}

      {showSubscriptionModal && videoToPlay && (
        <SubscriptionModal 
          isOpen={showSubscriptionModal} 
          onClose={() => setShowSubscriptionModal(false)} 
          videoId={videoToPlay.id}
        />
      )}
    </>
  );
}; 