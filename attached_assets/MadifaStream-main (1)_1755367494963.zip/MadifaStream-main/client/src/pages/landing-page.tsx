/**
 * Landing Page - Rich Streaming Platform Experience
 * 
 * Professional landing page with:
 * - Hero section with featured content
 * - Category-based content sections
 * - Smooth animations and transitions
 * - Public access content showcase
 * - Mobile-first responsive design
 */

import { useVideos } from "@/hooks/use-videos";
import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { Helmet } from "react-helmet-async";
import { PublicLayout } from "@/components/layouts/PublicLayout";
import { Button } from "@/components/ui/button";
import { ThumbnailImage } from '@/components/ui/thumbnail-image';
import { VideoGridCard } from '@/components/video/unified-video-card';
import { Clock, Play, Star } from 'lucide-react';
import { useMemo, useEffect } from "react";
import type { Database } from "@/types/database-generated.types";

type Video = Database['public']['Tables']['videos']['Row'];

// Landing Page Video Showcase Component (trailers only, no login required)
const LandingVideoShowcase = ({ videos }: { videos: Video[] }) => {
  const [, navigate] = useLocation();
  
  const handleVideoClick = (video: Video) => {
    if (video.is_trailer) {
      // Allow trailers to be played without login
      navigate(`/watch/${video.id}`);
    } else {
      // Redirect to signup for full movies
      navigate('/auth?tab=register');
    }
  };

  if (!videos.length) return null;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {videos.slice(0, 6).map((video) => (
        <VideoGridCard
          key={video.id}
          video={video}
          onPlay={handleVideoClick}
          imagePriority={false}
          showProgress={false}
          showViews={false}
        />
      ))}
    </div>
  );
};

export default function LandingPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { data: videosData, isLoading: isLoadingVideos } = useVideos();

  // Redirect authenticated users to home
  useEffect(() => {
    if (user) {
      navigate("/home");
    }
  }, [user, navigate]);

  const allVideos = Array.isArray(videosData) ? videosData : [];
  
  // For landing page, prioritize trailers and public content
  const showcaseVideos = useMemo(() => {
    const trailers = allVideos.filter(v => v.is_trailer);
    const nonPremiumMovies = allVideos.filter(v => !v.is_trailer && !v.is_premium);
    
    // Mix trailers and free content for showcase
    return [...trailers, ...nonPremiumMovies].slice(0, 12);
  }, [allVideos]);

  const featuredTrailers = showcaseVideos.filter(v => v.is_trailer).slice(0, 6);
  const sampleMovies = showcaseVideos.filter(v => !v.is_trailer).slice(0, 6);

  return (
    <PublicLayout>
      <Helmet>
        <title>Madifa Films | Stream Local Stories</title>
        <meta name="description" content="Stream the best South African movies and series on Madifa Films." />
      </Helmet>
      
      {/* Hero Section - Full bleed and full screen */}
      <section 
        className="relative flex items-center justify-center h-screen text-center bg-cover bg-center pt-24 md:pt-16" 
        style={{ backgroundImage: "url('/splash-screen.svg')" }}
      >
        <div className="absolute inset-0 bg-black/60"></div>
        <div className="relative z-10 px-4 max-w-5xl mx-auto">
          <h2 className="text-4xl md:text-6xl font-extrabold tracking-tight bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 bg-clip-text text-transparent">
            Authentic Mzansi Stories
          </h2>
          <p className="mt-4 text-lg md:text-xl text-gray-300 max-w-3xl mx-auto">
            Experience powerful Mzansi storytelling with exclusive South African films like uMantolwana, Ulwaluko, and Royal uMkhonto.
          </p>
          <div className="mt-10">
            <Link to="/auth?tab=register">
              <Button size="lg" className="cta-button px-10 py-6 text-xl font-bold transition-all duration-300 transform hover:scale-105 shadow-lg">
                Sign Up & Start Watching
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Content Preview Sections */}
      {!isLoadingVideos && showcaseVideos.length > 0 && (
        <section className="py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            {/* Featured Trailers */}
            {featuredTrailers.length > 0 && (
              <div className="mb-16">
                <div className="text-center mb-8">
                  <h3 className="text-3xl font-bold mb-2">Get a Taste of Our Stories</h3>
                  <p className="text-gray-400">Watch these trailers and see what awaits you</p>
                </div>
                <LandingVideoShowcase videos={featuredTrailers} />
                <div className="text-center mt-8">
                  <Link to="/auth?tab=register">
                    <Button variant="outline" size="lg" className="border-primary text-primary hover:bg-primary hover:text-white transition-all duration-300">
                      Sign Up to Watch Full Movies
                    </Button>
                  </Link>
                </div>
              </div>
            )}

            {/* Sample Movies Preview */}
            {sampleMovies.length > 0 && (
              <div className="mb-16">
                <div className="text-center mb-8">
                  <h3 className="text-3xl font-bold mb-2">Award-Winning South African Cinema</h3>
                  <p className="text-gray-400">Join thousands enjoying authentic Mzansi storytelling</p>
                </div>
                <LandingVideoShowcase videos={sampleMovies} />
                <div className="text-center mt-8">
                  <div className="bg-gradient-to-r from-primary/20 to-secondary/20 rounded-lg p-6 max-w-md mx-auto">
                    <Star className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-300">
                      Over <strong className="text-white">500+ hours</strong> of premium South African content
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      )}

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-900">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-4xl font-bold mb-2">Why Madifa?</h3>
          <p className="text-lg text-gray-400 mb-12">Everything you need for the ultimate local streaming experience.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="bg-gray-800 p-8 rounded-xl transform hover:-translate-y-2 transition-transform">
              <h4 className="text-2xl font-semibold text-primary mb-4">Exclusive Content</h4>
              <p className="text-gray-300">A curated library of the best South African films and series you won't find anywhere else.</p>
            </div>
            <div className="bg-gray-800 p-8 rounded-xl transform hover:-translate-y-2 transition-transform">
              <h4 className="text-2xl font-semibold text-primary mb-4">Watch Anywhere</h4>
              <p className="text-gray-300">Stream on your phone, tablet, laptop, and TV without any extra cost.</p>
            </div>
            <div className="bg-gray-800 p-8 rounded-xl transform hover:-translate-y-2 transition-transform">
              <h4 className="text-2xl font-semibold text-primary mb-4">Family Friendly</h4>
              <p className="text-gray-300">Create profiles for everyone in the family, with parental controls coming soon.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 bg-gray-800">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-4xl font-bold mb-2">Simple, Affordable Pricing</h3>
          <p className="text-lg text-gray-400 mb-12">One plan. Everything included. Cancel anytime.</p>
          <div className="inline-block bg-gray-700 p-10 rounded-2xl shadow-2xl border border-primary/20">
            <h4 className="text-3xl font-bold text-primary">Premium Plan</h4>
            <p className="text-5xl font-extrabold my-6">
              R59<span className="text-2xl text-gray-400">/month</span>
            </p>
            <ul className="space-y-4 text-lg text-gray-300 text-left">
              <li className="flex items-center"><svg className="w-6 h-6 text-green-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>Unlimited Streaming</li>
              <li className="flex items-center"><svg className="w-6 h-6 text-green-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>Access to all Premium Content</li>
              <li className="flex items-center"><svg className="w-6 h-6 text-green-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>High-Definition Quality</li>
              <li className="flex items-center"><svg className="w-6 h-6 text-green-500 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>Cancel Anytime</li>
            </ul>
            <Link to="/auth">
              <Button size="lg" className="cta-button mt-10 w-full font-bold text-lg transition-all duration-300">
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-900">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <h3 className="text-4xl font-bold mb-4">About Madifa</h3>
          <p className="text-lg text-gray-300">
            Madifa is a streaming service dedicated to celebrating and showcasing the rich tapestry of South African storytelling. Our mission is to provide a platform for local creators to share their voices and for audiences to discover the incredible talent that our country has to offer. We are proudly South African, for South Africans.
          </p>
        </div>
      </section>
    </PublicLayout>
  );
}