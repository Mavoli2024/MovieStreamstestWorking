/**
 * Modern Home Page
 * 
 * Professional streaming platform home page with:
 * - Hero section with featured content
 * - Category-based content sections
 * - Smooth animations and transitions
 * - Reliable data fetching
 * - Mobile-first responsive design
 */

import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import { useVideos } from '@/hooks/use-videos';
import { ModernContentGrid } from '@/components/content/ModernContentGrid';
import { ModernVideoPlayer } from '@/components/video/ModernVideoPlayer';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { useAuth } from '@/hooks/use-auth';
import { useWatchlist } from '@/hooks/use-watchlist';
import { 
  Play, 
  Star, 
  Clock, 
  TrendingUp, 
  Bookmark,
  ChevronRight,
  Sparkles,
  Crown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'react-hot-toast';

// Types
interface Video {
  id: string;
  title: string;
  description?: string;
  thumbnail_url?: string;
  duration?: number;
  release_year?: number;
  rating?: number;
  views?: number;
  is_premium?: boolean;
  genres?: string[];
  is_trailer?: boolean;
}

interface Category {
  id: string;
  name: string;
  description?: string;
  video_count?: number;
}

export function ModernHomePage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { data: watchlistData, addToWatchlist, removeFromWatchlist } = useWatchlist();
  
  // Convert watchlist array to Set for compatibility
  const watchlist = new Set(watchlistData?.map(item => item.video_id) || []);
  
  const [currentFeaturedIndex, setCurrentFeaturedIndex] = useState(0);
  const [isPlayingTrailer, setIsPlayingTrailer] = useState(false);

  // Fetch videos using the working hook with error handling
  const { data: videosData, isLoading: videosLoading, error: videosError } = useVideos();
  const allVideos = videosData || [];

  // Debug logging
  React.useEffect(() => {
    console.log('Home page state:', {
      videosLoading,
      videosError,
      videosDataLength: videosData?.length,
      allVideosLength: allVideos.length,
      sampleTitles: allVideos.slice(0, 3).map(v => ({ id: v.id, title: v.title, titleLength: v.title?.length }))
    });
  }, [videosLoading, videosError, videosData, allVideos]);

  // Create categories from video genres instead of using API
  const categoriesData = React.useMemo(() => {
    if (!allVideos.length) {
      return [
        { id: '1', name: 'Drama', description: 'Dramatic content' },
        { id: '2', name: 'Action', description: 'Action-packed content' },
        { id: '3', name: 'Comedy', description: 'Comedy content' },
        { id: '4', name: 'Documentary', description: 'Documentary content' }
      ];
    }
    
    // Extract unique genres from videos
    const genreSet = new Set<string>();
    allVideos.forEach(video => {
      if (video.genres && Array.isArray(video.genres)) {
        video.genres.forEach(genre => {
          if (genre && typeof genre === 'string') {
            genreSet.add(genre.trim());
          }
        });
      }
    });
    
    // Convert to category objects
    return Array.from(genreSet).map((genre, index) => ({
      id: String(index + 1),
      name: genre,
      description: `${genre} content`
    }));
  }, [allVideos]);

  // Create featured content from videos
  const featuredContent = React.useMemo(() => {
    if (!allVideos.length) return [];
    
    // Prioritize premium movies and popular trailers for featured content
    const premiumMovies = allVideos.filter(v => !v.is_trailer && v.is_premium);
    const popularTrailers = allVideos.filter(v => v.is_trailer).sort((a, b) => (b.views || 0) - (a.views || 0));
    
    return [...premiumMovies, ...popularTrailers].slice(0, 5);
  }, [allVideos]);

  // Auto-rotate featured content
  useEffect(() => {
    if (!featuredContent || featuredContent.length <= 1) return;

    const interval = setInterval(() => {
      setCurrentFeaturedIndex(prev => 
        prev === featuredContent.length - 1 ? 0 : prev + 1
      );
    }, 8000);

    return () => clearInterval(interval);
  }, [featuredContent]);

  const currentFeatured = featuredContent?.[currentFeaturedIndex];

  // Handle play trailer
  const handlePlayTrailer = () => {
    if (!currentFeatured) return;
    
    // Check if user has access to premium content
    if (currentFeatured.is_premium && !user) {
      toast.error('Premium subscription required');
      navigate('/pricing');
      return;
    }

    setIsPlayingTrailer(true);
  };

  // Handle watchlist toggle
  const handleWatchlistToggle = (videoId: string) => {
    if (!user) {
      toast.error('Please sign in to add to watchlist');
      navigate('/auth');
      return;
    }

    if (watchlist.has(videoId)) {
      removeFromWatchlist.mutate(videoId);
    } else {
      addToWatchlist.mutate(videoId);
    }
  };

  // Handle content click
  const handleContentClick = (video: Video) => {
    navigate(`/watch/${video.id}`);
  };

  // Error state - only show if we have a real error AND no data
  if (videosError && (!videosData || videosData.length === 0)) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4 p-8">
          <div className="text-6xl mb-4">😕</div>
          <h1 className="text-3xl font-bold text-foreground">Unable to Load Content</h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            We're having trouble loading videos right now. Please check your connection and try again.
          </p>
          <div className="space-y-2">
            <Button onClick={() => window.location.reload()} className="mr-2">
              Try Again
            </Button>
            <Button variant="outline" onClick={() => navigate('/browse')}>
              Browse Offline Content
            </Button>
          </div>
          <details className="mt-4 text-left max-w-md mx-auto">
            <summary className="cursor-pointer text-sm text-muted-foreground">Technical Details</summary>
            <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-auto">
              {JSON.stringify(videosError, null, 2)}
            </pre>
          </details>
        </div>
      </div>
    );
  }

  // Loading state with skeleton
  if (videosLoading && !allVideos.length) {
    return (
      <div className="min-h-screen bg-background">
        {/* Skeleton Hero */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-black via-gray-900 to-black animate-pulse" />
          <div className="relative z-10 container mx-auto px-4">
            <div className="max-w-2xl space-y-4">
              <Skeleton className="h-8 w-24" />
              <Skeleton className="h-16 w-3/4" />
              <Skeleton className="h-24 w-full" />
              <div className="flex gap-4">
                <Skeleton className="h-12 w-32" />
                <Skeleton className="h-12 w-32" />
              </div>
            </div>
          </div>
        </section>
        
        {/* Skeleton Content Grid */}
        <section className="py-16 bg-gray-900">
          <div className="container mx-auto px-4">
            <div className="mb-8">
              <Skeleton className="h-8 w-48 mb-4" />
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
                {[...Array(12)].map((_, i) => (
                  <div key={i} className="space-y-2">
                    <Skeleton className="aspect-video rounded" />
                    <Skeleton className="h-4 w-3/4" />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }

  // Empty state - no videos available
  if (!videosLoading && allVideos.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4 p-8">
          <div className="text-6xl mb-4">📺</div>
          <h1 className="text-3xl font-bold text-foreground">No Content Available</h1>
          <p className="text-muted-foreground max-w-md mx-auto">
            We're currently updating our library. Please check back soon for amazing South African content!
          </p>
          <div className="space-y-2">
            <Button onClick={() => window.location.reload()}>
              Refresh Page
            </Button>
            <Button variant="outline" onClick={() => navigate('/browse')} className="ml-2">
              Browse Categories
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {currentFeatured && (
          <>
            {/* Background */}
            <div className="absolute inset-0">
              {currentFeatured.thumbnail_url && (
                <img
                  src={currentFeatured.thumbnail_url}
                  alt={currentFeatured.title}
                  className="w-full h-full object-cover"
                />
              )}
              <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/50 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            </div>

            {/* Video Player Overlay */}
            <AnimatePresence>
              {isPlayingTrailer && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 z-50"
                >
                  <ModernVideoPlayer
                    videoId={currentFeatured.id}
                    title={currentFeatured.title}
                    thumbnail={currentFeatured.thumbnail_url}
                    onComplete={() => setIsPlayingTrailer(false)}
                    autoplay
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Hero Content */}
            <div className="relative z-10 container mx-auto px-4 text-white">
              <div className="max-w-2xl">
                <motion.div
                  key={currentFeatured.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                >
                  <div className="flex items-center gap-3 mb-4">
                    <Badge variant="secondary" className="bg-primary/20 text-primary border-primary/30">
                      {currentFeatured.is_premium ? 'Premium' : 'Free'}
                    </Badge>
                    {currentFeatured.is_trailer && (
                      <Badge variant="outline" className="border-white/30 text-white">
                        Trailer
                      </Badge>
                    )}
                  </div>

                  <h1 className="text-4xl md:text-6xl font-bold mb-4 leading-tight">
                    {currentFeatured.title}
                  </h1>

                  <p className="text-lg md:text-xl text-gray-300 mb-6 leading-relaxed">
                    {currentFeatured.description || `Experience the power of South African storytelling with ${currentFeatured.title}.`}
                  </p>

                  <div className="flex items-center gap-4 mb-8">
                    {currentFeatured.release_year && (
                      <span className="text-gray-400">{currentFeatured.release_year}</span>
                    )}
                    {currentFeatured.duration && (
                      <div className="flex items-center gap-1 text-gray-400">
                        <Clock className="w-4 h-4" />
                        <span>{Math.floor(currentFeatured.duration / 60)}h {currentFeatured.duration % 60}m</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-4">
                    <Button
                      onClick={handlePlayTrailer}
                      size="lg"
                      className="bg-white text-black hover:bg-gray-200 font-semibold px-8"
                    >
                      <Play className="w-5 h-5 mr-2" fill="currentColor" />
                      {currentFeatured.is_trailer ? 'Watch Trailer' : 'Play Now'}
                    </Button>

                    <Button
                      onClick={() => handleWatchlistToggle(currentFeatured.id)}
                      variant="outline"
                      size="lg"
                      className="border-white/30 text-white hover:bg-white/10"
                    >
                      <Bookmark className={cn("w-5 h-5 mr-2", watchlist.has(currentFeatured.id) && "fill-current")} />
                      {watchlist.has(currentFeatured.id) ? 'Remove' : 'My List'}
                    </Button>
                  </div>
                </motion.div>
              </div>
            </div>

            {/* Featured Content Indicators */}
            {featuredContent.length > 1 && (
              <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
                <div className="flex gap-2">
                  {featuredContent.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentFeaturedIndex(index)}
                      className={cn(
                        "w-3 h-3 rounded-full transition-all",
                        index === currentFeaturedIndex ? "bg-white" : "bg-white/40"
                      )}
                    />
                  ))}
                </div>
              </div>
            )}
          </>
        )}

        {/* Fallback when no featured content */}
        {!currentFeatured && !videosLoading && (
          <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
            <div className="text-center text-white z-10">
              <h1 className="text-4xl md:text-6xl font-bold mb-4">Welcome to MadifaStream</h1>
              <p className="text-xl mb-8">Premium South African Entertainment</p>
              <Button
                onClick={() => navigate('/browse')}
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90"
              >
                Browse Content
              </Button>
            </div>
          </div>
        )}
      </section>

      {/* Content Sections */}
      <section className="py-16 bg-gray-900">
        <div className="container mx-auto px-4">
          {/* All Videos Section */}
          {allVideos.length > 0 && (
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-6">
                <TrendingUp className="w-6 h-6 text-primary" />
                <h2 className="text-2xl font-bold text-white">All Content</h2>
                <Badge variant="secondary" className="bg-primary/20 text-primary">
                  {allVideos.length} videos
                </Badge>
              </div>
              
              <ModernContentGrid
                items={allVideos}
                variant="grid"
                columns={6}
                onItemClick={handleContentClick}
                onAddToWatchlist={(videoId) => handleWatchlistToggle(videoId)}
                onRemoveFromWatchlist={(videoId) => handleWatchlistToggle(videoId)}
                watchlist={watchlist}
              />
            </div>
          )}

          {/* Categories Section */}
          {categoriesData?.map((category) => {
            const categoryVideos = allVideos.filter(video => 
              video.genres?.includes(category.name) || 
              (category.name === 'Drama' && video.genres?.includes('Drama'))
            );
            
            if (categoryVideos.length === 0) return null;

            return (
              <div key={category.id} className="mb-12">
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-3">
                    <h2 className="text-2xl font-bold text-white">{category.name}</h2>
                    <Badge variant="secondary" className="bg-primary/20 text-primary">
                      {categoryVideos.length} videos
                    </Badge>
                  </div>
                  <Button
                    variant="ghost"
                    className="text-primary hover:text-primary/80"
                    onClick={() => navigate(`/browse?category=${category.name}`)}
                  >
                    View All
                    <ChevronRight className="w-4 h-4 ml-1" />
                  </Button>
                </div>
                
                <ModernContentGrid
                  items={categoryVideos.slice(0, 12)}
                  variant="carousel"
                  columns={6}
                  onItemClick={handleContentClick}
                  onAddToWatchlist={(videoId) => handleWatchlistToggle(videoId)}
                  onRemoveFromWatchlist={(videoId) => handleWatchlistToggle(videoId)}
                  watchlist={watchlist}
                />
              </div>
            );
          })}

          {/* Premium Content Section */}
          {allVideos.filter(v => v.is_premium).length > 0 && (
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-6">
                <Crown className="w-6 h-6 text-yellow-400" />
                <h2 className="text-2xl font-bold text-white">Premium Content</h2>
                <Badge variant="secondary" className="bg-yellow-400/20 text-yellow-400">
                  Exclusive
                </Badge>
              </div>
              
              <ModernContentGrid
                items={allVideos.filter(v => v.is_premium)}
                variant="carousel"
                columns={5}
                onItemClick={handleContentClick}
                onAddToWatchlist={(videoId) => handleWatchlistToggle(videoId)}
                onRemoveFromWatchlist={(videoId) => handleWatchlistToggle(videoId)}
                watchlist={watchlist}
              />
            </div>
          )}

          {/* Trailers Section */}
          {allVideos.filter(v => v.is_trailer).length > 0 && (
            <div className="mb-12">
              <div className="flex items-center gap-3 mb-6">
                <Sparkles className="w-6 h-6 text-primary" />
                <h2 className="text-2xl font-bold text-white">Trailers & Previews</h2>
                <Badge variant="secondary" className="bg-primary/20 text-primary">
                  Free to watch
                </Badge>
              </div>
              
              <ModernContentGrid
                items={allVideos.filter(v => v.is_trailer)}
                variant="carousel"
                columns={6}
                onItemClick={handleContentClick}
                onAddToWatchlist={(videoId) => handleWatchlistToggle(videoId)}
                onRemoveFromWatchlist={(videoId) => handleWatchlistToggle(videoId)}
                watchlist={watchlist}
              />
            </div>
          )}
        </div>
      </section>
    </div>
  );
} 