import {  AdaptiveLayout  } from "@/components/layouts/AdaptiveLayout";
import {  Helmet  } from "react-helmet-async";
import {  Link  } from "wouter";
import {  ArrowLeft, Accessibility  } from "lucide-react";
import {  Button  } from "@/components/ui/button";

export default function AccessibilityPage() {
  return (
    <AdaptiveLayout>
      <Helmet>
        <title>Accessibility Statement | Madifa Films</title>
        <meta name="description" content="Accessibility Statement for Madifa Films - Our commitment to making our platform accessible to everyone." />
      </Helmet>
      <div className="min-h-screen bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="flex items-center gap-3 mb-4">
              <Accessibility className="w-8 h-8 text-primary" />
              <h1 className="text-4xl font-bold">Accessibility Statement</h1>
            </div>
          </div>
          <div className="prose prose-invert max-w-none space-y-8">
            <section className="bg-gray-800/50 p-6 rounded-lg">
              <p className="text-gray-300 leading-relaxed mb-4">
                At Madifa Films, we believe that everyone should have equal access to South African stories and entertainment. 
                We are committed to making our streaming platform accessible to all users, including those with disabilities.
              </p>
              <p className="text-gray-300 leading-relaxed">
                <strong>Last updated:</strong> {new Date().toLocaleDateString()}
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">1. Our Accessibility Commitment</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                We are committed to ensuring our platform meets or exceeds the Web Content Accessibility Guidelines (WCAG) 2.1 Level AA standards. 
                Our goal is to provide an inclusive experience that allows all users to:
              </p>
              <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
                <li>Navigate our platform easily using keyboard controls</li>
                <li>Use screen readers and other assistive technologies</li>
                <li>Adjust text size and contrast as needed</li>
                <li>Access captions and audio descriptions for video content</li>
                <li>Understand content structure through proper headings</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">2. Current Accessibility Features</h2>
              
              <div className="space-y-4">
                <div className="bg-gray-800/30 p-5 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3 text-primary">Video Accessibility</h3>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 ml-4">
                    <li>Closed captions available for most content</li>
                    <li>Keyboard controls for video playback (spacebar to play/pause, arrow keys for seeking)</li>
                    <li>Screen reader compatible video controls</li>
                    <li>Audio descriptions coming soon</li>
                  </ul>
                </div>

                <div className="bg-gray-800/30 p-5 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3 text-primary">Navigation & Interface</h3>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 ml-4">
                    <li>Full keyboard navigation support</li>
                    <li>Skip links to main content</li>
                    <li>Logical heading structure (H1, H2, H3)</li>
                    <li>High contrast color scheme</li>
                    <li>Focus indicators for interactive elements</li>
                    <li>Alternative text for images</li>
                  </ul>
                </div>

                <div className="bg-gray-800/30 p-5 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3 text-primary">Screen Reader Support</h3>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 ml-4">
                    <li>Compatible with NVDA, JAWS, and VoiceOver</li>
                    <li>Proper ARIA labels and descriptions</li>
                    <li>Descriptive link text and button labels</li>
                    <li>Status announcements for dynamic content</li>
                  </ul>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">3. Keyboard Navigation</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                Our platform can be fully navigated using only a keyboard:
              </p>
              
              <div className="bg-gray-800/20 p-5 rounded-lg">
                <h3 className="font-semibold text-primary mb-3">Keyboard Shortcuts</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-300"><kbd className="bg-gray-700 px-2 py-1 rounded">Tab</kbd> - Navigate forward</p>
                    <p className="text-gray-300"><kbd className="bg-gray-700 px-2 py-1 rounded">Shift + Tab</kbd> - Navigate backward</p>
                    <p className="text-gray-300"><kbd className="bg-gray-700 px-2 py-1 rounded">Enter</kbd> - Activate button/link</p>
                    <p className="text-gray-300"><kbd className="bg-gray-700 px-2 py-1 rounded">Escape</kbd> - Close modal/menu</p>
                  </div>
                  <div>
                    <p className="text-gray-300"><kbd className="bg-gray-700 px-2 py-1 rounded">Space</kbd> - Play/pause video</p>
                    <p className="text-gray-300"><kbd className="bg-gray-700 px-2 py-1 rounded">←/→</kbd> - Seek video</p>
                    <p className="text-gray-300"><kbd className="bg-gray-700 px-2 py-1 rounded">↑/↓</kbd> - Volume control</p>
                    <p className="text-gray-300"><kbd className="bg-gray-700 px-2 py-1 rounded">F</kbd> - Toggle fullscreen</p>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">4. Known Issues & Improvements</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                We are continuously working to improve accessibility. Current areas of focus include:
              </p>
              <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
                <li>Expanding audio description availability across our content library</li>
                <li>Improving color contrast in certain interface elements</li>
                <li>Adding more customizable caption options</li>
                <li>Enhancing mobile accessibility features</li>
                <li>Implementing high contrast theme option</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">5. Third-Party Content</h2>
              <p className="text-gray-300 leading-relaxed">
                Some video content on our platform is provided by third-party creators. While we encourage all content creators to provide accessible content including captions and audio descriptions, we cannot guarantee the accessibility of all third-party content. We are actively working with our content partners to improve accessibility across our entire library.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">6. Getting Help</h2>
              <div className="bg-gradient-to-r from-primary/10 to-orange-500/10 p-5 rounded-lg border border-primary/20">
                <p className="text-gray-300 leading-relaxed mb-4">
                  If you experience any accessibility barriers while using our platform, please contact us. We take accessibility seriously and will work to address any issues promptly.
                </p>
                <div className="space-y-2">
                  <p className="text-gray-300">
                    <strong>Email:</strong>{" "}
                    <a href="mailto:accessibility@madifa.co.za" className="text-primary hover:underline">
                      accessibility@madifa.co.za
                    </a>
                  </p>
                  <p className="text-gray-300">
                    <strong>Phone:</strong> +27 11 123 4567
                  </p>
                  <p className="text-gray-300">
                    <strong>Response Time:</strong> We aim to respond within 2 business days
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">7. Feedback & Suggestions</h2>
              <p className="text-gray-300 leading-relaxed">
                Your feedback helps us improve. Please share your suggestions for making our platform more accessible by contacting us at{" "}
                <a href="mailto:accessibility@madifa.co.za" className="text-primary hover:underline">
                  accessibility@madifa.co.za
                </a>
                {" "}or through our{" "}
                <Link href="/feedback" className="text-primary hover:underline">
                  feedback page
                </Link>
                .
              </p>
            </section>
          </div>
        </div>
      </div>
    </AdaptiveLayout>
  );
}
