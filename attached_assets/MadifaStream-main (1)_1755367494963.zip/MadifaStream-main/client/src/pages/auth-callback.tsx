import { supabase } from "@/lib/supabase";
import { useQueryClient } from "@tanstack/react-query";
import {  Loader2  } from "lucide-react";
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { logger } from '@shared/logger';

export default function AuthCallback() {
  const [_location, _setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [error, setError] = useState<string | null>(null);
  const [_isProcessing, _setIsProcessing] = useState(true);
  const [debugInfo, setDebugInfo] = useState<string>("");

  useEffect(() => {
    // Extract hash or query parameters from the URL
    const hash = window.location.hash;
    const searchParams = new URLSearchParams(window.location.search);
    const errorParam = searchParams.get("error");
    const errorDescription = searchParams.get("error_description");

    // Log the current URL to help with debugging redirect issues
    if (import.meta.env.DEV) {
      logger.auth("Auth callback processing URL:", { arg1: window.location.href });
    }
    setDebugInfo(`Processing URL: ${window.location.href.substring(0, 100)}...`);

    // Log Supabase configuration
    const supabaseUrl = (supabase as any).supabaseUrl || '';
    setDebugInfo(prev => `${prev}\nSupabase URL: ${supabaseUrl}`);

    async function handleAuthCallback() {
      try {
        if (errorParam) {
          if (import.meta.env.DEV) {
          logger.auth("Auth error:", { arg1: errorParam, arg2: errorDescription });
        }
          setError(errorDescription || "Authentication failed");
          setDebugInfo(prev => `${prev}\nError: ${errorParam} - ${errorDescription}`);
          _setIsProcessing(false);
          return;
        }

        // For implicit flow, tokens come in the hash fragment. If absent, try PKCE exchange as a fallback.
        setDebugInfo(prev => `${prev}\nProcessing auth callback...`);
        let exchangeError: any = null;
        if (!hash || !hash.includes('access_token')) {
          const queryString = window.location.search.startsWith('?')
            ? window.location.search.slice(1)
            : window.location.search;
          const result = await supabase.auth.exchangeCodeForSession(queryString);
          exchangeError = result.error;
        }
        
        if (exchangeError) {
          // If exchange fails, try to get existing session
          setDebugInfo(prev => `${prev}\nCode exchange failed, checking existing session...`);
          const { data, error } = await supabase.auth.getSession();
          
          if (error || !data.session) {
            // If still no session, try parsing hash for implicit flow
            if (hash && hash.includes("access_token")) {
              try {
                const hashParams = new URLSearchParams(hash.substring(1));
                const accessToken = hashParams.get("access_token");
                const refreshToken = hashParams.get("refresh_token");

                if (accessToken) {
                  setDebugInfo(prev => `${prev}\nFound access token in hash, setting session...`);
                  const { error: setSessionError } = await supabase.auth.setSession({
                    access_token: accessToken,
                    refresh_token: refreshToken || "",
                  });
                  
                  if (setSessionError) {
                    throw setSessionError;
                  }
                } else {
                  throw new Error("No access token found");
                }
              } catch (err) {
                if (import.meta.env.DEV) {
                  logger.auth("Auth callback error:", { arg1: err });
                }
                setError("Authentication failed. Please try again.");
                setDebugInfo(prev => `${prev}\nAuth error: ${(err as Error).message}`);
                _setIsProcessing(false);
                return;
              }
            } else {
              setError("Authentication failed. No valid session found.");
              setDebugInfo(prev => `${prev}\nNo valid session or tokens found`);
              _setIsProcessing(false);
              return;
            }
          }
        }
        
        // Get the current session after exchange
        const { data: sessionData } = await supabase.auth.getSession();
        
        if (!sessionData.session) {
          setError("Failed to establish session after authentication");
          setDebugInfo(prev => `${prev}\nNo session after authentication`);
          _setIsProcessing(false);
          return;
        }

        // User is now authenticated
        try {
          const user = sessionData.session?.user;
          setDebugInfo(prev => `${prev}\nUser authenticated: ${user?.email}`);

          if (user) {
            // Check if profile exists, create if needed
            setDebugInfo(prev => `${prev}\nChecking user profile...`);
            const { data: profile, error: profileError } = await supabase
              .from('profiles')
              .select('*')
              .eq('id', user.id)
              .single();
            
            if (profileError && profileError.code === 'PGRST116') {
              // Profile doesn't exist, create it
              setDebugInfo(prev => `${prev}\nCreating new user profile...`);
              const { error: createError } = await supabase
                .from('profiles')
                .insert({
                  id: user.id,
                  email: user.email,
                  username: user.email?.split('@')[0] || 'user',
                  created_at: new Date().toISOString(),
                  updated_at: new Date().toISOString(),
                });
              
              if (createError) {
                logger.error("Failed to create profile:", { arg1: createError });
              }
            }
          }

          // Invalidate any user/profile related queries
          queryClient.invalidateQueries({ queryKey: ["/api/profiles"] });

          // Check for a pre-existing redirect in localStorage (for deep linking)
          const storedRedirect = localStorage.getItem('authRedirectUrl');

          // Use stored redirect or default to home page
          const redirectTo = storedRedirect || "/";

          // Clear stored redirect after using it
          if (storedRedirect) {
            localStorage.removeItem('authRedirectUrl');
          }

          if (import.meta.env.DEV) {
            logger.auth(`Auth successful, redirecting to: ${redirectTo}`);
          }
          setDebugInfo(prev => `${prev}\nAuth successful, redirecting to: ${redirectTo}`);

          // Allow a brief moment to display success message before redirect
          setTimeout(() => {
            _setLocation(redirectTo);
          }, 1000);
        } catch (err) {
          if (import.meta.env.DEV) {
            logger.auth("Profile creation error:", { arg1: err });
          }
          setError("Failed to set up your profile");
          setDebugInfo(prev => `${prev}\nProfile creation error: ${(err as Error).message}`);
          _setIsProcessing(false);
        }
      } catch (err) {
        if (import.meta.env.DEV) {
        logger.auth("Auth callback error:", { arg1: err });
      }
        setError("Authentication processing failed");
        setDebugInfo(prev => `${prev}\nGeneral auth error: ${(err as Error).message}`);
        _setIsProcessing(false);
      }
    }

    handleAuthCallback();
  }, [_setLocation, queryClient]);

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-4">
        <div className="bg-card p-8 rounded-lg shadow-lg max-w-md w-full text-center">
          <h1 className="text-2xl font-bold mb-4">Authentication Error</h1>
          <p className="text-destructive mb-6">{error}</p>
          <button
            onClick={() => _setLocation("/login")}
            className="bg-primary text-primary-foreground px-4 py-2 rounded hover:bg-primary/90"
          >
            Back to Login
          </button>
          {/* Debug information */}
          <div className="mt-8 p-4 bg-gray-100 dark:bg-gray-800 rounded text-left overflow-auto text-xs" style={{ maxHeight: '200px' }}>
            <pre>{debugInfo}</pre>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen p-4">
      <div className="bg-card p-8 rounded-lg shadow-lg max-w-md w-full text-center">
        <h1 className="text-2xl font-bold mb-4">Processing Login</h1>
        <div className="flex justify-center mb-6">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
        <p className="text-muted-foreground">
          Please wait while we complete your authentication...
        </p>
        {/* Debug information */}
        <div className="mt-8 p-4 bg-gray-100 dark:bg-gray-800 rounded text-left overflow-auto text-xs" style={{ maxHeight: '200px' }}>
          <pre>{debugInfo}</pre>
        </div>
      </div>
    </div>
  );
}