/**
 * Enhanced User Profile Page
 * 
 * Mobile-first responsive profile page with modern design
 * and optimized layout for all device sizes.
 */

import {  Helmet  } from 'react-helmet-async';
import {  UserProfile  } from '@/components/user/user-profile';
import { RobustMainLayout } from '@/components/layouts/RobustMainLayout';

export function ProfilePage() {
  return (
    <>
      <Helmet>
        <title>My Profile | Madifa</title>
        <meta name="description" content="Manage your Madifa account settings, preferences, and subscription" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      </Helmet>
      
      <>
        {/* Enhanced container with proper mobile spacing */}
        <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-950 dark:to-gray-900">
          <div className="container mx-auto py-4 sm:py-6 lg:py-8">
            {/* Page Header - Hidden on mobile to save space, avatar header serves this purpose */}
            <div className="hidden sm:block mb-6 lg:mb-8">
              <div className="text-center space-y-2">
                <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 dark:text-white">
                  Account Settings
                </h1>
                <p className="text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
                  Manage your profile, preferences, subscription, and security settings
                </p>
              </div>
            </div>
            
            {/* Enhanced UserProfile Component */}
            <UserProfile />
          </div>
        </div>
      </>
    </>
  );
}

export default ProfilePage;