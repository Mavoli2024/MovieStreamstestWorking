import {  MainLayout  } from "@/components/layouts/MainLayout";
import {  Input  } from "@/components/ui/input";
import {  Select, SelectContent, SelectItem, SelectTrigger, SelectValue  } from "@/components/ui/select";
import {  VideoDetailModal  } from "@/components/video-detail-modal";
import {  UnifiedVideoGrid, UnifiedFeaturedHero, UnifiedVideoCarousel  } from "@/components/video/unified-video-displays";
import { useVideos } from "@/hooks/use-videos";
import { useWatchlist } from "@/hooks/use-watchlist";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import {  AuthModal  } from "@/components/auth-modal";
import {  SubscriptionModal  } from "@/components/subscription-modal";
import {  Loader2, Search, X, Star, Film, Video as VideoIcon, Clock, Crown  } from "lucide-react";
import { useState, memo, useMemo, ElementType, useEffect } from "react";
import {  Helmet  } from "react-helmet-async";
import type { Database } from "@/types/database-generated.types";
import { useLocation } from "wouter";
import {  Badge  } from "@/components/ui/badge";


type Video = Database['public']['Tables']['videos']['Row'];

// Category tile component for discovery
const CategoryTile = memo(function CategoryTile({ 
  title, 
  icon: Icon, 
  color = "primary", 
  onClick, 
  isActive = false
}: { 
  title: string; 
  icon: ElementType; 
  color?: string; 
  onClick?: () => void; 
  isActive?: boolean;
}) {
  return (
    <div 
      className={`group cursor-pointer p-6 rounded-2xl border transition-all duration-200 transform hover:scale-105 ${
        isActive 
          ? `bg-${color}/20 border-${color} shadow-lg shadow-${color}/20` 
          : 'bg-card/50 border-border hover:border-primary/50 hover:bg-card/80'
      }`}
      onClick={onClick}
    >
      <Icon className={`w-8 h-8 mx-auto mb-3 ${isActive ? `text-${color}` : 'text-muted-foreground group-hover:text-primary'}`} />
      <h3 className={`text-center font-semibold ${isActive ? 'text-white' : 'text-foreground'}`}>{title}</h3>
    </div>
  );
});

export default function DiscoverContentPage() {
  const [location, setLocation] = useLocation();
  
  const urlParams = useMemo(() => new URLSearchParams(window.location.search), [location]);
  const initialCategory = useMemo(() => urlParams.get("category") || "", [urlParams]);

  const { toast } = useToast();
  const [selectedVideo, setSelectedVideo] = useState<Video | null>(null);
  const [showVideoDetail, setShowVideoDetail] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>(initialCategory);
  const [selectedGenre, setSelectedGenre] = useState<string>("");
  const [selectedYear, setSelectedYear] = useState<string>("");
  const [minimumRating, setMinimumRating] = useState<number>(0);
  const [sortBy, setSortBy] = useState<string>("recent");
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [videoToPlay, setVideoToPlay] = useState<Video | null>(null);
  
  const { user, checkSubscription } = useAuth();
  const { watchlist, addToWatchlist, removeFromWatchlist } = useWatchlist();

  useEffect(() => {
    setSelectedCategory(initialCategory);
  }, [initialCategory]);

  // Fetch all videos using the new Supabase hook
  const { data: videosData, isLoading: isLoadingVideos } = useVideos();
  const allVideos = useMemo(() => videosData || [], [videosData]);

  // Create watchlist set for quick lookups
  const watchlistSet = useMemo(() => 
    new Set(watchlist?.map((w: { video_id: string }) => w.video_id) || []), 
    [watchlist]
  );

  // Extract all unique genres from videos
  const availableGenres = useMemo(() => {
    const genreSet = new Set<string>();
    allVideos.forEach(video => {
      if (video.genres && Array.isArray(video.genres)) {
        video.genres.forEach(genre => genreSet.add(genre));
      }
    });
    return Array.from(genreSet).sort();
  }, [allVideos]);

  // Extract available years from videos
  const availableYears = useMemo(() => {
    const yearSet = new Set<number>();
    allVideos.forEach(video => {
      if (video.release_year) {
        yearSet.add(video.release_year);
      }
    });
    return Array.from(yearSet).sort((a, b) => b - a); // Newest first
  }, [allVideos]);

  // Handle category filtering
  const handleCategoryFilter = (category: string) => {
    if (category === selectedCategory) {
      setSelectedCategory(""); // Deselect if clicked again
      setLocation(window.location.pathname);
    } else {
      setSelectedCategory(category);
      setSearchTerm(""); // Clear search when filtering by category
      setLocation(`${window.location.pathname}?category=${category}`);
    }
  };
  
  // Filter videos based on selected category, genre, year, rating, or search
  const filteredVideos = useMemo(() => {
    let videos = allVideos;

    // Apply search filter first
    if (searchTerm.trim()) {
      videos = videos.filter(video => 
        video.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (video.description && video.description.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (video.genres && video.genres.some(genre => 
          genre.toLowerCase().includes(searchTerm.toLowerCase())
        ))
      );
    }
    
    // Apply category filter
    if (selectedCategory) {
      switch (selectedCategory) {
        case 'movie':
          videos = videos.filter(video => !video.is_trailer);
          break;
        case 'trailer':
          videos = videos.filter(video => video.is_trailer);
          break;
        case 'recent':
          videos = [...videos].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
          break;
        case 'all':
        default:
          // Keep all videos
          break;
      }
    }

    // Apply genre filter
    if (selectedGenre) {
      videos = videos.filter(video => 
        video.genres && video.genres.includes(selectedGenre)
      );
      }

    // Apply year filter
    if (selectedYear) {
      videos = videos.filter(video => 
        video.release_year === parseInt(selectedYear)
      );
    }

    // Apply rating filter (assuming videos have a rating field)
    if (minimumRating > 0) {
      videos = videos.filter(video => 
        (video as any).rating >= minimumRating
      );
    }

    // Apply sorting
    if (sortBy && videos.length > 0) {
      switch (sortBy) {
        case 'newest':
          videos = [...videos].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
          break;
        case 'oldest':
          videos = [...videos].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
          break;
        case 'title':
          videos = [...videos].sort((a, b) => a.title.localeCompare(b.title));
          break;
        case 'year_desc':
          videos = [...videos].sort((a, b) => (b.release_year || 0) - (a.release_year || 0));
          break;
        case 'year_asc':
          videos = [...videos].sort((a, b) => (a.release_year || 0) - (b.release_year || 0));
          break;
        case 'rating':
          videos = [...videos].sort((a, b) => ((b as any).rating || 0) - ((a as any).rating || 0));
          break;
        default:
          // Keep existing order
          break;
      }
    }
    
    // Return filtered videos only if there's a filter applied
    return (searchTerm.trim() || selectedCategory || selectedGenre || selectedYear || minimumRating > 0) ? videos : [];
  }, [allVideos, searchTerm, selectedCategory, selectedGenre, selectedYear, minimumRating, sortBy]);

  const showSearchResults = searchTerm.trim().length > 0;
  const showCategoryResults = selectedCategory && !searchTerm.trim();
  const showGenreResults = selectedGenre && !searchTerm.trim() && !selectedCategory;
  const showFilterResults = showSearchResults || showCategoryResults || showGenreResults;
  
  // Featured video is the first non-trailer video if available
  const featuredVideo = useMemo(() => allVideos.find(v => !v.is_trailer) || allVideos[0] || null, [allVideos]);
  
  const handleOpenVideoDetail = (video: Video) => {
    setSelectedVideo(video);
    setShowVideoDetail(true);
  };
  
  const handleCloseVideoDetail = () => {
    setShowVideoDetail(false);
  };
  
  const handlePlay = async (video: Video) => {
    if (video.is_trailer) {
      window.location.href = `/watch/${video.id}`;
      return;
    }

    if (!user) {
      setVideoToPlay(video);
      setShowAuthModal(true);
      return;
    }

    const hasSubscription = await checkSubscription();
    if (!hasSubscription) {
      setVideoToPlay(video);
      setShowSubscriptionModal(true);
      return;
    }

    window.location.href = `/watch/${video.id}`;
  }

  const handleAddToWatchlist = (videoId: string) => {
    addToWatchlist.mutate(videoId);
  };

  const handleRemoveFromWatchlist = (videoId: string) => {
    removeFromWatchlist.mutate(videoId);
  };

  const getCategoryTitle = () => {
    switch (selectedCategory) {
      case 'movie': return 'Full Movies';
      case 'trailer': return 'Trailers & Previews';
      case 'recent': return 'Recently Added';
      case 'all': return 'All Content';
      default: return '';
    }
  };

  return (
    <>
      <Helmet>
        <title>Discover | Madifa Films</title>
        <meta name="description" content="Discover trending and recently added African content on Madifa Films." />
      </Helmet>
      <div className="pb-20">
        {/* Enhanced Search Interface */}
        <div className="container mx-auto px-4 pt-8">
          <div className="relative mb-8 max-w-2xl mx-auto">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3">
              <Search size={20} className="text-gray-400" />
            </div>
            <Input
              type="search"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setSelectedCategory(''); // Clear category when searching
                setSelectedGenre(''); // Clear genre when searching
              }}
              placeholder="Search for 'uMantolwana', 'Ulwaluko', 'Royal uMkhonto'..."
              className="pl-12 bg-background/50 border border-border focus:border-primary h-14 text-lg"
            />
            {searchTerm && (
              <button
                className="absolute inset-y-0 right-3 text-gray-400 hover:text-white"
                onClick={() => setSearchTerm("")}
              >
                <X size={20} />
              </button>
            )}
          </div>

          {/* Category Discovery Tiles - Based on Actual Content */}
          <section className="mb-12">
            <h2 className="text-2xl font-bold mb-6 text-center">Discover Mzansi Stories</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              <CategoryTile 
                title="Full Movies" 
                icon={Film} 
                color="blue-500"
                onClick={() => handleCategoryFilter('movie')}
                isActive={selectedCategory === 'movie'}
              />
              <CategoryTile 
                title="Trailers" 
                icon={VideoIcon} 
                color="red-500"
                onClick={() => handleCategoryFilter('trailer')}
                isActive={selectedCategory === 'trailer'}
              />
              <CategoryTile 
                title="All Content" 
                icon={Star} 
                color="green-500"
                onClick={() => handleCategoryFilter('all')}
                isActive={selectedCategory === 'all'}
              />
              <CategoryTile 
                title="Recently Added" 
                icon={Clock} 
                color="purple-500"
                onClick={() => handleCategoryFilter('recent')}
                isActive={selectedCategory === 'recent'}
              />
            </div>
          </section>

          {/* Genre Filter */}
          {availableGenres.length > 0 && (
            <section className="mb-8">
              <h3 className="text-lg font-semibold mb-4">Browse by Genre</h3>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setSelectedGenre("")}
                  className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                    !selectedGenre 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                  }`}
                >
                  All Genres
                </button>
                {availableGenres.map((genre) => (
                  <button
                    key={genre}
                    onClick={() => setSelectedGenre(genre)}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                      selectedGenre === genre 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-secondary text-secondary-foreground hover:bg-secondary/80'
                    }`}
                  >
                    {genre}
                  </button>
                ))}
              </div>
            </section>
          )}

          {/* Additional Filters */}
          <section className="mb-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              
              {/* Year Filter */}
              {availableYears.length > 0 && (
                <div>
                  <label className="text-sm font-medium block mb-2">Release Year</label>
                  <Select value={selectedYear || "any-year"} onValueChange={(value) => setSelectedYear(value === "any-year" ? "" : value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Any year" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any-year">Any year</SelectItem>
                      {availableYears.map(year => (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {/* Rating Filter */}
              <div>
                <label className="text-sm font-medium block mb-2">Minimum Rating</label>
                <Select value={minimumRating.toString()} onValueChange={(value) => setMinimumRating(parseFloat(value))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any rating" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Any rating</SelectItem>
                    <SelectItem value="1">1+ stars</SelectItem>
                    <SelectItem value="2">2+ stars</SelectItem>
                    <SelectItem value="3">3+ stars</SelectItem>
                    <SelectItem value="4">4+ stars</SelectItem>
                    <SelectItem value="4.5">4.5+ stars</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Sort Options */}
              <div>
                <label className="text-sm font-medium block mb-2">Sort by</label>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger>
                    <SelectValue placeholder="Sort by..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recent">Recently Added</SelectItem>
                    <SelectItem value="newest">Newest First</SelectItem>
                    <SelectItem value="oldest">Oldest First</SelectItem>
                    <SelectItem value="title">Title A-Z</SelectItem>
                    <SelectItem value="year_desc">Release Year (Newest)</SelectItem>
                    <SelectItem value="year_asc">Release Year (Oldest)</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Clear All Filters */}
            {(selectedGenre || selectedYear || minimumRating > 0 || selectedCategory) && (
              <div className="text-center mt-4">
                <button
                  onClick={() => {
                    setSelectedGenre("");
                    setSelectedYear("");
                    setMinimumRating(0);
                    setSelectedCategory("");
                    setSortBy("recent");
                  }}
                  className="text-sm text-muted-foreground hover:text-foreground underline"
                >
                  Clear all filters
                </button>
              </div>
            )}
          </section>
        </div>

        {/* Loading state */}
        {isLoadingVideos && (
          <div className="flex justify-center items-center h-40">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
            <span className="ml-2 text-lg">Loading content...</span>
          </div>
        )}

        {/* Search or Category Results */}
        {!isLoadingVideos && (showSearchResults || showCategoryResults || showGenreResults) && (
          <div className="container mx-auto px-4 mt-8">
            <h2 className="text-2xl font-bold mb-6">
              {showSearchResults 
                ? `Search Results for "${searchTerm}" (${filteredVideos.length} results)`
                : showCategoryResults
                  ? `${getCategoryTitle()} (${filteredVideos.length} videos)`
                  : showGenreResults
                    ? `Content filtered by genre "${selectedGenre}" (${filteredVideos.length} results)`
                    : ''
              }
            </h2>
            {filteredVideos.length > 0 ? (
              <UnifiedVideoGrid 
                videos={filteredVideos} 
                columns={4}
                onPlay={handlePlay}
                onInfo={handleOpenVideoDetail}
                watchlist={watchlistSet}
                onAddToWatchlist={handleAddToWatchlist}
                onRemoveFromWatchlist={handleRemoveFromWatchlist}
              />
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">
                  {showSearchResults
                    ? `No videos found for "${searchTerm}". Try another search.`
                    : showCategoryResults
                      ? `No content available in this category yet.`
                      : showGenreResults
                        ? `No content found for the selected genre "${selectedGenre}".`
                        : ''
                  }
                </p>
              </div>
            )}
          </div>
        )}
        
        {/* Default View: Hero and Carousels */}
        {!isLoadingVideos && !showSearchResults && !showCategoryResults && !showGenreResults && (
          <>
            {featuredVideo && (
              <UnifiedFeaturedHero 
                video={featuredVideo} 
                onInfo={handleOpenVideoDetail} 
                onPlay={handlePlay}
                isInWatchlist={watchlistSet.has(featuredVideo.id)}
                onAddToWatchlist={handleAddToWatchlist}
                onRemoveFromWatchlist={handleRemoveFromWatchlist}
              />
            )}
            <div className="mt-8 space-y-8">
              {allVideos.length > 0 && (
                <UnifiedVideoCarousel
                  title="Popular Mzansi Films"
                  videos={allVideos.filter(v => !v.is_trailer).slice(0, 10)}
                  watchlist={watchlistSet}
                  onPlay={handlePlay}
                  onAddToWatchlist={handleAddToWatchlist}
                  onRemoveFromWatchlist={handleRemoveFromWatchlist}
                  onInfo={handleOpenVideoDetail}
                  showSeeMore={false}
                />
              )}
              {allVideos.filter(v => v.is_premium && !v.is_trailer).length > 0 && (
                <section className="mb-8">
                  <div className="container mx-auto px-4">
                    <div className="flex items-center gap-3 mb-6">
                      <Crown className="w-8 h-8 text-amber-500" />
                      <h2 className="text-3xl font-bold text-white">Premium Full Movies</h2>
                      <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-black font-bold">
                        {allVideos.filter(v => v.is_premium && !v.is_trailer).length} Premium Films
                      </Badge>
                    </div>
                    <UnifiedVideoGrid
                      videos={allVideos.filter(v => v.is_premium && !v.is_trailer)}
                      watchlist={watchlistSet}
                      onPlay={handlePlay}
                      onAddToWatchlist={handleAddToWatchlist}
                      onRemoveFromWatchlist={handleRemoveFromWatchlist}
                      onInfo={handleOpenVideoDetail}
                      columns={4}
                      className="grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6"
                    />
                  </div>
                </section>
              )}
              {allVideos.length > 0 && (
                <UnifiedVideoCarousel
                  title="Latest South African Films"
                  videos={[...allVideos].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).slice(0, 10)}
                  watchlist={watchlistSet}
                  onPlay={handlePlay}
                  onAddToWatchlist={handleAddToWatchlist}
                  onRemoveFromWatchlist={handleRemoveFromWatchlist}
                  onInfo={handleOpenVideoDetail}
                  showSeeMore={false}
                />
              )}
              {allVideos.filter(v => v.is_trailer).length > 0 && (
                <UnifiedVideoCarousel
                  title="Trailers & Previews"
                  videos={allVideos.filter(v => v.is_trailer)}
                  watchlist={watchlistSet}
                  onPlay={handlePlay}
                  onAddToWatchlist={handleAddToWatchlist}
                  onRemoveFromWatchlist={handleRemoveFromWatchlist}
                  onInfo={handleOpenVideoDetail}
                  showSeeMore={false}
                />
              )}
            </div>
          </>
        )}
       </div>
       
       {/* video detail modal */}
       {showVideoDetail && selectedVideo && (
         <VideoDetailModal
           video={selectedVideo}
           isInWatchlist={watchlistSet.has(selectedVideo.id)}
           onAddToWatchlist={handleAddToWatchlist}
           onRemoveFromWatchlist={handleRemoveFromWatchlist}
           onClose={handleCloseVideoDetail}
         />
       )}

      {showAuthModal && (
        <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
      )}

      {showSubscriptionModal && videoToPlay && (
        <SubscriptionModal 
          isOpen={showSubscriptionModal} 
          onClose={() => setShowSubscriptionModal(false)} 
          videoId={videoToPlay?.id}
        />
      )}
    </>
  );
}