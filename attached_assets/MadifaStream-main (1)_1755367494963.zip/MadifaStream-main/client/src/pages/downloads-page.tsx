import {  MainLayout  } from "@/components/layouts/MainLayout";
import {  Button  } from "@/components/ui/button";
import {  ThumbnailImage  } from "@/components/ui/thumbnail-image";
import { useAuth } from "@/hooks/use-auth";
import { useSubscription } from "@/hooks/use-subscription";
import { useDownloads } from "@/hooks/use-downloads";
import { useVideos } from "@/hooks/use-videos";
import {  ChevronDown, ChevronRight, Download, Play, X, Settings, Trash2  } from "lucide-react";
import { useState, useMemo } from "react";
import {  Link  } from "wouter";
import {  UnifiedVideoGrid  } from "@/components/video/unified-video-displays";
import {  Progress  } from "@/components/ui/progress";
import {  Badge  } from "@/components/ui/badge";

export default function DownloadsPage() {
  const { user } = useAuth();
  const { hasPremiumAccess } = useSubscription();
  const { 
    downloads, 
    completedDownloads, 
    downloadingItems, 
    settings,
    isLoading,
    deleteDownload,
    isDeletingDownload
  } = useDownloads();
  const { data: videosData } = useVideos();
  
  const [showSettings, setShowSettings] = useState(false);

  // Get all videos for recommendations
  const allVideos = useMemo(() => videosData || [], [videosData]);

  const handleDeleteDownload = (downloadId: number) => {
    deleteDownload(downloadId);
  };

  const formatTimeRemaining = (expiresAt: string) => {
    const expiry = new Date(expiresAt);
    const now = new Date();
    const diffMs = expiry.getTime() - now.getTime();
    const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffDays <= 0) return 'Expired';
    if (diffDays === 1) return '1 day left';
    return `${diffDays} days left`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'downloading': return 'bg-blue-500';
      case 'pending': return 'bg-yellow-500';
      case 'failed': return 'bg-red-500';
      case 'expired': return 'bg-gray-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <>
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-white">
            Downloads
          </h1>
          <div className="flex items-center gap-4">
            {hasPremiumAccess ? (
              <>
                <div className="bg-primary/20 p-2 rounded-md flex items-center">
                  <span className="text-primary/90 text-sm">
                    Premium Account: Downloads Available
                  </span>
                </div>
                <Button
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowSettings(!showSettings)}
                >
                  <Settings className="h-4 w-4 mr-2" />
                  Settings
                </Button>
              </>
            ) : (
              <Link to="/subscription">
                <Button className="bg-secondary hover:bg-secondary/90 text-white">
                  Upgrade to Download
                </Button>
              </Link>
            )}
          </div>
        </div>

        {/* Download Settings Panel */}
        {showSettings && hasPremiumAccess && settings && (
          <div className="bg-card p-4 rounded-md mb-8 border">
            <h3 className="text-lg font-medium mb-4">Download Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium">Max Downloads: {settings.max_downloads}</label>
                <p className="text-sm text-muted-foreground">Maximum number of downloads allowed</p>
              </div>
              <div>
                <label className="text-sm font-medium">Default Quality: {settings.download_quality.toUpperCase()}</label>
                <p className="text-sm text-muted-foreground">Quality for new downloads</p>
              </div>
              <div>
                <label className="text-sm font-medium">
                  Auto Download: {settings.auto_download_next_episode ? 'On' : 'Off'}
                </label>
                <p className="text-sm text-muted-foreground">Automatically download next episode</p>
              </div>
              <div>
                <label className="text-sm font-medium">
                  WiFi Only: {settings.wifi_only ? 'On' : 'Off'}
                </label>
                <p className="text-sm text-muted-foreground">Only download on WiFi connections</p>
              </div>
            </div>
          </div>
        )}

        {/* Information Panel */}
        <div className="bg-card p-4 rounded-md mb-8 border-l-4 border-secondary">
          <div className="flex items-start">
            <div className="flex-1">
              <h2 className="text-lg font-medium mb-2">Download movies and shows to watch offline</h2>
              <p className="text-muted-foreground text-sm">
                Madifa Premium subscribers can download content to watch when not connected to the internet.
                Downloads expire after 30 days or when you cancel your subscription.
              </p>
            </div>
            <ChevronDown className="text-muted-foreground h-5 w-5" />
          </div>
        </div>

        {hasPremiumAccess ? (
          <>
            {isLoading ? (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto mb-4"></div>
                  <p className="text-muted-foreground">Loading your downloads...</p>
                </div>
              </div>
            ) : (
              <>
                {/* Downloads in Progress */}
                {downloadingItems.length > 0 && (
                  <div className="mb-8">
                    <h2 className="text-xl font-medium mb-4">Downloading</h2>
                    <div className="space-y-4">
                      {downloadingItems.map((download) => (
                        <div key={download.id} className="bg-card rounded-lg p-4 flex items-center gap-4">
                          <ThumbnailImage
                            src={download.thumbnailUrl}
                            alt={download.title}
                            title={download.title}
                            className="w-24 h-16 rounded"
                          />
                          <div className="flex-1">
                            <h3 className="font-medium mb-1">{download.title}</h3>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground">
                              <Badge variant="secondary" className={getStatusColor(download.status)}>
                                {download.status}
                              </Badge>
                              <span>{download.downloadQuality.toUpperCase()}</span>
                              <span>{download.size}</span>
                            </div>
                            <div className="mt-2">
                              <Progress value={download.progress} className="h-2" />
                              <p className="text-xs text-muted-foreground mt-1">
                                {download.progress}% complete
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteDownload(download.id)}
                            disabled={isDeletingDownload}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Completed Downloads */}
                {completedDownloads.length > 0 ? (
                  <div className="mb-8">
                    <h2 className="text-xl font-medium mb-4">
                      Downloaded ({completedDownloads.length})
                    </h2>
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                      {completedDownloads.map((download) => (
                        <div key={download.id} className="bg-card rounded-lg overflow-hidden">
                          <div className="relative">
                            <ThumbnailImage
                              src={download.thumbnailUrl}
                              alt={download.title}
                              title={download.title}
                              className="w-full h-32"
                            />
                            <div className="absolute top-2 right-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="bg-black/50 hover:bg-black/70 text-white"
                                onClick={() => handleDeleteDownload(download.id)}
                                disabled={isDeletingDownload}
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                            <div className="absolute bottom-2 left-2">
                              <Button
                                size="sm"
                                className="bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm"
                                onClick={() => window.location.href = `/watch/${download.videoId}`}
                              >
                                <Play className="h-3 w-3 mr-1" />
                                Play
                              </Button>
                            </div>
                          </div>
                          <div className="p-3">
                            <h3 className="font-medium text-sm mb-1 line-clamp-2">{download.title}</h3>
                            <div className="flex items-center justify-between text-xs text-muted-foreground">
                              <span>{download.downloadQuality.toUpperCase()}</span>
                              <span>{download.size}</span>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              {formatTimeRemaining(download.expiresAt)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : downloads.length === 0 ? (
                  /* Empty State */
                  <div className="bg-card rounded-md p-8 text-center mb-8">
                    <Download className="h-16 w-16 mx-auto mb-4 text-secondary opacity-70" />
                    <h2 className="text-2xl font-bold mb-2">No Downloads Yet</h2>
                    <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
                      Start downloading your favorite movies and shows to watch them offline.
                      Look for the download button on any video.
                    </p>
                    <Link to="/browse">
                      <Button className="bg-secondary hover:bg-secondary/90 text-white px-8 py-2">
                        <Download className="h-4 w-4 mr-2" />
                        Browse Content
                      </Button>
                    </Link>
                  </div>
                ) : null}

                {/* Recommended Downloads Section */}
                {downloads.length > 0 && allVideos.length > 0 && (
                  <div className="mt-12">
                    <div className="flex justify-between items-center mb-4">
                      <h2 className="text-xl font-medium">Recommended for Download</h2>
                      <Link to="/browse" className="text-secondary flex items-center text-sm hover:underline">
                        See More <ChevronRight className="h-4 w-4" />
                      </Link>
                    </div>
                    <UnifiedVideoGrid
                      videos={allVideos.slice(0, 8) as any[]}
                      columns={4}
                      onPlay={(video) => window.location.href = `/watch/${video.id}`}
                      className=""
                    />
                  </div>
                )}
              </>
            )}
          </>
        ) : (
          // Premium required message
          <div className="bg-card rounded-md p-8 text-center">
            <Download className="h-16 w-16 mx-auto mb-4 text-secondary opacity-70" />
            <h2 className="text-2xl font-bold mb-2">Premium Subscription Required</h2>
            <p className="text-muted-foreground mb-6 max-w-lg mx-auto">
              Upgrade to Madifa Premium for R59/month to download movies and shows
              and watch them offline whenever and wherever you want.
            </p>
            <Link to="/subscription">
              <Button className="bg-secondary hover:bg-secondary/90 text-white px-8 py-2">
                Upgrade to Premium
              </Button>
            </Link>
          </div>
        )}
      </div>
    </>
  );
}