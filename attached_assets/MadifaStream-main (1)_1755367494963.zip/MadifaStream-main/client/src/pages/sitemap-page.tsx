import {  AdaptiveLayout  } from "@/components/layouts/AdaptiveLayout";
import {  Helmet  } from "react-helmet-async";
import {  Link  } from "wouter";
import {  ArrowLeft, Map  } from "lucide-react";
import {  Button  } from "@/components/ui/button";

export default function SitemapPage() {
  return (
    <AdaptiveLayout>
      <Helmet>
        <title>Sitemap | Madifa Films</title>
        <meta name="description" content="Sitemap for Madifa Films - Find all pages and content on our platform." />
      </Helmet>
      <div className="min-h-screen bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          <div className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="flex items-center gap-3 mb-4">
              <Map className="w-8 h-8 text-primary" />
              <h1 className="text-4xl font-bold">Sitemap</h1>
            </div>
          </div>
          <div className="space-y-8">
            <p className="text-gray-300 leading-relaxed mb-8">
              Find all pages and content on Madifa Films platform.
            </p>

            {/* Public Pages */}
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-primary">Public Pages</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-800/30 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-white">General</h3>
                  <ul className="space-y-1 text-gray-300">
                    <li><Link href="/" className="hover:text-primary transition-colors">Home / Landing</Link></li>
                    <li><Link href="/home" className="hover:text-primary transition-colors">Dashboard</Link></li>
                    <li><Link href="/browse" className="hover:text-primary transition-colors">Browse Content</Link></li>
                    <li><Link href="/search" className="hover:text-primary transition-colors">Search</Link></li>
                    <li><Link href="/discover" className="hover:text-primary transition-colors">Discover</Link></li>
                  </ul>
                </div>
                <div className="bg-gray-800/30 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-white">Account</h3>
                  <ul className="space-y-1 text-gray-300">
                    <li><Link href="/auth" className="hover:text-primary transition-colors">Sign In / Sign Up</Link></li>
                    <li><Link href="/profile" className="hover:text-primary transition-colors">User Profile</Link></li>
                    <li><Link href="/settings" className="hover:text-primary transition-colors">Account Settings</Link></li>
                    <li><Link href="/subscription" className="hover:text-primary transition-colors">Subscription</Link></li>
                    <li><Link href="/pricing" className="hover:text-primary transition-colors">Pricing Plans</Link></li>
                  </ul>
                </div>
              </div>
            </section>

            {/* User Content */}
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-primary">User Content</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-800/30 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-white">My Library</h3>
                  <ul className="space-y-1 text-gray-300">
                    <li><Link href="/my-list" className="hover:text-primary transition-colors">My List</Link></li>
                    <li><Link href="/watchlist" className="hover:text-primary transition-colors">Watchlist</Link></li>
                    <li><Link href="/history" className="hover:text-primary transition-colors">Watch History</Link></li>
                  </ul>
                </div>
                <div className="bg-gray-800/30 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-white">Video Playback</h3>
                  <ul className="space-y-1 text-gray-300">
                    <li><span className="text-gray-400">Watch Video: /watch/[id]</span></li>
                    <li><span className="text-gray-400">Category Browse: /browse/[category]</span></li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Legal & Support */}
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-primary">Legal & Support</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gray-800/30 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-white">Legal Pages</h3>
                  <ul className="space-y-1 text-gray-300">
                    <li><Link href="/terms" className="hover:text-primary transition-colors">Terms of Service</Link></li>
                    <li><Link href="/privacy" className="hover:text-primary transition-colors">Privacy Policy</Link></li>
                    <li><Link href="/cookies" className="hover:text-primary transition-colors">Cookie Policy</Link></li>
                    <li><Link href="/accessibility" className="hover:text-primary transition-colors">Accessibility Statement</Link></li>
                  </ul>
                </div>
                <div className="bg-gray-800/30 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2 text-white">Support</h3>
                  <ul className="space-y-1 text-gray-300">
                    <li><Link href="/feedback" className="hover:text-primary transition-colors">Feedback & Contact</Link></li>
                    <li><Link href="/sitemap" className="hover:text-primary transition-colors">Sitemap (This Page)</Link></li>
                  </ul>
                </div>
              </div>
            </section>

            {/* Payment Pages */}
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-primary">Payment Pages</h2>
              <div className="bg-gray-800/30 p-4 rounded-lg">
                <h3 className="font-semibold mb-2 text-white">Payment Flow</h3>
                <ul className="space-y-1 text-gray-300">
                  <li><span className="text-gray-400">Payment Success: /payment/success</span></li>
                  <li><span className="text-gray-400">Payment Cancelled: /payment/cancel</span></li>
                </ul>
              </div>
            </section>

            {/* Admin (Hidden from Regular Users) */}
            <section className="mb-8">
              <h2 className="text-2xl font-semibold mb-4 text-primary">Admin (Staff Only)</h2>
              <div className="bg-gray-800/30 p-4 rounded-lg">
                <ul className="space-y-1 text-gray-300">
                  <li><span className="text-gray-400">Admin Dashboard: /admin</span></li>
                </ul>
              </div>
            </section>

            <div className="mt-12 p-6 bg-gradient-to-r from-primary/10 to-orange-500/10 rounded-lg border border-primary/20">
              <h3 className="font-semibold mb-2 text-primary">Need Help?</h3>
              <p className="text-gray-300">
                If you can't find what you're looking for, try our{" "}
                <Link href="/search" className="text-primary hover:underline">
                  search function
                </Link>
                {" "}or{" "}
                <Link href="/feedback" className="text-primary hover:underline">
                  contact our support team
                </Link>
                .
              </p>
            </div>
          </div>
        </div>
      </div>
    </AdaptiveLayout>
  );
}
