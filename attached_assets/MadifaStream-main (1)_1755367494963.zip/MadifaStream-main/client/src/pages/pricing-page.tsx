import {  SubscriptionModal  } from '@/components/subscription-modal';
import { useLocation } from "wouter";
import {  Helmet  } from "react-helmet-async";

/**
 * SubscriptionPage (Modal Trigger)
 * This page's sole purpose is to trigger the SubscriptionModal and provide a background.
 * It redirects the user back to their previous page when the modal is closed.
 */
export default function SubscriptionPage() {
  const [, setLocation] = useLocation();

  const handleClose = () => {
    setLocation("/browse"); // Go back to the browse page
  };

  return (
    <>
      <Helmet>
        <title>Subscribe | Madifa Films</title>
        <meta name="description" content="Upgrade to Madifa Premium for unlimited HD streaming without ads." />
      </Helmet>
      {/* Modal overlay */}
      <div className="fixed inset-0 bg-black bg-opacity-50 z-40">
        <SubscriptionModal isOpen onClose={handleClose} />
      </div>
    </>
  );
} 