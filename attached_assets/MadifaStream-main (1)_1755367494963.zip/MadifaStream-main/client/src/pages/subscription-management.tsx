import { logger } from '@shared/logger';
/**
 * Comprehensive Subscription Management Page
 * 
 * Features:
 * - Current subscription overview
 * - Billing history
 * - Payment method management
 * - Plan upgrade/downgrade
 * - Subscription pause/cancel
 * - Usage statistics
 */

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/hooks/use-auth';
import {  MainLayout  } from '@/components/layouts/MainLayout';
import {  Card, CardContent, CardDescription, CardHeader, CardTitle  } from '@/components/ui/card';
import {  Badge  } from '@/components/ui/badge';
import {  Button  } from '@/components/ui/button';
import {  Tabs, TabsContent, TabsList, TabsTrigger  } from '@/components/ui/tabs';
import {  
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
 } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import {  
  CreditCard, 
  Calendar, 
  DollarSign, 
  Download, 
  Play, 
  Pause, 
  StopCircle, 
  Settings,
  History,
  BarChart3,
  Crown,
  AlertTriangle,
  CheckCircle,
  Loader2
 } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

// Types
interface BillingHistory {
  id: string;
  amount: number;
  currency: string;
  status: 'paid' | 'pending' | 'failed';
  invoice_date: string;
  description: string;
  invoice_url?: string;
}

interface PaymentMethod {
  id: string;
  type: 'card' | 'paypal' | 'bank';
  last_four?: string;
  brand?: string;
  expiry_month?: number;
  expiry_year?: number;
  is_default: boolean;
}

interface UsageStats {
  videos_watched: number;
  total_watch_time: number;
  downloads_used: number;
  downloads_limit: number;
}

export default function SubscriptionManagementPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [showPauseDialog, setShowPauseDialog] = useState(false);

  // Move all hooks to top level before any early returns
  // Fetch current subscription
  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ['subscription', user?.id],
    queryFn: async () => {
      if (!user?.id) throw new Error('No user');
      const response = await fetch(`/api/subscriptions/user/${user.id}`, {
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to fetch subscription');
      return response.json();
    },
    enabled: !!user?.id
  });

  // Fetch billing history
  const { data: billingHistory = [], isLoading: billingLoading } = useQuery({
    queryKey: ['billing-history', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      try {
        const response = await fetch(`/api/billing/history/${user.id}`, {
          credentials: 'include'
        });
        if (!response.ok) return []; // Return empty array if no billing history
        return (await response.json()) as BillingHistory[];
      } catch (error) {
        logger.error('Error fetching billing history:', { arg1: error });
        return [];
      }
    },
    enabled: !!user?.id
  });

  // Fetch payment methods
  const { data: paymentMethods = [], isLoading: paymentsLoading } = useQuery({
    queryKey: ['payment-methods', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      try {
        const response = await fetch(`/api/payment-methods/${user.id}`, {
          credentials: 'include'
        });
        if (!response.ok) return []; // Return empty array if no payment methods
        return (await response.json()) as PaymentMethod[];
      } catch (error) {
        logger.payment('Error fetching payment methods:', { arg1: error });
        return [];
      }
    },
    enabled: !!user?.id
  });

  // Fetch usage statistics
  const { data: usageStats } = useQuery({
    queryKey: ['usage-stats', user?.id],
    queryFn: async (): Promise<UsageStats> => {
      if (!user?.id) {
        return {
          videos_watched: 0,
          total_watch_time: 0,
          downloads_used: 0,
          downloads_limit: 10
        };
      }
      const response = await fetch(`/api/usage/stats/${user.id}`, {
        credentials: 'include'
      });
      if (!response.ok) {
        // Return default stats if API not available
        return {
          videos_watched: 0,
          total_watch_time: 0,
          downloads_used: 0,
          downloads_limit: 10
        };
      }
      return response.json();
    },
    enabled: !!user?.id
  });

  // Pause subscription mutation
  const pauseSubscriptionMutation = useMutation({
    mutationFn: async () => {
      if (!subscription?.id) throw new Error('No subscription');
      const response = await fetch(`/api/subscriptions/${subscription.id}/pause`, {
        method: 'POST',
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to pause subscription');
      return response.json();
    },
    onSuccess: () => {
      if (user?.id) {
        queryClient.invalidateQueries({ queryKey: ['subscription', user.id] });
      }
      toast({ title: 'Subscription paused successfully' });
      setShowPauseDialog(false);
    },
    onError: () => {
      toast({ 
        title: 'Failed to pause subscription', 
        description: 'Please try again later.',
        variant: 'destructive' 
      });
    }
  });

  // Cancel subscription mutation
  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      if (!subscription?.id) throw new Error('No subscription');
      const response = await fetch(`/api/subscriptions/${subscription.id}/cancel`, {
        method: 'POST',
        credentials: 'include'
      });
      if (!response.ok) throw new Error('Failed to cancel subscription');
      return response.json();
    },
    onSuccess: () => {
      if (user?.id) {
        queryClient.invalidateQueries({ queryKey: ['subscription', user.id] });
      }
      toast({ title: 'Subscription cancelled successfully' });
      setShowCancelDialog(false);
    },
    onError: () => {
      toast({ 
        title: 'Failed to cancel subscription', 
        description: 'Please try again later.',
        variant: 'destructive' 
      });
    }
  });

  // Early return after all hooks are declared
  if (!user) {
    return (
      <>
        <div className="container mx-auto px-4 py-8">
          <div className="text-center">
            <p>Please log in to manage your subscription.</p>
          </div>
        </div>
      </>
    );
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-ZA', {
      style: 'currency',
      currency: 'ZAR'
    }).format(amount / 100);
  };

  const formatWatchTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  if (subscriptionLoading) {
    return (
      <>
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin" />
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Subscription Management</h1>
          <p className="text-muted-foreground">
            Manage your subscription, billing, and account preferences
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Crown className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="billing" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              Billing
            </TabsTrigger>
            <TabsTrigger value="payment" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Payment
            </TabsTrigger>
            <TabsTrigger value="usage" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Usage
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Current Subscription */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Crown className="h-5 w-5" />
                  Current Subscription
                </CardTitle>
                <CardDescription>
                  Your active subscription details and status
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {subscription ? (
                  <>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-lg">{subscription.plan?.name || 'Premium Plan'}</h3>
                        <p className="text-muted-foreground">
                          {formatCurrency(subscription.plan?.price || 0)} per month
                        </p>
                      </div>
                      <Badge 
                        variant={subscription.is_active ? 'default' : 'secondary'}
                        className={cn(
                          subscription.is_active && 'bg-green-500 hover:bg-green-600'
                        )}
                      >
                        {subscription.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">Started</p>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(subscription.start_date), 'MMM d, yyyy')}
                          </p>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">Next Billing</p>
                          <p className="text-sm text-muted-foreground">
                            {subscription.end_date ? 
                              format(new Date(subscription.end_date), 'MMM d, yyyy') : 
                              'No end date'
                            }
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Settings className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <p className="text-sm font-medium">Auto-renew</p>
                          <p className="text-sm text-muted-foreground">
                            {subscription.is_active ? 'Enabled' : 'Disabled'}
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex flex-wrap gap-2 pt-4 border-t">
                      <Button variant="outline" size="sm">
                        <Crown className="h-4 w-4 mr-2" />
                        Upgrade Plan
                      </Button>
                      
                      <Dialog open={showPauseDialog} onOpenChange={setShowPauseDialog}>
                        <DialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            <Pause className="h-4 w-4 mr-2" />
                            Pause Subscription
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Pause Subscription</DialogTitle>
                            <DialogDescription>
                              Your subscription will be paused and you'll retain access until your current billing period ends.
                            </DialogDescription>
                          </DialogHeader>
                          <DialogFooter>
                            <Button variant="outline" onClick={() => setShowPauseDialog(false)}>
                              Cancel
                            </Button>
                            <Button 
                              onClick={() => pauseSubscriptionMutation.mutate()}
                              disabled={pauseSubscriptionMutation.isPending}
                            >
                              {pauseSubscriptionMutation.isPending && (
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              )}
                              Pause Subscription
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>

                      <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
                        <DialogTrigger asChild>
                          <Button variant="destructive" size="sm">
                            <StopCircle className="h-4 w-4 mr-2" />
                            Cancel Subscription
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Cancel Subscription</DialogTitle>
                            <DialogDescription>
                              Are you sure you want to cancel your subscription? You'll lose access to premium content at the end of your current billing period.
                            </DialogDescription>
                          </DialogHeader>
                          <DialogFooter>
                            <Button variant="outline" onClick={() => setShowCancelDialog(false)}>
                              Keep Subscription
                            </Button>
                            <Button 
                              variant="destructive"
                              onClick={() => cancelSubscriptionMutation.mutate()}
                              disabled={cancelSubscriptionMutation.isPending}
                            >
                              {cancelSubscriptionMutation.isPending && (
                                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                              )}
                              Cancel Subscription
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">No active subscription found</p>
                    <Button>
                      <Crown className="h-4 w-4 mr-2" />
                      Subscribe Now
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Billing Tab */}
          <TabsContent value="billing" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <History className="h-5 w-5" />
                  Billing History
                </CardTitle>
                <CardDescription>
                  View your past invoices and payment history
                </CardDescription>
              </CardHeader>
              <CardContent>
                {billingLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : billingHistory.length > 0 ? (
                  <div className="space-y-4">
                    {billingHistory.map((invoice) => (
                      <div key={invoice.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-4">
                          <div>
                            <DollarSign className="h-5 w-5 text-muted-foreground" />
                          </div>
                          <div>
                            <p className="font-medium">{invoice.description}</p>
                            <p className="text-sm text-muted-foreground">
                              {format(new Date(invoice.invoice_date), 'MMM d, yyyy')}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-medium">{formatCurrency(invoice.amount)}</p>
                          <Badge 
                            variant={
                              invoice.status === 'paid' ? 'default' : 
                              invoice.status === 'pending' ? 'secondary' : 'destructive'
                            }
                          >
                            {invoice.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground">No billing history available</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payment Tab */}
          <TabsContent value="payment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Payment Methods
                </CardTitle>
                <CardDescription>
                  Manage your payment methods and billing information
                </CardDescription>
              </CardHeader>
              <CardContent>
                {paymentsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : paymentMethods.length > 0 ? (
                  <div className="space-y-4">
                    {paymentMethods.map((method) => (
                      <div key={method.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-4">
                          <CreditCard className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <p className="font-medium">
                              {method.brand} ending in {method.last_four}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              Expires {method.expiry_month}/{method.expiry_year}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {method.is_default && (
                            <Badge variant="outline">Default</Badge>
                          )}
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                        </div>
                      </div>
                    ))}
                    <Button variant="outline" className="w-full">
                      Add Payment Method
                    </Button>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-muted-foreground mb-4">No payment methods on file</p>
                    <Button>
                      <CreditCard className="h-4 w-4 mr-2" />
                      Add Payment Method
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Usage Tab */}
          <TabsContent value="usage" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Videos Watched</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">{usageStats?.videos_watched || 0}</div>
                  <p className="text-sm text-muted-foreground">This month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Watch Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {formatWatchTime(usageStats?.total_watch_time || 0)}
                  </div>
                  <p className="text-sm text-muted-foreground">This month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Downloads</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">
                    {usageStats?.downloads_used || 0} / {usageStats?.downloads_limit || 10}
                  </div>
                  <p className="text-sm text-muted-foreground">Downloads used</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Plan Features</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">HD Streaming</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Offline Downloads</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="text-sm">Multiple Devices</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
