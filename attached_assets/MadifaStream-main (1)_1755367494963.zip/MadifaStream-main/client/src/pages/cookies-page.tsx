import {  AdaptiveLayout  } from "@/components/layouts/AdaptiveLayout";
import {  Helmet  } from "react-helmet-async";
import {  Link  } from "wouter";
import {  ArrowLeft, Cookie, Settings, Info  } from "lucide-react";
import {  Button  } from "@/components/ui/button";

export default function CookiesPage() {
  return (
    <AdaptiveLayout>
      <Helmet>
        <title>Cookie Policy | Madifa Films</title>
        <meta name="description" content="Cookie Policy for Madifa Films - How we use cookies and similar technologies." />
      </Helmet>

      <div className="min-h-screen bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          {/* Header */}
          <div className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <div className="flex items-center gap-3 mb-4">
              <Cookie className="w-8 h-8 text-primary" />
              <h1 className="text-4xl font-bold">Cookie Policy</h1>
            </div>
            <p className="text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          {/* Content */}
          <div className="prose prose-invert max-w-none space-y-8">
            <section className="bg-gray-800/50 p-6 rounded-lg">
              <h2 className="text-xl font-semibold mb-3 flex items-center gap-2">
                <Info className="w-5 h-5 text-primary" />
                What Are Cookies?
              </h2>
              <p className="text-gray-300 leading-relaxed">
                Cookies are small text files that are placed on your device when you visit our website. They help us provide you with a better experience by remembering your preferences and analyzing how you use our service.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">1. Types of Cookies We Use</h2>
              
              <div className="space-y-4">
                <div className="bg-gray-800/30 p-5 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3 text-primary">Essential Cookies</h3>
                  <p className="text-gray-300 mb-3">
                    These cookies are necessary for the website to function properly. They enable core functionality such as security, network management, and accessibility.
                  </p>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 ml-4">
                    <li>Authentication and security</li>
                    <li>Session management</li>
                    <li>Load balancing</li>
                    <li>Basic functionality</li>
                  </ul>
                  <p className="text-sm text-gray-400 mt-3">
                    <strong>Duration:</strong> Session or up to 1 year
                  </p>
                </div>

                <div className="bg-gray-800/30 p-5 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3 text-primary">Performance Cookies</h3>
                  <p className="text-gray-300 mb-3">
                    These cookies help us understand how visitors interact with our website by collecting and reporting information anonymously.
                  </p>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 ml-4">
                    <li>Page load times and performance</li>
                    <li>User journey analysis</li>
                    <li>Error tracking</li>
                    <li>Feature usage statistics</li>
                  </ul>
                  <p className="text-sm text-gray-400 mt-3">
                    <strong>Duration:</strong> Up to 2 years
                  </p>
                </div>

                <div className="bg-gray-800/30 p-5 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3 text-primary">Functional Cookies</h3>
                  <p className="text-gray-300 mb-3">
                    These cookies allow the website to remember choices you make and provide enhanced, more personal features.
                  </p>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 ml-4">
                    <li>Language preferences</li>
                    <li>Video quality settings</li>
                    <li>User interface preferences</li>
                    <li>Personalized content recommendations</li>
                  </ul>
                  <p className="text-sm text-gray-400 mt-3">
                    <strong>Duration:</strong> Up to 1 year
                  </p>
                </div>

                <div className="bg-gray-800/30 p-5 rounded-lg">
                  <h3 className="text-lg font-semibold mb-3 text-primary">Analytics Cookies</h3>
                  <p className="text-gray-300 mb-3">
                    These cookies help us analyze website traffic and understand user behavior to improve our service.
                  </p>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 ml-4">
                    <li>Viewing patterns and preferences</li>
                    <li>Content engagement metrics</li>
                    <li>User flow analysis</li>
                    <li>A/B testing data</li>
                  </ul>
                  <p className="text-sm text-gray-400 mt-3">
                    <strong>Duration:</strong> Up to 2 years
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">2. Third-Party Cookies</h2>
              <p className="text-gray-300 leading-relaxed mb-4">
                We also use cookies from trusted third-party services to enhance your experience:
              </p>
              
              <div className="space-y-3">
                <div className="bg-gray-800/20 p-4 rounded-lg">
                  <h3 className="font-semibold text-primary mb-2">Video Delivery</h3>
                  <p className="text-gray-300 text-sm">
                    Our video streaming service uses cookies to optimize video delivery and track playback performance.
                  </p>
                </div>

                <div className="bg-gray-800/20 p-4 rounded-lg">
                  <h3 className="font-semibold text-primary mb-2">Payment Processing</h3>
                  <p className="text-gray-300 text-sm">
                    Secure payment processing requires cookies to maintain transaction security and prevent fraud.
                  </p>
                </div>

                <div className="bg-gray-800/20 p-4 rounded-lg">
                  <h3 className="font-semibold text-primary mb-2">Analytics Services</h3>
                  <p className="text-gray-300 text-sm">
                    We use analytics services to understand user behavior and improve our platform performance.
                  </p>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4 flex items-center gap-2">
                <Settings className="w-6 h-6 text-primary" />
                3. Managing Your Cookie Preferences
              </h2>
              
              <div className="space-y-4">
                <p className="text-gray-300 leading-relaxed">
                  You have several options for managing cookies:
                </p>

                <div className="bg-gradient-to-r from-primary/10 to-orange-500/10 p-5 rounded-lg border border-primary/20">
                  <h3 className="text-lg font-semibold mb-3 text-primary">Browser Settings</h3>
                  <p className="text-gray-300 mb-3">
                    Most web browsers allow you to control cookies through their settings:
                  </p>
                  <ul className="list-disc list-inside text-gray-300 space-y-1 ml-4">
                    <li>Block all cookies</li>
                    <li>Block third-party cookies</li>
                    <li>Delete existing cookies</li>
                    <li>Receive notifications when cookies are set</li>
                  </ul>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-800/30 p-4 rounded-lg">
                    <h4 className="font-semibold text-primary mb-2">Chrome</h4>
                    <p className="text-gray-300 text-sm">
                      Settings → Privacy and Security → Cookies and other site data
                    </p>
                  </div>
                  <div className="bg-gray-800/30 p-4 rounded-lg">
                    <h4 className="font-semibold text-primary mb-2">Firefox</h4>
                    <p className="text-gray-300 text-sm">
                      Settings → Privacy & Security → Cookies and Site Data
                    </p>
                  </div>
                  <div className="bg-gray-800/30 p-4 rounded-lg">
                    <h4 className="font-semibold text-primary mb-2">Safari</h4>
                    <p className="text-gray-300 text-sm">
                      Preferences → Privacy → Manage Website Data
                    </p>
                  </div>
                  <div className="bg-gray-800/30 p-4 rounded-lg">
                    <h4 className="font-semibold text-primary mb-2">Edge</h4>
                    <p className="text-gray-300 text-sm">
                      Settings → Cookies and site permissions → Cookies
                    </p>
                  </div>
                </div>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">4. Impact of Disabling Cookies</h2>
              <div className="bg-amber-500/10 border border-amber-500/20 p-5 rounded-lg">
                <p className="text-gray-300 leading-relaxed mb-3">
                  While you can disable cookies, please note that this may affect your experience:
                </p>
                <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
                  <li>You may need to log in repeatedly</li>
                  <li>Video quality and playback settings may not be saved</li>
                  <li>Personalized recommendations may not work properly</li>
                  <li>Some features may not function correctly</li>
                  <li>We won't be able to remember your preferences</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">5. Mobile App Data</h2>
              <p className="text-gray-300 leading-relaxed">
                Our mobile app may use similar technologies to cookies, such as local storage and device identifiers, to provide the same functionality. You can manage these through your device settings or by uninstalling the app.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">6. Updates to This Policy</h2>
              <p className="text-gray-300 leading-relaxed">
                We may update this Cookie Policy from time to time to reflect changes in our practices or for legal reasons. We will notify you of any significant changes by posting the updated policy on our website.
              </p>
            </section>

            <section className="bg-gray-800/50 p-6 rounded-lg">
              <h2 className="text-2xl font-semibold mb-4">7. Contact Us</h2>
              <p className="text-gray-300 leading-relaxed mb-3">
                If you have any questions about our use of cookies, please contact us:
              </p>
              <div className="space-y-2">
                <p className="text-gray-300">
                  <strong>Email:</strong>{" "}
                  <a href="mailto:privacy@madifa.co.za" className="text-primary hover:underline">
                    privacy@madifa.co.za
                  </a>
                </p>
                <p className="text-gray-300">
                  <strong>Support:</strong>{" "}
                  <a href="mailto:support@madifa.co.za" className="text-primary hover:underline">
                    support@madifa.co.za
                  </a>
                </p>
              </div>
            </section>
          </div>
        </div>
      </div>
    </AdaptiveLayout>
  );
}