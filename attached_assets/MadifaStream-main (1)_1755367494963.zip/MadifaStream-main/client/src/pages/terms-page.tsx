import {  AdaptiveLayout  } from "@/components/layouts/AdaptiveLayout";
import {  Helmet  } from "react-helmet-async";
import {  Link  } from "wouter";
import {  ArrowLeft  } from "lucide-react";
import {  Button  } from "@/components/ui/button";

export default function TermsPage() {
  return (
    <AdaptiveLayout>
      <Helmet>
        <title>Terms of Service | Madifa Films</title>
        <meta name="description" content="Terms of Service for Madifa Films streaming platform." />
      </Helmet>

      <div className="min-h-screen bg-gray-900 text-white">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          {/* Header */}
          <div className="mb-8">
            <Link href="/">
              <Button variant="ghost" className="text-white hover:bg-white/10 mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Button>
            </Link>
            <h1 className="text-4xl font-bold mb-4">Terms of Service</h1>
            <p className="text-gray-400">Last updated: {new Date().toLocaleDateString()}</p>
          </div>

          {/* Content */}
          <div className="prose prose-invert max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-semibold mb-4">1. Acceptance of Terms</h2>
              <p className="text-gray-300 leading-relaxed">
                By accessing and using Madifa Films ("the Service"), you accept and agree to be bound by the terms and provision of this agreement. These Terms of Service govern your use of the Madifa Films streaming platform.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">2. Description of Service</h2>
              <p className="text-gray-300 leading-relaxed">
                Madifa Films is a streaming platform that provides access to South African movies, series, and documentaries. The Service may include premium content that requires a paid subscription and free content available to all users.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">3. User Accounts</h2>
              <div className="space-y-3">
                <p className="text-gray-300 leading-relaxed">
                  To access certain features of the Service, you must create an account. You agree to:
                </p>
                <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
                  <li>Provide accurate and complete information</li>
                  <li>Maintain the security of your account credentials</li>
                  <li>Notify us immediately of any unauthorized use</li>
                  <li>Be responsible for all activities under your account</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">4. Subscription and Payment</h2>
              <div className="space-y-3">
                <p className="text-gray-300 leading-relaxed">
                  Premium content requires a paid subscription. By subscribing, you agree to:
                </p>
                <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
                  <li>Pay all applicable fees for your chosen subscription plan</li>
                  <li>Automatic renewal unless cancelled before the next billing cycle</li>
                  <li>No refunds for partial subscription periods</li>
                  <li>Price changes with 30 days' notice</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">5. Acceptable Use</h2>
              <div className="space-y-3">
                <p className="text-gray-300 leading-relaxed">
                  You agree not to:
                </p>
                <ul className="list-disc list-inside text-gray-300 space-y-2 ml-4">
                  <li>Share your account credentials with others</li>
                  <li>Download, copy, or redistribute content without authorization</li>
                  <li>Use the Service for any illegal or unauthorized purpose</li>
                  <li>Attempt to circumvent technical protection measures</li>
                  <li>Use automated systems to access the Service</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">6. Content and Intellectual Property</h2>
              <p className="text-gray-300 leading-relaxed">
                All content on Madifa Films, including but not limited to videos, images, text, and software, is owned by Madifa Films or its licensors and is protected by copyright and other intellectual property laws. You may not reproduce, distribute, or create derivative works from this content.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">7. Privacy</h2>
              <p className="text-gray-300 leading-relaxed">
                Your privacy is important to us. Please review our <Link href="/privacy" className="text-primary hover:underline">Privacy Policy</Link>, which governs how we collect, use, and protect your information.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">8. Limitation of Liability</h2>
              <p className="text-gray-300 leading-relaxed">
                Madifa Films shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of the Service. Our total liability shall not exceed the amount you paid for the Service in the past 12 months.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">9. Termination</h2>
              <p className="text-gray-300 leading-relaxed">
                We may terminate or suspend your account immediately, without prior notice, for any reason, including if you breach these Terms of Service. You may also terminate your account at any time through your account settings.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">10. Changes to Terms</h2>
              <p className="text-gray-300 leading-relaxed">
                We reserve the right to modify these terms at any time. We will notify users of significant changes via email or through the Service. Continued use of the Service after changes constitutes acceptance of the new terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold mb-4">11. Contact Information</h2>
              <p className="text-gray-300 leading-relaxed">
                If you have any questions about these Terms of Service, please contact us at{" "}
                <a href="mailto:support@madifa.co.za" className="text-primary hover:underline">
                  support@madifa.co.za
                </a>
              </p>
            </section>
          </div>
        </div>
      </div>
    </AdaptiveLayout>
  );
} 