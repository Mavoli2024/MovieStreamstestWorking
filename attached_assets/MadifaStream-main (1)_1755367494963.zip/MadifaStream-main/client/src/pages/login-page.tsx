// Redirect legacy /login route to unified auth page
import { useEffect } from 'react';
import { useLocation } from 'wouter';

export default function LoginPage() {
  const [_, navigate] = useLocation();
  useEffect(() => {
    navigate('/auth?tab=login');
  }, [navigate]);
  return null;
}