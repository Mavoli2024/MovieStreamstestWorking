/**
 * Type adapters for components to handle type mismatches between
 * Supabase generated types and our UI expectations
 */
import type { Database } from "@/types/database-generated.types";

// Canonical DB types (generated)
export type SupabaseVideoRow = Database['public']['Tables']['videos']['Row'];
export type SupabaseCategory = Database['public']['Tables']['categories']['Row'];
export type SupabaseWatchProgress = Database['public']['Tables']['watch_progress']['Row'];
export type SupabaseWatchlist = Database['public']['Tables']['watchlist']['Row'];

// UI-facing video type with friendly aliases
export interface UIVideo {
  id: string;
  title: string;
  description: string | null;
  thumbnail_url: string | null;
  video_url: string | null;
  trailer_url: string | null;
  release_year: number | null;
  duration_minutes: number; // derived from DB `duration`
  age_rating: string | null;
  genres: string[] | null;
  cast: string[] | null; // derived from DB `cast_members`
  director: string | null;
  created_at: string | null;
  updated_at: string | null;
  is_trailer: boolean | null;
  collection_id: string | null;
  collection_name: string | null;
  views: number | null;
  metadata_json: string | null;
  is_premium: boolean | null;
  status: string | null;
  // Bunny fields (optional)
  bunny_video_id?: string | null;
  bunny_playback_id?: string | null;
  bunny_guid?: string | null;
  bunny_library_id?: string | null;
}

/**
 * Ensures video objects have the required fields for UI components
 * Accepts a DB row or a loosely-typed object and normalizes fields
 */
export function adaptVideoForUI(video: unknown): UIVideo {
  const v = (video as Partial<SupabaseVideoRow> & { duration_minutes?: number; cast?: string[] | string | null }) || {};

  const castFromMembers = Array.isArray(v.cast_members)
    ? v.cast_members
    : v.cast
      ? (Array.isArray(v.cast) ? v.cast : typeof v.cast === 'string' ? [v.cast] : null)
      : null;

  const durationMinutes = typeof v.duration === 'number'
    ? v.duration
    : typeof v.duration_minutes === 'number'
      ? v.duration_minutes
      : 0;

  return {
    id: v.id ?? `temp-${Date.now()}`,
    title: v.title ?? '',
    description: v.description ?? null,
    thumbnail_url: v.thumbnail_url ?? null,
    video_url: v.video_url ?? null,
    trailer_url: v.trailer_url ?? null,
    release_year: v.release_year ?? null,
    duration_minutes: durationMinutes,
    age_rating: v.age_rating ?? null,
    genres: (v.genres as string[] | null | undefined) ?? null,
    cast: castFromMembers,
    director: v.director ?? null,
    created_at: (v.created_at as string | null | undefined) ?? null,
    updated_at: (v.updated_at as string | null | undefined) ?? null,
    is_trailer: v.is_trailer ?? null,
    collection_id: (v.collection_id as string | null | undefined) ?? null,
    collection_name: (v.collection_name as string | null | undefined) ?? null,
    views: v.views ?? null,
    metadata_json: v.metadata_json ?? null,
    is_premium: v.is_premium ?? null,
    status: v.status ?? null,
    bunny_video_id: v.bunny_video_id ?? null,
    bunny_playback_id: v.bunny_playback_id ?? null,
    bunny_guid: v.bunny_guid ?? null,
    bunny_library_id: v.bunny_library_id ?? null,
  };
}

/**
 * Adapts an array of videos for UI components
 */
export function adaptVideosForUI(videos: unknown[]): UIVideo[] {
  return videos.map((video) => adaptVideoForUI(video));
}

/**
 * Creates a watchlist item with required fields
 */
export function createWatchlistItem(userId: string, videoId: string): SupabaseWatchlist {
  return {
    id: `temp-${Date.now()}`,
    user_id: userId,
    video_id: videoId,
    added_at: new Date().toISOString()
  } as SupabaseWatchlist;
}
