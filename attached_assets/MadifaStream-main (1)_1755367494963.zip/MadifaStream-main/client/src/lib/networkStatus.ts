// Network status utility to manage and override browser's offline detection
// This helps prevent unnecessary "offline" warnings

/**
 * Initialize network status detection and disable unwanted offline notifications.
 * Particularly useful for auth pages where offline warnings are not helpful.
 */
export function initNetworkStatus() {
  // Override the navigator.onLine check if needed
  // This effectively disables offline mode detection warnings from service workers
  if (typeof window !== 'undefined') {
    // Check if a service worker is causing offline notifications
    const originalOnlineGetter = Object.getOwnPropertyDescriptor(
      Navigator.prototype, 'onLine'
    )?.get;
    
    if (originalOnlineGetter) {
      // Override the onLine property to always return true
      // This prevents "You are currently offline" notifications
      Object.defineProperty(Navigator.prototype, 'onLine', {
        get: function() {
          // Always online on login/auth pages
          if (window.location.pathname.includes('/auth')) {
            return true;
          }
          
          // Use the original behavior elsewhere
          return originalOnlineGetter.call(this);
        },
        configurable: true
      });
    }
  }
}

/**
 * Check if the device has network connectivity
 * @returns boolean indicating online status
 */
export function isOnline(): boolean {
  if (typeof navigator !== 'undefined') {
    return navigator.onLine;
  }
  return true; // Default to true when not in browser environment
}