import { logger } from '@shared/logger';
/**
 * Thumbnail Utility Functions
 * 
 * A centralized set of utilities for handling thumbnails, including:
 * - URL extraction and formatting
 * - Fallback generation
 * - Error handling
 */

import type {  Video  } from '@shared/schema';
import type { Database } from '@/types/database-generated.types';

type DatabaseVideo = Database['public']['Tables']['videos']['Row'];
type FlexibleVideo = Partial<Video> | Partial<DatabaseVideo>;

// No direct CDN host constant – thumbnails served through backend proxy

// Bunny CDN host constant (temporary stub – real URL is provided by backend)
// Bunny CDN host constant – pulled from Vite env so it can differ per environment
export const BUNNY_CDN_HOST: string =
  import.meta.env.VITE_BUNNY_CDN_HOSTNAME || 'vz-685277f9-aa1.b-cdn.net';

/**
 * Extract Bunny GUID from a URL string
 * @param url The URL to extract the GUID from
 * @returns The extracted GUID or null if not found
 */
export function extractBunnyGuid(url: string): string | null {
  if (!url) return null;
  
  // Extract GUID using regex patterns
  // Pattern 1: Look for standard video embed URL pattern
  const embedPattern = /\/player\/([a-zA-Z0-9-]+)\//;
  const embedMatch = url.match(embedPattern);
  if (embedMatch && embedMatch[1]) {
    return embedMatch[1];
  }
  
  // Pattern 2: Look for direct CDN URL pattern with GUID
  const cdnPattern = /\/([a-zA-Z0-9-]{36})\//;
  const cdnMatch = url.match(cdnPattern);
  if (cdnMatch && cdnMatch[1]) {
    return cdnMatch[1];
  }
  
  // Pattern 3: URL ends with the GUID
  const trailingPattern = /([a-zA-Z0-9-]{36})$/;
  const trailingMatch = url.match(trailingPattern);
  if (trailingMatch && trailingMatch[1]) {
    return trailingMatch[1];
  }
  
  return null;
}

/**
 * Get the best thumbnail URL for a video
 * Uses a cascading strategy to find the most appropriate thumbnail
 * 
 * @param video The video object to get the thumbnail for
 * @param _preferredSize Optional size preference ('small', 'medium', 'large')
 * @returns The best available thumbnail URL
 */
export function getBestThumbnailUrl(
  video: FlexibleVideo | null | undefined, 
  _preferredSize: 'small' | 'medium' | 'large' = 'medium'
): string {
  if (!video) return '';
  
  // First priority: Custom thumbnailUrl if it exists
  if (video.thumbnail_url) {
    return video.thumbnail_url;
  }
  
  // Second priority: Extract from video URL and create direct CDN URL
  const videoId = video.video_url ? extractBunnyGuid(video.video_url) : null;
  
  if (videoId) {
    return `https://${BUNNY_CDN_HOST}/${videoId}/thumbnail.jpg`;
  }
  
  // Third priority: Use trailer thumbnail
  if (video.trailer_url) {
    const trailerId = extractBunnyGuid(video.trailer_url);
    if (trailerId) {
      return `https://${BUNNY_CDN_HOST}/${trailerId}/thumbnail.jpg`;
    }
  }
  
  // Fourth priority: Try direct CDN with video ID
  if (video.id) {
    return `https://${BUNNY_CDN_HOST}/${video.id}/thumbnail.jpg`;
  }
  
  // Final fallback: generate SVG placeholder
  return generateSvgThumbnail(video.title || 'Video');
}

/**
 * Generate a SVG placeholder thumbnail with the given text
 * 
 * @param text Text to display on the thumbnail
 * @param backgroundColor Optional background color (default: gradient)
 * @returns A data URL containing an SVG image
 */
export function generateSvgThumbnail(text: string, backgroundColor?: string): string {
  const gradient = !backgroundColor 
    ? '<linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:#3a506b;stop-opacity:1" /><stop offset="100%" style="stop-color:#1c2541;stop-opacity:1" /></linearGradient>'
    : '';
    
  const background = backgroundColor || 'url(#grad)';
  
  // Create a nice SVG placeholder with the video title
  return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
    <svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360">
      <defs>
        ${gradient}
      </defs>
      <rect width="640" height="360" fill="${background}" />
      <rect x="280" y="140" width="80" height="80" rx="10" stroke="#ffffff" stroke-width="8" fill="none" opacity="0.8" />
      <polygon points="300,170 300,190 320,180" fill="#ffffff" opacity="0.8" />
      <text x="320" y="270" font-family="Arial, sans-serif" font-size="24" fill="white" text-anchor="middle" dominant-baseline="middle">${text}</text>
    </svg>
  `)}`;
}

/**
 * Create a server API URL for a thumbnail with proper fallback
 * 
 * @param videoId The video ID to get a thumbnail for
 * @param attempt Optional indicator of which fallback attempt this is
 * @returns A URL to the thumbnail API endpoint
 */
export function getThumbnailApiUrl(videoId: string | number | null | undefined, attempt = 0): string {
  if (!videoId) return '';
  
  // Generate direct CDN URL instead of API proxy
  return `https://vz-f5c9bae3-d51.b-cdn.net/${videoId}/thumbnail.jpg${attempt > 0 ? `?v=${attempt}` : ''}`;
}

/**
 * Record a thumbnail error to help track and fix issues
 * 
 * @param videoId The video ID that had an error
 * @param method The method that was being used
 * @param error The error that occurred
 */
export function logThumbnailError(videoId: string | number, method: string, _error: unknown): void {
  // Only log in development environment to reduce console noise in production
  if (import.meta.env.DEV) {
    logger.warn(`Thumbnail fallback for video ${videoId} using ${method}`);
  }
  
  // Could be extended to report to error tracking service
}

/**
 * Determine if a URL is likely to be a valid image URL
 * 
 * @param url The URL to check
 * @returns True if it looks like an image URL
 */
export function isLikelyImageUrl(url: string | null | undefined): boolean {
  if (!url) return false;
  
  // Check for common image extensions
  const imageExtensions = ['.jpg', '.jpeg', '.png', '.webp', '.avif', '.gif'];
  const hasImageExtension = imageExtensions.some(ext => url.toLowerCase().endsWith(ext));
  
  // Check for image-specific domains or paths
  const containsImageTerms = url.includes('/thumbnail') || url.includes('/poster') || url.includes('/image');
  
  return hasImageExtension || containsImageTerms;
}