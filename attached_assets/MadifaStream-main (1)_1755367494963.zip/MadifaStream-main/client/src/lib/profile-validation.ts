/**
 * Profile Validation System
 * 
 * Comprehensive validation for all profile-related forms with:
 * - Real-time validation feedback
 * - Custom validation rules
 * - Sanitization utilities
 * - Error handling
 * - Social link validation
 */

import { z } from 'zod';

// Custom validation patterns
export const validationPatterns = {
  username: /^[a-zA-Z0-9_-]{3,30}$/,
  displayName: /^[a-zA-Z0-9\s\-_'".]{2,50}$/,
  website: /^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$/,
  socialHandle: /^[a-zA-Z0-9_.-]+$/,
  hexColor: /^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/,
  phoneNumber: /^[\+]?[1-9][\d]{0,15}$/,
};

// Social platform URL patterns
export const socialPlatformPatterns = {
  twitter: /^https?:\/\/(www\.)?(twitter\.com|x\.com)\/[a-zA-Z0-9_]+\/?$/,
  instagram: /^https?:\/\/(www\.)?instagram\.com\/[a-zA-Z0-9_.]+\/?$/,
  facebook: /^https?:\/\/(www\.)?facebook\.com\/[a-zA-Z0-9.]+\/?$/,
  linkedin: /^https?:\/\/(www\.)?linkedin\.com\/(in|company)\/[a-zA-Z0-9-]+\/?$/,
  youtube: /^https?:\/\/(www\.)?(youtube\.com\/(c\/|channel\/|user\/|@)|youtu\.be\/)[a-zA-Z0-9_-]+\/?$/,
  tiktok: /^https?:\/\/(www\.)?tiktok\.com\/@[a-zA-Z0-9_.]+\/?$/,
  github: /^https?:\/\/(www\.)?github\.com\/[a-zA-Z0-9_-]+\/?$/,
};

// Custom error messages
export const validationMessages = {
  required: 'This field is required',
  invalidEmail: 'Please enter a valid email address',
  invalidUsername: 'Username must be 3-30 characters and contain only letters, numbers, hyphens, and underscores',
  invalidDisplayName: 'Display name must be 2-50 characters and contain only letters, numbers, spaces, and common punctuation',
  invalidWebsite: 'Please enter a valid website URL starting with http:// or https://',
  invalidSocialUrl: (platform: string) => `Please enter a valid ${platform} URL`,
  tooShort: (min: number) => `Must be at least ${min} characters`,
  tooLong: (max: number) => `Must be no more than ${max} characters`,
  invalidDate: 'Please enter a valid date',
  futureBirthDate: 'Birth date cannot be in the future',
  tooYoung: 'You must be at least 13 years old to use this service',
  invalidColor: 'Please enter a valid hex color code',
  profanityDetected: 'This content contains inappropriate language',
  specialCharacters: 'This field contains invalid special characters',
};

// Profanity filter (basic implementation)
const profanityWords = [
  // Add common profanity words here (simplified for demo)
  'badword1', 'badword2', // Replace with actual profanity list
];

export const containsProfanity = (text: string): boolean => {
  const lowerText = text.toLowerCase();
  return profanityWords.some(word => lowerText.includes(word));
};

// Age calculation utility
export const calculateAge = (birthDate: string): number => {
  const today = new Date();
  const birth = new Date(birthDate);
  let age = today.getFullYear() - birth.getFullYear();
  const monthDiff = today.getMonth() - birth.getMonth();
  
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
    age--;
  }
  
  return age;
};

// Social URL extractor
export const extractSocialHandle = (url: string, platform: keyof typeof socialPlatformPatterns): string => {
  if (!url) return '';
  
  try {
    const urlObj = new URL(url);
    const pathname = urlObj.pathname;
    
    switch (platform) {
      case 'twitter':
        return pathname.replace('/', '');
      case 'instagram':
        return pathname.replace('/', '');
      case 'facebook':
        return pathname.replace('/', '');
      case 'linkedin':
        return pathname.replace(/\/(in|company)\//, '');
      case 'youtube':
        return pathname.replace(/\/(c\/|channel\/|user\/|@)/, '');
      case 'tiktok':
        return pathname.replace('/@', '');
      case 'github':
        return pathname.replace('/', '');
      default:
        return '';
    }
  } catch {
    return '';
  }
};

// Input sanitization
export const sanitizeInput = (input: string, options: {
  removeHtml?: boolean;
  trimWhitespace?: boolean;
  removeSpecialChars?: boolean;
  maxLength?: number;
} = {}): string => {
  let sanitized = input;
  
  if (options.removeHtml) {
    sanitized = sanitized.replace(/<[^>]*>/g, '');
  }
  
  if (options.trimWhitespace) {
    sanitized = sanitized.trim().replace(/\s+/g, ' ');
  }
  
  if (options.removeSpecialChars) {
    sanitized = sanitized.replace(/[^\w\s\-'".]/g, '');
  }
  
  if (options.maxLength) {
    sanitized = sanitized.substring(0, options.maxLength);
  }
  
  return sanitized;
};

// Main profile validation schemas
export const profileValidationSchemas = {
  // Basic profile information
  basicProfile: z.object({
    username: z.string()
      .min(3, validationMessages.tooShort(3))
      .max(30, validationMessages.tooLong(30))
      .regex(validationPatterns.username, validationMessages.invalidUsername)
      .refine(text => !containsProfanity(text), validationMessages.profanityDetected)
      .optional(),
    
    displayName: z.string()
      .min(2, validationMessages.tooShort(2))
      .max(50, validationMessages.tooLong(50))
      .regex(validationPatterns.displayName, validationMessages.invalidDisplayName)
      .refine(text => !containsProfanity(text), validationMessages.profanityDetected)
      .optional(),
    
    email: z.string()
      .email(validationMessages.invalidEmail),
    
    bio: z.string()
      .max(500, validationMessages.tooLong(500))
      .refine(text => !containsProfanity(text), validationMessages.profanityDetected)
      .optional(),
    
    location: z.string()
      .max(100, validationMessages.tooLong(100))
      .optional(),
    
    website: z.string()
      .regex(validationPatterns.website, validationMessages.invalidWebsite)
      .or(z.literal(''))
      .optional(),
    
    dateOfBirth: z.string()
      .optional()
      .refine((date) => {
        if (!date) return true;
        const birthDate = new Date(date);
        const today = new Date();
        return birthDate <= today;
      }, validationMessages.futureBirthDate)
      .refine((date) => {
        if (!date) return true;
        const age = calculateAge(date);
        return age >= 13;
      }, validationMessages.tooYoung),
    
    avatarColor: z.string()
      .regex(validationPatterns.hexColor, validationMessages.invalidColor)
      .optional(),
  }),

  // Social links validation
  socialLinks: z.object({
    twitter: z.string()
      .regex(socialPlatformPatterns.twitter, validationMessages.invalidSocialUrl('Twitter'))
      .or(z.literal(''))
      .optional(),
    
    instagram: z.string()
      .regex(socialPlatformPatterns.instagram, validationMessages.invalidSocialUrl('Instagram'))
      .or(z.literal(''))
      .optional(),
    
    facebook: z.string()
      .regex(socialPlatformPatterns.facebook, validationMessages.invalidSocialUrl('Facebook'))
      .or(z.literal(''))
      .optional(),
    
    linkedin: z.string()
      .regex(socialPlatformPatterns.linkedin, validationMessages.invalidSocialUrl('LinkedIn'))
      .or(z.literal(''))
      .optional(),
    
    youtube: z.string()
      .regex(socialPlatformPatterns.youtube, validationMessages.invalidSocialUrl('YouTube'))
      .or(z.literal(''))
      .optional(),
    
    tiktok: z.string()
      .regex(socialPlatformPatterns.tiktok, validationMessages.invalidSocialUrl('TikTok'))
      .or(z.literal(''))
      .optional(),
    
    github: z.string()
      .regex(socialPlatformPatterns.github, validationMessages.invalidSocialUrl('GitHub'))
      .or(z.literal(''))
      .optional(),
  }),

  // Privacy preferences
  preferences: z.object({
    notifications: z.boolean(),
    emailMarketing: z.boolean(),
    profilePrivacy: z.enum(['public', 'friends', 'private']),
    showAge: z.boolean(),
    showLocation: z.boolean(),
    showEmail: z.boolean(),
    theme: z.enum(['light', 'dark', 'system']),
    language: z.enum(['en', 'af', 'zu', 'xh']).optional(),
    timezone: z.string().optional(),
  }),

  // Password change validation
  passwordChange: z.object({
    currentPassword: z.string()
      .min(1, validationMessages.required),
    
    newPassword: z.string()
      .min(8, validationMessages.tooShort(8))
      .max(128, validationMessages.tooLong(128))
      .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/, 
        'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character'),
    
    confirmPassword: z.string()
      .min(1, validationMessages.required)
  }).refine(data => data.newPassword === data.confirmPassword, {
    message: 'Passwords do not match',
    path: ['confirmPassword'],
  }),

  // Complete enhanced profile schema
  enhancedProfile: z.object({
    bio: z.string()
      .max(500, validationMessages.tooLong(500))
      .refine(text => !containsProfanity(text), validationMessages.profanityDetected)
      .optional(),
    
    location: z.string()
      .max(100, validationMessages.tooLong(100))
      .optional(),
    
    website: z.string()
      .regex(validationPatterns.website, validationMessages.invalidWebsite)
      .or(z.literal(''))
      .optional(),
    
    dateOfBirth: z.string()
      .optional()
      .refine((date) => {
        if (!date) return true;
        const birthDate = new Date(date);
        const today = new Date();
        return birthDate <= today;
      }, validationMessages.futureBirthDate)
      .refine((date) => {
        if (!date) return true;
        const age = calculateAge(date);
        return age >= 13;
      }, validationMessages.tooYoung),
    
    socialLinks: z.object({
      twitter: z.string().regex(socialPlatformPatterns.twitter, validationMessages.invalidSocialUrl('Twitter')).or(z.literal('')).optional(),
      instagram: z.string().regex(socialPlatformPatterns.instagram, validationMessages.invalidSocialUrl('Instagram')).or(z.literal('')).optional(),
      facebook: z.string().regex(socialPlatformPatterns.facebook, validationMessages.invalidSocialUrl('Facebook')).or(z.literal('')).optional(),
      linkedin: z.string().regex(socialPlatformPatterns.linkedin, validationMessages.invalidSocialUrl('LinkedIn')).or(z.literal('')).optional(),
      youtube: z.string().regex(socialPlatformPatterns.youtube, validationMessages.invalidSocialUrl('YouTube')).or(z.literal('')).optional(),
      tiktok: z.string().regex(socialPlatformPatterns.tiktok, validationMessages.invalidSocialUrl('TikTok')).or(z.literal('')).optional(),
      github: z.string().regex(socialPlatformPatterns.github, validationMessages.invalidSocialUrl('GitHub')).or(z.literal('')).optional(),
    }),
    
    preferences: z.object({
      notifications: z.boolean(),
      emailMarketing: z.boolean(),
      profilePrivacy: z.enum(['public', 'friends', 'private']),
      showAge: z.boolean(),
      showLocation: z.boolean(),
      showEmail: z.boolean(),
      theme: z.enum(['light', 'dark', 'system']),
      language: z.enum(['en', 'af', 'zu', 'xh']).optional(),
      timezone: z.string().optional(),
    }),
  }),
};

// Real-time validation utilities
export const validateField = (
  fieldName: string, 
  value: unknown, 
  schema: z.ZodSchema
): { isValid: boolean; error?: string } => {
  try {
    schema.parse({ [fieldName]: value });
    return { isValid: true };
  } catch (error) {
    if (error instanceof z.ZodError) {
      const fieldError = error.errors.find(err => err.path.includes(fieldName));
      return { 
        isValid: false, 
        error: fieldError?.message || 'Invalid input' 
      };
    }
    return { isValid: false, error: 'Validation failed' };
  }
};

// Debounced validation hook helper
export const createDebouncedValidator = (
  schema: z.ZodSchema,
  delay= 300
) => {
  let timeoutId: NodeJS.Timeout;
  
  return (fieldName: string, value: unknown, callback: (result: { isValid: boolean; error?: string }) => void) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => {
      const result = validateField(fieldName, value, schema);
      callback(result);
    }, delay);
  };
};

// Form submission validator
export const validateFormData = <T>(
  data: T,
  schema: z.ZodSchema<T>
): { isValid: boolean; errors: Record<string, string>; data?: T } => {
  try {
    const validatedData = schema.parse(data);
    return { isValid: true, errors: {}, data: validatedData };
  } catch (error) {
    if (error instanceof z.ZodError) {
      const errors: Record<string, string> = {};
      error.errors.forEach((err) => {
        const path = err.path.join('.');
        errors[path] = err.message;
      });
      return { isValid: false, errors, data: undefined };
    }
    return { isValid: false, errors: { general: 'Validation failed' }, data: undefined };
  }
}; 