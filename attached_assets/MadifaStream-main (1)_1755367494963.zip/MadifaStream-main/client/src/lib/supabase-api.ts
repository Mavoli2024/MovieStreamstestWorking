import type { Database } from '@/types/database-generated.types';
import { supabase } from './supabase';
import { generatePlaceholderThumbnail } from './placeholder-utils';
import { logger } from '@shared/logger';

// Type definitions based on our new database schema
export type Profile = Database['public']['Tables']['profiles']['Row'] & { role?: string };
export type Video = Database['public']['Tables']['videos']['Row'];
export type VideoInsert = Database['public']['Tables']['videos']['Insert'];
export type VideoUpdate = Database['public']['Tables']['videos']['Update'];
export type Watchlist = Database['public']['Tables']['watchlist']['Row'];
export type WatchlistInsert = Database['public']['Tables']['watchlist']['Insert'];
export type WatchProgress = Database['public']['Tables']['watch_progress']['Row'];
export type EnhancedVideo = Video;

/**
 * Get current user's profile
 */
export async function getCurrentProfile(): Promise<Profile | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error fetching profile:', { arg1: error });
      }
      throw error;
    }

    return data;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error getting current profile:', { arg1: error });
    }
    return null;
  }
}

/**
 * Create or update user profile
 */
  export async function upsertProfile(profileData: Partial<Profile>): Promise<Profile | null> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('No authenticated user');

    const { data, error } = await supabase
      .from('profiles')
      .upsert({
        id: user.id,
        ...profileData,
        updated_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error upserting profile:', { arg1: error });
      }
      throw error;
    }
    return data;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error upserting profile:', { arg1: error });
    }
    throw error;
  }
}

/**
 * Get all videos (paginated)
 * Uses API endpoint to bypass RLS restrictions for discovery/browsing
 */
export async function getVideos(): Promise<Video[]> {
  try {
    // PRIMARY: Use API endpoint with service role key (bypasses RLS for discovery)
    try {
      const response = await fetch('/api/videos/public');
      if (response.ok) {
        const apiData = await response.json();
        console.log('Successfully fetched videos via API:', apiData.items?.length || 0, 'items');
        console.log('Sample video data:', apiData.items?.slice(0, 2).map(v => ({ id: v.id, title: v.title, titleType: typeof v.title })));
        return apiData.items || apiData.videos || apiData || [];
      } else {
        console.warn('API endpoint returned non-OK status:', response.status);
      }
    } catch (apiError) {
      console.warn('API endpoint failed, trying Supabase direct:', apiError);
    }

    // FALLBACK: Use direct Supabase query (subject to RLS policies)
    const { data, error: supabaseError } = await supabase
      .from('videos')
      .select('*')
      .order('created_at', { ascending: false });

    if (supabaseError) {
      console.error('Supabase error fetching videos:', supabaseError);
      if (import.meta.env.DEV) {
        logger.api('Error fetching videos from Supabase:', { arg1: supabaseError });
      }
      throw supabaseError;
    }
    
    console.log('Successfully fetched videos via Supabase:', data?.length || 0, 'items');
    console.log('Sample video data:', data?.slice(0, 2).map(v => ({ id: v.id, title: v.title, titleType: typeof v.title })));
    return data || [];
  } catch (error) {
    console.error('Fatal error getting videos:', error);
    if (import.meta.env.DEV) {
      logger.api('Error getting videos:', { arg1: error });
    }
    return [];
  }
}

/**
 * Get a specific video by ID
 */
export async function getVideo(id: string): Promise<Video | null> {
  try {
    const { data, error } = await supabase
      .from('videos')
      .select('*')
      .eq('id', id)
      .single();

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error fetching video:', { arg1: error });
      }
      throw error;
    }

    return data;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error getting video:', { arg1: error });
    }
    return null;
  }
}

/**
 * Create a new video upload using Edge Function
 */
export async function createVideoUpload(videoData: {
  title: string;
  description?: string;
  category?: string;
  tags?: string[];
  is_premium?: boolean;
}): Promise<{ uploadUrl: string; videoGuid: string; libraryId: string; videoId: string }> {
  try {
    const response = await fetch('/api/bunny/create-upload-session', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: videoData.title,
        collectionId: videoData.category || '',
      }),
      credentials: 'include',
    });

    if (!response.ok) {
      const message = await response.text().catch(() => 'Failed to create upload session');
      throw new Error(message);
    }
    return await response.json();
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error creating video upload:', { arg1: error });
    }
    throw error;
  }
}

/**
 * Get signed video URL for playback
 */
export async function getSignedVideoUrl(videoId: string): Promise<{ signedUrl: string; expires?: number }> {
  try {
    const { data: sessionData } = await supabase.auth.getSession();
    const token = sessionData.session?.access_token;

    const response = await fetch('/api/signed-video-url', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ videoId }),
      credentials: 'include',
    });

    if (!response.ok) {
      const text = await response.text().catch(() => '');
      if (import.meta.env.DEV) {
        logger.api('Error getting signed video URL (server route):', { arg1: `${response.status} ${response.statusText} ${text}` });
      }
      throw new Error('Failed to get signed video URL');
    }

    const data = await response.json();
    return { signedUrl: data.signedUrl, expires: data.expires };
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error getting signed video URL:', { arg1: error });
    }
    throw error;
  }
}

/**
 * Update video metadata
 */
export async function updateVideo(id: string, updates: VideoUpdate): Promise<Video | null> {
  try {
    const { data, error } = await supabase
      .from('videos')
      .update({
        ...updates,
        updated_at: new Date().toISOString()
      })
      .eq('id', id)
      .select()
      .single();

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error updating video:', { arg1: error });
      }
      throw error;
    }
    
    return data;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error updating video:', { arg1: error });
    }
    throw error;
  }
}

/**
 * Delete a video
 */
export async function deleteVideo(id: string): Promise<boolean> {
  try {
    const { error } = await supabase
      .from('videos')
      .delete()
      .eq('id', id);

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error deleting video:', { arg1: error });
      }
      throw error;
    }
    
    return true;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error deleting video:', { arg1: error });
    }
    throw error;
  }
}

/**
 * Get user's watch progress for a video
 */
export async function getWatchProgress(videoId: string, userId: string): Promise<number> {
  try {
    if (!userId) return 0;

    const { data, error } = await supabase
      .from('watch_progress')
      .select('progress_seconds')
      .eq('user_id', userId)
      .eq('video_id', videoId)
      .single();

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error fetching watch progress:', { arg1: error });
      }
      // Don't throw error for missing watch progress - return 0 instead
      return 0;
    }
    
    return data?.progress_seconds || 0;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error fetching watch progress:', { arg1: error });
    }
    return 0;
  }
}

/**
 * Get all watch progress for a user
 */
export async function getWatchProgressForUser(userId: string): Promise<WatchProgress[]> {
  try {
    if (!userId) return [];

    const { data, error } = await supabase
      .from('watch_progress')
      .select('*')
      .eq('user_id', userId);

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error fetching user watch progress:', { arg1: error });
      }
      return [];
    }
    
    return data || [];
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error getting user watch progress:', { arg1: error });
    }
    return [];
  }
}

/**
 * Update user's watch progress for a video
 */
export async function updateWatchProgress(
  videoId: string,
  progressSeconds: number,
  userId: string
): Promise<void> {
  try {
    if (!userId) return;

    const { error } = await supabase.from('watch_progress').upsert({
      user_id: userId,
      video_id: videoId,
      progress_seconds: progressSeconds,
      updated_at: new Date().toISOString(),
    });

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error updating watch progress:', { arg1: error });
      }
      throw error;
    }
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error updating watch progress:', { arg1: error });
    }
    throw error;
  }
}

/**
 * Check if user has premium subscription
 */
export async function checkPremiumSubscription(): Promise<boolean> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return false;

    const { data, error } = await supabase
      .from('subscriptions')
      .select('is_active, end_date')
      .eq('user_id', user.id)
      .eq('is_active', true)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle(); // Use maybeSingle() to handle no results gracefully

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error checking premium subscription:', { arg1: error });
      }
      return false;
    }

    // No subscription found
    if (!data) return false;

    // Check if subscription is still valid
    if (data.end_date) {
      return new Date(data.end_date) > new Date();
    }

    return data.is_active === true;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error checking premium subscription:', { arg1: error });
    }
    return false;
  }
}

/**
 * Get user's watchlist
 */
export async function getWatchlist(): Promise<Watchlist[]> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return [];

    const { data, error } = await supabase
      .from('watchlist')
      .select('*')
      .eq('user_id', user.id)
      .order('added_at', { ascending: false });

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error fetching watchlist:', { arg1: error });
      }
      return [];
    }
    
    return data || [];
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error fetching watchlist:', { arg1: error });
    }
    return [];
  }
}

/**
 * Add video to watchlist
 */
export async function addToWatchlist(videoId: string): Promise<Watchlist> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      .from('watchlist')
      .insert({
        user_id: user.id,
        video_id: videoId,
        added_at: new Date().toISOString()
      })
      .select()
      .single();

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error adding to watchlist:', { arg1: error });
      }
      throw error;
    }
    
    return data;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error adding to watchlist:', { arg1: error });
    }
    throw error;
  }
}

/**
 * Remove video from watchlist
 */
export async function removeFromWatchlist(videoId: string): Promise<boolean> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('User not authenticated');

    const { error } = await supabase
      .from('watchlist')
      .delete()
      .eq('user_id', user.id)
      .eq('video_id', videoId);

    if (error) {
      if (import.meta.env.DEV) {
        logger.api('Error removing from watchlist:', { arg1: error });
      }
      throw error;
    }
    
    return true;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error removing from watchlist:', { arg1: error });
    }
    throw error;
  }
}

export async function fetchApi(endpoint: string, options?: RequestInit): Promise<unknown> {
  const res = await fetch(endpoint, { credentials: 'include', ...options });
  if (!res.ok) throw new Error(`${res.status}: ${res.statusText}`);
  return res.headers.get('content-type')?.includes('application/json') ? res.json() : res.text();
}