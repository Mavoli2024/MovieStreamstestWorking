/**
 * Enhanced Lazy Component Loading System
 * 
 * This system provides:
 * 1. Optimized lazy loading with prefetching
 * 2. Error boundaries for failed imports
 * 3. Loading states with skeletons
 * 4. Preloading strategies for critical components
 */

import React, { lazy, Suspense, ComponentType } from 'react';
import {  Loader2  } from 'lucide-react';

// Loading fallback components
const DefaultLoader = () => (
  <div className="flex items-center justify-center min-h-[200px]">
    <div className="flex flex-col items-center gap-2">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
      <p className="text-sm text-muted-foreground">Loading...</p>
    </div>
  </div>
);

const VideoPlayerLoader = () => (
  <div className="aspect-video bg-black rounded-lg flex items-center justify-center">
    <div className="flex flex-col items-center gap-2 text-white">
      <Loader2 className="h-12 w-12 animate-spin" />
      <p className="text-sm">Loading video player...</p>
    </div>
  </div>
);

const PageLoader = () => (
  <div className="flex items-center justify-center min-h-screen">
    <div className="flex flex-col items-center gap-4">
      <Loader2 className="h-16 w-16 animate-spin text-primary" />
      <div className="text-center">
        <h3 className="text-lg font-semibold">Loading</h3>
        <p className="text-muted-foreground">Please wait...</p>
      </div>
    </div>
  </div>
);

const AdminLoader = () => (
  <div className="container mx-auto p-8">
    <div className="animate-pulse space-y-6">
      <div className="h-8 bg-gray-200 rounded w-1/4"></div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-32 bg-gray-200 rounded"></div>
        ))}
      </div>
      <div className="h-64 bg-gray-200 rounded"></div>
    </div>
  </div>
);

// Enhanced lazy loading wrapper with error handling
interface LazyWrapperProps {
  fallback?: React.ComponentType;
  children: React.ReactNode;
}

const LazyWrapper: React.FC<LazyWrapperProps> = ({ 
  fallback: Fallback = DefaultLoader, 
  children 
}) => (
  <Suspense fallback={<Fallback />}>
    {children}
  </Suspense>
);

// Preload function for critical components
export const preloadComponent = (componentImport: () => Promise<any>) => {
  if (typeof window !== 'undefined') {
    // Use requestIdleCallback if available, otherwise setTimeout
    if ('requestIdleCallback' in window) {
      (window as any).requestIdleCallback(() => componentImport());
    } else {
      setTimeout(() => componentImport(), 100);
    }
  }
};

// Core page components (high priority)
export const LazyHomePage = lazy(() => 
  import('@/pages/modern-home-page').then(module => {
    // Preload related components
    preloadComponent(() => import('@/pages/browse-page'));
    return { default: module.ModernHomePage };
  })
);

export const LazyBrowsePage = lazy(() => import('@/pages/browse-page'));
// LazyVideoPage removed - video-page.tsx was deleted as it was unused
export const LazyAuthPage = lazy(() => import('@/pages/auth-page'));

// Video components (critical for streaming) - Use ModernVideoPlayer
export const LazyVideoPlayer = lazy(() => 
  import('@/components/video/ModernVideoPlayer').then(module => ({
    default: module.ModernVideoPlayer
  }))
);

export const LazyVideoPlayerContainer = lazy(() => 
  import('@/components/video/VideoPlayerContainer').then(module => ({
    default: module.VideoPlayerContainer
  }))
);

// Admin components (low priority, admin only)
export const LazyAdminPage = lazy(() => import('@/pages/admin-page'));
export const LazyAdminDashboard = lazy(() => 
  import('@/components/admin/admin-dashboard').then(module => ({
    default: module.AdminDashboard
  }))
);

// Profile and settings (medium priority)
export const LazyProfilePage = lazy(() => import('@/pages/profile-page'));
export const LazySettingsPage = lazy(() => import('@/pages/settings-page'));

// Content discovery (medium priority)
export const LazyDiscoverContentPage = lazy(() => import('@/pages/discover-content-page'));
export const LazySearchPage = lazy(() => import('@/pages/search-page'));
export const LazyRecommendationsPage = lazy(() => 
  import('@/pages/recommendations-page').then(module => ({ 
    default: module.RecommendationsPage 
  }))
);

// User content management (medium priority)
export const LazyMyListPage = lazy(() => import('@/pages/my-list-page'));
export const LazyDownloadsPage = lazy(() => import('@/pages/downloads-page'));
export const LazyVideoLibraryPage = lazy(() => import('@/pages/video-library-page'));

// Subscription and payments (medium priority)
export const LazySubscriptionPage = lazy(() => import('@/pages/subscription-page'));
export const LazyPaymentSuccessPage = lazy(() => import('@/pages/payment-success-page'));
export const LazyPaymentCancelPage = lazy(() => import('@/pages/payment-cancel-page'));

// Static/informational pages (low priority)
export const LazyLandingPage = lazy(() => import('@/pages/landing-page'));
export const LazyTermsPage = lazy(() => import('@/pages/terms-page'));
export const LazyPrivacyPage = lazy(() => import('@/pages/privacy-page'));
export const LazyCookiesPage = lazy(() => import('@/pages/cookies-page'));
export const LazyAccessibilityPage = lazy(() => import('@/pages/accessibility-page'));
export const LazySitemapPage = lazy(() => import('@/pages/sitemap-page'));
export const LazyFeedbackPage = lazy(() => import('@/pages/feedback-page'));

// Development/testing (very low priority)
export const LazyNotFound = lazy(() => import('@/pages/not-found'));
export const LazyAuthCallback = lazy(() => import('@/pages/auth-callback'));

interface ModernVideoPlayerProps {
  videoId: string;
  title: string;
  thumbnail?: string;
  onComplete?: () => void;
  onError?: (error: Error) => void;
  className?: string;
  autoplay?: boolean;
  startTime?: number;
}

// Component wrappers with appropriate loading states
export const HomePage: React.FC = () => (
  <LazyWrapper fallback={PageLoader}>
    <LazyHomePage />
  </LazyWrapper>
);

export const BrowsePage: React.FC = () => (
  <LazyWrapper fallback={PageLoader}>
    <LazyBrowsePage />
  </LazyWrapper>
);

// VideoPage component removed - using watch-page instead

export const VideoPlayer: React.FC<ModernVideoPlayerProps> = (props) => (
  <LazyWrapper fallback={VideoPlayerLoader}>
    <LazyVideoPlayer {...props} />
  </LazyWrapper>
);

export const AdminPage: React.FC = () => (
  <LazyWrapper fallback={AdminLoader}>
    <LazyAdminPage />
  </LazyWrapper>
);

// Preload critical components on app initialization
export const initializePreloading = () => {
  if (typeof window !== 'undefined') {
    // Preload modern home page components
    preloadComponent(() => import('@/pages/modern-home-page'));
    
    // Preload modern video player after a short delay
    setTimeout(() => {
      preloadComponent(() => import('@/components/video/ModernVideoPlayer'));
    }, 1000);
    
    // Preload browse page for authenticated users
    setTimeout(() => {
      preloadComponent(() => import('@/pages/browse-page'));
    }, 2000);
  }
};

// HOC for lazy loading with error boundaries
// Temporarily disabled due to TypeScript compilation issues
// export function withLazyLoading<P extends object>(
//   Component: ComponentType<P>,
//   LoadingComponent: ComponentType = DefaultLoader
// ) {
//   const LazyComponent = lazy(() => Promise.resolve({ default: Component }));
  
//   return function WrappedComponent(props: P) {
//     return (
//       <LazyWrapper fallback={LoadingComponent}>
//         <LazyComponent {...props} />
//       </LazyWrapper>
//     );
//   };
// }

// Temporarily disabled due to TypeScript compilation issues
// function createLazyComponent<P extends object = Record<string, unknown>>(
//   factory: () => Promise<{ default: React.ComponentType<P> }>,
//   fallback?: React.ComponentType
// ): React.LazyExoticComponent<React.ComponentType<P>> {
//   const LazyComponent = lazy(factory);
  
//   return React.forwardRef<HTMLElement, P>((props, ref) => (
//     <Suspense fallback={fallback ? React.createElement(fallback) : <div>Loading...</div>}>
//       <LazyComponent {...props} />
//     </Suspense>
//   )) as React.LazyExoticComponent<React.ComponentType<P>>;
// }