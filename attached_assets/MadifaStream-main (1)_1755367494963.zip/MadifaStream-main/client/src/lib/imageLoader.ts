/**
 * Advanced image loading utilities to improve performance
 */

// Keep track of preloaded images to avoid redundant loads
const preloadedImages = new Set<string>();
const failedImages = new Set<string>();

/**
 * Preload an image to make it instantly available when needed
 * @param src Image source URL
 * @returns Promise that resolves when the image is loaded or rejects on error
 */
export function preloadImage(src: string): Promise<HTMLImageElement> {
  // Skip if already preloaded or previously failed
  if (preloadedImages.has(src) || failedImages.has(src)) {
    return Promise.resolve(new Image());
  }

  return new Promise((resolve, reject) => {
    const img = new Image();
    
    img.onload = () => {
      preloadedImages.add(src);
      resolve(img);
    };
    
    img.onerror = () => {
      failedImages.add(src);
      reject(new Error(`Failed to load image: ${src}`));
    };
    
    img.src = src;
  });
}

/**
 * Preload multiple images in parallel
 * @param sources Array of image URLs to preload
 * @returns Promise that resolves when all images are loaded
 */
export function preloadImages(sources: string[]): Promise<HTMLImageElement[]> {
  return Promise.all(sources.map(src => preloadImage(src).catch(() => new Image())));
}

/**
 * Check if an image exists and can be loaded
 * @param src Image source URL
 * @returns Promise that resolves to true if image exists, false otherwise
 */
export function checkImageExists(src: string): Promise<boolean> {
  if (preloadedImages.has(src)) return Promise.resolve(true);
  if (failedImages.has(src)) return Promise.resolve(false);
  
  return preloadImage(src)
    .then(() => true)
    .catch(() => false);
}

/**
 * Generate SVG placeholder with specified dimensions and text
 * @param width Width of the placeholder
 * @param height Height of the placeholder
 * @param text Text to display in the placeholder
 * @param bgColor Background color
 * @returns SVG image as a data URL
 */
export function generatePlaceholderSVG(
  width= 320, 
  height= 180, 
  text= 'Image', 
  bgColor= '#f0f0f0'
): string {
  const svg = `
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <rect width="100%" height="100%" fill="${bgColor}" />
      <text 
        x="50%" 
        y="50%" 
        font-family="Arial, sans-serif" 
        font-size="16" 
        fill="#666" 
        text-anchor="middle" 
        dominant-baseline="middle"
      >
        ${text}
      </text>
    </svg>
  `;
  
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

/**
 * Calculate the ideal image dimensions based on the device's screen size and pixel density
 * @param width Original width
 * @param height Original height
 * @returns Optimized dimensions
 */
export function getOptimizedDimensions(width: number, height: number): { width: number, height: number } {
  const pixelRatio = window.devicePixelRatio || 1;
  const screenWidth = window.innerWidth;
  
  // If the image is larger than the screen, scale it down
  if (width > screenWidth) {
    const scaleFactor = screenWidth / width;
    return {
      width: Math.round(width * scaleFactor),
      height: Math.round(height * scaleFactor)
    };
  }
  
  // For high-density displays, provide higher resolution images
  if (pixelRatio > 1) {
    return {
      width: Math.round(width * pixelRatio),
      height: Math.round(height * pixelRatio)
    };
  }
  
  return { width, height };
}

/**
 * Clear the preloaded image cache
 * Useful when needing to free up memory
 */
export function clearImageCache(): void {
  preloadedImages.clear();
  failedImages.clear();
}