/**
 * Form Validation Library
 * 
 * A collection of reusable validation schemas and helper functions
 * for consistent form validation across the application.
 */

import * as z from 'zod';
import {  ZodError  } from 'zod';

/**
 * Common validation patterns
 */
const validationPatterns = {
  // Password must contain at least 8 characters, 1 uppercase, 1 lowercase, and 1 number
  password: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d\w\W]{8,}$/,
  
  // South African phone number format (optional +27 prefix)
  saPhoneNumber: /^(\+27|0)[6-8][0-9]{8}$/,
  
  // Basic URL validation
  url: /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([/\w .-]*)*\/?$/,
  
  // Basic email validation (Zod has built-in email validation but this can be used as a pre-check)
  email: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/
};

/**
 * Error messages for validation failures
 */
export const validationMessages = {
  required: 'This field is required',
  email: 'Please enter a valid email address',
  password: 'Password must be at least 8 characters with uppercase, lowercase & numbers',
  passwordMatch: 'Passwords do not match',
  phoneNumber: 'Please enter a valid South African phone number',
  termsAccepted: 'You must accept the terms to continue',
  minLength: (min: number) => `Must be at least ${min} characters`,
  maxLength: (max: number) => `Cannot exceed ${max} characters`,
  invalidUrl: 'Please enter a valid URL',
  invalidDate: 'Please enter a valid date',
  invalidNumber: 'Please enter a valid number',
  minimumAge: (age: number) => `You must be at least ${age} years old`,
  invalidCode: 'Please enter a valid verification code'
};

/**
 * Authentication schemas
 */
export const authSchemas = {
  /**
   * Login form schema
   */
  loginSchema: z.object({
    email: z.string()
      .min(1, { message: validationMessages.required })
      .email({ message: validationMessages.email }),
    password: z.string()
      .min(1, { message: validationMessages.required }),
    rememberMe: z.boolean().optional()
  }),

  /**
   * Registration form schema
   */
  registerSchema: z.object({
    email: z.string()
      .min(1, { message: validationMessages.required })
      .email({ message: validationMessages.email }),
    password: z.string()
      .min(8, { message: validationMessages.minLength(8) })
      .regex(validationPatterns.password, { message: validationMessages.password }),
    confirmPassword: z.string()
      .min(1, { message: validationMessages.required }),
    username: z.string()
      .min(3, { message: validationMessages.minLength(3) })
      .max(30, { message: validationMessages.maxLength(30) })
      .optional(),
    agreeTerms: z.literal(true, {
      errorMap: () => ({ message: validationMessages.termsAccepted })
    }),
    role: z.enum(['user', 'admin']).optional()
  }).refine((data) => data.password === data.confirmPassword, {
    message: validationMessages.passwordMatch,
    path: ['confirmPassword']
  }),

  /**
   * Password reset request schema
   */
  resetPasswordRequestSchema: z.object({
    email: z.string()
      .min(1, { message: validationMessages.required })
      .email({ message: validationMessages.email })
  }),

  /**
   * Password reset confirmation schema
   */
  resetPasswordConfirmSchema: z.object({
    password: z.string()
      .min(8, { message: validationMessages.minLength(8) })
      .regex(validationPatterns.password, { message: validationMessages.password }),
    confirmPassword: z.string()
      .min(1, { message: validationMessages.required })
  }).refine((data) => data.password === data.confirmPassword, {
    message: validationMessages.passwordMatch,
    path: ['confirmPassword']
  })
};

/**
 * Profile schemas
 */
export const profileSchemas = {
  /**
   * Profile update schema
   */
  profileUpdateSchema: z.object({
    username: z.string()
      .min(3, { message: validationMessages.minLength(3) })
      .max(30, { message: validationMessages.maxLength(30) })
      .optional(),
    displayName: z.string()
      .max(50, { message: validationMessages.maxLength(50) })
      .optional(),
    avatarColor: z.string().optional(),
    role: z.enum(['user', 'admin']).optional()
  }),

  /**
   * Change password schema
   */
  changePasswordSchema: z.object({
    currentPassword: z.string()
      .min(1, { message: validationMessages.required }),
    newPassword: z.string()
      .min(8, { message: validationMessages.minLength(8) })
      .regex(validationPatterns.password, { message: validationMessages.password }),
    confirmNewPassword: z.string()
      .min(1, { message: validationMessages.required })
  }).refine((data) => data.newPassword === data.confirmNewPassword, {
    message: validationMessages.passwordMatch,
    path: ['confirmNewPassword']
  })
};

/**
 * Payment and subscription schemas
 */
export const paymentSchemas = {
  /**
   * Card payment schema (if implementing direct card payments)
   */
  cardPaymentSchema: z.object({
    cardNumber: z.string()
      .min(1, { message: validationMessages.required })
      .regex(/^[0-9]{16}$/, { message: 'Please enter a valid 16-digit card number' }),
    expiryMonth: z.string()
      .min(1, { message: validationMessages.required })
      .regex(/^(0[1-9]|1[0-2])$/, { message: 'Please enter a valid month (01-12)' }),
    expiryYear: z.string()
      .min(1, { message: validationMessages.required })
      .regex(/^[0-9]{2}$/, { message: 'Please enter a valid 2-digit year' }),
    cvv: z.string()
      .min(1, { message: validationMessages.required })
      .regex(/^[0-9]{3,4}$/, { message: 'Please enter a valid CVV code' }),
    nameOnCard: z.string()
      .min(1, { message: validationMessages.required })
  }),

  /**
   * Subscription selection schema
   */
  subscriptionSelectionSchema: z.object({
    planId: z.number({
      required_error: 'Please select a subscription plan',
      invalid_type_error: 'Invalid plan selection'
    }),
    acceptTerms: z.literal(true, {
      errorMap: () => ({ message: 'You must accept the subscription terms' })
    })
  })
};

/**
 * Helper function to handle validation errors more gracefully
 * @param error The error object from the catch block
 * @returns An object with field-specific error messages
 */
export function handleValidationError(error: unknown): Record<string, string> {
  const errors: Record<string, string> = {};
  
  if (error instanceof ZodError) {
    // Extract field-specific error messages from Zod error
    error.errors.forEach((err) => {
      if (err.path.length > 0) {
        const fieldName = err.path.join('.');
        errors[fieldName] = err.message;
      }
    });
  } else if (error instanceof Error) {
    // For non-Zod errors, put a generic message in a special key
    errors['_form'] = error.message || 'An unexpected error occurred';
  } else {
    errors['_form'] = 'An unexpected error occurred';
  }
  
  return errors;
}

/**
 * Types for the validation schemas
 */
export type LoginFormValues = z.infer<typeof authSchemas.loginSchema>;
export type RegisterFormValues = z.infer<typeof authSchemas.registerSchema>;
export type ResetPasswordRequestValues = z.infer<typeof authSchemas.resetPasswordRequestSchema>;
export type ResetPasswordConfirmValues = z.infer<typeof authSchemas.resetPasswordConfirmSchema>;
export type ProfileUpdateValues = z.infer<typeof profileSchemas.profileUpdateSchema>;
export type ChangePasswordValues = z.infer<typeof profileSchemas.changePasswordSchema>;
export type CardPaymentValues = z.infer<typeof paymentSchemas.cardPaymentSchema>;
export type SubscriptionSelectionValues = z.infer<typeof paymentSchemas.subscriptionSelectionSchema>;