/**
 * Type compatibility utilities to help resolve TypeScript errors between
 * Supabase generated types and our schema types
 */
import type { Database } from "@/types/database-generated.types";
import { type Video } from '@shared/schema';

// Define createPartialVideo here instead of importing it to avoid path issues
function createPartialVideo(data: Partial<any>): unknown {
  return {
    id: data.id || `temp-${Date.now()}`,
    title: data.title || '',
    description: data.description || '',
    thumbnail_url: data.thumbnail_url || '',
    video_url: data.video_url || '',
    trailer_url: data.trailer_url || null,
    release_year: data.release_year || new Date().getFullYear(),
    duration: data.duration || 0,
    age_rating: data.age_rating || '',
    genres: data.genres || [],
    cast: data.cast || null,
    director: data.director || null,
    created_at: data.created_at || new Date().toISOString(),
    is_trailer: data.is_trailer || false,
    collection_id: data.collection_id || null,
    collection_name: data.collection_name || null,
    views: data.views || 0,
    is_premium: data.is_premium || false,
    ...data
  };
}

// Type aliases for Supabase generated types
export type SupabaseVideo = Database['public']['Tables']['videos']['Row'];
export type SupabaseCategory = Database['public']['Tables']['categories']['Row'];
export type SupabaseWatchProgress = Database['public']['Tables']['watch_progress']['Row'];
export type SupabaseWatchlist = Database['public']['Tables']['watchlist']['Row'];
export type SupabaseProfile = Database['public']['Tables']['profiles']['Row'];

/**
 * Convert BunnyStream video data to a format compatible with our Video type
 * This helps with type errors when displaying BunnyStream videos in components
 * that expect our schema Video type
 */
export function adaptBunnyVideoToApp(bunnyVideo: any): Video {
  return {
    id: `bunny-${bunnyVideo.guid}`,
    title: bunnyVideo.title || "",
    description: bunnyVideo.description || "",
    video_url: bunnyVideo.directPlayUrl || `https://iframe.mediadelivery.net/embed/425043/${bunnyVideo.guid}`,
    thumbnail_url: bunnyVideo.thumbnailUrl || `https://vz-f5c9bae3-d51.b-cdn.net/${bunnyVideo.guid}/thumbnail.jpg`,
    duration: bunnyVideo.length ? bunnyVideo.length * 60 : 0, // Convert to seconds
    release_year: bunnyVideo.dateUploaded ? new Date(bunnyVideo.dateUploaded).getFullYear() : new Date().getFullYear(),
    created_at: bunnyVideo.dateUploaded ? new Date(bunnyVideo.dateUploaded) : new Date(),
    collection_id: bunnyVideo.collectionId || null,
    collection_name: bunnyVideo.collection || null,
    views: bunnyVideo.views || 0,
    is_premium: false,
    genres: [], // Use genres instead of tags (matches schema)
  } as Video;
}

/**
 * Safely access properties that might be null/undefined
 * This helps avoid TypeScript errors with optional chaining
 */
export function safeGet<T, K extends keyof T>(obj: T | null | undefined, key: K): T[K] | undefined {
  return obj ? obj[key] : undefined;
}

/**
 * Type assertion helper for components
 * Use this when TypeScript can't infer the correct type
 */
export function asVideoType(video: unknown): SupabaseVideo {
  return video as SupabaseVideo;
}

/**
 * Create an empty watchlist item for type compatibility
 */
export function createEmptyWatchlistItem(userId: string, videoId: string): SupabaseWatchlist {
  return {
    id: `temp-${Date.now()}`,
    user_id: userId,
    video_id: videoId,
    added_at: new Date().toISOString()
  } as SupabaseWatchlist;
}

/**
 * Create an empty watch progress item for type compatibility
 */
export function createEmptyWatchProgress(userId: string, videoId: string): SupabaseWatchProgress {
  return {
    id: `temp-${Date.now()}`,
    video_id: videoId,
    user_id: userId,
    progress_seconds: 0,
    updated_at: new Date().toISOString(),
    completed: false,
  } as any;
}
