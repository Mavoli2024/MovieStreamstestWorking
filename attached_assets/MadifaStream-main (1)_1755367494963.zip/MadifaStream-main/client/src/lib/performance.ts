/**
 * Global performance optimization utilities
 * Implements efficient resource loading, memory management, and rendering optimizations
 */

/**
 * Defers non-critical JavaScript execution
 * @param callback Function to execute after the main thread is idle
 */
export function deferExecution(callback: () => void): void {
  if ('requestIdleCallback' in window) {
    window.requestIdleCallback(() => callback());
  } else {
    setTimeout(callback, 1);
  }
}

/**
 * Optimizes image loading with proper sizing and formats
 * @param src Source URL of the image
 * @param width Desired width of the image
 * @param height Desired height of the image
 * @param _format Image format (webp, avif, etc.)
 */
export function optimizedImageUrl(
  src: string,
  width?: number,
  height?: number,
  _format: 'webp' | 'avif' | 'original' = 'webp'
): string {
  if (!src) return '';
  
  // Handle SVG files - return as is (they're already optimized)
  if (src.endsWith('.svg')) return src;
  
  // For absolute URLs, return as is (likely external CDN with their own optimization)
  if (src.startsWith('http')) return src;
  
  // For local assets, add correct path prefix
  const fullPath = src.startsWith('/') ? src : `/${src}`;
  
  // In production, we'd add query params for resizing and format conversion
  return fullPath;
}

/**
 * Safely accesses deeply nested objects to prevent null errors
 * @param obj Object to safely access
 * @param path Path to access in dot notation (e.g., 'user.profile.name')
 * @param defaultValue Value to return if path does not exist
 */
export function safeGet<T>(obj: unknown, path: string, defaultValue: T): T {
  const keys = path.split('.');
  let result = obj;
  
  for (const key of keys) {
    if (result === null || result === undefined) {
      return defaultValue;
    }
    result = result[key];
  }
  
  return (result === undefined || result === null) ? defaultValue : result as T;
}

/**
 * Throttles function calls to limit execution frequency
 * @param func Function to throttle
 * @param limit Time limit in milliseconds
 */
export function throttle<T extends (...args: unknown[]) => any>(func: T, limit: number): (...args: Parameters<T>) => void {
  let inThrottle = false;
  
  return function(...args: Parameters<T>): void {
    if (!inThrottle) {
      func(...args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

/**
 * Creates an optimized infinite scroll manager for large data sets
 * @param loadMore Function to load more data
 * @param options Configuration options
 */
export function createInfiniteScroll(
  loadMore: () => Promise<void>,
  options: {
    threshold?: number;
    rootMargin?: string;
    disabled?: boolean;
  } = {}
): { 
  observerRef: (node: Element | null) => void;
  disconnect: () => void;
} {
  const threshold = options.threshold || 0.5;
  const rootMargin = options.rootMargin || '100px';
  let observer: IntersectionObserver | null = null;
  let loading = false;
  
  const observerRef = (node: Element | null) => {
    if (options.disabled) return;
    
    if (observer) {
      observer.disconnect();
    }
    
    if (!node) return;
    
    observer = new IntersectionObserver(
      async ([entry]) => {
        if (entry?.isIntersecting && !loading) {
          loading = true;
          await loadMore();
          loading = false;
        }
      },
      { threshold, rootMargin }
    );
    
    observer.observe(node);
  };
  
  const disconnect = () => {
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  };
  
  return { observerRef, disconnect };
}