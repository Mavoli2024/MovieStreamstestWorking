import { logger } from '@shared/logger';
/**
 * Enhanced Bunny Stream Client
 * 
 * A client for interacting with Bunny Stream services with:
 * - Improved error handling
 * - Retry mechanisms
 * - Graceful degradation
 * - Detailed error logging
 */

// Get environment variables
// Unused constants removed
const SECURE_API_ENDPOINT = '/api/secure-bunny';

// Types for Bunny Stream responses
export interface BunnyStreamVideo {
  guid: string;
  title: string;
  description?: string;
  collectionId?: string;
  thumbnailFileName?: string;
  dateUploaded: string;
  views?: number;
  length?: number;
  status?: string;
  framerate?: number;
  width?: number;
  height?: number;
}

export interface BunnyStreamCollection {
  id: string;
  name: string;
  videoCount: number;
}

// Error types for Bunny Stream
export enum BunnyStreamErrorType {
  NETWORK = 'network',
  AUTHENTICATION = 'authentication',
  NOT_FOUND = 'not_found',
  SERVER = 'server',
  RATE_LIMIT = 'rate_limit',
  PERMISSION = 'permission',
  VALIDATION = 'validation',
  UNKNOWN = 'unknown'
}

// Custom error class for Bunny Stream errors
export class BunnyStreamError extends Error {
  type: BunnyStreamErrorType;
  status?: number;
  retryable: boolean;
  
  constructor(
    message: string, 
    type: BunnyStreamErrorType = BunnyStreamErrorType.UNKNOWN, 
    status?: number
  ) {
    super(message);
    this.name = 'BunnyStreamError';
    this.type = type;
    this.status = status;
    
    // Determine if error is retryable
    this.retryable = [
      BunnyStreamErrorType.NETWORK,
      BunnyStreamErrorType.SERVER,
      BunnyStreamErrorType.RATE_LIMIT
    ].includes(type);
  }
}

/**
 * Creates a direct stream URL for a video
 * @param videoId The Bunny Stream video GUID
 * @returns Direct stream URL
 */
export function getDirectStreamUrl(videoId: string): string {
  if (!videoId) return '';
  // Delegate to backend to generate secure tokenised stream URL
  return `/api/videos/${videoId}/stream`; // Backend should handle redirect/token
}

/**
 * Creates a thumbnail URL for a video
 * @param videoId The Bunny Stream video GUID
 * @param fileName Optional thumbnail filename (default: 'thumbnail.jpg')
 * @returns Thumbnail URL
 */
export function getThumbnailUrl(videoId: string, fileName= 'thumbnail.jpg'): string {
  if (!videoId) return '';
  
  // Use the server proxy to avoid CORS issues
  return `https://vz-f5c9bae3-d51.b-cdn.net/${videoId}/thumbnail.jpg`;
}

/**
 * Main Bunny Stream client with error handling
 */
export const BunnyStreamClient = {
  /**
   * Fetch videos from Bunny Stream
   * @param page Page number (default: 1)
   * @param perPage Items per page (default: 20)
   * @param retries Number of retries on failure (default: 2)
   * @returns List of videos
   */
  async getVideos(page= 1, perPage= 20, retries= 2): Promise<BunnyStreamVideo[]> {
    try {
      const response = await fetch(`${SECURE_API_ENDPOINT}/videos?page=${page}&perPage=${perPage}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw await handleErrorResponse(response);
      }
      
      const data = await response.json();
      return data.items || [];
      
    } catch (error) {
      if (error instanceof BunnyStreamError && error.retryable && retries > 0) {
        if (import.meta.env.DEV) {
          logger.api(`Retrying Bunny Stream videos fetch (${retries} retries left)...`);
        }
        // Exponential backoff: wait longer between retries
        await new Promise(resolve => setTimeout(resolve, (3 - retries) * 1000));
        return this.getVideos(page, perPage, retries - 1);
      }
      
      if (import.meta.env.DEV) {
        logger.api('Failed to fetch Bunny Stream videos:', { arg1: error });
      }
      handleClientError(error);
      return []; // Return empty array as fallback
    }
  },
  
  /**
   * Fetch a single video's metadata
   * @param videoId The Bunny Stream video GUID
   * @param retries Number of retries on failure (default: 2)
   * @returns Video metadata or null if not found
   */
  async getVideo(videoId: string, retries= 2): Promise<BunnyStreamVideo | null> {
    if (!videoId) {
      throw new BunnyStreamError(
        'Video ID is required', 
        BunnyStreamErrorType.VALIDATION
      );
    }
    
    try {
      const response = await fetch(`${SECURE_API_ENDPOINT}/videos/${videoId}`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw await handleErrorResponse(response);
      }
      
      return response.json();
      
    } catch (error) {
      if (error instanceof BunnyStreamError && error.retryable && retries > 0) {
        if (import.meta.env.DEV) {
          logger.api(`Retrying Bunny Stream video fetch (${retries} retries left)...`);
        }
        await new Promise(resolve => setTimeout(resolve, (3 - retries) * 1000));
        return this.getVideo(videoId, retries - 1);
      }
      
      if (import.meta.env.DEV) {
        logger.api(`Failed to fetch Bunny Stream video ${videoId}:`, { arg1: error });
      }
      handleClientError(error);
      return null;
    }
  },
  
  /**
   * Check if a video is playable
   * @param videoId The Bunny Stream video GUID
   * @returns Promise resolving to boolean indicating if video is playable
   */
  async isVideoPlayable(videoId: string): Promise<boolean> {
    if (!videoId) return false;
    
    try {
      const streamUrl = getDirectStreamUrl(videoId);
      const response = await fetch(streamUrl, { method: 'HEAD' });
      return response.ok;
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.api(`Video ${videoId} playability check failed:`, { arg1: error });
      }
      return false;
    }
  },
  
  /**
   * Fetch collections from Bunny Stream
   * @param retries Number of retries on failure (default: 2)
   * @returns List of collections
   */
  async getCollections(retries= 2): Promise<BunnyStreamCollection[]> {
    try {
      const response = await fetch(`${SECURE_API_ENDPOINT}/collections`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw await handleErrorResponse(response);
      }
      
      const data = await response.json();
      return data.items || [];
      
    } catch (error) {
      if (error instanceof BunnyStreamError && error.retryable && retries > 0) {
        if (import.meta.env.DEV) {
          logger.api(`Retrying Bunny Stream collections fetch (${retries} retries left)...`);
        }
        await new Promise(resolve => setTimeout(resolve, (3 - retries) * 1000));
        return this.getCollections(retries - 1);
      }
      
      if (import.meta.env.DEV) {
        logger.api('Failed to fetch Bunny Stream collections:', { arg1: error });
      }
      handleClientError(error);
      return []; // Return empty array as fallback
    }
  },
  
  /**
   * Fetch videos in a collection
   * @param collectionId The collection ID
   * @param retries Number of retries on failure (default: 2)
   * @returns List of videos in the collection
   */
  async getVideosInCollection(collectionId: string, retries= 2): Promise<BunnyStreamVideo[]> {
    if (!collectionId) {
      throw new BunnyStreamError(
        'Collection ID is required', 
        BunnyStreamErrorType.VALIDATION
      );
    }
    
    try {
      const response = await fetch(`${SECURE_API_ENDPOINT}/collections/${collectionId}/videos`, {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw await handleErrorResponse(response);
      }
      
      const data = await response.json();
      return data.items || [];
      
    } catch (error) {
      if (error instanceof BunnyStreamError && error.retryable && retries > 0) {
        if (import.meta.env.DEV) {
          logger.api(`Retrying collection videos fetch (${retries} retries left)...`);
        }
        await new Promise(resolve => setTimeout(resolve, (3 - retries) * 1000));
        return this.getVideosInCollection(collectionId, retries - 1);
      }
      
      if (import.meta.env.DEV) {
        logger.api(`Failed to fetch videos in collection ${collectionId}:`, { arg1: error });
      }
      handleClientError(error);
      return []; // Return empty array as fallback
    }
  }
};

/**
 * Helper to handle API error responses
 */
async function handleErrorResponse(response: Response): Promise<BunnyStreamError> {
  let errorType = BunnyStreamErrorType.UNKNOWN;
  let errorMessage = 'An unknown error occurred';
  
  try {
    const errorData = await response.json();
    errorMessage = errorData.message || errorData.error || 'An error occurred with Bunny Stream';
  } catch {
    errorMessage = `Bunny Stream API error (${response.status}): ${response.statusText}`;
  }
  
  // Determine error type based on status code
  switch (response.status) {
    case 401:
    case 403:
      errorType = BunnyStreamErrorType.AUTHENTICATION;
      break;
    case 404:
      errorType = BunnyStreamErrorType.NOT_FOUND;
      break;
    case 429:
      errorType = BunnyStreamErrorType.RATE_LIMIT;
      break;
    case 400:
    case 422:
      errorType = BunnyStreamErrorType.VALIDATION;
      break;
    case 500:
    case 502:
    case 503:
    case 504:
      errorType = BunnyStreamErrorType.SERVER;
      break;
    default:
      if (response.status >= 500) {
        errorType = BunnyStreamErrorType.SERVER;
      } else if (response.status >= 400) {
        errorType = BunnyStreamErrorType.UNKNOWN;
      }
  }
  
  return new BunnyStreamError(errorMessage, errorType, response.status);
}

/**
 * Helper to handle client-side errors
 */
function handleClientError(error: unknown): void {
  if (error instanceof BunnyStreamError) {
    // Already handled
    return;
  }
  
  // Handle network errors
  if (error instanceof TypeError && error.message.includes('network')) {
    if (import.meta.env.DEV) {
      logger.api('Bunny Stream network error:', { arg1: error });
    }
    // Could dispatch to error tracking service here
    return;
  }
  
  // Handle other errors
  if (import.meta.env.DEV) {
    logger.api('Bunny Stream client error:', { arg1: error });
  }
  // Could dispatch to error tracking service here
}