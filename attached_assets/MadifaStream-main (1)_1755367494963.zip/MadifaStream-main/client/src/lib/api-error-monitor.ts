import * as Sentry from '@sentry/react';

export interface ApiError {
  message: string;
  status?: number;
  endpoint?: string;
  method?: string;
  timestamp: number;
  retryCount?: number;
  userId?: string;
}

export class ApiErrorMonitor {
  private static instance: ApiErrorMonitor;
  private errorQueue: ApiError[] = [];
  private maxQueueSize = 100;

  static getInstance(): ApiErrorMonitor {
    if (!ApiErrorMonitor.instance) {
      ApiErrorMonitor.instance = new ApiErrorMonitor();
    }
    return ApiErrorMonitor.instance;
  }

  /**
   * Monitor and report API errors to Sentry
   */
  captureApiError(error: ApiError): void {
    // Add to local queue for analysis
    this.addToQueue(error);

    // Send to Sentry with rich context
    Sentry.withScope(scope => {
      // Set error tags
      scope.setTag('error.type', 'api');
      scope.setTag('error.api.status', error.status || 'unknown');
      scope.setTag('error.api.endpoint', error.endpoint || 'unknown');
      scope.setTag('error.api.method', error.method || 'unknown');
      
      // Set error level based on status code
      if (error.status && error.status >= 500) {
        scope.setLevel('error');
      } else if (error.status && error.status >= 400) {
        scope.setLevel('warning');
      } else {
        scope.setLevel('info');
      }

      // Add contextual information
      scope.setContext('api_error', {
        endpoint: error.endpoint,
        method: error.method,
        status: error.status,
        timestamp: error.timestamp,
        retryCount: error.retryCount,
        userId: error.userId,
        userAgent: navigator.userAgent,
        url: window.location.href,
      });

      // Add fingerprint for grouping similar errors
      scope.setFingerprint([
        error.endpoint || 'unknown',
        error.method || 'unknown',
        String(error.status || 'unknown'),
      ]);

      // Capture the error
      Sentry.captureException(new Error(error.message));
    });
  }

  /**
   * Monitor fetch requests and automatically capture errors
   */
  monitorFetch(): void {
    const originalFetch = window.fetch;
    
    window.fetch = async (...args) => {
      const [resource, config] = args;
      const startTime = Date.now();
      
      try {
        const response = await originalFetch(...args);
        
        // Monitor slow requests
        const duration = Date.now() - startTime;
        if (duration > 5000) { // 5 seconds
          this.captureSlowRequest(resource, config, duration);
        }
        
        // Monitor error responses
        if (!response.ok) {
          this.captureApiError({
            message: `HTTP ${response.status}: ${response.statusText}`,
            status: response.status,
            endpoint: this.extractEndpoint(resource),
            method: config?.method || 'GET',
            timestamp: Date.now(),
          });
        }
        
        return response;
      } catch (error) {
        // Network errors, timeouts, etc.
        this.captureApiError({
          message: error instanceof Error ? error.message : 'Network error',
          endpoint: this.extractEndpoint(resource),
          method: config?.method || 'GET',
          timestamp: Date.now(),
        });
        
        throw error;
      }
    };
  }

  /**
   * Capture slow API requests for performance monitoring
   */
  private captureSlowRequest(resource: RequestInfo | URL, config: RequestInit | undefined, duration: number): void {
    Sentry.withScope(scope => {
      scope.setTag('performance.type', 'slow_api');
      scope.setTag('performance.api.endpoint', this.extractEndpoint(resource));
      scope.setTag('performance.api.method', config?.method || 'GET');
      scope.setLevel('warning');
      
      scope.setContext('slow_request', {
        endpoint: this.extractEndpoint(resource),
        method: config?.method || 'GET',
        duration,
        threshold: 5000,
        url: window.location.href,
      });
      
      Sentry.captureMessage(`Slow API request: ${duration}ms`, 'warning');
    });
  }

  /**
   * Extract endpoint from URL for monitoring
   */
  private extractEndpoint(resource: RequestInfo | URL): string {
    if (typeof resource === 'string') {
      try {
        const url = new URL(resource, window.location.origin);
        return url.pathname;
      } catch {
        return resource;
      }
    } else if (resource instanceof URL) {
      return resource.pathname;
    } else if (resource instanceof Request) {
      try {
        const url = new URL(resource.url);
        return url.pathname;
      } catch {
        return resource.url;
      }
    }
    return 'unknown';
  }

  /**
   * Add error to local queue for analysis
   */
  private addToQueue(error: ApiError): void {
    this.errorQueue.push(error);
    
    // Keep queue size manageable
    if (this.errorQueue.length > this.maxQueueSize) {
      this.errorQueue.shift();
    }
  }

  /**
   * Get error statistics for debugging
   */
  getErrorStats(): {
    total: number;
    byStatus: Record<number, number>;
    byEndpoint: Record<string, number>;
    recent: ApiError[];
  } {
    const stats = {
      total: this.errorQueue.length,
      byStatus: {} as Record<number, number>,
      byEndpoint: {} as Record<string, number>,
      recent: this.errorQueue.slice(-10),
    };

    this.errorQueue.forEach(error => {
      // Count by status
      if (error.status) {
        stats.byStatus[error.status] = (stats.byStatus[error.status] || 0) + 1;
      }
      
      // Count by endpoint
      if (error.endpoint) {
        stats.byEndpoint[error.endpoint] = (stats.byEndpoint[error.endpoint] || 0) + 1;
      }
    });

    return stats;
  }

  /**
   * Clear error queue
   */
  clearQueue(): void {
    this.errorQueue = [];
  }
}

// Initialize the monitor
export const apiErrorMonitor = ApiErrorMonitor.getInstance();

// Auto-start monitoring in browser environment
if (typeof window !== 'undefined') {
  apiErrorMonitor.monitorFetch();
} 