/**
 * Form Submission Handler
 * 
 * Provides utilities for handling form submissions, including:
 * - API request handling
 * - Error processing
 * - Response formatting
 * - Loading state management
 */

import { useCallback, useState } from 'react';
import { toast } from '@/hooks/use-toast';
import { handleValidationError } from './form-validation';
import { useQueryClient } from '@tanstack/react-query';

/**
 * Options for form submission
 */
interface FormSubmissionOptions<TData> {
  onSuccess?: (data: TData) => void;
  onError?: (error: unknown) => void;
  successMessage?: string;
  errorMessage?: string;
  showToasts?: boolean;
  resetForm?: boolean;
  invalidateQueries?: string | string[];
}

/**
 * Result of form submission hook
 */
interface FormSubmissionResult<TData> {
  isSubmitting: boolean;
  formError: string | null;
  fieldErrors: Record<string, string>;
  submitForm: (formData: unknown) => Promise<TData | null>;
  resetErrors: () => void;
  data: TData | null;
}

/**
 * Hook for handling form submissions
 * 
 * @param submitFn The function to call for form submission (e.g., API request)
 * @param options Configuration options
 * @returns Form submission state and handlers
 */
export function useFormSubmission<TData = any>(
  submitFn: (data: unknown) => Promise<TData>,
  options: FormSubmissionOptions<TData> = {}
): FormSubmissionResult<TData> {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [data, setData] = useState<TData | null>(null);
  
  const queryClient = useQueryClient();
  
  const resetErrors = useCallback(() => {
    setFormError(null);
    setFieldErrors({});
  }, []);
  
  const submitForm = useCallback(async (formData: unknown): Promise<TData | null> => {
    resetErrors();
    setIsSubmitting(true);
    
    try {
      const result = await submitFn(formData);
      setData(result);
      
      // Show success toast if enabled
      if (options.showToasts !== false && options.successMessage) {
        toast({
          title: "Success",
          description: options.successMessage,
          variant: "default",
        });
      }
      
      // Invalidate queries if specified
      if (options.invalidateQueries) {
        const queries = Array.isArray(options.invalidateQueries) 
          ? options.invalidateQueries 
          : [options.invalidateQueries];
          
        for (const query of queries) {
          await queryClient.invalidateQueries({ queryKey: [query] });
        }
      }
      
      // Call success callback if provided
      if (options.onSuccess) {
        options.onSuccess(result);
      }
      
      return result;
    } catch (error) {
      // console.log('Form submission error:', error);
      
      // Process error and map to form fields
      const errors = handleValidationError(error);
      
      // Set form-level error
      if (errors._form) {
        setFormError(errors._form);
      }
      
      // Set field-specific errors
      const fieldErrorsObj: Record<string, string> = {};
      
      Object.entries(errors).forEach(([field, message]) => {
        if (field !== '_form') {
          fieldErrorsObj[field] = message;
        }
      });
      
      setFieldErrors(fieldErrorsObj);
      
      // Show error toast if enabled
      if (options.showToasts !== false) {
        toast({
          title: "Error",
          description: options.errorMessage || errors._form || "Form submission failed",
          variant: "destructive",
        });
      }
      
      // Call error callback if provided
      if (options.onError) {
        options.onError(error);
      }
      
      return null;
    } finally {
      setIsSubmitting(false);
    }
  }, [submitFn, options, resetErrors, queryClient]);
  
  return {
    isSubmitting,
    formError,
    fieldErrors,
    submitForm,
    resetErrors,
    data
  };
}

/**
 * Utility function to submit data to an API endpoint
 * 
 * @param url The API endpoint URL
 * @param data The data to submit
 * @param method The HTTP method to use
 * @param headers Additional headers to include
 * @returns The response data
 */
export async function submitToApi<TData = any>(
  url: string,
  data: unknown,
  method: 'POST' | 'PUT' | 'PATCH' | 'DELETE' = 'POST',
  headers: Record<string, string> = {}
): Promise<TData> {
  const response = await fetch(url, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...headers
    },
    body: JSON.stringify(data),
    credentials: 'include'
  });
  
  const responseData = await response.json();
  
  if (!response.ok) {
    // Extract error message from response if available
    const errorMessage = responseData.message || response.statusText;
    
    // Throw error with details
    const error = new Error(errorMessage);
    (error as any).status = response.status;
    (error as any).data = responseData;
    
    throw error;
  }
  
  return responseData as TData;
}

export function handleFormError(error: unknown): void {
  // console.log('Form submission error', error);
}