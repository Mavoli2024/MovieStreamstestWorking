import { createClient, AuthError } from '@supabase/supabase-js';
import type { SupabaseClient } from '@supabase/supabase-js';

// Minimal supabase client for testing
const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || '';
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';
import { logger } from '@shared/logger';

if (import.meta.env.DEV) {
  logger.info('Supabase URL:', { arg1: SUPABASE_URL });
  logger.info('Supabase Key (first 10 chars):', { arg1: SUPABASE_ANON_KEY.substring(0, 10) });
}

let supabaseClient: SupabaseClient;

if (!SUPABASE_URL || !SUPABASE_ANON_KEY) {
  logger.error('Supabase env vars missing');
  logger.error('VITE_SUPABASE_URL:', { arg1: !!SUPABASE_URL });
  logger.error('VITE_SUPABASE_ANON_KEY:', { arg1: !!SUPABASE_ANON_KEY });
  
  // Create a dummy client to prevent errors
  supabaseClient = {
    auth: {
      getUser: () => Promise.resolve({ data: { user: null }, error: null }),
      signUp: () => Promise.resolve({ data: null, error: new Error('Supabase not configured') }),
      signInWithPassword: () => Promise.resolve({ data: null, error: new Error('Supabase not configured') }),
      signOut: () => Promise.resolve({ error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } })
    },
    from: () => ({
      select: () => ({ eq: () => ({ single: () => Promise.resolve({ data: null, error: new Error('Supabase not configured') }) }) })
    })
  } as any;
} else {
  try {
    if (import.meta.env.DEV) {
      logger.info('Creating Supabase client...');
    }
    supabaseClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        // Let the client parse tokens from the callback URL (implicit flow)
        detectSessionInUrl: true,
        flowType: 'implicit',
      },
    });
    if (import.meta.env.DEV) {
      logger.info('Supabase client created successfully!');
    }
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.error('Error creating Supabase client:', { arg1: error });
    }
    throw error;
  }
}

export const supabase = supabaseClient;

// Set auth cookie and localStorage token on session changes
supabase.auth.onAuthStateChange((event, session) => {
  if (import.meta.env.DEV) {
    logger.auth(`Supabase Auth Event: ${event}`, { arg1: session ? 'User session exists' : 'No session' });
  }
  
  // Set or remove the auth cookie and localStorage token
  if (session?.access_token) {
    // Set the authentication token as a cookie for server-side validation
    document.cookie = `supabase_auth_token=${session.access_token}; path=/; max-age=${session.expires_in}; SameSite=Lax`;
    
    // CRITICAL FIX: Store access token in localStorage for api-service.ts
    localStorage.setItem('auth_token', session.access_token);
    
    if (import.meta.env.DEV) {
      logger.auth('Stored access token in localStorage for API calls');
    }
  } else if (event === 'SIGNED_OUT') {
    // Clear the cookie and localStorage on sign out
    document.cookie = 'supabase_auth_token=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax';
    localStorage.removeItem('auth_token');
    
    if (import.meta.env.DEV) {
      logger.auth('Removed access token from localStorage');
    }
  }
});

/**
 * Custom AuthError handler 
 * @param error The error to handle
 * @returns A user-friendly error message
 */
export function handleSupabaseAuthError(error: unknown): string {
  if (error instanceof AuthError) {
    // Handle Supabase-specific auth errors
    switch ((error as any).status) {
      case 400:
        if ((error as any).message.includes('Email not confirmed')) {
          return 'Please check your email and click the confirmation link.';
        } else if ((error as any).message.includes('Invalid login credentials')) {
          return 'Invalid email or password. Please try again.';
        }
        return 'Invalid request. Please check your input.';
      case 422:
        return 'Email already registered or invalid format.';
      case 429:
        return 'Too many requests. Please wait a moment before trying again.';
      default:
        return (error as any).message || 'Authentication failed. Please try again.';
    }
  }
  
  // Handle other types of errors
  if (error instanceof Error) {
    return error.message;
  }
  
  return 'An unexpected error occurred. Please try again.';
}

/**
 * Sign up a new user with email and password
 * @param email User's email address
 * @param password User's password
 * @param metadata Optional user metadata like name
 * @returns Auth data response from Supabase
 */
export async function signUp(
  email: string, 
  password: string, 
  metadata?: { name?: string; [key: string]: unknown }
) {
  if (import.meta.env.DEV) {
    logger.info('[SupabaseLib] signUp: Attempting user registration.');
  }
  if (import.meta.env.DEV) {
    logger.info('[SupabaseLib] signUp: Email:', { arg1: email });
  }
  // console.log('[SupabaseLib] signUp: Password:', password ? 'Provided' : 'Missing'); // Avoid logging password in prod
  if (import.meta.env.DEV) {
    logger.info('[SupabaseLib] signUp: Metadata:', { arg1: JSON.stringify(metadata) });
  }

  try {
    // Determine the correct redirect URL based on the environment
    const siteUrl = import.meta.env.VITE_SITE_URL || 
                    window.location.origin || 
                    'https://madifastream.netlify.app';
    
    const redirectUrl = `${siteUrl}/auth/callback`;
    if (import.meta.env.DEV) {
      logger.info(`Using callback URL for signup: ${redirectUrl}`);
    }
    
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: redirectUrl,
        data: metadata
      }
    });
    
    if (error) {
      if (import.meta.env.DEV) {
        logger.auth('[SupabaseLib] signUp: Supabase auth.signUp returned an error:', { arg1: JSON.stringify(error, Object.getOwnPropertyNames(error)) });
      }
      throw error; // Re-throw to be caught by the outer catch block for handleAuthError
    }
    
    // Log successful signup
    if (import.meta.env.DEV) {
      logger.info(`[SupabaseLib] signUp: User signup successful for ${email}.`);
    }
    
    return data;
  } catch (error: unknown) {
    // This catch block is for the try around supabase.auth.signUp
    if (import.meta.env.DEV) {
      logger.auth('[SupabaseLib] signUp: Caught error during supabase.auth.signUp call. Raw error:', { arg1: JSON.stringify(error, Object.getOwnPropertyNames(error)) });
    }
    const message = handleSupabaseAuthError(error);
    if (import.meta.env.DEV) {
      logger.auth('[SupabaseLib] signUp: Processed error message by handleAuthError:', { arg1: message });
    }
    throw new Error(message); // Re-throw the processed error
  }
}

/**
 * Sign in a user with email and password
 * @param email User's email address
 * @param password User's password
 * @returns Auth data response from Supabase
 */
export async function signIn(email: string, password: string) {
  try {
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    if (error) throw error;
    
    // Log successful login (without password)
    if (import.meta.env.DEV) {
      logger.info(`User login successful: ${email}`);
    }
    
    return data;
  } catch (error) {
    // Use our custom error handler
    const message = handleSupabaseAuthError(error);
    throw new Error(message);
  }
}

/**
 * Sign in a user with Google OAuth
 * @param redirectUrl Optional URL to redirect after authentication
 * @returns Auth response from Supabase
 */
export async function signInWithGoogle(redirectUrl?: string) {
  try {
    // Determine the site URL with production fallback
    const siteUrl = import.meta.env.VITE_SITE_URL || 
                    window.location.origin || 
                    'https://madifastream.netlify.app';
    
    // Use the site's callback path - not the Supabase URL
    const callbackUrl = redirectUrl || `${siteUrl}/auth/callback`;
    
    if (import.meta.env.DEV) {
      logger.auth(`Using callback URL for Google auth: ${callbackUrl}`);
    }
    if (import.meta.env.DEV) {
      logger.info(`Supabase project URL: ${SUPABASE_URL}`);
    }
    
    // Store the current URL to redirect back after auth
    localStorage.setItem('authRedirectUrl', window.location.pathname);
    
    const { data, error } = await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: callbackUrl,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent'
        }
      }
    });
    
    if (error) throw error;
    
    // Log that redirect is happening
    if (import.meta.env.DEV) {
      logger.auth('Redirecting to Google for authentication');
    }
    
    return data;
  } catch (error) {
    // Use our custom error handler
    const message = handleSupabaseAuthError(error);
    throw new Error(message);
  }
}

/**
 * Sign out the current user
 */
export async function signOut() {
  try {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
    
    // Log successful logout
    if (import.meta.env.DEV) {
      logger.info('User logged out successfully');
    }
  } catch (error) {
    // Use our custom error handler
    const message = handleSupabaseAuthError(error);
    throw new Error(message);
  }
}

/**
 * Get the current user session
 * @returns Current session or null if not authenticated
 */
export async function getSession() {
  try {
    const { data, error } = await supabase.auth.getSession();
    if (error) throw error;
    
    return data.session;
  } catch (error) {
    // Use our custom error handler but don't throw - just return null
    const message = handleSupabaseAuthError(error);
    if (import.meta.env.DEV) {
      logger.error(message);
    }
    return null;
  }
}

/**
 * Get the current user
 * @returns Current user or null if not authenticated
 */
export async function getCurrentUser() {
  try {
    const { data, error } = await supabase.auth.getUser();
    if (error) throw error;
    
    return data.user;
  } catch (error) {
    // Use our custom error handler but don't throw - just return null
    const message = handleSupabaseAuthError(error);
    if (import.meta.env.DEV) {
      logger.error(message);
    }
    return null;
  }
}

/**
 * Reset password for a user
 * @param email Email address for the account
 * @returns Success boolean
 */
export async function resetPassword(email: string) {
  try {
    // Determine the correct redirect URL based on the environment
    const siteUrl = import.meta.env.VITE_SITE_URL || 
                    window.location.origin || 
                    'https://madifastream.netlify.app';
    
    const redirectUrl = `${siteUrl}/auth/callback`;
    
    if (import.meta.env.DEV) {
      logger.info(`Using callback URL for password reset: ${redirectUrl}`);
    }
    
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: redirectUrl,
    });
    
    if (error) throw error;
    
    // Log password reset request
    if (import.meta.env.DEV) {
      logger.info(`Password reset requested for: ${email}`);
    }
    
    return true;
  } catch (error) {
    // Use our custom error handler
    const message = handleSupabaseAuthError(error);
    throw new Error(message);
  }
}