import * as Sentry from "@sentry/react";

// Import API error monitor and performance monitor
import { apiErrorMonitor } from './api-error-monitor';
import { performanceMonitor } from './performance-monitor';

// Initialize Sentry
Sentry.init({
  dsn: import.meta.env.VITE_SENTRY_DSN,
  
  // Set tracesSampleRate to 1.0 to capture 100% of transactions for performance monitoring
  // We recommend adjusting this value in production
  tracesSampleRate: 1.0,
  
  // Capture replay sessions on errors
  replaysSessionSampleRate: 0.1, // 10% of sessions
  replaysOnErrorSampleRate: 1.0, // 100% of sessions with errors

  // Debug mode for development
  debug: import.meta.env.DEV,

  // Environment
  environment: import.meta.env.MODE,

  // Performance monitoring
  integrations: [
    Sentry.browserTracingIntegration(),
    Sentry.replayIntegration({
      // Mask sensitive data
      maskAllText: true,
      blockAllMedia: true,
    }),
  ],

  // Set up trace propagation for API calls
  tracePropagationTargets: [
    "localhost",
    "madifa.co.za",
    "madifa.site",
    /^https:\/\/api\.madifa\.(co\.za|site)/,
  ],

  // Filter out noise
  beforeSend(event, hint) {
    // Don't capture errors from browser extensions
    if (event.exception) {
      const error = hint.originalException;
      if (error && typeof error === 'object' && 'stack' in error && 
          typeof error.stack === 'string' && error.stack.includes('extension://')) {
        return null;
      }
    }

    // Don't capture network errors that are likely user connectivity issues
    if (event.message && event.message.includes('Network Error')) {
      return null;
    }

    // Don't capture non-Error exceptions
    if (event.exception && !event.exception.values?.[0]?.type) {
      return null;
    }

    return event;
  },
});

// Helper function to capture API errors with context
export const captureAPIError = (error: Error, context: {
  url?: string;
  method?: string;
  status?: number;
  response?: any;
}) => {
  Sentry.withScope(scope => {
    scope.setTag("error.type", "api");
    scope.setContext("api", context);
    scope.setLevel("error");
    Sentry.captureException(error);
  });
};

// Helper function to capture user actions
export const captureUserAction = (action: string, data?: any) => {
  Sentry.addBreadcrumb({
    category: "user.action",
    message: action,
    level: "info",
    data,
  });
};

// Helper function to set user context
export const setUserContext = (user: {
  id: string;
  email?: string;
  username?: string;
}) => {
  Sentry.setUser(user);
};

// Initialize monitoring systems
if (typeof window !== 'undefined') {
  apiErrorMonitor.monitorFetch();
  performanceMonitor.init();
} 