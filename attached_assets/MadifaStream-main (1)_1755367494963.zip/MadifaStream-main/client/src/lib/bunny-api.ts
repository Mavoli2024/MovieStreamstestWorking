export interface BunnyVideoMetadata {
  guid: string;
  title: string;
  dateUploaded: string;
  views: number;
  length: number; // seconds
  status?: number;
  thumbnailFileName?: string;
  thumbnailUrl: string;
  directPlayUrl: string;
  storageSize: number; // bytes
  availableResolutions?: string[];
  encodeProgress?: number;
}

/**
 * Extract the Bunny video GUID from a Bunny Stream URL.
 * We support URLs of the form:
 *   https://{hostname}/{libraryId}/{guid}/play
 *   https://{hostname}/{guid}/play
 *   {guid}
 * If the GUID cannot be parsed the function returns null.
 */
export function extractBunnyGuid(url: string | null | undefined): string | null {
  if (!url) return null;
  try {
    // Quick path – if the string itself is a 36-char GUID just return it.
    if (/^[0-9a-fA-F-]{36}$/.test(url)) {
      return url;
    }

    const httpsRemoved = url.replace(/^https?:\/\//, "");
    const parts = httpsRemoved.split("/");

    // GUID is almost always the last non-empty segment before 'play' or similar
    for (let i = parts.length - 1; i >= 0; i--) {
      const segment = parts[i];
      if (/^[0-9a-fA-F-]{36}$/.test(segment)) return segment;
    }
  } catch {
    // ignore
  }
  return null;
}

/**
 * Human friendly video length (e.g. "1:04:22" or "04:05").
 */
export function formatVideoLength(totalSeconds = 0): string {
  if (!totalSeconds || totalSeconds <= 0) return "0:00";
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = Math.floor(totalSeconds % 60);
  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, "0")}:${seconds.toString().padStart(2, "0")}`;
  }
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

/**
 * Format file size in a human readable way (e.g. "12.4 MB").
 */
export function formatFileSize(bytes = 0): string {
  if (bytes === 0) return "0 B";
  const k = 1024;
  const sizes = ["B", "KB", "MB", "GB", "TB", "PB"] as const;
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  const value = bytes / Math.pow(k, i);
  return `${value.toFixed(1)} ${sizes[i]}`;
}

/**
 * Fetch live metadata for a Bunny Stream video via our secured backend endpoint.
 * This keeps the client free of any privileged API keys and avoids direct calls
 * to the Bunny API from the browser.
 */
export async function getVideoMetadata(guid: string): Promise<BunnyVideoMetadata> {
  if (!guid) {
    throw new Error("getVideoMetadata: guid is required");
  }

  const response = await fetch(`/api/bunny/videos/${guid}`, {
    credentials: "include",
  });

  if (!response.ok) {
    throw new Error(`Failed to fetch Bunny metadata (${response.status})`);
  }

  // The backend is expected to return an object that already matches the
  // BunnyVideoMetadata interface. If it diverges, we adapt the important fields
  // with sensible fallbacks so legacy callers don't break.
  const data = await response.json();

  // Basic defensive mapping – ensures all required keys exist.
  const metadata: BunnyVideoMetadata = {
    guid: data.guid || guid,
    title: data.title || "",
    dateUploaded: data.dateUploaded || data.uploaded || "",
    views: data.views ?? 0,
    length: data.length ?? 0,
    status: data.status,
    thumbnailFileName: data.thumbnailFileName,
    thumbnailUrl: data.thumbnailUrl || `https://vz-f5c9bae3-d51.b-cdn.net/${guid}/thumbnail.jpg`,
    directPlayUrl: data.directPlayUrl || `/api/videos/${guid}/stream`,
    storageSize: data.storageSize ?? 0,
    availableResolutions: data.availableResolutions,
    encodeProgress: data.encodeProgress,
  };

  return metadata;
} 