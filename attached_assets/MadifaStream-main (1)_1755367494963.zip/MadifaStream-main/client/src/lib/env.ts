// Centralised client-side environment configuration
// This indirection lets us easily switch between development, staging and
// production without scattering fallbacks throughout the codebase.
//
// In production we rely on Vite to inject variables at build time. When the
// variable is not provided we default to an empty string, meaning all API
// requests go to the same origin (useful when the backend is served from the
// same domain via a reverse proxy).

// If VITE_BACKEND_API_URL is provided use it, otherwise default to empty string
// which makes fetches relative to the current origin (works for Vercel previews)
export const BACKEND_API_URL: string =
  import.meta.env.VITE_BACKEND_API_URL || "";

// Helper to build absolute URLs
export function api(path: string): string {
  // Ensure leading slash for caller convenience
  const normalised = path.startsWith("/") ? path : `/${path}`;
  return `${BACKEND_API_URL}${normalised}`;
}