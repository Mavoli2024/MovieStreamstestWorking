import axe from 'axe-core'
// import { expect } from '@jest/globals' // Testing dependency not available

// Extend Jest matchers (disabled in build)
// expect.extend(toHaveNoViolations)

interface UIMetrics {
  timestamp: number
  url: string
  accessibility: {
    violations: number
    warnings: number
    passes: number
  }
  performance: {
    lcp: number
    fid: number
    cls: number
    tbt: number
  }
  usability: {
    clickableElements: number
    formElements: number
    navigationElements: number
    missingAltText: number
  }
  consistency: {
    colorContrast: boolean
    fontSizes: string[]
    spacing: string[]
    buttonSizes: string[]
  }
}

class UIMonitor {
  private metrics: UIMetrics[] = []
  private observer: PerformanceObserver | null = null
  private isMonitoring = false

  constructor() {
    this.initializeMonitoring()
  }

  private initializeMonitoring() {
    if (typeof window === 'undefined') return

    // Initialize performance observer
    if ('PerformanceObserver' in window) {
      this.observer = new PerformanceObserver((list) => {
        const entries = list.getEntries()
        this.processPerformanceEntries(entries)
      })

      this.observer.observe({ entryTypes: ['navigation', 'paint', 'layout-shift'] })
    }

    // Monitor DOM changes
    const mutationObserver = new MutationObserver((mutations) => {
      this.checkAccessibility()
    })

    mutationObserver.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['aria-label', 'alt', 'role']
    })
  }

  async checkAccessibility(): Promise<void> {
    try {
      const results = await axe.run(document.body, {
        rules: {
          'color-contrast': { enabled: true },
          'keyboard-navigation': { enabled: true },
          'aria-labels': { enabled: true },
          'heading-order': { enabled: true },
          'alt-text': { enabled: true },
          'focus-management': { enabled: true }
        }
      })

      const violations = results.violations
      const warnings = results.incomplete
      const passes = results.passes

      // Log accessibility issues
      if (violations.length > 0) {
        console.group('🚨 Accessibility Violations')
        violations.forEach(violation => {
          console.error(`${violation.id}: ${violation.description}`)
          console.log('Elements:', violation.nodes.map(node => node.target))
          console.log('Impact:', violation.impact)
          console.log('Help:', violation.helpUrl)
        })
        console.groupEnd()
      }

      if (warnings.length > 0) {
        console.group('⚠️ Accessibility Warnings')
        warnings.forEach(warning => {
          console.warn(`${warning.id}: ${warning.description}`)
        })
        console.groupEnd()
      }

      // Store metrics
      this.updateMetrics({
        accessibility: {
          violations: violations.length,
          warnings: warnings.length,
          passes: passes.length
        }
      })

    } catch (error) {
      console.error('Accessibility check failed:', error)
    }
  }

  checkUsability(): void {
    const clickableElements = document.querySelectorAll('button, a, [onclick], [role="button"]').length
    const formElements = document.querySelectorAll('input, textarea, select').length
    const navigationElements = document.querySelectorAll('nav, [role="navigation"]').length
    const imagesWithoutAlt = document.querySelectorAll('img:not([alt])').length

    // Check for proper focus indicators
    const focusableElements = document.querySelectorAll(
      'button, a, input, textarea, select, [tabindex]:not([tabindex="-1"])'
    )
    
    let focusIndicatorIssues = 0
    focusableElements.forEach(element => {
      const styles = window.getComputedStyle(element, ':focus')
      if (!styles.outline && !styles.boxShadow) {
        focusIndicatorIssues++
      }
    })

    this.updateMetrics({
      usability: {
        clickableElements,
        formElements,
        navigationElements,
        missingAltText: imagesWithoutAlt
      }
    })

    if (focusIndicatorIssues > 0) {
      console.warn(`🔍 ${focusIndicatorIssues} elements missing focus indicators`)
    }
  }

  checkConsistency(): void {
    // Check color contrast
    const textElements = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, span, div')
    let contrastIssues = 0

    // Check font sizes
    const fontSizes = new Set<string>()
    const spacingValues = new Set<string>()
    const buttonSizes = new Set<string>()

    textElements.forEach(element => {
      const styles = window.getComputedStyle(element)
      fontSizes.add(styles.fontSize)
      spacingValues.add(styles.marginTop)
      spacingValues.add(styles.marginBottom)
      spacingValues.add(styles.paddingTop)
      spacingValues.add(styles.paddingBottom)
    })

    // Check button consistency
    const buttons = document.querySelectorAll('button')
    buttons.forEach(button => {
      const styles = window.getComputedStyle(button)
      buttonSizes.add(`${styles.height}x${styles.minWidth}`)
    })

    this.updateMetrics({
      consistency: {
        colorContrast: contrastIssues === 0,
        fontSizes: Array.from(fontSizes),
        spacing: Array.from(spacingValues),
        buttonSizes: Array.from(buttonSizes)
      }
    })

    // Report consistency issues
    if (fontSizes.size > 8) {
      console.warn(`🎨 Too many font sizes (${fontSizes.size}). Consider consolidating.`)
    }
    if (buttonSizes.size > 5) {
      console.warn(`🔘 Too many button sizes (${buttonSizes.size}). Consider standardizing.`)
    }
  }

  private processPerformanceEntries(entries: PerformanceEntry[]): void {
    entries.forEach(entry => {
      if (entry.entryType === 'navigation') {
        const navEntry = entry as PerformanceNavigationTiming
        this.updateMetrics({
          performance: {
            lcp: navEntry.loadEventEnd - navEntry.loadEventStart,
            fid: 0, // Will be updated by user interaction
            cls: 0, // Will be updated by layout shift observer
            tbt: navEntry.domInteractive - navEntry.fetchStart
          }
        })
      }
    })
  }

  private updateMetrics(partialMetrics: Partial<UIMetrics>): void {
    const currentMetrics: UIMetrics = {
      timestamp: Date.now(),
      url: window.location.href,
      accessibility: { violations: 0, warnings: 0, passes: 0 },
      performance: { lcp: 0, fid: 0, cls: 0, tbt: 0 },
      usability: { clickableElements: 0, formElements: 0, navigationElements: 0, missingAltText: 0 },
      consistency: { colorContrast: true, fontSizes: [], spacing: [], buttonSizes: [] },
      ...partialMetrics
    }

    this.metrics.push(currentMetrics)

    // Keep only last 50 metrics
    if (this.metrics.length > 50) {
      this.metrics = this.metrics.slice(-50)
    }
  }

  startMonitoring(): void {
    if (this.isMonitoring) return

    this.isMonitoring = true
    
    // Run initial checks
    this.checkAccessibility()
    this.checkUsability()
    this.checkConsistency()

    // Set up periodic checks
    setInterval(() => {
      this.checkAccessibility()
      this.checkUsability()
      this.checkConsistency()
    }, 30000) // Check every 30 seconds

    console.log('🔍 UI Monitoring started')
  }

  stopMonitoring(): void {
    this.isMonitoring = false
    this.observer?.disconnect()
    console.log('🔍 UI Monitoring stopped')
  }

  getMetrics(): UIMetrics[] {
    return [...this.metrics]
  }

  getLatestMetrics(): UIMetrics | null {
    return this.metrics[this.metrics.length - 1] || null
  }

  generateReport(): string {
    const latest = this.getLatestMetrics()
    if (!latest) return 'No metrics available'

    return `
UI/UX Monitoring Report
=======================
Timestamp: ${new Date(latest.timestamp).toLocaleString()}
URL: ${latest.url}

Accessibility:
- Violations: ${latest.accessibility.violations}
- Warnings: ${latest.accessibility.warnings}
- Passes: ${latest.accessibility.passes}

Performance:
- LCP: ${latest.performance.lcp}ms
- FID: ${latest.performance.fid}ms
- CLS: ${latest.performance.cls}
- TBT: ${latest.performance.tbt}ms

Usability:
- Clickable Elements: ${latest.usability.clickableElements}
- Form Elements: ${latest.usability.formElements}
- Navigation Elements: ${latest.usability.navigationElements}
- Missing Alt Text: ${latest.usability.missingAltText}

Consistency:
- Color Contrast: ${latest.consistency.colorContrast ? 'PASS' : 'FAIL'}
- Font Sizes: ${latest.consistency.fontSizes.length} different sizes
- Button Sizes: ${latest.consistency.buttonSizes.length} different sizes
    `
  }

  // Quick accessibility check for specific element
  async checkElement(element: HTMLElement): Promise<any> {
    try {
      const results = await axe.run(element)
      return results
    } catch (error) {
      console.error('Element accessibility check failed:', error)
      return null
    }
  }
}

// Export singleton instance
export const uiMonitor = new UIMonitor()

// Initialize monitoring in development
if (process.env.NODE_ENV === 'development') {
  // Auto-start monitoring after DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      uiMonitor.startMonitoring()
    })
  } else {
    uiMonitor.startMonitoring()
  }

  // Make it available globally for debugging
  (window as any).uiMonitor = uiMonitor
}

// Export types and utilities
export type { UIMetrics }
export { UIMonitor } 