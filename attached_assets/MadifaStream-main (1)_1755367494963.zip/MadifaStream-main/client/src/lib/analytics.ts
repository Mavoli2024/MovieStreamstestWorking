import * as Sentry from '@sentry/react';
// import posthog from 'posthog-js'; // Optional dependency

// Analytics & Error Tracking Configuration
export const initializeAnalytics = () => {
  // Initialize Sentry for error tracking
  if (import.meta.env.VITE_SENTRY_DSN) {
    Sentry.init({
      dsn: import.meta.env.VITE_SENTRY_DSN,
      environment: import.meta.env.MODE,
      integrations: [
        // BrowserTracing and Replay integrations can be added here
        // when properly imported from @sentry/tracing and @sentry/replay
      ],
      tracesSampleRate: import.meta.env.PROD ? 0.1 : 1.0,
      replaysSessionSampleRate: import.meta.env.PROD ? 0.1 : 1.0,
      replaysOnErrorSampleRate: 1.0,
    });
  }

  // PostHog analytics disabled - missing dependency
  // if (import.meta.env.VITE_POSTHOG_KEY) {
  //   posthog.init(import.meta.env.VITE_POSTHOG_KEY, {
  //     api_host: import.meta.env.VITE_POSTHOG_HOST || 'https://app.posthog.com',
  //     loaded: (posthog) => {
  //       if (import.meta.env.DEV) posthog.debug();
  //     }
  //   });
  // }

  // Initialize Google Analytics
  if (import.meta.env.VITE_GA_MEASUREMENT_ID) {
    // Load gtag script
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${import.meta.env.VITE_GA_MEASUREMENT_ID}`;
    document.head.appendChild(script);

    // Initialize gtag
    (window as any).dataLayer = (window as any).dataLayer || [];
    function gtag(...args: unknown[]) {
      (window as any).dataLayer.push(args);
    }
    (window as any).gtag = gtag;

    gtag('js', new Date());
    gtag('config', import.meta.env.VITE_GA_MEASUREMENT_ID, {
      page_title: document.title,
      page_location: window.location.href,
    });
  }

  // Initialize Hotjar for user behavior analytics
  if (import.meta.env.VITE_HOTJAR_ID) {
    (function(h: any, o: any, t: any, j: any, a?: any, r?: any) {
      h.hj = h.hj || function(...args: unknown[]) { (h.hj.q = h.hj.q || []).push(args); };
      h._hjSettings = { hjid: import.meta.env.VITE_HOTJAR_ID, hjsv: 6 };
      a = o.getElementsByTagName('head')[0];
      r = o.createElement('script'); r.async = 1;
      r.src = t + h._hjSettings.hjid + j + h._hjSettings.hjsv;
      a.appendChild(r);
    })(window, document, 'https://static.hotjar.com/c/hotjar-', '.js?sv=');
  }
};

// Analytics Event Tracking
export const trackEvent = (eventName: string, properties?: Record<string, any>) => {
  // PostHog disabled - missing dependency

  // Google Analytics
  if ((window as any).gtag) {
    (window as any).gtag('event', eventName, {
      custom_parameter_1: properties?.category,
      custom_parameter_2: properties?.label,
      value: properties?.value,
      ...properties
    });
  }
};

// User Identification
export const identifyUser = (userId: string, traits?: Record<string, any>) => {
  // PostHog disabled - missing dependency

  // Sentry
  Sentry.setUser({
    id: userId,
    ...traits
  });
};

// Page View Tracking
export const trackPageView = (pageName: string, properties?: Record<string, any>) => {
  trackEvent('page_view', {
    page_name: pageName,
    page_url: window.location.href,
    ...properties
  });

  // Google Analytics page view
  if ((window as any).gtag) {
    (window as any).gtag('config', import.meta.env.VITE_GA_MEASUREMENT_ID, {
      page_title: pageName,
      page_location: window.location.href,
    });
  }
};

// Video Analytics
export const trackVideoEvent = (action: string, videoId: string, properties?: Record<string, any>) => {
  trackEvent(`video_${action}`, {
    video_id: videoId,
    ...properties
  });
};

// Subscription Analytics
export const trackSubscriptionEvent = (action: string, planId?: string, properties?: Record<string, any>) => {
  trackEvent(`subscription_${action}`, {
    plan_id: planId,
    ...properties
  });
};

// Error Tracking
export const trackError = (error: Error, context?: Record<string, any>) => {
  Sentry.captureException(error, {
    extra: context
  });
  
  trackEvent('error_occurred', {
    error_message: error.message,
    error_stack: error.stack,
    ...context
  });
}; 