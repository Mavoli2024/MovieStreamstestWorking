import { logger } from '@shared/logger';
/**
 * Enhanced Performance Monitoring System
 * Extends the existing system with additional metrics and optimizations
 */

import { onCLS, onFCP, onINP, onLCP, onTTFB, Metric } from 'web-vitals';

// Additional performance metrics interface
interface EnhancedPerformanceMetrics {
  bundleLoadTimes: Record<string, number>;
  componentLoadTimes: Record<string, number>;
  chunkLoadErrors: string[];
  memoryLeaks: Array<{
    timestamp: number;
    heapUsed: number;
    heapTotal: number;
  }>;
  treeshakingEffectiveness: {
    totalImports: number;
    unusedImports: number;
    bundleSizeReduction: number;
  };
  cacheHitRates: Record<string, { hits: number; total: number }>;
  lazyLoadingStats: {
    componentsLoaded: number;
    averageLoadTime: number;
    failureRate: number;
  };
}

// Global enhanced metrics
const enhancedMetrics: EnhancedPerformanceMetrics = {
  bundleLoadTimes: {},
  componentLoadTimes: {},
  chunkLoadErrors: [],
  memoryLeaks: [],
  treeshakingEffectiveness: {
    totalImports: 0,
    unusedImports: 0,
    bundleSizeReduction: 0
  },
  cacheHitRates: {},
  lazyLoadingStats: {
    componentsLoaded: 0,
    averageLoadTime: 0,
    failureRate: 0
  }
};

/**
 * Track bundle loading performance
 */
export function trackBundleLoad(bundleName: string, startTime: number, endTime: number) {
  const loadTime = endTime - startTime;
  enhancedMetrics.bundleLoadTimes[bundleName] = loadTime;
  
  // Report slow bundles
  if (loadTime > 1000) {
    logger.warn(`Slow bundle load: ${bundleName} took ${loadTime}ms`);
  }
  
  // Send to analytics
  if (import.meta.env.VITE_ANALYTICS_ENDPOINT) {
    sendMetricToAnalytics({
      metric: 'bundle-load-time',
      value: loadTime,
      bundleName,
      timestamp: Date.now()
    });
  }
}

/**
 * Track component lazy loading performance
 */
export function trackComponentLoad(componentName: string, loadTime: number, success: boolean) {
  enhancedMetrics.componentLoadTimes[componentName] = loadTime;
  enhancedMetrics.lazyLoadingStats.componentsLoaded++;
  
  // Update average load time
  const total = Object.values(enhancedMetrics.componentLoadTimes).reduce((a, b) => a + b, 0);
  enhancedMetrics.lazyLoadingStats.averageLoadTime = total / enhancedMetrics.lazyLoadingStats.componentsLoaded;
  
  // Track failures
  if (!success) {
    enhancedMetrics.lazyLoadingStats.failureRate = 
      (enhancedMetrics.lazyLoadingStats.failureRate * (enhancedMetrics.lazyLoadingStats.componentsLoaded - 1) + 1) / 
      enhancedMetrics.lazyLoadingStats.componentsLoaded;
  }
  
  if (import.meta.env.DEV) {
    logger.info(`Component ${componentName} loaded in ${loadTime}ms`);
  }
}

/**
 * Monitor chunk loading errors
 */
export function trackChunkError(chunkName: string, error: Error) {
  enhancedMetrics.chunkLoadErrors.push(`${chunkName}: ${error.message}`);
  
  logger.error(`Chunk loading error for ${chunkName}:`, { arg1: error });
  
  // Send error to monitoring service
  if (import.meta.env.VITE_ANALYTICS_ENDPOINT) {
    sendMetricToAnalytics({
      metric: 'chunk-load-error',
      chunkName,
      error: error.message,
      timestamp: Date.now()
    });
  }
}

/**
 * Enhanced memory leak detection
 */
export function monitorMemoryLeaks() {
  if (!('memory' in performance)) return;
  
  const checkMemory = () => {
    const memory = (performance as any).memory;
    const currentUsage = {
      timestamp: Date.now(),
      heapUsed: memory.usedJSHeapSize,
      heapTotal: memory.totalJSHeapSize
    };
    
    enhancedMetrics.memoryLeaks.push(currentUsage);
    
    // Keep only last 50 measurements
    if (enhancedMetrics.memoryLeaks.length > 50) {
      enhancedMetrics.memoryLeaks.shift();
    }
    
    // Detect potential memory leaks
    if (enhancedMetrics.memoryLeaks.length >= 10) {
      const recent = enhancedMetrics.memoryLeaks.slice(-10);
      const growth = recent[9].heapUsed - recent[0].heapUsed;
      const timeSpan = recent[9].timestamp - recent[0].timestamp;
      
      // If memory grew by more than 50MB in 5 minutes, warn
      if (growth > 50 * 1024 * 1024 && timeSpan < 5 * 60 * 1000) {
        logger.warn(`Memory leak detected: ${JSON.stringify({
          growth: `${Math.round(growth / 1024 / 1024)}MB`,
          timeSpan: `${Math.round(timeSpan / 1000)}s`
        })}`);
      }
    }
  };
  
  // Check memory every 30 seconds
  setInterval(checkMemory, 30000);
  checkMemory(); // Initial check
}

/**
 * Track cache performance
 */
export function trackCacheHit(resourceType: string, hit: boolean) {
  if (!enhancedMetrics.cacheHitRates[resourceType]) {
    enhancedMetrics.cacheHitRates[resourceType] = { hits: 0, total: 0 };
  }
  
  enhancedMetrics.cacheHitRates[resourceType].total++;
  if (hit) {
    enhancedMetrics.cacheHitRates[resourceType].hits++;
  }
  
  // Log poor cache performance
  const rate = enhancedMetrics.cacheHitRates[resourceType];
  const hitRate = rate.hits / rate.total;
  
  if (rate.total >= 10 && hitRate < 0.7) {
    logger.warn(`Low cache hit rate for ${resourceType}: ${Math.round(hitRate * 100)}%`);
  }
}

/**
 * Measure tree shaking effectiveness
 */
export function measureTreeShaking() {
  // This would be populated by build-time analysis
  // For now, we'll estimate based on bundle sizes
  const bundleSize = enhancedMetrics.bundleLoadTimes;
  const estimatedOptimization = Object.keys(bundleSize).length * 0.15; // Assume 15% improvement
  
  enhancedMetrics.treeshakingEffectiveness.bundleSizeReduction = estimatedOptimization;
  
  if (import.meta.env.DEV) {
    logger.info('Estimated tree shaking effectiveness:', { arg1: enhancedMetrics.treeshakingEffectiveness });
  }
}

/**
 * Enhanced Web Vitals tracking with additional context
 */
export function initEnhancedWebVitals() {
  const handleMetric = (metric: Metric) => {
    // Add additional context
    const enhancedMetric = {
      ...metric,
      url: window.location.href,
      userAgent: navigator.userAgent,
      connection: (navigator as any).connection?.effectiveType || 'unknown',
      memory: (performance as any).memory ? {
        used: (performance as any).memory.usedJSHeapSize,
        total: (performance as any).memory.totalJSHeapSize
      } : null,
      devicePixelRatio: window.devicePixelRatio,
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight
      },
      bundleLoadTimes: enhancedMetrics.bundleLoadTimes,
      componentStats: enhancedMetrics.lazyLoadingStats
    };
    
    sendMetricToAnalytics(enhancedMetric);
    
    if (import.meta.env.DEV) {
      logger.info('Enhanced Web Vital:', { arg1: enhancedMetric });
    }
  };
  
  // Track all Core Web Vitals
  onLCP(handleMetric);
  onINP(handleMetric);
  onCLS(handleMetric);
  onFCP(handleMetric);
  onTTFB(handleMetric);
}

/**
 * Send metrics to analytics endpoint
 */
function sendMetricToAnalytics(data: unknown) {
  if (!import.meta.env.VITE_ANALYTICS_ENDPOINT) return;
  
  fetch(import.meta.env.VITE_ANALYTICS_ENDPOINT, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  }).catch(err => {
    if (import.meta.env.DEV) {
      logger.error('Failed to send enhanced metrics:', { arg1: err });
    }
  });
}

/**
 * Get performance optimization recommendations
 */
export function getPerformanceRecommendations() {
  const recommendations: string[] = [];
  
  // Bundle size recommendations
  const largeBundles = Object.entries(enhancedMetrics.bundleLoadTimes)
    .filter(([_, time]) => time > 1000);
  
  if (largeBundles.length > 0) {
    recommendations.push(`Optimize large bundles: ${largeBundles.map(([name]) => name).join(', ')}`);
  }
  
  // Component loading recommendations
  if (enhancedMetrics.lazyLoadingStats.averageLoadTime > 200) {
    recommendations.push('Consider preloading critical components to reduce lazy loading times');
  }
  
  if (enhancedMetrics.lazyLoadingStats.failureRate > 0.1) {
    recommendations.push('High lazy loading failure rate detected - check network conditions and error handling');
  }
  
  // Cache recommendations
  Object.entries(enhancedMetrics.cacheHitRates).forEach(([type, stats]) => {
    const hitRate = stats.hits / stats.total;
    if (hitRate < 0.7 && stats.total >= 10) {
      recommendations.push(`Improve caching for ${type} (current hit rate: ${Math.round(hitRate * 100)}%)`);
    }
  });
  
  // Memory recommendations
  if (enhancedMetrics.memoryLeaks.length > 20) {
    const recent = enhancedMetrics.memoryLeaks.slice(-20);
    const avgGrowth = recent.reduce((sum, leak, index) => {
      if (index === 0) return 0;
      return sum + (leak.heapUsed - recent[index - 1].heapUsed);
    }, 0) / (recent.length - 1);
    
    if (avgGrowth > 1024 * 1024) { // 1MB average growth
      recommendations.push('Potential memory leak detected - review component cleanup and event listeners');
    }
  }
  
  return recommendations;
}

/**
 * Get comprehensive performance summary
 */
export function getEnhancedPerformanceSummary() {
  return {
    ...enhancedMetrics,
    recommendations: getPerformanceRecommendations(),
    overallScore: calculateOverallPerformanceScore(),
    lastUpdated: new Date().toISOString()
  };
}

/**
 * Calculate overall performance score (0-100)
 */
function calculateOverallPerformanceScore(): number {
  let score = 100;
  
  // Penalize slow bundle loads
  const avgBundleTime = Object.values(enhancedMetrics.bundleLoadTimes).reduce((a, b) => a + b, 0) / 
    Object.values(enhancedMetrics.bundleLoadTimes).length || 0;
  
  if (avgBundleTime > 1000) score -= 20;
  else if (avgBundleTime > 500) score -= 10;
  
  // Penalize high failure rates
  if (enhancedMetrics.lazyLoadingStats.failureRate > 0.1) score -= 30;
  else if (enhancedMetrics.lazyLoadingStats.failureRate > 0.05) score -= 15;
  
  // Penalize poor cache performance
  const avgCacheHitRate = Object.values(enhancedMetrics.cacheHitRates)
    .reduce((sum, stats) => sum + (stats.hits / stats.total), 0) / 
    Object.values(enhancedMetrics.cacheHitRates).length || 1;
  
  if (avgCacheHitRate < 0.5) score -= 25;
  else if (avgCacheHitRate < 0.7) score -= 10;
  
  // Penalize chunk errors
  if (enhancedMetrics.chunkLoadErrors.length > 5) score -= 20;
  else if (enhancedMetrics.chunkLoadErrors.length > 0) score -= 5;
  
  return Math.max(0, Math.round(score));
}

/**
 * Initialize all enhanced monitoring
 */
export function initEnhancedPerformanceMonitoring() {
  initEnhancedWebVitals();
  monitorMemoryLeaks();
  measureTreeShaking();
  
  // Set up chunk loading error monitoring
  window.addEventListener('error', (event) => {
    if (event.filename && event.filename.includes('chunk')) {
      trackChunkError(event.filename, new Error(event.message));
    }
  });
  
  // Set up unhandled promise rejection monitoring
  window.addEventListener('unhandledrejection', (event) => {
    if (event.reason && event.reason.message && event.reason.message.includes('Loading chunk')) {
      trackChunkError('dynamic-import', event.reason);
    }
  });
  
  if (import.meta.env.DEV) {
    logger.info('Enhanced performance monitoring initialized');
  }
}