/**
 * Centralized Routes Configuration - Single Source of Truth (SSOT)
 * All navigation components should import and use these routes
 */

// Public routes (no authentication required)
export const PUBLIC_ROUTES = {
  HOME: '/',
  AUTH: '/auth',
  AUTH_LOGIN: '/auth?tab=login', 
  AUTH_REGISTER: '/auth?tab=register',
  AUTH_CALLBACK: '/auth/callback',
  TERMS: '/terms',
  PRIVACY: '/privacy',
  COOKIES: '/cookies',
  ACCESSIBILITY: '/accessibility',
  SITEMAP: '/sitemap',
  FEEDBACK: '/feedback',
} as const;

// Protected routes (authentication required)
export const PROTECTED_ROUTES = {
  DASHBOARD: '/home',
  BROWSE: '/browse',
  DISCOVER: '/iscover',
  SEARCH: '/search', 
  WATCH: '/watch',
  PROFILE: '/profile',
  SETTINGS: '/settings',
  ADMIN: '/admin',
  ADMIN_LIBRARY: '/admin/library',
  SUBSCRIPTION: '/subscription',
  DOWNLOADS: '/downloads',
  MY_LIST: '/my-list',
  RECOMMENDATIONS: '/recommendations',
  PAYMENT_SUCCESS: '/payment/success',
  PAYMENT_CANCEL: '/payment/cancel',
} as const;

// All routes combined
export const ROUTES = {
  ...PUBLIC_ROUTES,
  ...PROTECTED_ROUTES,
} as const;

// Route builders for dynamic routes
export const buildRoute = {
  watch: (videoId: string) => `${PROTECTED_ROUTES.WATCH}/${videoId}`,
  browse: (params?: { type?: string; collection?: string }) => {
    const base = PROTECTED_ROUTES.BROWSE;
    if (!params) return base;
    
    const searchParams = new URLSearchParams();
    if (params.type) searchParams.set('type', params.type);
    if (params.collection) searchParams.set('collection', params.collection);
    
    const query = searchParams.toString();
    return query ? `${base}?${query}` : base;
  },
  auth: (tab?: 'login' | 'register') => {
    const base = PUBLIC_ROUTES.AUTH;
    return tab ? `${base}?tab=${tab}` : base;
  },
} as const;

export const APP_ROUTES = [
  ...Object.values(PUBLIC_ROUTES).map(path => ({ path, requireAuth: false })),
  ...Object.values(PROTECTED_ROUTES).map(path => ({ path, requireAuth: true })),
];
