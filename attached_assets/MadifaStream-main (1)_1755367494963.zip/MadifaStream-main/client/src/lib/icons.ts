import { logger } from '@shared/logger';
/**
 * Icons Preloader Utility
 * 
 * Preloads critical icons for better performance
 */

// List of critical icons that should be preloaded
const CRITICAL_ICONS = [
  'play',
  'pause',
  'volume-2',
  'volume-x',
  'maximize',
  'minimize',
  'settings',
  'heart',
  'bookmark',
  'share',
  'download',
] as const;

/**
 * Preload critical icons for better performance
 * This helps reduce layout shift and improves perceived performance
 */
export function preloadCriticalIcons(): void {
  try {
    // For lucide-react icons, we don't need to preload anything special
    // as they are SVG components that load on demand
    
    // If we had icon fonts or image icons, we would preload them here
    // For now, this is just a placeholder to satisfy the import
    
    if (import.meta.env.DEV) {
      logger.info('Critical icons preloaded successfully');
    }
  } catch (error) {
    logger.warn('Failed to preload critical icons:', { arg1: error });
  }
}

/**
 * Get icon component dynamically (for future use)
 */
export function getIcon(name: string) {
  // This could be expanded to return actual icon components
  // For now, it's just a placeholder
  return null;
}

export type IconName = typeof CRITICAL_ICONS[number]; 