import { uiMonitor } from './ui-monitoring'

interface ErrorReport {
  timestamp: number
  message: string
  stack?: string
  url: string
  userAgent: string
  userId?: string
  sessionId: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  context: Record<string, any>
}

interface PerformanceReport {
  timestamp: number
  url: string
  metrics: {
    lcp: number
    fid: number
    cls: number
    tbt: number
    fcp: number
    ttfb: number
  }
  deviceInfo: {
    connection: string
    memory: number
    cores: number
    platform: string
  }
  userSession: {
    sessionId: string
    userId?: string
    sessionDuration: number
    pageViews: number
  }
}

interface UserInteractionReport {
  timestamp: number
  action: string
  element: string
  duration: number
  success: boolean
  errorMessage?: string
  context: Record<string, any>
}

class ProductionMonitor {
  private sessionId: string
  private userId?: string
  private sessionStart: number
  private pageViews: number = 0
  private errors: ErrorReport[] = []
  private performanceReports: PerformanceReport[] = []
  private interactionReports: UserInteractionReport[] = []
  private isProduction: boolean
  private alertThresholds = {
    errorRate: 0.05, // 5% error rate
    performanceScore: 0.7, // 70% performance score
    accessibilityViolations: 5,
    loadTime: 3000, // 3 seconds
    interactionDelay: 100 // 100ms
  }

  constructor() {
    this.sessionId = this.generateSessionId()
    this.sessionStart = Date.now()
    this.isProduction = process.env.NODE_ENV === 'production'
    
    this.initializeMonitoring()
  }

  private generateSessionId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
  }

  private initializeMonitoring(): void {
    // Error monitoring
    window.addEventListener('error', (event) => {
      this.reportError({
        message: event.message,
        stack: event.error?.stack,
        severity: 'high',
        context: {
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno
        }
      })
    })

    window.addEventListener('unhandledrejection', (event) => {
      this.reportError({
        message: `Unhandled Promise Rejection: ${event.reason}`,
        severity: 'critical',
        context: {
          reason: event.reason,
          promise: event.promise
        }
      })
    })

    // Performance monitoring
    if ('PerformanceObserver' in window) {
      // Core Web Vitals
      this.observeWebVitals()
      
      // Navigation timing
      this.observeNavigation()
      
      // Resource timing
      this.observeResources()
    }

    // User interaction monitoring
    this.monitorUserInteractions()

    // Page visibility changes
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        this.sendReports()
      }
    })

    // Send reports before page unload
    window.addEventListener('beforeunload', () => {
      this.sendReports()
    })

    // Periodic reporting
    setInterval(() => {
      this.sendReports()
    }, 30000) // Every 30 seconds
  }

  private observeWebVitals(): void {
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'largest-contentful-paint') {
          this.updatePerformanceMetrics({ lcp: entry.startTime })
        }
        if (entry.entryType === 'first-input') {
          this.updatePerformanceMetrics({ fid: (entry as any).processingStart - entry.startTime })
        }
        if (entry.entryType === 'layout-shift') {
          if (!(entry as any).hadRecentInput) {
            this.updatePerformanceMetrics({ cls: (entry as any).value })
          }
        }
      }
    })

    observer.observe({ entryTypes: ['largest-contentful-paint', 'first-input', 'layout-shift'] })
  }

  private observeNavigation(): void {
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'navigation') {
          const navEntry = entry as PerformanceNavigationTiming
          this.updatePerformanceMetrics({
            ttfb: navEntry.responseStart - navEntry.requestStart,
            fcp: navEntry.domContentLoadedEventStart - navEntry.fetchStart,
            tbt: navEntry.domInteractive - navEntry.fetchStart
          })
        }
      }
    })

    observer.observe({ entryTypes: ['navigation'] })
  }

  private observeResources(): void {
    const observer = new PerformanceObserver((list) => {
      for (const entry of list.getEntries()) {
        if (entry.entryType === 'resource') {
          const resourceEntry = entry as PerformanceResourceTiming
          
          // Check for slow resources
          if (resourceEntry.duration > 1000) {
            this.reportError({
              message: `Slow resource: ${resourceEntry.name}`,
              severity: 'medium',
              context: {
                duration: resourceEntry.duration,
                size: resourceEntry.transferSize,
                type: resourceEntry.initiatorType
              }
            })
          }
        }
      }
    })

    observer.observe({ entryTypes: ['resource'] })
  }

  private monitorUserInteractions(): void {
    const interactionTypes = ['click', 'keydown', 'scroll', 'input']
    
    interactionTypes.forEach(type => {
      document.addEventListener(type, (event) => {
        const startTime = performance.now()
        const target = event.target as HTMLElement
        
        // Track interaction performance
        requestAnimationFrame(() => {
          const duration = performance.now() - startTime
          
          this.reportInteraction({
            action: type,
            element: this.getElementSelector(target),
            duration,
            success: true,
            context: {
              timestamp: Date.now(),
              pageUrl: window.location.href
            }
          })

          // Alert on slow interactions
          if (duration > this.alertThresholds.interactionDelay) {
            this.reportError({
              message: `Slow interaction: ${type} took ${duration}ms`,
              severity: 'medium',
              context: {
                element: this.getElementSelector(target),
                duration,
                action: type
              }
            })
          }
        })
      })
    })
  }

  private getElementSelector(element: HTMLElement): string {
    if (element.id) return `#${element.id}`
    if (element.className) return `.${element.className.split(' ')[0]}`
    return element.tagName.toLowerCase()
  }

  private updatePerformanceMetrics(metrics: Partial<PerformanceReport['metrics']>): void {
    const deviceInfo = this.getDeviceInfo()
    
    const report: PerformanceReport = {
      timestamp: Date.now(),
      url: window.location.href,
      metrics: {
        lcp: 0,
        fid: 0,
        cls: 0,
        tbt: 0,
        fcp: 0,
        ttfb: 0,
        ...metrics
      },
      deviceInfo,
      userSession: {
        sessionId: this.sessionId,
        userId: this.userId,
        sessionDuration: Date.now() - this.sessionStart,
        pageViews: this.pageViews
      }
    }

    this.performanceReports.push(report)

    // Check performance thresholds
    this.checkPerformanceThresholds(report)
  }

  private getDeviceInfo() {
    const connection = (navigator as any).connection
    const memory = (performance as any).memory
    
    return {
      connection: connection?.effectiveType || 'unknown',
      memory: memory?.usedJSHeapSize || 0,
      cores: navigator.hardwareConcurrency || 0,
      platform: navigator.platform
    }
  }

  private checkPerformanceThresholds(report: PerformanceReport): void {
    const { metrics } = report
    
    if (metrics.lcp > this.alertThresholds.loadTime) {
      this.reportError({
        message: `Poor LCP: ${metrics.lcp}ms`,
        severity: 'high',
        context: { metrics, deviceInfo: report.deviceInfo }
      })
    }

    if (metrics.fid > this.alertThresholds.interactionDelay) {
      this.reportError({
        message: `Poor FID: ${metrics.fid}ms`,
        severity: 'high',
        context: { metrics, deviceInfo: report.deviceInfo }
      })
    }

    if (metrics.cls > 0.25) {
      this.reportError({
        message: `High CLS: ${metrics.cls}`,
        severity: 'high',
        context: { metrics, deviceInfo: report.deviceInfo }
      })
    }
  }

  reportError(error: Omit<ErrorReport, 'timestamp' | 'url' | 'userAgent' | 'sessionId'>): void {
    const errorReport: ErrorReport = {
      timestamp: Date.now(),
      url: window.location.href,
      userAgent: navigator.userAgent,
      sessionId: this.sessionId,
      userId: this.userId,
      ...error
    }

    this.errors.push(errorReport)

    // Immediate console logging for development
    if (!this.isProduction) {
      console.error('📊 Production Monitor Error:', errorReport)
    }

    // Send critical errors immediately
    if (error.severity === 'critical') {
      this.sendErrorReport(errorReport)
    }
  }

  reportInteraction(interaction: Omit<UserInteractionReport, 'timestamp'>): void {
    const interactionReport: UserInteractionReport = {
      timestamp: Date.now(),
      ...interaction
    }

    this.interactionReports.push(interactionReport)

    // Keep only last 100 interactions
    if (this.interactionReports.length > 100) {
      this.interactionReports = this.interactionReports.slice(-100)
    }
  }

  private async sendErrorReport(error: ErrorReport): Promise<void> {
    if (!this.isProduction) return

    try {
      await fetch('/api/monitoring/errors', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(error)
      })
    } catch (err) {
      console.error('Failed to send error report:', err)
    }
  }

  private async sendReports(): Promise<void> {
    if (!this.isProduction || this.errors.length === 0) return

    try {
      // Send all pending reports
      await Promise.all([
        this.sendErrorReports(),
        this.sendPerformanceReports(),
        this.sendInteractionReports(),
        this.sendUIMetrics()
      ])

      // Clear sent reports
      this.errors = []
      this.performanceReports = []
      this.interactionReports = []

    } catch (error) {
      console.error('Failed to send monitoring reports:', error)
    }
  }

  private async sendErrorReports(): Promise<void> {
    if (this.errors.length === 0) return

    await fetch('/api/monitoring/errors', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(this.errors)
    })
  }

  private async sendPerformanceReports(): Promise<void> {
    if (this.performanceReports.length === 0) return

    await fetch('/api/monitoring/performance', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(this.performanceReports)
    })
  }

  private async sendInteractionReports(): Promise<void> {
    if (this.interactionReports.length === 0) return

    await fetch('/api/monitoring/interactions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(this.interactionReports)
    })
  }

  private async sendUIMetrics(): Promise<void> {
    const metrics = uiMonitor.getMetrics()
    if (metrics.length === 0) return

    await fetch('/api/monitoring/ui', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(metrics)
    })
  }

  setUserId(userId: string): void {
    this.userId = userId
  }

  trackPageView(url: string): void {
    this.pageViews++
    
    // Track page load performance using Navigation Timing API
    if (performance.getEntriesByType) {
      const navEntries = performance.getEntriesByType('navigation') as PerformanceNavigationTiming[]
      if (navEntries.length > 0) {
        const navEntry = navEntries[0]
        const loadTime = navEntry.loadEventEnd - navEntry.fetchStart
        if (loadTime > this.alertThresholds.loadTime) {
          this.reportError({
            message: `Slow page load: ${loadTime}ms`,
            severity: 'medium',
            context: { url, loadTime }
          })
        }
      }
    }
  }

  getSessionReport(): string {
    return `
Production Monitoring Report
============================
Session ID: ${this.sessionId}
User ID: ${this.userId || 'Anonymous'}
Session Duration: ${Math.round((Date.now() - this.sessionStart) / 1000)}s
Page Views: ${this.pageViews}

Errors: ${this.errors.length}
Performance Reports: ${this.performanceReports.length}
Interactions: ${this.interactionReports.length}

Latest UI Metrics:
${uiMonitor.generateReport()}
    `
  }
}

// Export singleton instance
export const productionMonitor = new ProductionMonitor()

// Initialize monitoring
if (typeof window !== 'undefined') {
  // Make it available globally for debugging
  (window as any).productionMonitor = productionMonitor
  
  // Track initial page view
  productionMonitor.trackPageView(window.location.href)
}

// Export types
export type { ErrorReport, PerformanceReport, UserInteractionReport } 