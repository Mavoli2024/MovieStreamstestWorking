import { logger } from '@shared/logger';
/**
 * API Client with proper error handling and type safety
 */

export interface ApiError {
  message: string;
  status: number;
  code?: string;
}

export class ApiClientError extends Error {
  public status: number;
  public code?: string;

  constructor(message: string, status: number, code?: string) {
    super(message);
    this.name = 'ApiClientError';
    this.status = status;
    this.code = code;
  }
}

export interface ApiResponse<T = any> {
  data?: T;
  error?: ApiError;
  success: boolean;
}

/**
 * Enhanced fetch wrapper with proper error handling
 */
export async function api<T = any>(
  input: RequestInfo | URL,
  init?: RequestInit
): Promise<T> {
  const config: RequestInit = {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...init?.headers,
    },
    ...init,
  };

  try {
    const response = await fetch(input, config);
    
    // Handle non-JSON responses
    const contentType = response.headers.get('content-type');
    const isJson = contentType?.includes('application/json');

    if (!response.ok) {
      let errorMessage = `HTTP ${response.status}: ${response.statusText}`;
      let errorCode: string | undefined;

      if (isJson) {
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || errorData.error || errorMessage;
          errorCode = errorData.code;
        } catch {
          // If JSON parsing fails, use the default error message
        }
      } else {
        try {
          errorMessage = await response.text() || errorMessage;
        } catch {
          // If text parsing fails, use the default error message
        }
      }

      throw new ApiClientError(errorMessage, response.status, errorCode);
    }

    // Handle successful responses
    if (isJson) {
      const data = await response.json();
      return data as T;
    }

    // For non-JSON responses, return the response object
    return response as unknown as T;
  } catch (error) {
    if (error instanceof ApiClientError) {
      throw error;
    }

    // Handle network errors, timeouts, etc.
    if (error instanceof TypeError && error.message.includes('fetch')) {
      throw new ApiClientError(
        'Network error: Please check your internet connection',
        0,
        'NETWORK_ERROR'
      );
    }

    // Handle other unexpected errors
    throw new ApiClientError(
      error instanceof Error ? error.message : 'An unexpected error occurred',
      0,
      'UNKNOWN_ERROR'
    );
  }
}

/**
 * Convenience methods for common HTTP verbs
 */
export const apiClient = {
  get: <T = any>(url: string, config?: RequestInit) =>
    api<T>(url, { method: 'GET', ...config }),

  post: <T = any>(url: string, data?: unknown, config?: RequestInit) =>
    api<T>(url, {
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
      ...config,
    }),

  put: <T = any>(url: string, data?: unknown, config?: RequestInit) =>
    api<T>(url, {
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
      ...config,
    }),

  patch: <T = any>(url: string, data?: unknown, config?: RequestInit) =>
    api<T>(url, {
      method: 'PATCH',
      body: data ? JSON.stringify(data) : undefined,
      ...config,
    }),

  delete: <T = any>(url: string, config?: RequestInit) =>
    api<T>(url, { method: 'DELETE', ...config }),
};

/**
 * Query key factory for React Query
 */
export const queryKeys = {
  // Auth
  auth: {
    user: () => ['auth', 'user'] as const,
    session: () => ['auth', 'session'] as const,
  },
  
  // Profiles
  profiles: {
    all: (userId?: string) => ['profiles', userId] as const,
    detail: (profileId: number) => ['profiles', 'detail', profileId] as const,
  },
  
  // Videos
  videos: {
    all: (filters?: Record<string, any>) => ['videos', filters] as const,
    detail: (videoId: string) => ['videos', 'detail', videoId] as const,
    trending: () => ['videos', 'trending'] as const,
    search: (query: string) => ['videos', 'search', query] as const,
  },
  
  // Subscriptions
  subscriptions: {
    current: (userId?: string) => ['subscriptions', 'current', userId] as const,
    plans: () => ['subscriptions', 'plans'] as const,
  },
} as const;

/**
 * Legacy wrapper kept for backward compatibility. Delegates to the new `api` helper
 * but preserves the previous function signature used across the code-base.
 */
export async function fetchApi<T = any>(endpoint: string, options?: RequestInit): Promise<T> {
  try {
    const data = await api<T>(endpoint, options);
    return data;
  } catch (err) {
    handleApiError(err);
    throw err; // Re-throw so callers can still do their own handling
  }
}

/**
 * Centralised error logger – ensures a single responsibility for console output.
 * In production this could forward the error to Sentry/Logrocket etc.
 */
export function handleApiError(error: unknown): void {
  if (error instanceof ApiClientError) {
    if (import.meta.env.DEV) {
      logger.api(`[API] ${error.status} – ${error.message}`, { arg1: { code: error.code } });
    }
  } else if (error instanceof Error) {
    if (import.meta.env.DEV) {
      logger.api('[API] Unexpected error:', { arg1: error.message });
    }
  } else {
    if (import.meta.env.DEV) {
      logger.api('[API] Unknown error', { arg1: error });
    }
  }
}