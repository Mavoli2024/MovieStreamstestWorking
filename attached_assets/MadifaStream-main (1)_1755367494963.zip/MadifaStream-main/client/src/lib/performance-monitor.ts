import * as Sentry from '@sentry/react';

export interface PerformanceMetric {
  name: string;
  value: number;
  rating: 'good' | 'needs-improvement' | 'poor';
  timestamp: number;
  url: string;
}

export class PerformanceMonitor {
  private static instance: PerformanceMonitor;
  private metrics: PerformanceMetric[] = [];
  private observer: PerformanceObserver | null = null;

  static getInstance(): PerformanceMonitor {
    if (!PerformanceMonitor.instance) {
      PerformanceMonitor.instance = new PerformanceMonitor();
    }
    return PerformanceMonitor.instance;
  }

  /**
   * Initialize performance monitoring
   */
  init(): void {
    if (typeof window === 'undefined') return;

    // Monitor Core Web Vitals
    this.monitorCoreWebVitals();
    
    // Monitor custom metrics
    this.monitorCustomMetrics();
    
    // Monitor resource loading
    this.monitorResourceLoading();
  }

  /**
   * Monitor Core Web Vitals (CLS, FID, LCP)
   */
  private monitorCoreWebVitals(): void {
    // Use web-vitals library if available, otherwise fallback to manual monitoring
    if ('web-vitals' in window) {
      // If web-vitals is loaded, use it
      const webVitals = (window as any)['web-vitals'];
      webVitals.getCLS(this.handleMetric.bind(this));
      webVitals.getFID(this.handleMetric.bind(this));
      webVitals.getLCP(this.handleMetric.bind(this));
    } else {
      // Fallback to manual monitoring
      this.monitorLCP();
      this.monitorFID();
      this.monitorCLS();
    }
  }

  /**
   * Monitor Largest Contentful Paint (LCP)
   */
  private monitorLCP(): void {
    if (!('PerformanceObserver' in window)) return;

    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      const lastEntry = entries[entries.length - 1];
      
      if (lastEntry) {
        this.handleMetric({
          name: 'LCP',
          value: lastEntry.startTime,
          rating: this.getLCPRating(lastEntry.startTime),
          timestamp: Date.now(),
          url: window.location.href,
        });
      }
    });

    observer.observe({ entryTypes: ['largest-contentful-paint'] });
  }

  /**
   * Monitor First Input Delay (FID)
   */
  private monitorFID(): void {
    if (!('PerformanceObserver' in window)) return;

    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry: any) => {
        if (entry.name === 'first-input') {
          this.handleMetric({
            name: 'FID',
            value: entry.processingStart - entry.startTime,
            rating: this.getFIDRating(entry.processingStart - entry.startTime),
            timestamp: Date.now(),
            url: window.location.href,
          });
        }
      });
    });

    observer.observe({ entryTypes: ['first-input'] });
  }

  /**
   * Monitor Cumulative Layout Shift (CLS)
   */
  private monitorCLS(): void {
    if (!('PerformanceObserver' in window)) return;

    let clsValue = 0;
    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry: any) => {
        if (!entry.hadRecentInput) {
          clsValue += entry.value;
        }
      });

      this.handleMetric({
        name: 'CLS',
        value: clsValue,
        rating: this.getCLSRating(clsValue),
        timestamp: Date.now(),
        url: window.location.href,
      });
    });

    observer.observe({ entryTypes: ['layout-shift'] });
  }

  /**
   * Monitor custom application metrics
   */
  private monitorCustomMetrics(): void {
    // Time to Interactive (TTI) approximation
    window.addEventListener('load', () => {
      setTimeout(() => {
        const navigationEntry = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming;
        if (navigationEntry) {
          const tti = navigationEntry.domContentLoadedEventEnd - (navigationEntry.fetchStart || 0);
          this.handleMetric({
            name: 'TTI',
            value: tti,
            rating: this.getTTIRating(tti),
            timestamp: Date.now(),
            url: window.location.href,
          });
        }
      }, 0);
    });

    // First Contentful Paint (FCP)
    if ('PerformanceObserver' in window) {
      const observer = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach((entry) => {
          if (entry.name === 'first-contentful-paint') {
            this.handleMetric({
              name: 'FCP',
              value: entry.startTime,
              rating: this.getFCPRating(entry.startTime),
              timestamp: Date.now(),
              url: window.location.href,
            });
          }
        });
      });

      observer.observe({ entryTypes: ['paint'] });
    }
  }

  /**
   * Monitor resource loading performance
   */
  private monitorResourceLoading(): void {
    if (!('PerformanceObserver' in window)) return;

    const observer = new PerformanceObserver((list) => {
      const entries = list.getEntries();
      entries.forEach((entry) => {
        const resourceEntry = entry as PerformanceResourceTiming;
        
        // Monitor slow resources
        if (resourceEntry.duration > 1000) { // 1 second threshold
          this.captureSlowResource(resourceEntry);
        }
        
        // Monitor failed resources
        if (resourceEntry.transferSize === 0 && resourceEntry.decodedBodySize === 0) {
          this.captureFailedResource(resourceEntry);
        }
      });
    });

    observer.observe({ entryTypes: ['resource'] });
  }

  /**
   * Handle performance metric
   */
  private handleMetric(metric: PerformanceMetric): void {
    this.metrics.push(metric);
    
    // Send to Sentry
    Sentry.withScope(scope => {
      scope.setTag('performance.metric', metric.name);
      scope.setTag('performance.rating', metric.rating);
      scope.setLevel(metric.rating === 'poor' ? 'warning' : 'info');
      
      scope.setContext('performance', {
        metric: metric.name,
        value: metric.value,
        rating: metric.rating,
        url: metric.url,
        timestamp: metric.timestamp,
      });
      
      if (metric.rating === 'poor') {
        Sentry.captureMessage(`Poor ${metric.name}: ${metric.value}ms`, 'warning');
      } else {
        Sentry.addBreadcrumb({
          category: 'performance',
          message: `${metric.name}: ${metric.value}ms (${metric.rating})`,
          level: 'info',
        });
      }
    });
  }

  /**
   * Capture slow resource loading
   */
  private captureSlowResource(entry: PerformanceResourceTiming): void {
    Sentry.withScope(scope => {
      scope.setTag('performance.type', 'slow_resource');
      scope.setLevel('warning');
      
      scope.setContext('slow_resource', {
        name: entry.name,
        duration: entry.duration,
        size: entry.transferSize,
        type: this.getResourceType(entry.name),
        url: window.location.href,
      });
      
      Sentry.captureMessage(`Slow resource: ${entry.name} (${entry.duration}ms)`, 'warning');
    });
  }

  /**
   * Capture failed resource loading
   */
  private captureFailedResource(entry: PerformanceResourceTiming): void {
    Sentry.withScope(scope => {
      scope.setTag('performance.type', 'failed_resource');
      scope.setLevel('error');
      
      scope.setContext('failed_resource', {
        name: entry.name,
        type: this.getResourceType(entry.name),
        url: window.location.href,
      });
      
      Sentry.captureMessage(`Failed to load resource: ${entry.name}`, 'error');
    });
  }

  /**
   * Get resource type from URL
   */
  private getResourceType(url: string): string {
    if (url.includes('.js')) return 'script';
    if (url.includes('.css')) return 'stylesheet';
    if (url.match(/\.(jpg|jpeg|png|gif|webp|svg)$/)) return 'image';
    if (url.includes('.woff') || url.includes('.ttf')) return 'font';
    return 'other';
  }

  /**
   * Rating functions for Core Web Vitals
   */
  private getLCPRating(value: number): 'good' | 'needs-improvement' | 'poor' {
    if (value <= 2500) return 'good';
    if (value <= 4000) return 'needs-improvement';
    return 'poor';
  }

  private getFIDRating(value: number): 'good' | 'needs-improvement' | 'poor' {
    if (value <= 100) return 'good';
    if (value <= 300) return 'needs-improvement';
    return 'poor';
  }

  private getCLSRating(value: number): 'good' | 'needs-improvement' | 'poor' {
    if (value <= 0.1) return 'good';
    if (value <= 0.25) return 'needs-improvement';
    return 'poor';
  }

  private getFCPRating(value: number): 'good' | 'needs-improvement' | 'poor' {
    if (value <= 1800) return 'good';
    if (value <= 3000) return 'needs-improvement';
    return 'poor';
  }

  private getTTIRating(value: number): 'good' | 'needs-improvement' | 'poor' {
    if (value <= 3800) return 'good';
    if (value <= 7300) return 'needs-improvement';
    return 'poor';
  }

  /**
   * Get performance summary
   */
  getPerformanceSummary(): {
    metrics: PerformanceMetric[];
    averages: Record<string, number>;
    ratings: Record<string, { good: number; needsImprovement: number; poor: number }>;
  } {
    const summary = {
      metrics: [...this.metrics],
      averages: {} as Record<string, number>,
      ratings: {} as Record<string, { good: number; needsImprovement: number; poor: number }>,
    };

    // Calculate averages and ratings
    const metricGroups = this.groupMetricsByName();
    
    Object.entries(metricGroups).forEach(([name, metrics]) => {
      summary.averages[name] = metrics.reduce((sum, m) => sum + m.value, 0) / metrics.length;
      
      summary.ratings[name] = {
        good: metrics.filter(m => m.rating === 'good').length,
        needsImprovement: metrics.filter(m => m.rating === 'needs-improvement').length,
        poor: metrics.filter(m => m.rating === 'poor').length,
      };
    });

    return summary;
  }

  /**
   * Group metrics by name
   */
  private groupMetricsByName(): Record<string, PerformanceMetric[]> {
    return this.metrics.reduce((groups, metric) => {
      if (!groups[metric.name]) {
        groups[metric.name] = [];
      }
      groups[metric.name].push(metric);
      return groups;
    }, {} as Record<string, PerformanceMetric[]>);
  }

  /**
   * Clear metrics
   */
  clearMetrics(): void {
    this.metrics = [];
  }
}

// Initialize the performance monitor
export const performanceMonitor = PerformanceMonitor.getInstance();

// Auto-start monitoring in browser environment
if (typeof window !== 'undefined') {
  performanceMonitor.init();
}