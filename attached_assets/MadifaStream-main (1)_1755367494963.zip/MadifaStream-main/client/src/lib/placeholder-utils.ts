export function generatePlaceholderThumbnail(title: string): string {
  const initials = title
    .split(' ')
    .map((t) => t.charAt(0).toUpperCase())
    .join('')
    .slice(0, 2);
  return `https://dummyimage.com/640x360/333/fff&text=${encodeURIComponent(initials)}`;
} 