import { logger } from '@shared/logger';
/**
 * Performance Monitoring Hook
 * 
 * Provides real-time performance monitoring including:
 * - Core Web Vitals (LCP, FID, CLS)
 * - Bundle size tracking
 * - Network monitoring
 * - Memory usage
 */

import { useEffect, useRef, useState, useCallback } from 'react';

// Global gtag function declaration
declare global {
  interface Window {
    gtag?: (...args: [string, string, Record<string, unknown>?]) => void;
  }
}

interface WindowWithGtag extends Window {
  gtag?: (...args: [string, string, Record<string, unknown>?]) => void;
}

interface PerformanceMetrics {
  lcp?: number; // Largest Contentful Paint
  fid?: number; // First Input Delay
  cls?: number; // Cumulative Layout Shift
  fcp?: number; // First Contentful Paint
  ttfb?: number; // Time to First Byte
  bundleSize?: number;
  memoryUsage?: number;
  networkType?: string;
  timing?: number;
  navigation?: number;
  memory?: number;
  connection?: string;
  fps: number;
  renderTime: number;
  visibleItems: number;
  scrollPosition: number;
}

interface PerformanceConfig {
  enableWebVitals?: boolean;
  enableNetworkMonitoring?: boolean;
  enableMemoryMonitoring?: boolean;
  reportInterval?: number;
}

interface UsePerformanceMonitorOptions {
  enableVirtualScrolling?: boolean;
  itemHeight?: number;
  containerHeight?: number;
  threshold?: number;
  rootMargin?: string;
}

export function usePerformanceMonitor(options: UsePerformanceMonitorOptions = {}) {
  const {
    enableVirtualScrolling = false,
    itemHeight = 300,
    containerHeight = 600,
    threshold = 0.1,
    rootMargin = '50px'
  } = options;

  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    fps: 0,
    memory: 0,
    renderTime: 0,
    visibleItems: 0,
    scrollPosition: 0
  });

  const [visibleIndexes, setVisibleIndexes] = useState<{start: number; end: number}>({
    start: 0,
    end: Math.ceil(containerHeight / itemHeight)
  });

  const containerRef = useRef<HTMLDivElement>(null);
  const observerRef = useRef<IntersectionObserver | null>(null);
  const frameRef = useRef<number | undefined>(undefined);
  const lastTimeRef = useRef<number>(performance.now());
  const fpsCounterRef = useRef<number[]>([]);

  // Intersection Observer for visibility tracking
  const setupIntersectionObserver = useCallback(() => {
    if (typeof window === 'undefined') return;

    if (observerRef.current) {
      observerRef.current.disconnect();
    }

    observerRef.current = new IntersectionObserver(
      (entries) => {
        const visibleEntries = entries.filter(entry => entry.isIntersecting);
        setMetrics(prev => ({
          ...prev,
          visibleItems: visibleEntries.length
        }));
      },
      {
        threshold,
        rootMargin
      }
    );

    return observerRef.current;
  }, [threshold, rootMargin]);

  // Virtual scrolling calculations
  const calculateVisibleRange = useCallback((scrollTop: number, totalItems: number) => {
    if (!enableVirtualScrolling) {
      return { start: 0, end: totalItems };
    }

    const start = Math.floor(scrollTop / itemHeight);
    const visibleCount = Math.ceil(containerHeight / itemHeight);
    const end = Math.min(start + visibleCount + 1, totalItems); // +1 for buffer

    return { start: Math.max(0, start - 1), end }; // -1 for buffer before
  }, [enableVirtualScrolling, itemHeight, containerHeight]);

  // Scroll handler for virtual scrolling
  const handleScroll = useCallback((event: Event) => {
    const target = event.target as HTMLElement;
    const scrollTop = target.scrollTop;
    
    setMetrics(prev => ({
      ...prev,
      scrollPosition: scrollTop
    }));

    // Update visible range for virtual scrolling
    if (enableVirtualScrolling) {
      const totalItems = parseInt(target.dataset.totalItems || '0');
      const newRange = calculateVisibleRange(scrollTop, totalItems);
      setVisibleIndexes(newRange);
    }
  }, [calculateVisibleRange, enableVirtualScrolling]);

  // FPS monitoring
  const measureFPS = useCallback(() => {
    const now = performance.now();
    const delta = now - lastTimeRef.current;
    lastTimeRef.current = now;

    if (delta > 0) {
      const fps = 1000 / delta;
      fpsCounterRef.current.push(fps);
      
      // Keep only last 60 frames for average
      if (fpsCounterRef.current.length > 60) {
        fpsCounterRef.current.shift();
      }

      const averageFPS = fpsCounterRef.current.reduce((sum, f) => sum + f, 0) / fpsCounterRef.current.length;
      
      setMetrics(prev => ({
        ...prev,
        fps: Math.round(averageFPS)
      }));
    }

    frameRef.current = requestAnimationFrame(measureFPS);
  }, []);

  // Memory monitoring
  const measureMemory = useCallback(() => {
    if ('memory' in performance) {
      const memoryInfo = (performance as any).memory;
      setMetrics(prev => ({
        ...prev,
        memory: Math.round(memoryInfo.usedJSHeapSize / 1024 / 1024) // MB
      }));
    }
  }, []);

  // Render time monitoring
  const measureRenderTime = useCallback(() => {
    const startTime = performance.now();
    
    // Use requestAnimationFrame to measure actual render time
    requestAnimationFrame(() => {
      const endTime = performance.now();
      setMetrics(prev => ({
        ...prev,
        renderTime: Math.round(endTime - startTime)
      }));
    });
  }, []);

  // Performance observer for more detailed metrics
  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Setup intersection observer
    const observer = setupIntersectionObserver();

    // Setup scroll listener for virtual scrolling
    const container = containerRef.current;
    if (container && enableVirtualScrolling) {
      container.addEventListener('scroll', handleScroll, { passive: true });
    }

    // Start FPS monitoring
    frameRef.current = requestAnimationFrame(measureFPS);

    // Periodic memory monitoring
    const memoryInterval = setInterval(measureMemory, 1000);

    // Performance Observer for render metrics
    if ('PerformanceObserver' in window) {
      const perfObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        entries.forEach(entry => {
          if (entry.entryType === 'measure') {
            setMetrics(prev => ({
              ...prev,
              renderTime: Math.round(entry.duration)
            }));
          }
        });
      });

      try {
        perfObserver.observe({ entryTypes: ['measure'] });
      } catch (e) {
        logger.warn('Performance Observer not supported for measures');
      }
    }

    return () => {
      if (observer) observer.disconnect();
      if (container) container.removeEventListener('scroll', handleScroll);
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      clearInterval(memoryInterval);
    };
  }, [setupIntersectionObserver, handleScroll, measureFPS, measureMemory, enableVirtualScrolling]);

  // Hook for measuring component render times
  const measureComponentRender = useCallback((componentName: string) => {
    performance.mark(`${componentName}-start`);
    
    return () => {
      performance.mark(`${componentName}-end`);
      performance.measure(
        `${componentName}-render`,
        `${componentName}-start`,
        `${componentName}-end`
      );
    };
  }, []);

  // Observe elements for intersection
  const observeElement = useCallback((element: Element) => {
    if (observerRef.current) {
      observerRef.current.observe(element);
    }
  }, []);

  const unobserveElement = useCallback((element: Element) => {
    if (observerRef.current) {
      observerRef.current.unobserve(element);
    }
  }, []);

  // Virtual scrolling helpers
  const getVirtualizedProps = useCallback((totalItems: number) => {
    if (!enableVirtualScrolling) {
      return {
        items: Array.from({ length: totalItems }, (_, i) => i),
        containerStyle: {},
        itemStyle: () => ({}),
      };
    }

    const totalHeight = totalItems * itemHeight;
    const offsetTop = visibleIndexes.start * itemHeight;
    
    return {
      items: Array.from(
        { length: visibleIndexes.end - visibleIndexes.start },
        (_, i) => visibleIndexes.start + i
      ),
      containerStyle: {
        height: containerHeight,
        overflow: 'auto',
        position: 'relative' as const,
      },
      itemStyle: (index: number) => ({
        position: 'absolute' as const,
        top: offsetTop + (index * itemHeight),
        height: itemHeight,
        width: '100%',
      }),
      spacerStyle: {
        height: totalHeight,
        width: '100%',
      },
      visibleRange: visibleIndexes,
    };
  }, [enableVirtualScrolling, itemHeight, containerHeight, visibleIndexes]);

  return {
    metrics,
    containerRef,
    measureComponentRender,
    observeElement,
    unobserveElement,
    getVirtualizedProps,
    visibleIndexes,
    isPerformanceMode: metrics.fps < 30 || metrics.memory > 100, // Simple performance mode detection
  };
}