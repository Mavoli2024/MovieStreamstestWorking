/**
 * Real-time Notifications Hook
 * 
 * Manages real-time in-app notifications and push notifications
 * using Supabase real-time subscriptions
 */

import { useState, useEffect, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuth } from './use-auth';
import { useToast } from './use-toast';
import { realtimeService, RealtimeEvent } from '../services/realtimeService';
import { notificationService } from '../services/pushNotificationService';

export interface UserNotification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'content' | 'subscription' | 'download' | 'recommendation' | 'system';
  action_url?: string;
  is_read: boolean;
  created_at: string;
  updated_at: string;
}

export interface NotificationStats {
  total: number;
  unread: number;
  byType: Record<string, number>;
}

export function useRealtimeNotifications() {
  const { user, session } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isRealtimeConnected, setIsRealtimeConnected] = useState(false);
  const [lastNotificationTime, setLastNotificationTime] = useState<Date | null>(null);

  // Fetch notifications
  const {
    data: notifications = [],
    isLoading,
    error,
    refetch: refetchNotifications
  } = useQuery<UserNotification[]>({
    queryKey: ['notifications', user?.id],
    queryFn: async () => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch('/api/notifications', {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch notifications');
      }

      const data = await response.json();
      return data.notifications || [];
    },
    enabled: !!session?.access_token,
    staleTime: 2 * 60 * 1000, // 2 minutes
  });

  // Handle real-time notification updates
  const handleNotificationUpdate = useCallback((event: RealtimeEvent) => {
    setLastNotificationTime(new Date());
    
    queryClient.setQueryData<UserNotification[]>(['notifications', user?.id], (oldNotifications) => {
      if (!oldNotifications) return oldNotifications;

      switch (event.eventType) {
        case 'INSERT':
          // New notification
          if (event.new && event.new.user_id === user?.id) {
            const newNotification = event.new as UserNotification;
            
            // Show toast notification for important types
            if (['system', 'subscription'].includes(newNotification.type)) {
              toast({
                title: newNotification.title,
                description: newNotification.message,
              });
            }

            // Add to beginning of notifications array
            return [newNotification, ...oldNotifications];
          }
          break;

        case 'UPDATE':
          // Notification updated (e.g., marked as read)
          if (event.new && event.old) {
            return oldNotifications.map(notification =>
              notification.id === event.new.id
                ? { ...notification, ...event.new }
                : notification
            );
          }
          break;

        case 'DELETE':
          // Notification deleted
          if (event.old) {
            return oldNotifications.filter(notification => 
              notification.id !== event.old.id
            );
          }
          break;
      }

      return oldNotifications;
    });
  }, [user?.id, toast, queryClient]);

  // Set up real-time subscription for notifications
  useEffect(() => {
    if (!user?.id || !session?.access_token) {
      return;
    }

    const subscriptionId = `notifications-${user.id}`;

    const subscribeToNotifications = async () => {
      try {
        const success = await realtimeService.subscribe(subscriptionId, {
          table: 'user_notifications',
          schema: 'public',
          event: '*',
          filter: `user_id=eq.${user.id}`,
          callback: handleNotificationUpdate,
        });

        setIsRealtimeConnected(success);

        if (!success) {
          console.warn('Failed to establish real-time notifications subscription');
        }
      } catch (error) {
        console.error('Error setting up real-time notifications subscription:', error);
        setIsRealtimeConnected(false);
      }
    };

    subscribeToNotifications();

    return () => {
      realtimeService.unsubscribe(subscriptionId);
      setIsRealtimeConnected(false);
    };
  }, [user?.id, session?.access_token, handleNotificationUpdate]);

  // Mark notification as read
  const markAsRead = useCallback(async (notificationId: string) => {
    if (!session?.access_token) return false;

    try {
      const response = await fetch(`/api/notifications/${notificationId}/read`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to mark notification as read');
      }

      // Real-time subscription will handle the UI update
      return true;
    } catch (error) {
      console.error('Error marking notification as read:', error);
      toast({
        title: 'Error',
        description: 'Failed to update notification',
        variant: 'destructive',
      });
      return false;
    }
  }, [session?.access_token, toast]);

  // Mark all notifications as read
  const markAllAsRead = useCallback(async () => {
    if (!session?.access_token) return false;

    try {
      const response = await fetch('/api/notifications/mark-all-read', {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to mark all notifications as read');
      }

      toast({
        title: 'All notifications marked as read',
      });

      return true;
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      toast({
        title: 'Error',
        description: 'Failed to update notifications',
        variant: 'destructive',
      });
      return false;
    }
  }, [session?.access_token, toast]);

  // Delete notification
  const deleteNotification = useCallback(async (notificationId: string) => {
    if (!session?.access_token) return false;

    try {
      const response = await fetch(`/api/notifications/${notificationId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to delete notification');
      }

      return true;
    } catch (error) {
      console.error('Error deleting notification:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete notification',
        variant: 'destructive',
      });
      return false;
    }
  }, [session?.access_token, toast]);

  // Clear all notifications
  const clearAllNotifications = useCallback(async () => {
    if (!session?.access_token) return false;

    try {
      const response = await fetch('/api/notifications/clear-all', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to clear all notifications');
      }

      toast({
        title: 'All notifications cleared',
      });

      return true;
    } catch (error) {
      console.error('Error clearing all notifications:', error);
      toast({
        title: 'Error',
        description: 'Failed to clear notifications',
        variant: 'destructive',
      });
      return false;
    }
  }, [session?.access_token, toast]);

  // Test push notifications
  const testPushNotification = useCallback(async () => {
    if (!user?.id) return false;

    try {
      const success = await notificationService.sendNotification(user.id, {
        title: 'Test Notification',
        body: 'This is a test push notification from MadifaStream',
        type: 'system',
        url: '/notifications'
      });

      if (success) {
        toast({
          title: 'Push notification sent',
          description: 'Check your device for the test notification',
        });
      } else {
        toast({
          title: 'Push notification failed',
          description: 'Unable to send push notification',
          variant: 'destructive',
        });
      }

      return success;
    } catch (error) {
      console.error('Error sending test push notification:', error);
      return false;
    }
  }, [user?.id, toast]);

  // Initialize push notifications
  const initializePushNotifications = useCallback(async () => {
    try {
      const initialized = await notificationService.initializeNotifications();
      
      if (initialized) {
        toast({
          title: 'Push notifications enabled',
          description: 'You will now receive push notifications',
        });
        
        // Start heartbeat monitoring
        notificationService.startHeartbeat();
      }
      
      return initialized;
    } catch (error) {
      console.error('Error initializing push notifications:', error);
      return false;
    }
  }, [toast]);

  // Calculate notification statistics
  const getNotificationStats = useCallback((): NotificationStats => {
    const total = notifications.length;
    const unread = notifications.filter(n => !n.is_read).length;
    const byType = notifications.reduce((acc, notification) => {
      acc[notification.type] = (acc[notification.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return { total, unread, byType };
  }, [notifications]);

  // Get recent notifications (last 24 hours)
  const getRecentNotifications = useCallback(() => {
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    return notifications.filter(notification => 
      new Date(notification.created_at) > twentyFourHoursAgo
    );
  }, [notifications]);

  // Get push notification service status
  const getPushServiceStatus = useCallback(async () => {
    return await notificationService.getServiceStatus();
  }, []);

  return {
    notifications,
    isLoading,
    error,
    
    // Real-time status
    isRealtimeConnected,
    lastNotificationTime,
    
    // Actions
    markAsRead,
    markAllAsRead,
    deleteNotification,
    clearAllNotifications,
    
    // Push notifications
    initializePushNotifications,
    testPushNotification,
    getPushServiceStatus,
    
    // Statistics and helpers
    getNotificationStats,
    getRecentNotifications,
    notificationStats: getNotificationStats(),
    recentNotifications: getRecentNotifications(),
    unreadCount: notifications.filter(n => !n.is_read).length,
    
    // Manual refresh
    refreshNotifications: refetchNotifications,
  };
}