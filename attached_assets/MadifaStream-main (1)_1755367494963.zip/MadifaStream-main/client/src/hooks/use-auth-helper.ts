import { logger } from '@shared/logger';
/**
 * Authentication Helper Functions
 * 
 * Utility functions to support Supabase authentication flow
 */

import type {  Session  } from '@supabase/supabase-js';
import type {  QueryClient  } from '@tanstack/react-query';

/**
 * Verifies a user with our backend to ensure database records exist
 */
export async function verifyUser(session: Session, queryClient?: QueryClient): Promise<any> {
  try {
    const response = await fetch('/api/auth/verify-user', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${session.access_token}`
      },
      body: JSON.stringify({
        auth_id: session.user.id,
        email: session.user.email,
        user_metadata: session.user.user_metadata
      })
    });

    // For 405 Method Not Allowed errors, log it but don't throw an error
    // This allows auth to continue working even when this endpoint has issues
    if (!response.ok) {
      if (import.meta.env.DEV) {
        logger.auth("User verification on sign in:", { arg1: response.status });
      }

      // Only refresh queries - don't throw for 405 errors since auth still works
      if (response.status === 405) {
        // Refresh user data anyway
        if (queryClient) {
          queryClient.invalidateQueries({ queryKey: ["/api/user/profile"] });
        }
        return { success: true, note: "Verification skipped due to endpoint configuration" };
      }

      // For other error types, still throw
      throw new Error(`User verification failed: ${response.statusText}`);
    }

    // Refresh user data
    if (queryClient) {
      queryClient.invalidateQueries({ queryKey: ["/api/user/profile"] });
    }

    return await response.json();
  } catch (error) {
    // Log the error but don't throw it, allowing auth to continue
    if (import.meta.env.DEV) {
      logger.auth("Error in verifyUser, but continuing auth flow:", { arg1: error });
    }
    return { success: false, error: String(error) };
  }
}

/**
 * Get current user's auth token
 */
export async function getAuthToken(): Promise<string | null> {
  const storageKey = 'sb-' + import.meta.env.SUPABASE_URL.split('//')[1].split('.')[0] + '-auth-token';
  const storedSession = localStorage.getItem(storageKey);

  if (!storedSession) return null;

  try {
    const session = JSON.parse(storedSession);
    return session?.access_token || null;
  } catch (e) {
    if (import.meta.env.DEV) {
      logger.auth('Error parsing auth token:', { arg1: e });
    }
    return null;
  }
}