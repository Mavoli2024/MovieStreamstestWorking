import { extractBunnyGuid } from '@/lib/bunny-api';
import type { Video } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';

export interface BunnyMetadata {
  guid: string;
  title: string;
  dateUploaded: string;
  views: number;
  length: number;
  status: number;
  thumbnailFileName: string;
  thumbnailUrl: string;
  directPlayUrl: string;
  storageSize: number;
  availableResolutions: string[];
  encodeProgress: number;
}

/**
 * Hook to fetch BunnyStream metadata for a video
 */
export function useBunnyMetadata(video: Video | undefined) {
  // Skip if no video or videoUrl
  const enabled = !!(video?.id && video?.video_url);
  const guid = video?.video_url ? extractBunnyGuid(video.video_url) : null;
  
  const { 
    data: metadata,
    isLoading,
    error
  } = useQuery<BunnyMetadata>({
    queryKey: [`/api//${video?.id}/bunnystream`],
    enabled: enabled,
  });
  
  return { 
    metadata,
    isLoading,
    error,
    guid
  };
}

/**
 * Hook to fetch all BunnyStream videos metadata
 */
export function useAllBunnyMetadata() {
  const { 
    data: metadata,
    isLoading,
    error
  } = useQuery<BunnyMetadata[]>({
    queryKey: ['/api/bunnystream/videos'],
  });
  
  return { 
    metadata: metadata || [],
    isLoading,
    error
  };
}