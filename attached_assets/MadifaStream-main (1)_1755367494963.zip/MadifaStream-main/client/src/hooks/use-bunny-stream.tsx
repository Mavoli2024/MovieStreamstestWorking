import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { EnhancedVideoMetadata } from "@/services/enhanced-video-service";

/**
 * Interface for BunnyStream video metadata
 */
export interface BunnyStreamVideo {
  videoLibraryId: number;
  guid: string;
  title: string;
  description: string | null;
  dateUploaded: string;
  views: number;
  isPublic: boolean;
  length: number;
  status: number;
  framerate: number;
  width: number;
  height: number;
  availableResolutions: string;
  storageSize: number;
  thumbnailFileName: string;
  category: string;
}

/**
 * Hook to fetch and merge BunnyStream data with our local videos
 */
export function useBunnyStream(options = {}) {
  const { toast } = useToast();
  // Get videos from our database
  const {
    data: videos,
    isLoading: isLoadingLocal,
    error: localError,
  } = useQuery<EnhancedVideoMetadata[]>({
    queryKey: ["/api/videos"],
    ...options,
  });

  // Fetch BunnyStream data when we have local videos
  const {
    data: bunnyData,
    isLoading: isLoadingBunny,
    error: bunnyError,
  } = useQuery<BunnyStreamVideo[]>({
    queryKey: ["/api/bunny/videos"],
    enabled: !!videos, // Only fetch if we have videos
    ...options,
  });

  // Merge Bunny data with local videos
  const enhancedVideos = videos?.map((video) => {
    const bunnyVideo = bunnyData?.find((b) => 
      b.guid === (video as any).bunny_guid || (video as any).bunnyGuid
    );
    return bunnyVideo ? { ...video, ...bunnyVideo } : video;
  });

  if (localError || bunnyError) {
    toast({
      title: "Error fetching content",
      description: localError?.message || bunnyError?.message,
      variant: "destructive",
    });
  }

  return {
    data: enhancedVideos || [],
    isLoading: isLoadingLocal || isLoadingBunny,
    error: localError || bunnyError,
  };
}