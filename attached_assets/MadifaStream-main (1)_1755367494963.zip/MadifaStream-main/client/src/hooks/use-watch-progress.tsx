import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from './use-auth';
import { useCallback, useRef, useEffect } from 'react';

import { getApiBaseUrl } from '../constants/app-constants';

const API_BASE = getApiBaseUrl();

interface WatchProgress {
  video_id: string;
  progress_seconds: number;
  completed: boolean;
}

export function useWatchProgress(videoId: string) {
  const { user, session } = useAuth();
  const queryClient = useQueryClient();
  
  // Debounce timer ref
  const saveTimerRef = useRef<NodeJS.Timeout | null>(null);
  const lastSavedRef = useRef<number>(0);

  // Get progress query
  const { data: progressData, isLoading } = useQuery<WatchProgress>({
    queryKey: ['watch-progress', videoId, user?.id],
    queryFn: async () => {
      if (!session?.access_token) {
        return { progress_seconds: 0, completed: false };
      }

      const response = await fetch(`${API_BASE}/api/videos/${videoId}/watch-progress`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch watch progress');
      }

      return response.json();
    },
    enabled: !!session?.access_token && !!videoId,
    staleTime: 30 * 1000, // 30 seconds
  });

  // Save progress mutation
  const saveProgressMutation = useMutation({
    mutationFn: async ({ progress_seconds, completed }: { progress_seconds: number; completed: boolean }) => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/videos/${videoId}/watch-progress`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ progress_seconds, completed }),
      });

      if (!response.ok) {
        throw new Error('Failed to save watch progress');
      }

      return response.json();
    },
    onSuccess: (data) => {
      // Update cache
      queryClient.setQueryData(['watch-progress', videoId, user?.id], data);
    },
  });

  // Debounced save function
  const saveProgress = useCallback((seconds: number, completed = false) => {
    // Clear existing timer
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
    }

    // Don't save if less than 5 seconds have passed since last save (unless completed)
    if (!completed && Math.abs(seconds - lastSavedRef.current) < 5) {
      return;
    }

    // Set new timer for debounced save (10 seconds)
    saveTimerRef.current = setTimeout(() => {
      saveProgressMutation.mutate({ progress_seconds: Math.floor(seconds), completed });
      lastSavedRef.current = seconds;
    }, completed ? 0 : 10000); // Save immediately if completed, otherwise debounce
  }, [videoId, saveProgressMutation]);

  // Force save function (for unmount/pause)
  const forceSave = useCallback((seconds: number, completed = false) => {
    // Clear any pending saves
    if (saveTimerRef.current) {
      clearTimeout(saveTimerRef.current);
    }

    // Save immediately
    if (session?.access_token && seconds > 0) {
      saveProgressMutation.mutate({ progress_seconds: Math.floor(seconds), completed });
      lastSavedRef.current = seconds;
    }
  }, [session?.access_token, saveProgressMutation]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (saveTimerRef.current) {
        clearTimeout(saveTimerRef.current);
      }
    };
  }, []);

  return {
    progress: progressData?.progress_seconds || 0,
    completed: progressData?.completed || false,
    isLoading,
    saveProgress,
    forceSave,
    isSaving: saveProgressMutation.isPending,
  };
}

// Hook for getting all watch progress for a user (useful for browse page)
export function useAllWatchProgress() {
  const { user, session } = useAuth();

  const { data: progressList = [], isLoading } = useQuery<WatchProgress[]>({
    queryKey: ['all-watch-progress', user?.id],
    queryFn: async () => {
      if (!session?.access_token) {
        return [];
      }

      // This would need a new endpoint to get all progress
      // For now, return empty array
      return [];
    },
    enabled: !!session?.access_token,
  });

  const getProgress = useCallback((videoId: string) => {
    const progress = progressList.find((p: WatchProgress) => p.video_id === videoId);
    return {
      seconds: progress?.progress_seconds || 0,
      percentage: 0, // Would need video duration to calculate
      completed: progress?.completed || false,
    };
  }, [progressList]);

  return {
    progressList,
    isLoading,
    getProgress,
  };
}

// Separate hook for home page usage that returns progressRecords and updateProgress
export function useWatchProgressRecords() {
  const { progressList, isLoading } = useAllWatchProgress();
  const queryClient = useQueryClient();
  
  const updateProgress = useMutation({
    mutationFn: async ({ videoId, progressSeconds }: { videoId: string; progressSeconds: number }) => {
      // This would update progress for a specific video
      // Implementation would depend on API structure
      return { videoId, progressSeconds };
    },
    onSuccess: () => {
      // Invalidate and refetch progress data
      queryClient.invalidateQueries({ queryKey: ['all-watch-progress'] });
    },
  });
  
  return {
    progressRecords: progressList,
    isLoading,
    updateProgress: updateProgress.mutate,
  };
}

// Default export for home page usage that returns progressRecords
export default function useWatchProgressAll() {
  return useWatchProgressRecords();
}