import { useCallback, useMemo, useEffect } from 'react';
import { useLocation } from 'wouter';
import { APP_ROUTES, RouteDefinition } from '../utils/navigation';
import { useAuthStore } from '../stores/authStore';
import { useUIStore } from '../stores/uiStore';

// Enhanced navigation hook that replaces the old NavigationManager
export const useEnhancedNavigation = () => {
  const [location, setLocation] = useLocation();
  const { isAuthenticated, hasAnyRole } = useAuthStore();
  const { addToast } = useUIStore();

  // Navigate to a path with optional query parameters
  const navigate = useCallback((path: string, options?: {
    replace?: boolean;
    state?: any;
    params?: Record<string, string>;
  }) => {
    let finalPath = path;
    
    // Add query parameters if provided
    if (options?.params) {
      const searchParams = new URLSearchParams(options.params);
      finalPath = `${path}?${searchParams.toString()}`;
    }
    
    setLocation(finalPath);
    
    // Store navigation state if provided
    if (options?.state) {
      if (options.replace) {
        window.history.replaceState(options.state, '', finalPath);
      } else {
        window.history.pushState(options.state, '', finalPath);
      }
    }
  }, [setLocation]);

  // Navigate back with fallback
  const goBack = useCallback((fallbackPath: string = '/') => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      navigate(fallbackPath);
    }
  }, [navigate]);

  // Navigate forward
  const goForward = useCallback(() => {
    window.history.forward();
  }, []);

  // Navigate to login with return URL
  const goToLogin = useCallback((returnUrl?: string) => {
    const loginPath = returnUrl 
      ? `/login?returnUrl=${encodeURIComponent(returnUrl)}`
      : '/login';
    navigate(loginPath);
  }, [navigate]);

  // Navigate to a protected route with auth check
  const navigateProtected = useCallback((path: string, options?: {
    requiredRoles?: string[];
    fallbackPath?: string;
  }) => {
    if (!isAuthenticated) {
      goToLogin(path);
      return;
    }

    if (options?.requiredRoles && !hasAnyRole(options.requiredRoles)) {
      addToast({
        type: 'error',
        title: 'Access Denied',
        message: 'You do not have permission to access this page.',
      });
      navigate(options.fallbackPath || '/');
      return;
    }

    navigate(path);
  }, [isAuthenticated, hasAnyRole, navigate, goToLogin, addToast]);

  // Get current route information
  const currentRoute = useMemo(() => {
    return APP_ROUTES.find(route => {
      if (route.path === location) return true;
      
      // Handle dynamic routes like /watch/:id
      if (route.path.includes(':')) {
        const routeRegex = new RegExp(
          '^' + route.path.replace(/:[^\s/]+/g, '([^/]+)') + '$'
        );
        return routeRegex.test(location);
      }
      
      return false;
    });
  }, [location]);

  // Extract parameters from current route
  const routeParams = useMemo(() => {
    if (!currentRoute || !currentRoute.path.includes(':')) {
      return {};
    }

    const routeParts = currentRoute.path.split('/');
    const locationParts = location.split('/');
    const params: Record<string, string> = {};

    routeParts.forEach((part, index) => {
      if (part.startsWith(':')) {
        const paramName = part.substring(1);
        params[paramName] = locationParts[index] || '';
      }
    });

    return params;
  }, [currentRoute, location]);

  // Get query parameters
  const queryParams = useMemo(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const params: Record<string, string> = {};
    
    searchParams.forEach((value, key) => {
      params[key] = value;
    });
    
    return params;
  }, [location]);

  // Update query parameters
  const updateQuery = useCallback((updates: Record<string, string | null>, replace = false) => {
    const searchParams = new URLSearchParams(window.location.search);
    
    Object.entries(updates).forEach(([key, value]) => {
      if (value === null) {
        searchParams.delete(key);
      } else {
        searchParams.set(key, value);
      }
    });
    
    const newUrl = `${window.location.pathname}?${searchParams.toString()}`;
    
    if (replace) {
      window.history.replaceState(null, '', newUrl);
    } else {
      window.history.pushState(null, '', newUrl);
    }
    
    setLocation(newUrl);
  }, [setLocation]);

  // Generate breadcrumbs
  const breadcrumbs = useMemo(() => {
    const pathParts = location.split('/').filter(Boolean);
    const crumbs: Array<{ name: string; path: string; title: string }> = [];

    // Always add home
    crumbs.push({
      name: 'home',
      path: '/',
      title: 'Home',
    });

    // Build breadcrumbs from path parts
    let currentPath = '';
    pathParts.forEach((part, index) => {
      currentPath += `/${part}`;
      
      const route = APP_ROUTES.find(r => r.path === currentPath);
      if (route) {
        crumbs.push({
          name: route.name,
          path: currentPath,
          title: route.title,
        });
      } else {
        // Handle dynamic routes
        const dynamicRoute = APP_ROUTES.find(r => {
          if (!r.path.includes(':')) return false;
          const routeRegex = new RegExp(
            '^' + r.path.replace(/:[^\s/]+/g, '([^/]+)') + '$'
          );
          return routeRegex.test(currentPath);
        });
        
        if (dynamicRoute) {
          crumbs.push({
            name: dynamicRoute.name,
            path: currentPath,
            title: part, // Use the actual parameter value as title
          });
        }
      }
    });

    return crumbs;
  }, [location]);

  // Check if user can access a route
  const canAccessRoute = useCallback((route: RouteDefinition) => {
    if (!route.requiresAuth) return true;
    
    if (!isAuthenticated) return false;
    
    if (route.roles && route.roles.length > 0) {
      return hasAnyRole(route.roles);
    }
    
    return true;
  }, [isAuthenticated, hasAnyRole]);

  return {
    // Current state
    location,
    currentRoute,
    routeParams,
    queryParams,
    breadcrumbs,
    
    // Navigation methods
    navigate,
    goBack,
    goForward,
    goToLogin,
    navigateProtected,
    
    // Query manipulation
    updateQuery,
    
    // Utility methods
    canAccessRoute,
  };
};

// Specific navigation helpers
export const useVideoNavigation = () => {
  const { navigate, navigateProtected } = useEnhancedNavigation();

  return {
    goToWatch: (videoId: string) => {
      navigateProtected(`/watch/${videoId}`, {
        requiredRoles: ['user'],
        fallbackPath: '/',
      });
    },
    
    goToVideoDetails: (videoId: string) => {
      navigate(`/video/${videoId}`);
    },
    
    goToSearch: (query?: string) => {
      const searchPath = query 
        ? `/search?q=${encodeURIComponent(query)}`
        : '/search';
      navigate(searchPath);
    },
    
    goToBrowse: (filters?: Record<string, string>) => {
      const browsePath = filters 
        ? `/browse?${new URLSearchParams(filters).toString()}`
        : '/browse';
      navigate(browsePath);
    },
  };
};

export const useUserNavigation = () => {
  const { navigate, navigateProtected } = useEnhancedNavigation();

  return {
    goToProfile: () => {
      navigateProtected('/profile', {
        requiredRoles: ['user'],
      });
    },
    
    goToWatchlist: () => {
      navigateProtected('/watchlist', {
        requiredRoles: ['user'],
      });
    },
    
    goToHistory: () => {
      navigateProtected('/history', {
        requiredRoles: ['user'],
      });
    },
    
    goToSettings: () => {
      navigateProtected('/settings', {
        requiredRoles: ['user'],
      });
    },
  };
};

// Hook for automatic page title updates
export const usePageTitle = (customTitle?: string) => {
  const { currentRoute } = useEnhancedNavigation();

  useEffect(() => {
    const title = customTitle || currentRoute?.title || 'MadifaStream';
    document.title = `${title} - MadifaStream`;
  }, [customTitle, currentRoute]);

  return {
    setTitle: (title: string) => {
      document.title = `${title} - MadifaStream`;
    },
  };
};
