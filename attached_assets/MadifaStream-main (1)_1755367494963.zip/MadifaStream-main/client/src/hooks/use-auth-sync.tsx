import { useEffect, useRef } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from '@/stores/authStore';
import { logger } from '@shared/logger';

/**
 * Hook to synchronize authentication state between Supabase and local store
 * This ensures auth persistence across page refreshes and handles middleware
 */
export function useAuthSync() {
  const { 
    setUser, 
    setSession, 
    setLoading,
    setProfile,
    session: storedSession 
  } = useAuthStore();
  
  const initRef = useRef(false);

  useEffect(() => {
    // Prevent double initialization
    if (initRef.current) return;
    initRef.current = true;

    let mounted = true;

    const syncAuthState = async () => {
      try {
        setLoading(true);
        
        // Get current session from Supabase
        const { data: { session }, error } = await supabase.auth.getSession();
        
        if (error) {
          logger.error("Auth sync error:", { arg1: error });
          if (mounted) {
            setSession(null);
            setUser(null);
          }
          return;
        }

        if (mounted) {
          if (session) {
            // Session exists, update store
            setSession(session);
            setUser(session.user);
            
            // Store auth token for API calls
            localStorage.setItem('auth_token', session.access_token);
            
            // Fetch user profile
            try {
              const { data: profile } = await supabase
                .from('profiles')
                .select('*')
                .eq('id', session.user.id)
                .single();
              
              if (profile) {
                setProfile(profile);
              }
            } catch (profileError) {
              logger.error("Profile fetch error:", { arg1: profileError });
            }
            
            if (import.meta.env.DEV) {
              logger.auth("Auth state synchronized:", { 
                arg1: session.user.email,
                arg2: "Session valid" 
              });
            }
          } else {
            // No session, clear everything
            setSession(null);
            setUser(null);
            setProfile(null);
            localStorage.removeItem('auth_token');
            
            if (import.meta.env.DEV) {
              logger.auth("No session found, cleared auth state");
            }
          }
        }
      } catch (error) {
        logger.error("Auth sync failed:", { arg1: error });
        if (mounted) {
          setSession(null);
          setUser(null);
        }
      } finally {
        if (mounted) {
          setLoading(false);
        }
      }
    };

    // Initial sync
    syncAuthState();

    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!mounted) return;

        if (import.meta.env.DEV) {
          logger.auth(`Auth event: ${event}`, { 
            arg1: session?.user?.email || 'No user' 
          });
        }

        switch (event) {
          case 'SIGNED_IN':
            if (session) {
              setSession(session);
              setUser(session.user);
              localStorage.setItem('auth_token', session.access_token);
              
              // Fetch profile after sign in
              try {
                const { data: profile } = await supabase
                  .from('profiles')
                  .select('*')
                  .eq('id', session.user.id)
                  .single();
                
                if (profile) {
                  setProfile(profile);
                } else {
                  // Create profile if it doesn't exist
                  const { data: newProfile } = await supabase
                    .from('profiles')
                    .insert({
                      id: session.user.id,
                      email: session.user.email,
                      username: session.user.email?.split('@')[0] || 'user',
                      created_at: new Date().toISOString(),
                      updated_at: new Date().toISOString(),
                    })
                    .select()
                    .single();
                  
                  if (newProfile) {
                    setProfile(newProfile);
                  }
                }
              } catch (profileError) {
                logger.error("Profile handling error:", { arg1: profileError });
              }
            }
            break;

          case 'SIGNED_OUT':
            setSession(null);
            setUser(null);
            setProfile(null);
            localStorage.removeItem('auth_token');
            break;

          case 'TOKEN_REFRESHED':
            if (session) {
              setSession(session);
              localStorage.setItem('auth_token', session.access_token);
            }
            break;

          case 'USER_UPDATED':
            if (session) {
              setUser(session.user);
              // Refetch profile
              try {
                const { data: profile } = await supabase
                  .from('profiles')
                  .select('*')
                  .eq('id', session.user.id)
                  .single();
                
                if (profile) {
                  setProfile(profile);
                }
              } catch (profileError) {
                logger.error("Profile update error:", { arg1: profileError });
              }
            }
            break;
        }
      }
    );

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []); // Empty dependency array - only run once

  return {
    isAuthenticated: !!storedSession,
    isReady: !useAuthStore((state) => state.isLoading)
  };
}