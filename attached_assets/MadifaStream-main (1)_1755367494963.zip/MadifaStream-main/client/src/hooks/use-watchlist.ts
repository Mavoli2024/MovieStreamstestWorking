import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getWatchlist, addToWatchlist, removeFromWatchlist, type Watchlist } from '@/lib/supabase-api';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from './use-auth';

export function useWatchlist() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user } = useAuth();

  const queryKey = ['watchlist', user?.id];

  const { data: watchlist = [], isLoading, isError } = useQuery<Watchlist[]>({
    queryKey,
    queryFn: getWatchlist,
    enabled: !!user
  });

  const addMutation = useMutation({
    mutationFn: addToWatchlist,
    onMutate: async (videoId: string) => {
      await queryClient.cancelQueries({ queryKey });
      const previousWatchlist = queryClient.getQueryData<Watchlist[]>(queryKey);

      const optimisticItem: Watchlist = {
        id: crypto.randomUUID(),
        user_id: user!.id,
        video_id: videoId,
        added_at: new Date().toISOString(),
      };

      queryClient.setQueryData<Watchlist[]>(queryKey, (old = []) => [...old, optimisticItem]);

      return { previousWatchlist };
    },
    onError: (err, videoId, context) => {
      queryClient.setQueryData(queryKey, context?.previousWatchlist);
      toast({
        title: "Error adding to watchlist",
        description: "There was an issue. Please try again.",
        variant: "destructive",
      });
    },
    onSuccess: () => {
      toast({ title: "Added to Watchlist" });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey });
    },
  });

  const removeMutation = useMutation({
    mutationFn: removeFromWatchlist,
    onMutate: async (videoId: string) => {
      await queryClient.cancelQueries({ queryKey });
      const previousWatchlist = queryClient.getQueryData<Watchlist[]>(queryKey);

      queryClient.setQueryData<Watchlist[]>(queryKey, (old = []) => 
        old.filter((item) => item.video_id !== videoId)
      );

      return { previousWatchlist };
    },
    onError: (err, videoId, context) => {
      queryClient.setQueryData(queryKey, context?.previousWatchlist);
      toast({
        title: "Error removing from watchlist",
        description: "There was an issue. Please try again.",
        variant: "destructive",
      });
    },
    onSuccess: () => {
      toast({ title: "Removed from Watchlist" });
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey });
    },
  });

  return {
    data: watchlist,
    watchlist,
    isLoading,
    isError,
    addToWatchlist: addMutation,
    removeFromWatchlist: removeMutation,
  };
}
