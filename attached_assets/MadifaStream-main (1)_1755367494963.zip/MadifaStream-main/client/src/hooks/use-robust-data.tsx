import { useState, useEffect, useCallback, useRef } from 'react';
import { robustApi } from '@/services/robust-api';
import { logger } from '@shared/logger';

interface UseRobustDataState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
  retryCount: number;
  lastFetch: number;
}

interface UseRobustDataOptions {
  retries?: number;
  retryDelay?: number;
  cacheTime?: number;
  refetchOnWindowFocus?: boolean;
  enabled?: boolean;
  onSuccess?: (data: any) => void;
  onError?: (error: Error) => void;
}

const DEFAULT_OPTIONS: Required<UseRobustDataOptions> = {
  retries: 3,
  retryDelay: 1000,
  cacheTime: 300000, // 5 minutes
  refetchOnWindowFocus: true,
  enabled: true,
  onSuccess: () => {},
  onError: () => {},
};

// Global cache to prevent duplicate requests
const requestCache = new Map<string, {
  data: any;
  timestamp: number;
  promise?: Promise<any>;
}>();

export function useRobustData<T = any>(
  key: string,
  fetcher: () => Promise<T>,
  options: UseRobustDataOptions = {}
) {
  const opts = { ...DEFAULT_OPTIONS, ...options };
  const [state, setState] = useState<UseRobustDataState<T>>({
    data: null,
    loading: false,
    error: null,
    retryCount: 0,
    lastFetch: 0,
  });

  const abortControllerRef = useRef<AbortController | null>(null);
  const mountedRef = useRef(true);

  const updateState = useCallback((updates: Partial<UseRobustDataState<T>>) => {
    if (mountedRef.current) {
      setState(prev => ({ ...prev, ...updates }));
    }
  }, []);

  const fetchData = useCallback(async (isRetry = false): Promise<void> => {
    if (!opts.enabled) return;

    // Check cache first
    const cached = requestCache.get(key);
    const now = Date.now();
    
    if (cached && (now - cached.timestamp) < opts.cacheTime) {
      updateState({
        data: cached.data,
        loading: false,
        error: null,
        lastFetch: cached.timestamp,
      });
      opts.onSuccess(cached.data);
      return;
    }

    // If there's already a pending request for this key, wait for it
    if (cached?.promise) {
      try {
        const data = await cached.promise;
        updateState({
          data,
          loading: false,
          error: null,
          lastFetch: now,
        });
        opts.onSuccess(data);
        return;
      } catch (error) {
        // Let the error handling below take care of it
      }
    }

    // Cancel previous request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }

    abortControllerRef.current = new AbortController();

    if (!isRetry) {
      updateState({ 
        loading: true, 
        error: null, 
        retryCount: 0 
      });
    } else {
      updateState(prev => ({ 
        retryCount: prev.retryCount + 1 
      }));
    }

    try {
      logger.info(`Fetching data for key: ${key}`);
      
      // Create the promise and cache it
      const promise = fetcher();
      requestCache.set(key, {
        data: null,
        timestamp: now,
        promise,
      });

      const data = await promise;

      // Validate data
      if (data === null || data === undefined) {
        throw new Error('No data received from server');
      }

      // Update cache with successful result
      requestCache.set(key, {
        data,
        timestamp: now,
      });

      updateState({
        data,
        loading: false,
        error: null,
        lastFetch: now,
      });

      opts.onSuccess(data);
      logger.info(`Data fetched successfully for key: ${key}`);

    } catch (error) {
      // Remove failed promise from cache
      requestCache.delete(key);

      if (abortControllerRef.current?.signal.aborted) {
        return; // Request was cancelled, don't update state
      }

      const errorMessage = error instanceof Error ? error.message : 'Failed to fetch data';
      logger.error(`Data fetch failed for key ${key}:`, error);

      // Auto-retry with exponential backoff
      if (state.retryCount < opts.retries) {
        const delay = opts.retryDelay * Math.pow(2, state.retryCount);
        logger.info(`Retrying data fetch in ${delay}ms (attempt ${state.retryCount + 1}/${opts.retries})`);
        
        setTimeout(() => {
          if (mountedRef.current) {
            fetchData(true);
          }
        }, delay);
        return;
      }

      updateState({
        error: errorMessage,
        loading: false,
      });

      opts.onError(new Error(errorMessage));
    }
  }, [key, fetcher, opts, state.retryCount, updateState]);

  const refetch = useCallback(() => {
    requestCache.delete(key); // Clear cache
    setState(prev => ({ ...prev, retryCount: 0 })); // Reset retry count
    return fetchData();
  }, [key, fetchData]);

  const mutate = useCallback((newData: T | null) => {
    if (newData !== null) {
      requestCache.set(key, {
        data: newData,
        timestamp: Date.now(),
      });
    } else {
      requestCache.delete(key);
    }
    
    updateState({
      data: newData,
      error: null,
    });
  }, [key, updateState]);

  // Initial fetch
  useEffect(() => {
    if (opts.enabled) {
      fetchData();
    }
    
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, [key, opts.enabled]);

  // Refetch on window focus
  useEffect(() => {
    if (!opts.refetchOnWindowFocus) return;

    const handleFocus = () => {
      const cached = requestCache.get(key);
      const now = Date.now();
      
      // Only refetch if cache is older than 30 seconds
      if (!cached || (now - cached.timestamp) > 30000) {
        fetchData();
      }
    };

    window.addEventListener('focus', handleFocus);
    return () => window.removeEventListener('focus', handleFocus);
  }, [key, fetchData, opts.refetchOnWindowFocus]);

  // Cleanup on unmount
  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  return {
    ...state,
    refetch,
    mutate,
    isRefetching: state.loading && state.data !== null,
    isRetrying: state.retryCount > 0,
  };
}

// Specialized hook for videos
export function useRobustVideos(options: UseRobustDataOptions = {}) {
  return useRobustData(
    'videos',
    () => robustApi.get('/api/videos/public'),
    {
      cacheTime: 60000, // 1 minute cache for videos
      ...options,
    }
  );
}

// Specialized hook for video by ID
export function useRobustVideo(videoId: string, options: UseRobustDataOptions = {}) {
  return useRobustData(
    `video-${videoId}`,
    () => robustApi.get(`/api/videos/${videoId}`),
    {
      enabled: !!videoId,
      ...options,
    }
  );
}

// Specialized hook for categories
export function useRobustCategories(options: UseRobustDataOptions = {}) {
  return useRobustData(
    'categories',
    () => robustApi.get('/api/categories'),
    {
      cacheTime: 600000, // 10 minutes cache for categories
      ...options,
    }
  );
}

// Specialized hook for user profile
export function useRobustProfile(options: UseRobustDataOptions = {}) {
  return useRobustData(
    'profile',
    () => robustApi.get('/api/user/profile'),
    {
      cacheTime: 300000, // 5 minutes cache for profile
      refetchOnWindowFocus: false, // Don't refetch profile on focus
      ...options,
    }
  );
}

export default useRobustData;