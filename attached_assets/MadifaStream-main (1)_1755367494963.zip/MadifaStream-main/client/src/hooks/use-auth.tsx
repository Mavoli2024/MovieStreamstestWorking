import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { type Profile } from "@/lib/supabase-api";
import type {  Session, User  } from "@supabase/supabase-js";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import React, { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { logger } from '@shared/logger';

// Define the shape of the context value
interface AuthContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null; // The full user profile from our 'profiles' table
  userData?: Profile | null; // alias for backward compatibility
  _profile?: Profile | null; // temporary alias for legacy code paths
  isLoading: boolean;
  checkSubscription: () => Promise<boolean>;
  login: (credentials: { email: string; password: string }) => Promise<unknown>;
  register: (details: { email: string; password: string; [key: string]: unknown }) => Promise<unknown>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  signInWithGoogle?: () => Promise<void>;
  loginMutation: ReturnType<typeof useMutation>;
  registerMutation: ReturnType<typeof useMutation>;
  logoutMutation: ReturnType<typeof useMutation>;
}

// Create the context
export const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Define the props for the provider component
interface AuthProviderProps {
  children: ReactNode;
}

async function fetchUserProfile(userId: string): Promise<Profile | null> {
    const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
    
    if (error) {
      if (import.meta.env.DEV) {
          logger.auth("Error fetching user profile:", { arg1: error });
      }   
      return null;
    }
    
    return data;
}

export const AuthProvider = ({ children }: AuthProviderProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [_credentials, _setCredentials] = useState<{ email: string; password: string } | null>(null);
  const [_details, _setDetails] = useState<{ email: string; password: string; [key: string]: unknown } | null>(null);
  const [_email, _setEmail] = useState<string>("");

  // Use React Query to fetch the user's profile
  const { data: profile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['profile', user?.id],
    queryFn: () => (user ? fetchUserProfile(user.id) : Promise.resolve(null)),
    enabled: !!user, // Only run the query if there is a user
  });

  useEffect(() => {
    let mounted = true;
    
    const initializeAuth = async () => {
      try {
        // Check for existing session
        const { data: { session: existingSession }, error } = await supabase.auth.getSession();
        
        if (error) {
          logger.error("Error getting session:", { arg1: error });
        }
        
        if (mounted) {
          setSession(existingSession);
          setUser(existingSession?.user ?? null);
          
          // If we have a session, ensure it's persisted properly
          if (existingSession) {
            // Store auth token for API calls
            localStorage.setItem('auth_token', existingSession.access_token);
            
            // Invalidate profile query to fetch fresh data
            queryClient.invalidateQueries({ queryKey: ['profile', existingSession.user.id] });
          }
          
          setIsLoading(false);
        }
      } catch (error) {
        logger.error("Auth initialization error:", { arg1: error });
        if (mounted) {
          setIsLoading(false);
        }
      }
    };
    
    initializeAuth();

    // Listen for auth state changes
    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (import.meta.env.DEV) {
        logger.auth(`Auth state changed: ${event}`, { arg1: session?.user?.email });
      }
      
      if (mounted) {
        setSession(session);
        setUser(session?.user ?? null);
        
        // Handle different auth events
        switch (event) {
          case 'SIGNED_IN':
            // Store auth token for API calls
            if (session?.access_token) {
              localStorage.setItem('auth_token', session.access_token);
            }
            // Invalidate queries to refresh user data
            queryClient.invalidateQueries({ queryKey: ['profile', session?.user?.id] });
            queryClient.invalidateQueries({ queryKey: ['user'] });
            break;
            
          case 'SIGNED_OUT':
            // Clear all auth-related data
            localStorage.removeItem('auth_token');
            queryClient.clear();
            break;
            
          case 'TOKEN_REFRESHED':
            // Update stored token
            if (session?.access_token) {
              localStorage.setItem('auth_token', session.access_token);
            }
            break;
            
          case 'USER_UPDATED':
            // Refresh profile data
            queryClient.invalidateQueries({ queryKey: ['profile', session?.user?.id] });
            break;
        }
      }
    });

    return () => {
      mounted = false;
      authListener.subscription.unsubscribe();
    };
  }, [queryClient]);

  const loginMutation = useMutation({
    mutationFn: async (credentials: { email: string; password: string }) => {
      const { data, error } = await supabase.auth.signInWithPassword(credentials);
      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profile'] });
      toast({
        title: "Welcome back!",
        description: "You have been successfully signed in.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Sign In Failed",
        description: error.message || "Invalid email or password. Please try again.",
        variant: "destructive",
      });
    }
  });

  const registerMutation = useMutation({
    mutationFn: async (details: { email: string; password: string; [key: string]: unknown }) => {
        const { email, password, ...rest } = details;
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
            options: { data: rest }
      });
      if (error) throw error;
      return data;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['profile'] });
      if (data?.user && !data.user.confirmed_at) {
        toast({
          title: "Registration Successful!",
          description: "Please check your email to confirm your account before signing in.",
        });
      } else {
      toast({
          title: "Account Created!",
          description: "Welcome to Madifa! Your account has been created successfully.",
      });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Failed to create account. Please try again.",
        variant: "destructive",
      });
    }
  });

  const logoutMutation = useMutation<void, Error, undefined>({
    mutationFn: async () => {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
    },
    onSuccess: () => {
      setSession(null);
      setUser(null);
      queryClient.clear();
    }
  });

  const resetPasswordMutation = useMutation({
    mutationFn: async (email: string) => {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "Password Reset Email Sent",
        description: "Check your email for instructions to reset your password.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send password reset email.",
        variant: "destructive",
      });
    }
  });

  const signInWithGoogle = async () => {
    // Store current URL for post-auth redirect
    const currentUrl = window.location.pathname;
    if (currentUrl !== '/auth' && currentUrl !== '/login') {
      localStorage.setItem('authRedirectUrl', currentUrl);
    }
    
    // Configure redirect URL based on environment
    const redirectUrl = import.meta.env.PROD 
      ? `${window.location.origin}/auth-callback`
      : `${window.location.origin}/auth-callback`;
    
    if (import.meta.env.DEV) {
      logger.auth("Google OAuth redirect URL:", { arg1: redirectUrl });
    }
    
    const { error } = await supabase.auth.signInWithOAuth({ 
      provider: 'google',
      options: {
        redirectTo: redirectUrl,
        queryParams: {
          access_type: 'offline',
          prompt: 'consent',
        }
      }
    });
    
    if (error) {
      logger.error("Google sign in error:", { arg1: error });
      throw error;
    }
  };

  const checkSubscription = async (): Promise<boolean> => {
    if (!user) return false;
    // Work around TS2589 deep instantiation error by opting out of generics on the query
    // Work around TS2589 deep instantiation error 
    const sb = supabase as typeof supabase;
    const { data, error } = await sb
      .from('subscriptions')
      .select('status')
      .eq('user_id', user.id)
      .in('status', ['trialing', 'active'])
      .single();
    
    if (error && error.code !== 'PGRST116') { // PGRST116 is "not found" which is expected for users without subscriptions
      if (import.meta.env.DEV) {
        logger.auth("Subscription check error:", { arg1: error });
      }
    }
    
    return !!data;
  };

  const value = {
    session,
    user,
    profile: profile ?? null,
    _profile: profile ?? null,
    userData: profile ?? null,
    isLoading: isLoading || isLoadingProfile,
    checkSubscription,
    login: loginMutation.mutateAsync,
    register: registerMutation.mutateAsync,
    logout: () => logoutMutation.mutateAsync(undefined),
    resetPassword: resetPasswordMutation.mutateAsync,
    signInWithGoogle,
    loginMutation,
    registerMutation,
    logoutMutation,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};