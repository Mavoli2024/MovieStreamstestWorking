import { type SubscriptionPlan } from "@/types/database-generated.types";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "./use-auth";
import { supabase } from "@/lib/supabase";
import { logger } from '@shared/logger';

export function useSubscription() {
  const { profile, isLoading: isAuthLoading } = useAuth();

  // Query subscriptions table directly for accurate status
  const { 
    data: subscription, 
    isLoading: isSubscriptionLoading 
  } = useQuery({
    queryKey: ['user-subscription', profile?.id],
    queryFn: async () => {
      if (!profile?.id) return null;
      
      const { data, error } = await supabase
        .from('subscriptions')
        .select('is_active, end_date, plan_id')
        .eq('user_id', profile.id)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        logger.error('Error fetching subscription:', { arg1: error });
        return null;
      }

      // Check if subscription is expired
      if (data?.end_date) {
        const now = new Date();
        const endDate = new Date(data.end_date);
        if (endDate <= now) {
          return null; // Expired
        }
      }

      return data;
    },
    enabled: !!profile?.id && !isAuthLoading,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const isLoading = isAuthLoading || isSubscriptionLoading;
  const hasPremiumAccess = !isLoading && !!subscription?.is_active;
  const isFreeTier = !isLoading && !subscription?.is_active;

  // This is a simplified "subscription" object for compatibility with components
  // that might expect it. The core logic relies only on `hasPremiumAccess`.
  const subscriptionData = profile ? {
    planId: hasPremiumAccess ? "premium" : "free",
    isActive: hasPremiumAccess,
    id: 1, 
    userId: profile.id,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  } : null;

  // The query for plans can remain if the UI needs to display plan details.
  // Access control is completely independent of this.
  const {
    data: plans,
    isLoading: isPlansLoading,
    error: plansError
  } = useQuery<SubscriptionPlan[]>({
    queryKey: ["subscription-plans-simple"],
    queryFn: async () => {
      // In a real app, this would fetch from the database.
      // For now, static data is acceptable.
      return [
        {
          id: "free",
          name: "Free",
          price: 0,
          video_quality: "SD",
          max_devices: 1,
          offline_downloads: false,
          max_downloads: 0,
          duration_months: 0,
          features: ["Limited content", "SD quality", "With ads"],
        },
        {
          id: "premium",
          name: "Premium",
          price: 5900,
          video_quality: "HD",
          max_devices: 4,
          offline_downloads: true,
          max_downloads: 20,
          duration_months: 1,
          features: ["All content", "HD quality", "No ads", "Offline downloads"],
        },
      ] as any;
    },
  });
  
  // Helper functions now correctly use the profile-derived status.
  const canWatchFullContent = () => {
    return hasPremiumAccess;
  };
  
  const canOnlyWatchTrailers = () => {
    return !hasPremiumAccess;
  };
  
  const currentPlan = subscriptionData && plans
    ? plans.find(plan => plan.id === subscriptionData.planId)
    : null;
  
  const premiumPlan = plans?.find(plan => plan.name === "Premium") || null;
  
  const freePlan = plans?.find(plan => plan.name === "Free") || null;
  
  return {
    subscription: subscriptionData,
    plans,
    isLoading: isAuthLoading || isPlansLoading,
    error: plansError,
    hasPremiumAccess,
    isFreeTier,
    canWatchFullContent,
    canOnlyWatchTrailers,
    currentPlan,
    premiumPlan,
    freePlan
  };
}