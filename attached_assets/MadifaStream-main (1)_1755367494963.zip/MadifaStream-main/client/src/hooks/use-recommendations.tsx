import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from './use-auth';

import { getApiBaseUrl } from '@/constants/app-constants';

const API_BASE = getApiBaseUrl();

import type { Database } from '@/types/database-generated.types';
import { logger } from '@shared/logger';

type Video = Database['public']['Tables']['videos']['Row'];

export interface Recommendation extends Video {
  recommendation_score: number;
  reason: string;
}

export interface SimilarVideo extends Video {
  similarity_score: number;
}

export interface TrendingVideo extends Video {
  trending_score: number;
  recent_views: number;
}

export function useRecommendations() {
  const { session } = useAuth();
  const queryClient = useQueryClient();

  // Get personalized recommendations
  const {
    data: recommendations = [],
    isLoading: isLoadingRecommendations,
    error: recommendationsError
  } = useQuery<Recommendation[]>({
    queryKey: ['recommendations'],
    queryFn: async () => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/recommendations?limit=20`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch recommendations');
      }

      const data = await response.json();
      return data.recommendations || [];
    },
    enabled: !!session?.access_token,
    staleTime: 10 * 60 * 1000, // 10 minutes
    refetchOnWindowFocus: false,
  });

  // Get trending videos
  const {
    data: trending = [],
    isLoading: isLoadingTrending
  } = useQuery<TrendingVideo[]>({
    queryKey: ['trending', '7d'],
    queryFn: async () => {
      const response = await fetch(`${API_BASE}/api/recommendations/trending?timeframe=7d&limit=15`);

      if (!response.ok) {
        throw new Error('Failed to fetch trending videos');
      }

      const data = await response.json();
      return data.trending_videos || [];
    },
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
  });

  // Get similar videos for a specific video
  const getSimilarVideos = async (videoId: string, limit = 10): Promise<SimilarVideo[]> => {
    try {
      const response = await fetch(`${API_BASE}/api/recommendations/similar/${videoId}?limit=${limit}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch similar videos');
      }

      const data = await response.json();
      return data.similar_videos || [];
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Error fetching similar videos:', { arg1: error });
      }
      return [];
    }
  };

  // Record feedback on recommendations
  const recordFeedbackMutation = useMutation({
    mutationFn: async ({ videoId, action, source }: { 
      videoId: string; 
      action: 'view' | 'play' | 'add_to_watchlist' | 'like' | 'dismiss'; 
      source: string;
    }) => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/recommendations/feedback`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ videoId, action, source }),
      });

      if (!response.ok) {
        throw new Error('Failed to record feedback');
      }

      return response.json();
    },
    onSuccess: () => {
      // Invalidate recommendations to refresh with improved suggestions
      queryClient.invalidateQueries({ queryKey: ['recommendations'] });
    },
  });

  // Helper function to record when user interacts with recommended content
  const recordInteraction = (videoId: string, action: 'view' | 'play' | 'add_to_watchlist' | 'like' | 'dismiss', source = 'recommendations') => {
    recordFeedbackMutation.mutate({ videoId, action, source });
  };

  // Get recommendations by category
  const getRecommendationsByCategory = () => {
    if (!recommendations.length) return {};

    const categories: { [key: string]: Recommendation[] } = {
      'For You': recommendations.slice(0, 8),
      'Similar to What You Watched': recommendations.filter(r => 
        r.reason.includes('You enjoy') || r.reason.includes('director')
      ).slice(0, 6),
      'Popular Picks': recommendations.filter(r => 
        r.reason.includes('Popular')
      ).slice(0, 6),
      'New Releases': recommendations.filter(r => 
        new Date(r.release_year, 0, 1).getTime() > new Date().getTime() - (2 * 365 * 24 * 60 * 60 * 1000)
      ).slice(0, 6)
    };

    // Remove empty categories
    Object.keys(categories).forEach(key => {
      if (categories[key].length === 0) {
        delete categories[key];
      }
    });

    return categories;
  };

  return {
    // Data
    recommendations,
    trending,
    
    // Loading states
    isLoadingRecommendations,
    isLoadingTrending,
    
    // Errors
    recommendationsError,
    
    // Functions
    getSimilarVideos,
    recordInteraction,
    getRecommendationsByCategory,
    
    // Mutations
    isRecordingFeedback: recordFeedbackMutation.isPending,
  };
}

// Hook for getting similar videos (with React Query caching)
export function useSimilarVideos(videoId: string, enabled = true) {
  return useQuery<SimilarVideo[]>({
    queryKey: ['similar-videos', videoId],
    queryFn: async () => {
      const response = await fetch(`${API_BASE}/api/recommendations/similar/${videoId}?limit=8`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch similar videos');
      }

      const data = await response.json();
      return data.similar_videos || [];
    },
    enabled: enabled && !!videoId,
    staleTime: 15 * 60 * 1000, // 15 minutes
  });
} 