import { useEffect } from 'react';

interface SupabaseErrorHandlerOptions {
  onError?: (error: Error) => void;
}

export function useSupabaseErrorHandler(options: SupabaseErrorHandlerOptions = {}) {
  useEffect(() => {
    // This could be expanded to listen for specific Supabase errors
    // For now, it's just a placeholder that allows the onError callback to be used
    const handleError = (event: ErrorEvent) => {
      if (event.error && options.onError) {
        options.onError(event.error);
      }
    };

    // Listen for global errors
    window.addEventListener('error', handleError);

    return () => {
      window.removeEventListener('error', handleError);
    };
  }, [options.onError]);

  /**
   * Optional helper for Native (Capacitor) environments to display toast notifications
   * when Supabase errors occur. Currently a **no-op** on web but returning the function
   * prevents runtime crashes when the caller destructures it.
   *
   * You can enhance this later to integrate with your toast / notification system.
   */
  const setupToastHandler = () => {
    /* Placeholder – integrate native toast logic if needed */
  };

  // Expose helpers so consumers can safely destructure them
  return { setupToastHandler };
} 