import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuth } from './use-auth';
import { useToast } from './use-toast';

import { getApiBaseUrl } from '@/constants/app-constants';

const API_BASE = getApiBaseUrl();

export interface Download {
  id: number;
  videoId: string;
  title: string;
  thumbnailUrl: string;
  size: string;
  progress: number;
  status: 'pending' | 'downloading' | 'completed' | 'failed' | 'expired';
  downloadedAt: string;
  expiresAt: string;
  downloadQuality: 'sd' | 'hd' | 'fhd';
  video: {
    id: string;
    title: string;
    description: string;
    thumbnail_url: string;
    duration_minutes: number;
    release_year: number;
    age_rating: string;
    genres: string[];
  };
}

export interface DownloadSettings {
  max_downloads: number;
  auto_download_next_episode: boolean;
  download_quality: 'sd' | 'hd' | 'fhd';
  wifi_only: boolean;
}

export function useDownloads() {
  const { user, session } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch user's downloads
  const {
    data: downloads = [],
    isLoading,
    error
  } = useQuery<Download[]>({
    queryKey: ['downloads', user?.id],
    queryFn: async () => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/downloads`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || 'Failed to fetch downloads');
      }

      return response.json();
    },
    enabled: !!session?.access_token,
    refetchInterval: 5000, // Poll every 5 seconds for download progress
  });

  // Fetch download settings
  const {
    data: settings,
    isLoading: isLoadingSettings
  } = useQuery<DownloadSettings>({
    queryKey: ['download-settings', user?.id],
    queryFn: async () => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/downloads/settings`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch download settings');
      }

      return response.json();
    },
    enabled: !!session?.access_token,
  });

  // Start download mutation
  const startDownloadMutation = useMutation({
    mutationFn: async ({ videoId, quality = 'hd' }: { videoId: string; quality?: 'sd' | 'hd' | 'fhd' }) => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/downloads`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ videoId, quality }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to start download');
      }

      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: 'Download Started',
        description: 'Your video download has been started successfully.',
      });
      // Refresh downloads list
      queryClient.invalidateQueries({ queryKey: ['downloads'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Download Failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Delete download mutation
  const deleteDownloadMutation = useMutation({
    mutationFn: async (downloadId: number) => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/downloads/${downloadId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to delete download');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Download Removed',
        description: 'The download has been removed from your device.',
      });
      // Refresh downloads list
      queryClient.invalidateQueries({ queryKey: ['downloads'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to Remove Download',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (newSettings: Partial<DownloadSettings>) => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/downloads/settings`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newSettings),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to update settings');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Settings Updated',
        description: 'Your download settings have been saved.',
      });
      // Refresh settings
      queryClient.invalidateQueries({ queryKey: ['download-settings'] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to Update Settings',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Helper functions
  const startDownload = (videoId: string, quality: 'sd' | 'hd' | 'fhd' = 'hd') => {
    startDownloadMutation.mutate({ videoId, quality });
  };

  const deleteDownload = (downloadId: number) => {
    deleteDownloadMutation.mutate(downloadId);
  };

  const updateSettings = (newSettings: Partial<DownloadSettings>) => {
    updateSettingsMutation.mutate(newSettings);
  };

  const isVideoDownloaded = (videoId: string) => {
    return downloads.some(download => download.videoId === videoId && download.status === 'completed');
  };

  const isVideoDownloading = (videoId: string) => {
    return downloads.some(download => 
      download.videoId === videoId && 
      (download.status === 'pending' || download.status === 'downloading')
    );
  };

  const getDownloadProgress = (videoId: string) => {
    const download = downloads.find(download => download.videoId === videoId);
    return download?.progress || 0;
  };

  const completedDownloads = downloads.filter(d => d.status === 'completed');
  const downloadingItems = downloads.filter(d => d.status === 'downloading' || d.status === 'pending');

  return {
    downloads,
    completedDownloads,
    downloadingItems,
    settings,
    isLoading,
    isLoadingSettings,
    error,
    startDownload,
    deleteDownload,
    updateSettings,
    isVideoDownloaded,
    isVideoDownloading,
    getDownloadProgress,
    isStartingDownload: startDownloadMutation.isPending,
    isDeletingDownload: deleteDownloadMutation.isPending,
    isUpdatingSettings: updateSettingsMutation.isPending,
  };
} 