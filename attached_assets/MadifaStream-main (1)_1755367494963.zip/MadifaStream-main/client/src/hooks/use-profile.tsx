import { useAuth } from "@/hooks/use-auth";

/**
 * A simplified hook to access the current user's profile data.
 * This hook is a lightweight wrapper around the `useAuth` hook,
 * providing direct access to the `profile` object and the
 * authentication loading state.
 *
 * It is intended to be the primary way UI components access
 * profile information, ensuring a consistent data source.
 */
export function useProfile() {
  const { profile, isLoading, user } = useAuth();

  return {
    // The full profile object for the authenticated user.
    activeProfile: profile,

    // Legacy alias expected by some components (e.g., MobileMainLayout)
    currentProfile: profile,

    // Loading state
    isLoadingProfile: isLoading,

    // Raw Supabase user object
    user,
  };
}