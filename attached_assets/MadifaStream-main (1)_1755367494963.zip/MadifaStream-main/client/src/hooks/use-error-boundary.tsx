/**
 * Error Boundary Hook
 * 
 * Provides error boundary functionality for components
 */

import { useState, useCallback } from 'react';
import { logger } from '@shared/logger';

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: unknown;
}

interface UseErrorBoundaryOptions {
  onError?: (error: Error, errorInfo: unknown) => void;
  fallback?: React.ComponentType<{ error: Error; resetError: () => void }>;
}

export function useErrorBoundary(options: UseErrorBoundaryOptions = {}) {
  const [state, setState] = useState<ErrorBoundaryState>({
    hasError: false,
    error: null,
    errorInfo: null,
  });

  const captureError = useCallback((error: Error, errorInfo?: unknown) => {
    logger.error('Error boundary caught error:', error, errorInfo as any);
    
    setState({
      hasError: true,
      error,
      errorInfo,
    });

    if (options.onError) {
      options.onError(error, errorInfo);
    }
  }, [options.onError]);

  const resetError = useCallback(() => {
    setState({
      hasError: false,
      error: null,
      errorInfo: null,
    });
  }, []);

  const throwError = useCallback((error: Error) => {
    captureError(error);
  }, [captureError]);

  return {
    hasError: state.hasError,
    error: state.error,
    errorInfo: state.errorInfo,
    captureError,
    resetError,
    throwError,
  };
} 