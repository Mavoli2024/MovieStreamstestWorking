import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import type { Database } from '@/types/database-generated.types';

type Video = Database['public']['Tables']['videos']['Row'];

export function useAdminVideos() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const {
    data: videos = [],
    isLoading: videosLoading,
    refetch: refetchVideos,
  } = useQuery({
    queryKey: ['admin-videos'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('videos')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    },
  });

  const createVideoMutation = useMutation({
    mutationFn: async (data: Partial<Video>) => {
      const { error } = await supabase.from('videos').insert([data]);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-videos'] });
      toast({ title: 'Video created successfully' });
    },
  });

  const updateVideoMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Video> }) => {
      const { error } = await supabase
        .from('videos')
        .update(data)
        .eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-videos'] });
      toast({ title: 'Video updated successfully' });
    },
  });

  const deleteVideoMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from('videos').delete().eq('id', id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-videos'] });
      toast({ title: 'Video deleted successfully' });
    },
  });

  return {
    videos,
    videosLoading,
    refetchVideos,
    createVideo: createVideoMutation.mutate,
    updateVideo: updateVideoMutation.mutate,
    deleteVideo: deleteVideoMutation.mutate,
    isCreating: createVideoMutation.isPending,
    isUpdating: updateVideoMutation.isPending,
    isDeleting: deleteVideoMutation.isPending,
  };
} 