import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { logger } from '@shared/logger';

// Define a temporary Profile type for backward compatibility
type Profile = {
  id: string;
  userId: string;
  name: string;
  avatarColor?: string;
  isKids: boolean;
};

export function useProfile() {
  const { user, userData } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient(); // Move to component level

  // Create synthetic profile from user data
  const createSyntheticProfile = (): Profile | null => {
    if (!userData) return null;

    return {
      id: String(userData.id),
      userId: String(userData.id),
      name: userData.display_name || userData.username,
      avatarColor: "#1E90FF",
      isKids: false
    };
  };

  // Use current user data as the "current profile"
  const [currentProfile, setCurrentProfile] = useState<Profile | null>(createSyntheticProfile());

  // Fetch profiles - simplified to just return the current user as a "profile"
  const {
    data: profiles = [],
    isLoading: isLoadingProfiles,
    error: profilesError,
    refetch: refetchProfiles,
  } = useQuery<Profile[]>({
    queryKey: ["/api/profiles"],
    queryFn: async () => {
      if (!user) return [];

      try {
        const response = await fetch('/api/profiles', {
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${(await supabase.auth.getSession()).data.session?.access_token || ''}`,
          },
          credentials: 'include',
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch profiles: ${response.status}`);
        }

        return await response.json();
      } catch (error) {
        if (import.meta.env.DEV) {
          logger.error("Error fetching profiles:", { arg1: error });
        }
        return [];
      }
    },
    enabled: !!user,
  });

  // Simplified createProfile - logs message but doesn't actually create new profiles
  const createProfileMutation = useMutation({
    mutationFn: async (_profileData: { name: string; isKids?: boolean }) => {
      if (import.meta.env.DEV) {
        logger.info("Create profile operation not supported in simplified user model");
      }
      return createSyntheticProfile();
    },
    onSuccess: () => {
      toast({
        title: "Profile information",
        description: "Multiple profiles are not supported in the simplified user model.",
      });
    },
    onError: (error) => {
      toast({
        title: "Profile operation failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });

  // Simplified updateProfile - only updates name
  const updateProfileMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<Profile> }) => {
      if (import.meta.env.DEV) {
        logger.info("Simplified update profile operation", { arg1: id, arg2: data });
      }

      // Only support name updates for now
      if (data.name && userData) {
        try {
          const session = await supabase.auth.getSession();
          const token = session.data.session?.access_token;

          if (!token) {
            throw new Error('No authentication token available');
          }

          const response = await fetch(`/api/user/display-name`, {
            method: 'PATCH',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${token}`,
            },
            credentials: 'include',
            body: JSON.stringify({ displayName: data.name }),
          });

          if (!response.ok) {
            throw new Error(`Failed to update user: ${response.status}`);
          }

          return {
            success: true,
            profile: {
              ...createSyntheticProfile(),
              name: data.name
            }
          };
        } catch (error) {
          if (import.meta.env.DEV) {
            logger.error("Error updating display name:", { arg1: error });
          }
          throw error;
        }
      }

      // Return a mock success for other properties (to avoid breaking UI)
      return {
        success: true,
        profile: createSyntheticProfile()
      };
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/profiles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });

      if (data.profile) {
        setCurrentProfile(data.profile);
      }

      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update profile",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    },
  });

  // Simplified deleteProfile - not supported, shows message
  const deleteProfileMutation = useMutation({
    mutationFn: async (_id: string) => {
      if (import.meta.env.DEV) {
        logger.info("Delete profile operation not supported in simplified user model");
      }
      throw new Error("Deleting your account is not supported. Please contact support.");
    },
    onError: (error) => {
      toast({
        title: "Operation not supported",
        description: error instanceof Error ? error.message : "This operation is not supported",
        variant: "destructive",
      });
    },
  });

  // Simplified switchProfile - doesn't actually switch profiles
  const switchProfile = (_profileId: string) => {
    toast({
      title: "Operation not supported",
      description: "Multiple profiles are not supported in the current version.",
    });
  };

  // Helper function for backward compatibility
  const createDefaultProfile = () => {
    if (import.meta.env.DEV) {
      logger.info("Default profile creation not needed in simplified user model");
    }
    // Nothing to do - user is already created in the backend
  };

  return {
    // Profiles data
    profiles: profiles.length > 0 ? profiles : (currentProfile ? [currentProfile] : []),
    currentProfile: currentProfile || createSyntheticProfile(),
    isLoadingProfiles,
    profilesError,

    // Profile mutations
    createProfile: createProfileMutation.mutate,
    updateProfile: updateProfileMutation.mutate,
    deleteProfile: deleteProfileMutation.mutate,
    switchProfile,
    createDefaultProfile,

    // Loading states
    isCreatingProfile: createProfileMutation.isPending,
    isUpdatingProfile: updateProfileMutation.isPending,
    isDeletingProfile: deleteProfileMutation.isPending,

    // Manual refresh
    refetchProfiles,
  };
}