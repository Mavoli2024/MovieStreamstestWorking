/**
 * Form Handling and Validation Hook
 * 
 * Provides comprehensive form state management, validation, and submission handling
 * with type safety and error handling.
 */

import React, { useState, useCallback, useMemo, useRef } from 'react';
import { errorUtils, ErrorType, ErrorSeverity } from '../utils/errorHandling';

// Form field configuration
export interface FormField<T = any> {
  value: T;
  error?: string;
  touched: boolean;
  valid: boolean;
  required?: boolean;
  validators?: ValidationRule<T>[];
}

// Validation rule interface
export interface ValidationRule<T = any> {
  validate: (value: T, allValues?: Record<string, any>) => boolean;
  message: string;
  type?: 'required' | 'email' | 'password' | 'custom';
}

// Form state
export interface FormState<T extends Record<string, any>> {
  values: T;
  errors: Partial<Record<keyof T, string>>;
  touched: Partial<Record<keyof T, boolean>>;
  valid: boolean;
  submitting: boolean;
  submitted: boolean;
  pristine: boolean;
}

// Form options
export interface FormOptions<T extends Record<string, any>> {
  initialValues: T;
  validationRules?: Record<string, ValidationRule<any>[]>;
  onSubmit?: (values: T) => Promise<void> | void;
  onChange?: (values: T) => void;
  validateOnChange?: boolean;
  validateOnBlur?: boolean;
  resetOnSubmit?: boolean;
}

// Common validation rules
export const validationRules = {
  required: <T>(message: string = 'This field is required'): ValidationRule<T> => ({
    validate: (value: T) => {
      if (typeof value === 'string') return value.trim().length > 0;
      return value !== null && value !== undefined;
    },
    message,
    type: 'required',
  }),

  email: (message: string = 'Please enter a valid email address'): ValidationRule<string> => ({
    validate: (value: string) => {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return !value || emailRegex.test(value);
    },
    message,
    type: 'email',
  }),

  password: (message: string = 'Password must be at least 8 characters'): ValidationRule<string> => ({
    validate: (value: string) => {
      return !value || value.length >= 8;
    },
    message,
    type: 'password',
  }),

  strongPassword: (message: string = 'Password must contain uppercase, lowercase, number, and special character'): ValidationRule<string> => ({
    validate: (value: string) => {
      if (!value) return true;
      const hasUpper = /[A-Z]/.test(value);
      const hasLower = /[a-z]/.test(value);
      const hasNumber = /\d/.test(value);
      const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(value);
      return hasUpper && hasLower && hasNumber && hasSpecial;
    },
    message,
    type: 'password',
  }),

  minLength: (min: number, message?: string): ValidationRule<string> => ({
    validate: (value: string) => !value || value.length >= min,
    message: message || `Must be at least ${min} characters`,
    type: 'custom',
  }),

  maxLength: (max: number, message?: string): ValidationRule<string> => ({
    validate: (value: string) => !value || value.length <= max,
    message: message || `Must be no more than ${max} characters`,
    type: 'custom',
  }),

  pattern: (regex: RegExp, message: string): ValidationRule<string> => ({
    validate: (value: string) => !value || regex.test(value),
    message,
    type: 'custom',
  }),

  matchField: (fieldName: string, message: string = 'Fields must match'): ValidationRule<string> => ({
    validate: (value: string, allValues?: Record<string, any>) => {
      if (!allValues || !value) return true;
      return value === allValues[fieldName];
    },
    message,
    type: 'custom',
  }),

  custom: <T>(
    validator: (value: T, allValues?: Record<string, any>) => boolean,
    message: string
  ): ValidationRule<T> => ({
    validate: validator,
    message,
    type: 'custom',
  }),
};

// Form hook
export const useForm = <T extends Record<string, any>>(
  options: FormOptions<T>
) => {
  const {
    initialValues,
    validationRules: rules = {},
    onSubmit,
    onChange,
    validateOnChange = true,
    validateOnBlur = true,
    resetOnSubmit = false,
  } = options;

  // Form state
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<Partial<Record<keyof T, string>>>({});
  const [touched, setTouched] = useState<Partial<Record<keyof T, boolean>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  // Track initial values for pristine state
  const initialValuesRef = useRef(initialValues);

  // Computed state
  const formState = useMemo((): FormState<T> => {
    const valid = Object.keys(errors).length === 0;
    const pristine = JSON.stringify(values) === JSON.stringify(initialValuesRef.current);

    return {
      values,
      errors,
      touched,
      valid,
      submitting,
      submitted,
      pristine,
    };
  }, [values, errors, touched, submitting, submitted]);

  // Validate single field
  const validateField = useCallback((name: keyof T, value: any): string | undefined => {
    const fieldRules = rules[name as string];
    if (!fieldRules || !Array.isArray(fieldRules)) return undefined;

    for (const rule of fieldRules) {
      if (!rule.validate(value, values)) {
        return rule.message;
      }
    }

    return undefined;
  }, [rules, values]);

  // Validate all fields
  const validateForm = useCallback((): boolean => {
    const newErrors: Partial<Record<keyof T, string>> = {};
    let isValid = true;

    Object.keys(values).forEach((key) => {
      const fieldName = key as keyof T;
      const error = validateField(fieldName, values[fieldName]);
      
      if (error) {
        newErrors[fieldName] = error;
        isValid = false;
      }
    });

    setErrors(newErrors);
    return isValid;
  }, [values, validateField]);

  // Set field value
  const setFieldValue = useCallback((name: keyof T, value: any) => {
    setValues(prev => ({ ...prev, [name]: value }));

    // Validate on change if enabled
    if (validateOnChange) {
      const error = validateField(name, value);
      setErrors(prev => ({ ...prev, [name]: error }));
    }

    // Call onChange callback
    if (onChange) {
      onChange({ ...values, [name]: value });
    }
  }, [values, validateField, validateOnChange, onChange]);

  // Set field touched
  const setFieldTouched = useCallback((name: keyof T, isTouched: boolean = true) => {
    setTouched(prev => ({ ...prev, [name]: isTouched }));

    // Validate on blur if enabled
    if (validateOnBlur && isTouched) {
      const error = validateField(name, values[name]);
      setErrors(prev => ({ ...prev, [name]: error }));
    }
  }, [values, validateField, validateOnBlur]);

  // Set multiple values
  const setFormValues = useCallback((newValues: Partial<T>) => {
    setValues(prev => ({ ...prev, ...newValues }));
    
    if (onChange) {
      onChange({ ...values, ...newValues });
    }
  }, [values, onChange]);

  // Reset form
  const reset = useCallback((newInitialValues?: T) => {
    const valuesToReset = newInitialValues || initialValues;
    setValues(valuesToReset);
    setErrors({});
    setTouched({});
    setSubmitting(false);
    setSubmitted(false);
    
    if (newInitialValues) {
      initialValuesRef.current = newInitialValues;
    }
  }, [initialValues]);

  // Submit form
  const submit = useCallback(async (event?: React.FormEvent) => {
    if (event) {
      event.preventDefault();
    }

    setSubmitted(true);
    setSubmitting(true);

    try {
      // Validate form
      const isValid = validateForm();
      
      if (!isValid) {
        errorUtils.handleValidationError(
          Object.entries(errors).map(([key, message]) => ({ field: key, message })),
          'Form validation failed'
        );
        return;
      }

      // Call onSubmit if provided
      if (onSubmit) {
        await onSubmit(values);
      }

      // Reset form if requested
      if (resetOnSubmit) {
        reset();
      }

    } catch (error) {
      errorUtils.handleApiError(error, 'Form submission failed');
    } finally {
      setSubmitting(false);
    }
  }, [values, errors, validateForm, onSubmit, resetOnSubmit, reset]);

  // Get field props helper
  const getFieldProps = useCallback((name: keyof T) => ({
    name: name as string,
    value: values[name],
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
      setFieldValue(name, e.target.value);
    },
    onBlur: () => setFieldTouched(name),
    error: errors[name],
    touched: touched[name],
    required: rules[name as string]?.some((rule: any) => rule.type === 'required'),
  }), [values, errors, touched, rules, setFieldValue, setFieldTouched]);

  // Get field error helper
  const getFieldError = useCallback((name: keyof T): string | undefined => {
    return touched[name] ? errors[name] : undefined;
  }, [errors, touched]);

  // Check if field is valid
  const isFieldValid = useCallback((name: keyof T): boolean => {
    return !errors[name];
  }, [errors]);

  // Check if field is invalid
  const isFieldInvalid = useCallback((name: keyof T): boolean => {
    return Boolean(touched[name] && errors[name]);
  }, [errors, touched]);

  return {
    // State
    ...formState,

    // Actions
    setFieldValue,
    setFieldTouched,
    setFormValues,
    reset,
    submit,
    validateForm,
    validateField,

    // Helpers
    getFieldProps,
    getFieldError,
    isFieldValid,
    isFieldInvalid,
  };
};

// Common form configurations
export const commonForms = {
  loginForm: {
    initialValues: {
      email: '',
      password: '',
    },
    validationRules: {
      email: [validationRules.required(), validationRules.email()],
      password: [validationRules.required()],
    },
  },

  registerForm: {
    initialValues: {
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
    },
    validationRules: {
      username: [validationRules.required(), validationRules.minLength(3)],
      email: [validationRules.required(), validationRules.email()],
      password: [validationRules.required(), validationRules.strongPassword()],
      confirmPassword: [
        validationRules.required(),
        validationRules.matchField('password', 'Passwords must match'),
      ],
    },
  },

  profileForm: {
    initialValues: {
      username: '',
      email: '',
      bio: '',
      website: '',
    },
    validationRules: {
      username: [validationRules.required(), validationRules.minLength(3)],
      email: [validationRules.required(), validationRules.email()],
      bio: [validationRules.maxLength(500)],
      website: [
        validationRules.pattern(
          /^https?:\/\/.+/,
          'Please enter a valid URL starting with http:// or https://'
        ),
      ],
    },
  },

  searchForm: {
    initialValues: {
      query: '',
      category: '',
      sortBy: 'relevance',
    },
    validationRules: {
      query: [validationRules.required('Please enter a search term')],
    },
  },
};