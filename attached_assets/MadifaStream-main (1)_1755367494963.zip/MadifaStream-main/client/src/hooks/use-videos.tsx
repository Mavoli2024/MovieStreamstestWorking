import { useToast } from "@/hooks/use-toast";
import {
    addToWatchlist,
    createVideoUpload,
    deleteVideo,
    getSignedVideoUrl,
    getVideo,
    getVideos,
    getWatchlist,
    getWatchProgress,
    removeFromWatchlist,
    updateVideo,
    updateWatchProgress,
    type VideoUpdate,
} from "@/lib/supabase-api";
import {
    useMutation,
    useQuery,
    useQueryClient,
} from "@tanstack/react-query";

// Simple logger fallback for frontend
const logger = {
    error: (msg: string, data?: any) => console.error(`[ERROR] ${msg}`, data?.arg1 || '')
};

/**
 * Hook for fetching all videos with infinite scrolling
 */
export function useVideos() {
  return useQuery({
    queryKey: ['videos'],
    queryFn: getVideos,
  });
}

/**
 * Hook for fetching a specific video
 */
export function useVideo(videoId: string | undefined) {
  return useQuery({
    queryKey: ["video", videoId],
    queryFn: () => (videoId ? getVideo(videoId) : null),
    enabled: !!videoId,
  });
}

/**
 * Hook for watch progress
 */
export function useWatchProgress(
  videoId: string | undefined,
  userId: string | undefined
) {
  return useQuery({
    queryKey: ["watch-progress", videoId, userId],
    queryFn: () => (videoId && userId ? getWatchProgress(videoId, userId) : 0),
    enabled: !!videoId && !!userId,
  });
}

/**
 * Hook for user's watchlist
 */
export function useWatchlist() {
  return useQuery({
    queryKey: ["watchlist"],
    queryFn: getWatchlist,
  });
}

/**
 * Hook for video operations with mutations
 */
export function useVideoMutations() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const createVideoMutation = useMutation({
    mutationFn: createVideoUpload,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["videos"] });
      toast({
        title: "Video upload initiated",
        description: "Your video is being processed by Bunny.net",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Video upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateVideoMutation = useMutation({
    mutationFn: ({ id, updates }: { id: string; updates: VideoUpdate }) =>
      updateVideo(id, updates),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["videos"] });
      toast({
        title: "Video updated",
        description: "Video metadata has been updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteVideoMutation = useMutation({
    mutationFn: deleteVideo,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["videos"] });
      toast({
        title: "Video deleted",
        description: "Video has been removed successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Delete failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateWatchProgressMutation = useMutation({
    mutationFn: ({
      videoId,
      progressSeconds,
      userId,
    }: {
      videoId: string;
      progressSeconds: number;
      userId: string;
    }) => updateWatchProgress(videoId, progressSeconds, userId),
    onSuccess: (_, { videoId, userId }) => {
      queryClient.invalidateQueries({
        queryKey: ["watch-progress", videoId, userId],
      });
    },
    onError: (error: Error) => {
      logger.error("Failed to update watch progress:", { arg1: error });
    },
  });

  const addToWatchlistMutation = useMutation({
    mutationFn: addToWatchlist,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["watchlist"] });
      toast({
        title: "Added to watchlist",
        description: "Video has been added to your watchlist",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add to watchlist",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const removeFromWatchlistMutation = useMutation({
    mutationFn: removeFromWatchlist,
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["watchlist"] });
      toast({
        title: "Removed from watchlist",
        description: "Video has been removed from your watchlist",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to remove from watchlist",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return {
    createVideo: createVideoMutation,
    updateVideo: updateVideoMutation,
    deleteVideo: deleteVideoMutation,
    updateWatchProgress: updateWatchProgressMutation,
    addToWatchlist: addToWatchlistMutation,
    removeFromWatchlist: removeFromWatchlistMutation,
  };
}

/**
 * Hook for getting signed video URLs for playback
 */
export function useSignedVideoUrl(videoId: string | undefined) {
  return useQuery({
    queryKey: ["signed-video-url", videoId],
    queryFn: () => (videoId ? getSignedVideoUrl(videoId) : null),
    enabled: !!videoId,
    staleTime: 5 * 60 * 1000, // 5 minutes - signed URLs expire after some time
  });
}
