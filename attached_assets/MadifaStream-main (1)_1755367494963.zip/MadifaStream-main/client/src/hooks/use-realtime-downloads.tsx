/**
 * Real-time Downloads Hook
 * 
 * Replaces polling mechanism with real-time database subscriptions
 * for download progress updates
 */

import { useState, useEffect, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuth } from './use-auth';
import { useToast } from './use-toast';
import { realtimeService, RealtimeEvent } from '../services/realtimeService';
import type { Download, DownloadSettings } from './use-downloads';
import { getApiBaseUrl } from '@/constants/app-constants';

const API_BASE = getApiBaseUrl();

export function useRealtimeDownloads() {
  const { user, session } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isRealtimeConnected, setIsRealtimeConnected] = useState(false);
  const [lastUpdateTime, setLastUpdateTime] = useState<Date | null>(null);

  // Fetch initial downloads data (no polling interval needed)
  const {
    data: downloads = [],
    isLoading,
    error,
    refetch: refetchDownloads
  } = useQuery<Download[]>({
    queryKey: ['downloads', user?.id],
    queryFn: async () => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/downloads`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(error || 'Failed to fetch downloads');
      }

      return response.json();
    },
    enabled: !!session?.access_token,
    staleTime: 5 * 60 * 1000, // 5 minutes - data stays fresh longer since we get real-time updates
    // Remove refetchInterval since we're using real-time updates
  });

  // Handle real-time download updates
  const handleDownloadUpdate = useCallback((event: RealtimeEvent) => {
    setLastUpdateTime(new Date());
    
    // Update the downloads cache based on the real-time event
    queryClient.setQueryData<Download[]>(['downloads', user?.id], (oldDownloads) => {
      if (!oldDownloads) return oldDownloads;

      switch (event.eventType) {
        case 'INSERT':
          // New download added
          if (event.new && event.new.user_id === user?.id) {
            toast({
              title: 'Download Started',
              description: `Started downloading "${event.new.title}"`,
            });
            return [...oldDownloads, event.new];
          }
          break;

        case 'UPDATE':
          // Download progress or status updated
          if (event.new && event.old) {
            const updatedDownloads = oldDownloads.map(download => 
              download.id === event.new.id ? { ...download, ...event.new } : download
            );

            // Show notification for status changes
            if (event.old.status !== event.new.status) {
              if (event.new.status === 'completed') {
                toast({
                  title: 'Download Complete',
                  description: `"${event.new.title}" is ready to watch offline`,
                });
              } else if (event.new.status === 'failed') {
                toast({
                  title: 'Download Failed',
                  description: `Failed to download "${event.new.title}"`,
                  variant: 'destructive',
                });
              }
            }

            return updatedDownloads;
          }
          break;

        case 'DELETE':
          // Download removed
          if (event.old) {
            return oldDownloads.filter(download => download.id !== event.old.id);
          }
          break;
      }

      return oldDownloads;
    });
  }, [user?.id, toast, queryClient]);

  // Set up real-time subscription
  useEffect(() => {
    if (!user?.id || !session?.access_token) {
      return;
    }

    const subscriptionId = `downloads-${user.id}`;

    // Subscribe to downloads table changes for this user
    const subscribeToDownloads = async () => {
      try {
        const success = await realtimeService.subscribe(subscriptionId, {
          table: 'downloads',
          schema: 'public',
          event: '*', // Listen to all events
          filter: `user_id=eq.${user.id}`, // Only listen to this user's downloads
          callback: handleDownloadUpdate,
        });

        setIsRealtimeConnected(success);
        
        if (!success) {
          console.warn('Failed to establish real-time downloads subscription');
          // Fallback to periodic refetching if real-time fails
          const fallbackInterval = setInterval(() => {
            refetchDownloads();
          }, 10000); // 10 seconds as fallback
          
          return () => clearInterval(fallbackInterval);
        }
      } catch (error) {
        console.error('Error setting up real-time downloads subscription:', error);
        setIsRealtimeConnected(false);
      }
    };

    subscribeToDownloads();

    // Cleanup subscription on unmount
    return () => {
      realtimeService.unsubscribe(subscriptionId);
      setIsRealtimeConnected(false);
    };
  }, [user?.id, session?.access_token, handleDownloadUpdate, refetchDownloads]);

  // Monitor connection status
  useEffect(() => {
    const checkConnectionStatus = () => {
      const status = realtimeService.getConnectionStatus();
      setIsRealtimeConnected(status.status === 'OPEN');
    };

    // Check immediately
    checkConnectionStatus();

    // Set up periodic status checks
    const statusInterval = setInterval(checkConnectionStatus, 5000);

    return () => clearInterval(statusInterval);
  }, []);

  // Fetch download settings (no real-time needed for settings)
  const {
    data: settings,
    isLoading: isLoadingSettings
  } = useQuery<DownloadSettings>({
    queryKey: ['download-settings', user?.id],
    queryFn: async () => {
      if (!session?.access_token) {
        throw new Error('No authentication token');
      }

      const response = await fetch(`${API_BASE}/api/downloads/settings`, {
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch download settings');
      }

      return response.json();
    },
    enabled: !!session?.access_token,
  });

  // Helper functions (same as original useDownloads)
  const isVideoDownloaded = (videoId: string) => {
    return downloads.some(download => download.videoId === videoId && download.status === 'completed');
  };

  const isVideoDownloading = (videoId: string) => {
    return downloads.some(download => 
      download.videoId === videoId && 
      (download.status === 'pending' || download.status === 'downloading')
    );
  };

  const getDownloadProgress = (videoId: string) => {
    const download = downloads.find(download => download.videoId === videoId);
    return download?.progress || 0;
  };

  const completedDownloads = downloads.filter(d => d.status === 'completed');
  const downloadingItems = downloads.filter(d => d.status === 'downloading' || d.status === 'pending');

  // Get real-time statistics
  const getRealtimeStats = () => {
    return {
      isConnected: isRealtimeConnected,
      lastUpdateTime,
      connectionStatus: realtimeService.getConnectionStatus(),
      serviceStats: realtimeService.getStatistics(),
    };
  };

  return {
    downloads,
    completedDownloads,
    downloadingItems,
    settings,
    isLoading,
    isLoadingSettings,
    error,
    
    // Helper functions
    isVideoDownloaded,
    isVideoDownloading,
    getDownloadProgress,
    
    // Real-time specific features
    isRealtimeConnected,
    lastUpdateTime,
    getRealtimeStats,
    
    // Manual refresh (fallback)
    refreshDownloads: refetchDownloads,
  };
}