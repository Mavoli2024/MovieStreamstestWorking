import { useQuery } from "@tanstack/react-query";

// Define types for content collections and videos
export interface ContentCollection {
  id: string;
  guid?: string;
  name: string;
  description?: string;
  thumbnailUrl?: string;
  isActive?: boolean;
  previewVideoIds?: string[];
}

export interface ContentVideo {
  id: number;
  title: string;
  description: string;
  thumbnailUrl: string;
  videoUrl: string;
  trailerUrl: string | null;
  releaseYear: number;
  duration: number;
  views: number;
  ageRating: string;
  genres: string[];
  cast: string[];
  director: string;
  isTrailer: boolean;
  isPremium: boolean;
  categoryId: number;
  collectionId?: string;
  collectionName?: string;
  metadataJson?: string;
  storageSize?: number;
  availableResolutions?: string;
  encodeProgress?: number;
}

/**
 * Hook to fetch content collections (categories)
 */
export function useContentCollections() {
  return useQuery<ContentCollection[]>({
    queryKey: ['/api/categories'],
    queryFn: async () => {
      const response = await fetch('/api/categories');
      if (!response.ok) {
        throw new Error('Failed to fetch categories');
      }
      return await response.json();
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}

/**
 * Hook to fetch videos in a specific category
 */
export function useCollectionVideos(categoryId: number | string) {
  return useQuery<ContentVideo[]>({
    queryKey: ['/api/categories', categoryId, ''],
    queryFn: async () => {
      if (!categoryId) return [];

      const response = await fetch(`/api/categories/${categoryId}/`);
      if (!response.ok) {
        throw new Error('Failed to fetch category ');
      }
      return await response.json();
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
    enabled: !!categoryId,
  });
}

/**
 * Hook to fetch discover content (all videos)
 */
export function useDiscoverContent() {
  return useQuery({
    queryKey: ['/api/videos'],
    queryFn: async () => {
      const response = await fetch('/api/videos');
      if (!response.ok) {
        throw new Error('Failed to fetch videos');
      }
      const videos = await response.json();

      if (!videos || videos.length === 0) {
        return {
          trending: [],
          newest: [],
          random: []
        };
      }

      // Group videos into trending, newest, and random collections for UI presentation
      const trending = videos.filter(video => video.trending_score && video.trending_score > 75)
        .sort((a, b) => (b.trending_score || 0) - (a.trending_score || 0));
      const newest = [...videos].sort((a, b) => b.id - a.id).slice(0, 10);
      const random = [...videos].sort(() => Math.random() - 0.5).slice(0, 10);

      return { trending, newest, random };
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}