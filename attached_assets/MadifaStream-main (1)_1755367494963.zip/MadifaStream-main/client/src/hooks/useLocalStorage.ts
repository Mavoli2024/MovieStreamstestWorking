/**
 * Local Storage Hook
 * 
 * Provides a type-safe, reactive hook for managing localStorage state
 * with automatic serialization/deserialization and error handling.
 */

import { useState, useEffect, useCallback } from 'react';

// Storage event for cross-tab synchronization
const storageEvent = new CustomEvent('localStorage-change');

// Type for storage value
type StorageValue<T> = T | null;

// Hook options
interface UseLocalStorageOptions<T> {
  defaultValue?: T;
  serializer?: {
    serialize: (value: T) => string;
    deserialize: (value: string) => T;
  };
}

/**
 * Custom hook for managing localStorage state
 */
export const useLocalStorage = <T>(
  key: string,
  options: UseLocalStorageOptions<T> = {}
): [StorageValue<T>, (value: T | ((prev: T | null) => T)) => void, () => void] => {
  const {
    defaultValue = null,
    serializer = {
      serialize: JSON.stringify,
      deserialize: JSON.parse,
    },
  } = options;

  // Get initial value from localStorage
  const getStoredValue = useCallback((): T | null => {
    if (typeof window === 'undefined') return defaultValue;
    
    try {
      const item = window.localStorage.getItem(key);
      if (item === null) return defaultValue;
      return serializer.deserialize(item);
    } catch (error) {
      console.warn(`Error reading localStorage key "${key}":`, error);
      return defaultValue;
    }
  }, [key, defaultValue, serializer]);

  const [storedValue, setStoredValue] = useState<T | null>(getStoredValue);

  // Update localStorage and state
  const setValue = useCallback((value: T | ((prev: T | null) => T)) => {
    try {
      const valueToStore = typeof value === 'function' 
        ? (value as (prev: T | null) => T)(storedValue)
        : value;

      setStoredValue(valueToStore);
      
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(key, serializer.serialize(valueToStore));
        window.dispatchEvent(storageEvent);
      }
    } catch (error) {
      console.error(`Error setting localStorage key "${key}":`, error);
    }
  }, [key, storedValue, serializer]);

  // Remove value from localStorage
  const removeValue = useCallback(() => {
    try {
      setStoredValue(null);
      if (typeof window !== 'undefined') {
        window.localStorage.removeItem(key);
        window.dispatchEvent(storageEvent);
      }
    } catch (error) {
      console.error(`Error removing localStorage key "${key}":`, error);
    }
  }, [key]);

  // Listen for storage changes (cross-tab synchronization)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === key) {
        setStoredValue(getStoredValue());
      }
    };

    const handleCustomStorageChange = () => {
      setStoredValue(getStoredValue());
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('localStorage-change', handleCustomStorageChange);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('localStorage-change', handleCustomStorageChange);
    };
  }, [key, getStoredValue]);

  return [storedValue, setValue, removeValue];
};

// Specialized hooks for common use cases
export const usePersistedState = <T>(key: string, defaultValue: T) => {
  return useLocalStorage(key, { defaultValue });
};

export const useUserPreferences = () => {
  const [preferences, setPreferences] = useLocalStorage('user-preferences', {
    defaultValue: {
      theme: 'system' as 'light' | 'dark' | 'system',
      volume: 0.8,
      autoplay: true,
      subtitles: true,
      quality: 'auto' as 'auto' | '720p' | '1080p' | '4k',
      notifications: true,
    },
  });

  const updatePreference = useCallback(<K extends keyof NonNullable<typeof preferences>>(
    key: K,
    value: NonNullable<typeof preferences>[K]
  ) => {
    setPreferences(prev => ({
      ...prev,
      [key]: value,
    }));
  }, [setPreferences]);

  return {
    preferences,
    updatePreference,
    setPreferences,
  };
};

export const useWatchHistory = () => {
  const [history, setHistory] = useLocalStorage<Array<{
    videoId: string;
    title: string;
    thumbnail: string;
    timestamp: number;
    progress: number;
  }>>('watch-history', { defaultValue: [] });

  const addToHistory = useCallback((video: {
    videoId: string;
    title: string;
    thumbnail: string;
    progress: number;
  }) => {
    setHistory(prev => {
      const filtered = (prev || []).filter(item => item.videoId !== video.videoId);
      return [
        { ...video, timestamp: Date.now() },
        ...filtered,
      ].slice(0, 100); // Keep only last 100 items
    });
  }, [setHistory]);

  const removeFromHistory = useCallback((videoId: string) => {
    setHistory(prev => (prev || []).filter(item => item.videoId !== videoId));
  }, [setHistory]);

  const clearHistory = useCallback(() => {
    setHistory([]);
  }, [setHistory]);

  return {
    history: history || [],
    addToHistory,
    removeFromHistory,
    clearHistory,
  };
};
