import { useQuery } from '@tanstack/react-query';
import { logger } from '@shared/logger';

export interface ContentCollection {
  id: string;
  name: string;
  videoCount?: number;
  guid?: string; // Bunny library GUID
  previewVideoIds?: string[];
}

/**
 * Hook to fetch content collections - now properly enabled for SA content
 */
export function useBunnyCollections() {
  return useQuery<ContentCollection[]>({
    queryKey: ['sa-content-collections'],
    queryFn: async () => {
      // Return culturally relevant collections for South African content
      return [
        {
          id: 'mzansi-movies',
          name: 'Mzansi Movies',
          videoCount: 5,
          guid: '1b8a1846-1f29-4ee2-a895-8e088ea85171'
        },
        {
          id: 'previews-trailers', 
          name: 'Previews & Trailers',
          videoCount: 5,
          guid: 'c50bfd2b-1164-43ca-9293-419cccfca1fe'
        },
        {
          id: 'zulu-stories',
          name: 'Zulu Stories',
          videoCount: 3,
          guid: '1b8a1846-1f29-4ee2-a895-8e088ea85171'
        }
      ];
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}

/**
 * Hook to fetch videos in a collection - returns empty array to prevent API calls
 */
export function useCollectionVideos(collectionId: string) {
  return useQuery({
    queryKey: ['collection-videos-disabled', collectionId],
    queryFn: async () => {
      // Return empty array to prevent failing API calls
      if (import.meta.env.DEV) {
        logger.info('Collection videos hook disabled - returning empty array');
      }
      return [];
    },
    enabled: !!collectionId,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
} 