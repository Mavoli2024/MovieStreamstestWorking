import { createRoot } from "react-dom/client";
import React from "react";
import {  UnifiedErrorBoundary  } from "./components/error-boundary/UnifiedErrorBoundary";
import App from "./App"; // Now testing the full App
import { logger } from '@shared/logger';

// Step 2: Test App component (which includes ThemeProvider, etc.)
function TestAppWrapper() {
  return (
    <div>
      <div style={{ padding: '10px', background: '#f0f0f0', marginBottom: '10px' }}>
        <strong>Progressive Test: Step 2 - Testing Full App Component</strong>
        <p>If the app loads below, then App.tsx is NOT the issue.</p>
      </div>
      <App />
    </div>
  );
}

// Render with error boundary + full app
const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(
    <UnifiedErrorBoundary errorType="generic" variant="detailed">
      <TestAppWrapper />
    </UnifiedErrorBoundary>
  );
} else {
  logger.error('Root element not found');
} 