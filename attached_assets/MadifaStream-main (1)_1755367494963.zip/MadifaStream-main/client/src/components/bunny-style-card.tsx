import type { Video as BaseVideo } from "@shared/schema";
import { Clock, Eye, Play } from "lucide-react";
import { useState } from "react";
import { logger } from '@shared/logger';

// Extend the video type to include BunnyStream-specific metadata
interface BunnyVideo extends BaseVideo {
  metaData?: {
    views?: number;
    storageSize?: number;
    availableResolutions?: string | string[];
  };
  category?: string;
}

interface BunnyStyleCardProps {
  video: BunnyVideo;
  onClick?: (videoId: string) => void;
}

// Helper function to get video ID
const getVideoId = (video: BunnyVideo): string => {
  return (video as any).id || (video as any).bunny_video_id || '';
};

// Helper function to get thumbnail URL
const getThumbnailUrl = (video: BunnyVideo): string => {
  return (video as any).thumbnail_url || `https://vz-f5c9bae3-d51.b-cdn.net/${(video as any).bunny_video_id}/thumbnail.jpg` || '';
};

// Helper function to get video title
const getVideoTitle = (video: BunnyVideo): string => {
  return (video as any).title || '';
};

// Helper function to get video duration
const getVideoDuration = (video: BunnyVideo): number => {
  return (video as any).duration || 0;
};

const BunnyStyleCard: React.FC<BunnyStyleCardProps> = ({ video, onClick }) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const [imageError, setImageError] = useState(false);
  
  const videoId = getVideoId(video);
  const thumbnailUrl = getThumbnailUrl(video);
  const title = getVideoTitle(video);
  const duration = getVideoDuration(video);

  // Generate a stable color based on video title
  const generateColor = (str: string): string => {
    if (!str) return '#6366f1';
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = Math.abs(hash % 360);
    return `hsl(${hue}, 70%, 50%)`;
  };

  const handleClick = () => {
    if (onClick && videoId) {
      onClick(videoId);
    }
  };

  const handleWatchlistToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Implement watchlist functionality
    logger.info('Watchlist toggle for video:', videoId);
  };

  const formatDuration = (seconds: number): string => {
    if (!seconds || seconds <= 0) return '0:00';
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div 
      className="group relative bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer overflow-hidden"
      onClick={handleClick}
    >
      {/* Thumbnail Container */}
      <div className="relative aspect-video bg-gray-200 dark:bg-gray-700 overflow-hidden">
        {!imageError && thumbnailUrl ? (
          <img
            src={thumbnailUrl}
            alt={title}
            className={`w-full h-full object-cover transition-all duration-300 group-hover:scale-105 ${
              imageLoaded ? 'opacity-100' : 'opacity-0'
            }`}
            onLoad={() => setImageLoaded(true)}
            onError={() => setImageError(true)}
          />
        ) : (
          <div 
            className="w-full h-full flex items-center justify-center text-white text-4xl font-bold"
            style={{ backgroundColor: generateColor(title) }}
          >
            {title.charAt(0).toUpperCase()}
          </div>
        )}
        
        {/* Play Button Overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
          <div className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <Play className="w-12 h-12 text-white drop-shadow-lg" fill="white" />
          </div>
        </div>
        
        {/* Duration Badge */}
        {duration > 0 && (
          <div className="absolute bottom-2 right-2 bg-black bg-opacity-70 text-white text-xs px-2 py-1 rounded">
            {formatDuration(duration)}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="p-4">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-2 line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
          {title}
        </h3>
        
        {/* Metadata */}
        <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
          <div className="flex items-center gap-1">
            <Eye className="w-4 h-4" />
            <span>{(video as any).views || 0} views</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            <span>{formatDuration(duration)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export { BunnyStyleCard };