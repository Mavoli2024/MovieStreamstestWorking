/**
 * Enhanced User Profile Component
 * 
 * Mobile-first responsive design with modern styling, smooth transitions,
 * and optimized touch targets for all devices.
 */

import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';

import { 
    Avatar,
    AvatarFallback
 } from '@/components/ui/avatar';
import {  Button  } from '@/components/ui/button';
import { 
    Card,
    CardContent,
    CardDescription,
    CardHeader,
    CardTitle
 } from '@/components/ui/card';
import {
    Form,
    FormControl,
    FormDescription,
    FormField,
    FormItem,
    FormLabel,
    FormMessage,
} from '@/components/ui/form';
import {  Input  } from '@/components/ui/input';
import {  Separator  } from '@/components/ui/separator';
import {  SettingsTabs  } from '@/components/ui/settings-tabs';
import {  Tabs, TabsContent  } from '@/components/ui/tabs';
import {  FormWrapper, FormSection, FormDivider  } from '@/components/form/form-wrapper';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import {  Check, CreditCard, Loader2, Settings, Shield, User, Camera, Star, Heart  } from 'lucide-react';
import { AvatarUpload } from './avatar-upload';
import {  EnhancedProfileSettings  } from '../profile/enhanced-profile-settings';

// Form validation schemas
const profileFormSchema = z.object({
  displayName: z.string().min(2, { message: 'Display name must be at least 2 characters' }),
  email: z.string().email({ message: 'Please enter a valid email address' }),
});

const passwordFormSchema = z.object({
  currentPassword: z.string().min(1, { message: 'Current password is required' }),
  newPassword: z.string().min(6, { message: 'New password must be at least 6 characters' }),
  confirmPassword: z.string()
}).refine(data => data.newPassword === data.confirmPassword, {
  message: 'New passwords do not match',
  path: ['confirmPassword'],
});

// Enhanced color choices for avatar with more modern palette
const colorChoices = [
  { color: 'hsl(210, 70%, 45%)', name: 'Ocean Blue' },
  { color: 'hsl(160, 60%, 40%)', name: 'Emerald' },
  { color: 'hsl(280, 60%, 45%)', name: 'Royal Purple' },
  { color: 'hsl(350, 65%, 50%)', name: 'Ruby Red' },
  { color: 'hsl(30, 80%, 50%)', name: 'Sunset Orange' },
  { color: 'hsl(110, 55%, 45%)', name: 'Forest Green' },
  { color: 'hsl(45, 80%, 55%)', name: 'Golden Yellow' },
  { color: 'hsl(200, 50%, 50%)', name: 'Sky Blue' }
];

export function UserProfile() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('general');
  const [selectedColor, setSelectedColor] = useState<string | null>(null);

  const profileTabs = [
    { value: 'general', label: 'General', icon: <User className="mr-2 h-4 w-4" /> },
    { value: 'preferences', label: 'Preferences', icon: <Settings className="mr-2 h-4 w-4" /> },
    { value: 'subscription', label: 'Subscription', icon: <CreditCard className="mr-2 h-4 w-4" /> },
    { value: 'security', label: 'Security', icon: <Shield className="mr-2 h-4 w-4" /> },
  ];

  // Fetch user profile
  const { data: userData, isLoading: isLoadingProfile } = useQuery<{ success: boolean, data: Record<string, unknown> }>({
    queryKey: ['/api/user/profile']
  });

  // Update selected color when user data is loaded
  useEffect(() => {
    if (userData?.data?.avatarColor) {
      setSelectedColor(String(userData.data.avatarColor));
    }
  }, [userData]);

  const user = userData?.data;

  // Form setup for profile and password
  const form = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      displayName: '',
      email: '',
    },
    mode: 'onChange', // Enable real-time validation
  });

  const passwordForm = useForm<z.infer<typeof passwordFormSchema>>({
    resolver: zodResolver(passwordFormSchema),
    defaultValues: {
      currentPassword: '',
      newPassword: '',
      confirmPassword: '',
    },
  });

  // Update profile details
  const updateProfileMutation = useMutation({
    mutationFn: (values: z.infer<typeof profileFormSchema>) => {
      return fetch('/api/user/profile', {
        method: 'PUT',
        body: JSON.stringify(values),
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      toast({
        title: 'Profile updated',
        description: 'Your profile has been updated successfully.',
      });
    },
    onError: (_error) => {
      toast({
        title: 'Update failed',
        description: 'There was a problem updating your profile.',
        variant: 'destructive',
      });
    },
  });

  // Update password
  const updatePasswordMutation = useMutation({
    mutationFn: async (values: z.infer<typeof passwordFormSchema>) => {
      const { error } = await supabase.auth.updateUser({ password: values.newPassword });
      
      if (error) {
        if (error.message.includes('password')) {
          throw new Error('There was an issue verifying your current password. Please try again.');
        }
        throw error;
      }
    },
    onSuccess: () => {
      passwordForm.reset();
      toast({
        title: 'Password Updated',
        description: 'Your password has been changed successfully.',
      });
    },
    onError: (error: Error) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'There was a problem updating your password.',
        variant: 'destructive',
      });
    },
  });

  // Update avatar color
  const updateAvatarMutation = useMutation({
    mutationFn: (color: string) => {
      return fetch('/api/user/preferences', {
        method: 'PUT',
        body: JSON.stringify({ avatarColor: color }),
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      toast({
        title: 'Profile updated',
        description: 'Your avatar color has been updated.',
      });
    },
  });

  // Get subscription data
  const { data: subscriptionData, isLoading: isLoadingSubscription } = useQuery<{ success: boolean, data: Record<string, unknown> }>({
    queryKey: ['/api/user/subscription'],
  });

  const subscription = subscriptionData?.data;

  // Update form values when user data is loaded
  useEffect(() => {
    if (userData?.data && !isLoadingProfile) {
      const formData = {
        displayName: String(userData.data.displayName || userData.data.display_name || ''),
        email: String(userData.data.email || ''),
      };
      
      const currentValues = form.getValues();
      const isDataDifferent = 
        currentValues.displayName !== formData.displayName || 
        currentValues.email !== formData.email;
      
      const isFormEmpty = !currentValues.displayName && !currentValues.email;
      
      if (isDataDifferent || isFormEmpty) {
        form.reset(formData, { 
          keepDefaultValues: false,
          keepDirty: false,
          keepTouched: false
        });
      }
    }
  }, [userData?.data, isLoadingProfile, form]);

  // Submit profile update
  function onSubmit(values: z.infer<typeof profileFormSchema>) {
    updateProfileMutation.mutate(values);
  }

  // Submit password change
  function onPasswordSubmit(values: z.infer<typeof passwordFormSchema>) {
    updatePasswordMutation.mutate(values);
  }

  // Handle avatar color change
  function handleColorSelect(color: string) {
    setSelectedColor(color);
    updateAvatarMutation.mutate(color);
  }

  // Generate avatar initials
  function getInitials(name: string) {
    if (!name) return 'U';
    return name.split(' ').map((n) => n[0]).join('').toUpperCase().substring(0, 2);
  }

  // If loading, show enhanced skeleton UI
  if (isLoadingProfile) {
    return (
      <div className="w-full max-w-4xl mx-auto px-4 sm:px-6">
        <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800">
          <CardHeader className="text-center py-8">
            <div className="mx-auto w-24 h-24 bg-gray-200 dark:bg-gray-700 rounded-full animate-pulse mb-4"></div>
            <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded-lg w-48 mx-auto animate-pulse mb-2"></div>
            <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded-lg w-32 mx-auto animate-pulse"></div>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto px-4 sm:px-6 space-y-6">
      {/* Enhanced Profile Header Card */}
      <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-gray-50 dark:from-gray-900 dark:to-gray-800 overflow-hidden">
        <div className="relative">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 to-purple-600/10 dark:from-blue-500/20 dark:to-purple-500/20"></div>
          
          <CardHeader className="relative text-center py-8 sm:py-12">
            <div className="flex flex-col items-center space-y-4">
              {/* Enhanced Avatar with Upload */}
              <AvatarUpload
                currentAvatarUrl={String(user?.avatar_url || user?.avatarUrl || '')}
                userId={String(user?.id || '')}
                displayName={String(user?.displayName || user?.display_name || user?.username || 'User')}
                onUploadSuccess={(avatarUrl) => {
                  queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
                }}
              />
              
              {/* User Info */}
              <div className="space-y-2">
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">
                  {String(user?.displayName || user?.username || 'Anonymous User')}
                </h1>
                <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300">
                  {String(user?.email || '')}
                </p>
                
                {/* Status Badge */}
                <div className="flex justify-center">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                    <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                    Active Member
                  </span>
                </div>
              </div>
            </div>
          </CardHeader>
        </div>
      </Card>

      {/* Enhanced Main Content Card */}
      <Card className="border-0 shadow-xl bg-white dark:bg-gray-900">
        <CardContent className="p-0">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            {/* Enhanced Tab Navigation */}
            <div className="border-b border-gray-200 dark:border-gray-700 px-4 sm:px-6">
              <SettingsTabs tabs={profileTabs} className="border-0 bg-transparent" />
            </div>

            {/* Tab Content with Enhanced Styling */}
            <div className="p-4 sm:p-6 lg:p-8">
              <TabsContent value="general" className="space-y-6 mt-0">
                <FormWrapper
                  title="Profile Information"
                  subtitle="Update your personal details and account information"
                  onSubmit={form.handleSubmit(onSubmit)}
                  size="lg"
                >
                  <FormSection title="Basic Information">
                    <Form {...form}>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="displayName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                Display Name
                              </FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  className="h-12 text-base border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                                />
                              </FormControl>
                              <FormDescription className="text-xs text-gray-500 dark:text-gray-400">
                                This is the name that will be displayed to other users.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                Email Address
                              </FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  type="email" 
                                  className="h-12 text-base border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                                />
                              </FormControl>
                              <FormDescription className="text-xs text-gray-500 dark:text-gray-400">
                                Your email address is used for account recovery and notifications.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </Form>
                  </FormSection>

                  <div className="flex justify-end pt-6">
                    <Button
                      type="submit"
                      disabled={updateProfileMutation.isPending}
                      className="h-12 px-8 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
                    >
                      {updateProfileMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        'Save Changes'
                      )}
                    </Button>
                  </div>
                </FormWrapper>
              </TabsContent>

              <TabsContent value="preferences" className="space-y-6 mt-0">
                <EnhancedProfileSettings userId={String(user?.id || '')} />
              </TabsContent>

              <TabsContent value="subscription" className="space-y-6 mt-0">
                <FormWrapper
                  title="Subscription Management"
                  subtitle="View and manage your subscription details"
                  size="lg"
                >
                  {isLoadingSubscription ? (
                    <div className="text-center py-12">
                      <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600 mb-4" />
                      <p className="text-gray-600 dark:text-gray-400">Loading subscription details...</p>
                    </div>
                  ) : subscription ? (
                    <>
                      <FormSection title="Current Plan">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                          <div className="space-y-2">
                            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Plan</p>
                            <p className="text-xl font-bold text-gray-900 dark:text-white">
                              {(subscription.plan as any)?.name || 'Unknown'}
                            </p>
                          </div>
                          <div className="space-y-2">
                            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Status</p>
                            <div className="flex items-center space-x-2">
                              <span className={`inline-block h-3 w-3 rounded-full ${
                                (subscription.status as string) === 'active' ? 'bg-green-500' :
                                (subscription.status as string) === 'pending' ? 'bg-yellow-500' :
                                'bg-red-500'
                              }`} />
                              <p className="text-xl font-bold text-gray-900 dark:text-white capitalize">
                                {subscription.status as string}
                              </p>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Start Date</p>
                            <p className="text-lg font-semibold text-gray-900 dark:text-white">
                              {new Date(subscription.startDate as string).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="space-y-2">
                            <p className="text-sm font-medium text-gray-500 dark:text-gray-400">Renewal Date</p>
                            <p className="text-lg font-semibold text-gray-900 dark:text-white">
                              {subscription.endDate
                                ? new Date(subscription.endDate as string).toLocaleDateString()
                                : 'Auto-renews'}
                            </p>
                          </div>
                        </div>
                      </FormSection>

                      <FormDivider />

                      <FormSection title="Plan Features">
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {((subscription.plan as any)?.features as string[])?.map((feature: string, index: number) => (
                            <div key={index} className="flex items-center space-x-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                              <Check className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0" />
                              <span className="text-sm text-gray-900 dark:text-white font-medium">{feature}</span>
                            </div>
                          ))}
                        </div>
                      </FormSection>
                    </>
                  ) : (
                    <div className="text-center py-12 space-y-6">
                      <div className="mx-auto w-16 h-16 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center">
                        <CreditCard className="h-8 w-8 text-gray-400" />
                      </div>
                      <div className="space-y-2">
                        <h3 className="text-xl font-semibold text-gray-900 dark:text-white">
                          No Active Subscription
                        </h3>
                        <p className="text-gray-600 dark:text-gray-400 max-w-md mx-auto">
                          Unlock premium features and exclusive content with a subscription plan.
                        </p>
                      </div>
                      <Button className="h-12 px-8 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-200">
                        Upgrade Now
                      </Button>
                    </div>
                  )}
                </FormWrapper>
              </TabsContent>

              <TabsContent value="security" className="space-y-6 mt-0">
                <FormWrapper
                  title="Security Settings"
                  subtitle="Manage your account security and password"
                  onSubmit={passwordForm.handleSubmit(onPasswordSubmit)}
                  size="lg"
                >
                  <FormSection title="Change Password">
                    <div className="mb-6 p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                      <p className="text-sm text-amber-800 dark:text-amber-200">
                        <Shield className="inline h-4 w-4 mr-2" />
                        For security, we recommend choosing a strong password that you don't use elsewhere.
                      </p>
                    </div>
                    
                    <Form {...passwordForm}>
                      <div className="space-y-6">
                        <FormField
                          control={passwordForm.control}
                          name="newPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                New Password
                              </FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  type="password" 
                                  className="h-12 text-base border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                                />
                              </FormControl>
                              <FormDescription className="text-xs text-gray-500 dark:text-gray-400">
                                Must be at least 6 characters long.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={passwordForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                Confirm New Password
                              </FormLabel>
                              <FormControl>
                                <Input 
                                  {...field} 
                                  type="password" 
                                  className="h-12 text-base border-gray-300 dark:border-gray-600 focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                                />
                              </FormControl>
                              <FormDescription className="text-xs text-gray-500 dark:text-gray-400">
                                Re-enter your new password to confirm.
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    </Form>
                  </FormSection>

                  <div className="flex justify-end pt-6">
                    <Button
                      type="submit"
                      disabled={updatePasswordMutation.isPending}
                      className="h-12 px-8 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-medium rounded-lg shadow-lg hover:shadow-xl transition-all duration-200"
                    >
                      {updatePasswordMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Updating...
                        </>
                      ) : (
                        'Update Password'
                      )}
                    </Button>
                  </div>
                </FormWrapper>
              </TabsContent>
            </div>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}