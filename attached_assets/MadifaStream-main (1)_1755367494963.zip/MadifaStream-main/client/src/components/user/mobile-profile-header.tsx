/**
 * Mobile Profile Header Component
 * 
 * Optimized mobile header for profile pages with:
 * - Touch-friendly interface
 * - Responsive layout
 * - Gesture support
 * - Quick actions
 */

import React, { useState } from 'react';
import {  ArrowLeft, MoreVertical, Share, Settings, Edit3  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';
import {  Sheet, SheetContent, SheetTrigger  } from '@/components/ui/sheet';
import {  AvatarUpload  } from './avatar-upload';
import { cn } from '@/lib/utils';

interface MobileProfileHeaderProps {
  user: {
    id: string;
    displayName?: string;
    username?: string;
    email?: string;
    avatar_url?: string;
    avatarUrl?: string;
  };
  onBack?: () => void;
  onEdit?: () => void;
  onShare?: () => void;
  className?: string;
}

export function MobileProfileHeader({ 
  user, 
  onBack, 
  onEdit, 
  onShare,
  className 
}: MobileProfileHeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const displayName = user.displayName || user.username || 'User';
  const avatarUrl = user.avatar_url || user.avatarUrl;

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${displayName}'s Profile`,
          text: `Check out ${displayName}'s profile on Madifa`,
          url: window.location.href,
        });
      } catch (error) {
        // User cancelled or share failed
        onShare?.();
      }
    } else {
      onShare?.();
    }
    setIsMenuOpen(false);
  };

  return (
    <div className={cn(
      "sticky top-0 z-50 bg-white/95 dark:bg-gray-900/95 backdrop-blur-sm border-b border-gray-200 dark:border-gray-800",
      className
    )}>
      {/* Mobile Header Bar */}
      <div className="flex items-center justify-between p-4 md:hidden">
        <Button
          variant="ghost"
          size="sm"
          onClick={onBack}
          className="h-10 w-10 p-0 hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>

        <h1 className="text-lg font-semibold text-gray-900 dark:text-white truncate mx-4">
          Profile
        </h1>

        <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="h-10 w-10 p-0 hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              <MoreVertical className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-64">
            <div className="py-4 space-y-2">
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => {
                  onEdit?.();
                  setIsMenuOpen(false);
                }}
              >
                <Edit3 className="mr-3 h-4 w-4" />
                Edit Profile
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={handleShare}
              >
                <Share className="mr-3 h-4 w-4" />
                Share Profile
              </Button>
              <Button
                variant="ghost"
                className="w-full justify-start"
                onClick={() => {
                  // Navigate to settings
                  setIsMenuOpen(false);
                }}
              >
                <Settings className="mr-3 h-4 w-4" />
                Settings
              </Button>
            </div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Mobile Profile Summary */}
      <div className="px-4 pb-4 md:hidden">
        <div className="flex items-center space-x-4">
          <AvatarUpload
            currentAvatarUrl={avatarUrl}
            userId={user.id}
            displayName={displayName}
            className="flex-shrink-0"
          />
          
          <div className="flex-1 min-w-0">
            <h2 className="text-xl font-bold text-gray-900 dark:text-white truncate">
              {displayName}
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
              {user.email}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
} 