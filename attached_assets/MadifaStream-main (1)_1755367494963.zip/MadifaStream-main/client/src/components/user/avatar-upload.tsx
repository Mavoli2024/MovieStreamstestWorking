import { logger } from '@shared/logger';
/**
 * Avatar Upload Component
 * 
 * Provides avatar upload functionality with:
 * - Image file validation and size limits
 * - Image cropping with preview
 * - Supabase storage integration
 * - Progress tracking and error handling
 * - Mobile-optimized touch interface
 */

import React, { useState, useRef, useCallback } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {  Upload, Camera, X, RotateCcw, Check, Loader2  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';
import {  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger  } from '@/components/ui/dialog';
import {  Progress  } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';
import {  Avatar, AvatarFallback, AvatarImage  } from '@/components/ui/avatar';

interface AvatarUploadProps {
  currentAvatarUrl?: string;
  userId: string;
  displayName: string;
  onUploadSuccess?: (avatarUrl: string) => void;
  className?: string;
}

interface CropArea {
  x: number;
  y: number;
  width: number;
  height: number;
}

// Image validation constants
const MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const TARGET_SIZE = 200; // Target size for avatar

export function AvatarUpload({ 
  currentAvatarUrl, 
  userId, 
  displayName, 
  onUploadSuccess,
  className = ""
}: AvatarUploadProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // State
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [cropArea, setCropArea] = useState<CropArea>({ x: 0, y: 0, width: 0, height: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [imageNaturalSize, setImageNaturalSize] = useState({ width: 0, height: 0 });
  const [uploadProgress, setUploadProgress] = useState(0);

  // Generate initials from display name
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(word => word.charAt(0))
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  // Validate image file
  const validateImage = (file: File): string | null => {
    if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
      return 'Please select a valid image file (JPEG, PNG, or WebP)';
    }
    if (file.size > MAX_FILE_SIZE) {
      return 'Image file must be smaller than 5MB';
    }
    return null;
  };

  // Handle file selection
  const handleFileSelect = useCallback((file: File) => {
    const validationError = validateImage(file);
    if (validationError) {
      toast({
        title: 'Invalid file',
        description: validationError,
        variant: 'destructive',
      });
      return;
    }

    setSelectedFile(file);
    
    // Create preview URL
    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setImagePreview(imageUrl);
      
      // Get image natural dimensions
      const img = new Image();
      img.onload = () => {
        setImageNaturalSize({ width: img.naturalWidth, height: img.naturalHeight });
        
        // Set initial crop area (center square)
        const size = Math.min(img.naturalWidth, img.naturalHeight);
        setCropArea({
          x: (img.naturalWidth - size) / 2,
          y: (img.naturalHeight - size) / 2,
          width: size,
          height: size,
        });
      };
      img.src = imageUrl;
    };
    reader.readAsDataURL(file);
    setIsDialogOpen(true);
  }, [toast]);

  // Handle drag and drop
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  }, [handleFileSelect]);

  // Handle file input change
  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  // Crop image to canvas
  const cropImage = useCallback((): Promise<Blob> => {
    return new Promise((resolve, reject) => {
      if (!canvasRef.current || !imagePreview) {
        reject(new Error('Canvas or image not available'));
        return;
      }

      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Could not get canvas context'));
        return;
      }

      const img = new Image();
      img.onload = () => {
        // Set canvas size to target dimensions
        canvas.width = TARGET_SIZE;
        canvas.height = TARGET_SIZE;

        // Calculate scale factor
        const scaleX = img.naturalWidth / imageNaturalSize.width;
        const scaleY = img.naturalHeight / imageNaturalSize.height;

        // Draw cropped image
        ctx.drawImage(
          img,
          cropArea.x * scaleX,
          cropArea.y * scaleY,
          cropArea.width * scaleX,
          cropArea.height * scaleY,
          0,
          0,
          TARGET_SIZE,
          TARGET_SIZE
        );

        // Convert to blob
        canvas.toBlob((blob) => {
          if (blob) {
            resolve(blob);
          } else {
            reject(new Error('Failed to create image blob'));
          }
        }, 'image/jpeg', 0.9);
      };
      img.onerror = () => reject(new Error('Failed to load image'));
      img.src = imagePreview;
    });
  }, [imagePreview, cropArea, imageNaturalSize]);

  // Upload mutation
  const uploadMutation = useMutation({
    mutationFn: async () => {
      if (!selectedFile) throw new Error('No file selected');

      // Crop the image
      const croppedBlob = await cropImage();
      
      // Generate unique filename
      const fileExt = 'jpg';
      const fileName = `${userId}/avatar.${fileExt}`;
      
      // Upload to Supabase storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('avatars')
        .upload(fileName, croppedBlob, {
          upsert: true,
          contentType: 'image/jpeg'
        });

      if (uploadError) {
        throw uploadError;
      }

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('avatars')
        .getPublicUrl(fileName);

      // Update user profile with new avatar URL
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: publicUrl })
        .eq('id', userId);

      if (updateError) {
        throw updateError;
      }

      return publicUrl;
    },
    onSuccess: (avatarUrl) => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      setIsDialogOpen(false);
      setSelectedFile(null);
      setImagePreview(null);
      setUploadProgress(0);
      
      toast({
        title: 'Avatar updated',
        description: 'Your profile picture has been updated successfully.',
      });

      onUploadSuccess?.(avatarUrl);
    },
    onError: (error) => {
      logger.error('Avatar upload error:', { arg1: error });
      toast({
        title: 'Upload failed',
        description: 'There was a problem uploading your avatar. Please try again.',
        variant: 'destructive',
      });
      setUploadProgress(0);
    },
  });

  // Handle mouse events for cropping
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;

    const deltaX = e.clientX - dragStart.x;
    const deltaY = e.clientY - dragStart.y;

    setCropArea(prev => ({
      ...prev,
      x: Math.max(0, Math.min(prev.x + deltaX, imageNaturalSize.width - prev.width)),
      y: Math.max(0, Math.min(prev.y + deltaY, imageNaturalSize.height - prev.height)),
    }));

    setDragStart({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const resetCrop = () => {
    const size = Math.min(imageNaturalSize.width, imageNaturalSize.height);
    setCropArea({
      x: (imageNaturalSize.width - size) / 2,
      y: (imageNaturalSize.height - size) / 2,
      width: size,
      height: size,
    });
  };

  return (
    <div className={className}>
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogTrigger asChild>
          <div className="relative group cursor-pointer">
            <Avatar className="h-20 w-20 sm:h-24 sm:w-24 ring-4 ring-white dark:ring-gray-800 shadow-xl transition-transform duration-300 group-hover:scale-105">
              {currentAvatarUrl ? (
                <AvatarImage src={currentAvatarUrl} alt={displayName} />
              ) : (
                <AvatarFallback className="text-lg sm:text-xl font-bold text-white bg-gradient-to-br from-blue-500 to-purple-600">
                  {getInitials(displayName)}
                </AvatarFallback>
              )}
            </Avatar>
            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 rounded-full transition-all duration-300 flex items-center justify-center">
              <Camera className="h-6 w-6 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </div>
            <Button 
              size="sm" 
              variant="secondary" 
              className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full p-0 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            >
              <Camera className="h-4 w-4" />
            </Button>
          </div>
        </DialogTrigger>
        
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Upload Avatar</DialogTitle>
          </DialogHeader>
          
          {!imagePreview ? (
            <div className="space-y-4">
              {/* File drop zone */}
              <div
                className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-8 text-center hover:border-primary transition-colors cursor-pointer"
                onDrop={handleDrop}
                onDragOver={(e) => e.preventDefault()}
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-lg font-medium mb-2">Drop an image here</p>
                <p className="text-sm text-gray-500 mb-4">or click to select from your device</p>
                <p className="text-xs text-gray-400">Supports JPEG, PNG, WebP up to 5MB</p>
              </div>
              
              <input
                ref={fileInputRef}
                type="file"
                accept={ACCEPTED_IMAGE_TYPES.join(',')}
                onChange={handleFileInputChange}
                className="hidden"
              />
            </div>
          ) : (
            <div className="space-y-4">
              {/* Image cropping interface */}
              <div className="relative">
                <div className="aspect-square bg-gray-100 dark:bg-gray-800 rounded-lg overflow-hidden">
                  <div
                    className="relative w-full h-full cursor-move"
                    onMouseDown={handleMouseDown}
                    onMouseMove={handleMouseMove}
                    onMouseUp={handleMouseUp}
                    onMouseLeave={handleMouseUp}
                  >
                    <img
                      src={imagePreview}
                      alt="Preview"
                      className="w-full h-full object-contain"
                      draggable={false}
                    />
                    {/* Crop overlay */}
                    <div
                      className="absolute border-2 border-white shadow-lg"
                      style={{
                        left: `${(cropArea.x / imageNaturalSize.width) * 100}%`,
                        top: `${(cropArea.y / imageNaturalSize.height) * 100}%`,
                        width: `${(cropArea.width / imageNaturalSize.width) * 100}%`,
                        height: `${(cropArea.height / imageNaturalSize.height) * 100}%`,
                      }}
                    >
                      <div className="absolute inset-0 bg-white bg-opacity-20" />
                    </div>
                  </div>
                </div>
                
                <p className="text-xs text-gray-500 mt-2 text-center">
                  Drag to adjust the crop area
                </p>
              </div>

              {/* Upload progress */}
              {uploadMutation.isPending && (
                <div className="space-y-2">
                  <Progress value={uploadProgress} className="w-full" />
                  <p className="text-sm text-center text-gray-500">
                    Uploading avatar... {uploadProgress}%
                  </p>
                </div>
              )}

              {/* Action buttons */}
              <div className="flex justify-between space-x-2">
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={resetCrop}
                    disabled={uploadMutation.isPending}
                  >
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reset
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setImagePreview(null);
                      setSelectedFile(null);
                    }}
                    disabled={uploadMutation.isPending}
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                </div>
                
                <Button
                  onClick={() => uploadMutation.mutate()}
                  disabled={uploadMutation.isPending}
                  className="min-w-[100px]"
                >
                  {uploadMutation.isPending ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <Check className="h-4 w-4 mr-2" />
                  )}
                  {uploadMutation.isPending ? 'Uploading' : 'Save'}
                </Button>
              </div>
            </div>
          )}
          
          {/* Hidden canvas for image processing */}
          <canvas ref={canvasRef} className="hidden" />
        </DialogContent>
      </Dialog>
    </div>
  );
} 