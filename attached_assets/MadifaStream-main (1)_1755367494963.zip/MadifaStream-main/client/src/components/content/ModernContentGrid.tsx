/**
 * Modern Content Grid Component
 * 
 * Professional content display with:
 * - Smooth animations and transitions
 * - Lazy loading with intersection observer
 * - Skeleton loading states
 * - Error recovery
 * - Responsive design
 */

import React, { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { cn } from '@/lib/utils';
import { useLocation } from 'wouter';
import { toast } from 'react-hot-toast';

// Icons
import { 
  Play, Plus, Check, Info, Star, Clock, Calendar,
  TrendingUp, Crown, Lock, Download, Share2, Bookmark, BookmarkCheck, MoreVertical, Eye
 } from 'lucide-react';

// Components
import {  Button  } from '@/components/ui/button';
import {  Badge  } from '@/components/ui/badge';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {  Skeleton  } from '@/components/ui/skeleton';
import {  Card, CardContent  } from '@/components/ui/card';

interface ContentItem {
  id: string;
  title: string;
  description?: string;
  thumbnail_url?: string;
  duration_minutes?: number;
  release_year?: number;
  rating?: number;
  genres?: string[];
  is_premium?: boolean;
  is_new?: boolean;
  is_trending?: boolean;
  view_count?: number;
  progress?: number;
}

interface ModernContentGridProps {
  items: ContentItem[];
  loading?: boolean;
  error?: Error | null;
  onItemClick?: (item: ContentItem) => void;
  onAddToWatchlist?: (itemId: string) => void;
  onRemoveFromWatchlist?: (itemId: string) => void;
  watchlist?: Set<string>;
  variant?: 'grid' | 'carousel' | 'list';
  columns?: 2 | 3 | 4 | 5 | 6;
  showProgress?: boolean;
  showLoadMore?: boolean;
  isLoading?: boolean;
  onLoadMore?: () => void;
  className?: string;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { 
    opacity: 0, 
    y: 20 
  },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { 
      duration: 0.3
    }
  },
};

export function ModernContentGrid({
  items,
  loading = false,
  error = null,
  onItemClick,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  watchlist = new Set(),
  variant = 'grid',
  columns = 5,
  showProgress = true,
  showLoadMore = false,
  isLoading = false,
  onLoadMore,
  className,
}: ModernContentGridProps) {
  const [location, navigate] = useLocation();
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [imageErrors, setImageErrors] = useState<Set<string>>(new Set());
  const [retryCount, setRetryCount] = useState(0);

  // Handle item click
  const handleItemClick = useCallback((item: ContentItem) => {
    if (onItemClick) {
      onItemClick(item);
    } else {
      navigate(`/watch/${item.id}`);
    }
  }, [onItemClick, navigate]);

  // Handle watchlist toggle
  const handleWatchlistToggle = useCallback((e: React.MouseEvent, itemId: string) => {
    e.stopPropagation();
    
    if (watchlist.has(itemId)) {
      onRemoveFromWatchlist?.(itemId);
    } else {
      onAddToWatchlist?.(itemId);
    }
  }, [watchlist, onAddToWatchlist, onRemoveFromWatchlist]);

  // Handle image error
  const handleImageError = useCallback((itemId: string) => {
    setImageErrors(prev => new Set(prev).add(itemId));
  }, []);

  // Format duration
  const formatDuration = (minutes: number): string => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return mins > 0 ? `${hours}h ${mins}m` : `${hours}h`;
  };

  // Get grid columns class
  const getGridClass = (): string => {
    const gridClasses = {
      2: 'grid-cols-2',
      3: 'grid-cols-2 md:grid-cols-3',
      4: 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4',
      5: 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5',
      6: 'grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6',
    };
    return gridClasses[columns];
  };

  // Render skeleton loader
  const renderSkeleton = () => (
    <div className={cn('grid gap-4', getGridClass())}>
      {Array.from({ length: columns * 2 }).map((_, i) => (
        <div key={i} className="space-y-3">
          <Skeleton className="aspect-[2/3] rounded-lg" />
          <Skeleton className="h-4 w-3/4" />
          <Skeleton className="h-3 w-1/2" />
        </div>
      ))}
    </div>
  );

  // Render error state
  const renderError = () => (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="text-6xl mb-4">😕</div>
      <h3 className="text-xl font-semibold mb-2">Unable to load content</h3>
      <p className="text-muted-foreground mb-4">
        {error?.message || 'Something went wrong. Please try again.'}
      </p>
      <Button onClick={() => window.location.reload()}>
        Retry
      </Button>
    </div>
  );

  // Render empty state
  const renderEmpty = () => (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="text-6xl mb-4">🎬</div>
      <h3 className="text-xl font-semibold mb-2">No content available</h3>
      <p className="text-muted-foreground">
        Check back later for new content
      </p>
    </div>
  );

  // Render content item
  const renderItem = (item: ContentItem) => {
    const isHovered = hoveredItem === item.id;
    const isInWatchlist = watchlist.has(item.id);
    const hasImageError = imageErrors.has(item.id);

    return (
      <motion.div
        key={item.id}
        variants={itemVariants}
        layout
        onHoverStart={() => setHoveredItem(item.id)}
        onHoverEnd={() => setHoveredItem(null)}
        className="group relative cursor-pointer"
        onClick={() => handleItemClick(item)}
      >
        {/* Thumbnail */}
        <div className="relative aspect-[2/3] rounded-lg overflow-hidden bg-muted">
          {!hasImageError && item.thumbnail_url ? (
            <img
              src={item.thumbnail_url}
              alt={item.title}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              loading="lazy"
              onError={() => handleImageError(item.id)}
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-primary/20 to-primary/10">
              <Play className="w-12 h-12 text-primary/50" />
            </div>
          )}

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/0 to-black/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

          {/* Badges */}
          <div className="absolute top-2 left-2 right-2 flex items-start justify-between">
            <div className="flex flex-wrap gap-1">
              {item.is_premium && (
                <Badge className="bg-amber-500/90 text-white border-0">
                  <Crown className="w-3 h-3 mr-1" />
                  Premium
                </Badge>
              )}
              {item.is_new && (
                <Badge className="bg-green-500/90 text-white border-0">
                  New
                </Badge>
              )}
              {item.is_trending && (
                <Badge className="bg-red-500/90 text-white border-0">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  Trending
                </Badge>
              )}
            </div>
            
            {item.duration_minutes && (
              <Badge variant="secondary" className="bg-black/60 text-white border-0">
                {formatDuration(item.duration_minutes)}
              </Badge>
            )}
          </div>

          {/* Progress bar */}
          {showProgress && item.progress && item.progress > 0 && (
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/50">
              <div
                className="h-full bg-primary"
                style={{ width: `${item.progress}%` }}
              />
            </div>
          )}

          {/* Hover overlay */}
          <AnimatePresence>
            {isHovered && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 bg-black/60 flex items-center justify-center"
              >
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="bg-white text-black hover:bg-gray-200"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleItemClick(item);
                    }}
                  >
                    <Play className="w-4 h-4 mr-1 fill-black" />
                    Play
                  </Button>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="sm"
                          variant="secondary"
                          className="bg-white/20 text-white hover:bg-white/30"
                          onClick={(e) => handleWatchlistToggle(e, item.id)}
                        >
                          {isInWatchlist ? (
                            <Check className="w-4 h-4" />
                          ) : (
                            <Plus className="w-4 h-4" />
                          )}
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        {isInWatchlist ? 'Remove from Watchlist' : 'Add to Watchlist'}
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          size="sm"
                          variant="secondary"
                          className="bg-white/20 text-white hover:bg-white/30"
                          onClick={(e) => {
                            e.stopPropagation();
                            // TODO: Show info modal
                          }}
                        >
                          <Info className="w-4 h-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>More Info</TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Content info */}
        <div className="mt-3 space-y-1">
          <h3 className="font-medium text-sm line-clamp-2 group-hover:text-primary transition-colors relative z-10 bg-background/90 p-1 rounded">
            {item.title}
          </h3>
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            {item.release_year && (
              <span>{item.release_year}</span>
            )}
            
            {item.rating && (
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span>{item.rating.toFixed(1)}</span>
              </div>
            )}
            
            {item.view_count && (
              <span>{item.view_count.toLocaleString()} views</span>
            )}
          </div>
          
          {item.genres && item.genres.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {item.genres.slice(0, 2).map((genre) => (
                <Badge
                  key={genre}
                  variant="outline"
                  className="text-xs px-1.5 py-0"
                >
                  {genre}
                </Badge>
              ))}
              {item.genres.length > 2 && (
                <Badge
                  variant="outline"
                  className="text-xs px-1.5 py-0"
                >
                  +{item.genres.length - 2}
                </Badge>
              )}
            </div>
          )}
        </div>
      </motion.div>
    );
  };

  // Render carousel variant
  const renderCarousel = () => (
    <div className="relative">
      <div className="flex gap-4 overflow-x-auto scrollbar-hide snap-x snap-mandatory">
        {items.map((item) => (
          <div
            key={item.id}
            className="flex-none w-[200px] md:w-[240px] snap-start"
          >
            {renderItem(item)}
          </div>
        ))}
      </div>
    </div>
  );

  // Render list variant
  const renderList = () => (
    <div className="space-y-4">
      {items.map((item) => (
        <motion.div
          key={item.id}
          variants={itemVariants}
          className="group flex gap-4 p-4 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
          onClick={() => handleItemClick(item)}
        >
          {/* Thumbnail */}
          <div className="flex-none w-32 md:w-40 aspect-[2/3] rounded-md overflow-hidden bg-muted">
            {!imageErrors.has(item.id) && item.thumbnail_url ? (
              <img
                src={item.thumbnail_url}
                alt={item.title}
                className="w-full h-full object-cover"
                loading="lazy"
                onError={() => handleImageError(item.id)}
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <Play className="w-8 h-8 text-muted-foreground" />
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-4">
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-lg line-clamp-1 group-hover:text-primary transition-colors">
                  {item.title}
                </h3>
                
                {item.description && (
                  <p className="text-sm text-muted-foreground line-clamp-2 mt-1">
                    {item.description}
                  </p>
                )}
                
                <div className="flex items-center gap-4 mt-2 text-sm">
                  {item.release_year && (
                    <span className="text-muted-foreground">{item.release_year}</span>
                  )}
                  
                  {item.duration_minutes && (
                    <span className="text-muted-foreground">
                      {formatDuration(item.duration_minutes)}
                    </span>
                  )}
                  
                  {item.rating && (
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span>{item.rating.toFixed(1)}</span>
                    </div>
                  )}
                </div>
                
                <div className="flex items-center gap-2 mt-2">
                  {item.is_premium && (
                    <Badge className="bg-amber-500/10 text-amber-600 border-amber-500/20">
                      <Crown className="w-3 h-3 mr-1" />
                      Premium
                    </Badge>
                  )}
                  
                  {item.genres?.slice(0, 3).map((genre) => (
                    <Badge key={genre} variant="outline">
                      {genre}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant={watchlist.has(item.id) ? 'secondary' : 'outline'}
                  onClick={(e) => handleWatchlistToggle(e, item.id)}
                >
                  {watchlist.has(item.id) ? (
                    <Check className="w-4 h-4" />
                  ) : (
                    <Plus className="w-4 h-4" />
                  )}
                </Button>
                
                <Button
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleItemClick(item);
                  }}
                >
                  <Play className="w-4 h-4 mr-1 fill-white" />
                  Play
                </Button>
              </div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );

  // Main render
  if (loading) {
    return renderSkeleton();
  }

  if (error) {
    return renderError();
  }

  if (!Array.isArray(items) || items.length === 0) {
    return renderEmpty();
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className={className}
    >
      {variant === 'carousel' && renderCarousel()}
      {variant === 'list' && renderList()}
      {variant === 'grid' && (
        <div className={cn('grid gap-4', getGridClass())}>
          {items.map(renderItem)}
        </div>
      )}
    </motion.div>
  );
} 