import { logger } from '@shared/logger';
/**
 * User Synchronization Button Component
 * 
 * This component allows admins to synchronize users between Supabase Auth
 * and our application database, ensuring perfect sync between the two systems.
 */

import {  Button  } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {  AlertCircle, CheckCircle, RefreshCw  } from 'lucide-react';
import { useState } from 'react';

interface UserSyncButtonProps {
  onSyncComplete?: () => void;
}

export function UserSyncButton({ onSyncComplete }: UserSyncButtonProps) {
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<{
    success: boolean;
    message: string;
    count?: number;
  } | null>(null);
  const { toast } = useToast();

  const handleSyncUsers = async () => {
    try {
      setSyncing(true);
      setSyncResult(null);

      // Call the sync endpoint
      const res = await fetch('/api/admin/sync-users', {
        method: 'POST',
        credentials: 'include'
      });

      const response: { success: boolean; message: string; count?: number } = await res.json();

      if (response && response.success) {
        setSyncResult({
          success: true,
          message: response.message,
          count: response.count
        });

        toast({
          title: 'Synchronization successful',
          description: response.message,
        });

        // Notify parent component if needed
        if (onSyncComplete) {
          onSyncComplete();
        }
      } else {
        setSyncResult({
          success: false,
          message: response?.message || 'Synchronization failed'
        });

        toast({
          title: 'Synchronization failed',
          description: response?.message || 'Failed to synchronize users',
          variant: 'destructive'
        });
      }
    } catch (error) {
      logger.error('Error synchronizing users:', { arg1: error });

      setSyncResult({
        success: false,
        message: error instanceof Error ? error.message : 'Unknown error occurred'
      });

      toast({
        title: 'Synchronization error',
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: 'destructive'
      });
    } finally {
      setSyncing(false);
    }
  };

  return (
    <div className="space-y-2">
      <Button
        onClick={handleSyncUsers}
        disabled={syncing}
        className="w-full sm:w-auto"
      >
        {syncing ? (
          <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
        ) : (
          <RefreshCw className="mr-2 h-4 w-4" />
        )}
        Sync Supabase Users
      </Button>

      {syncResult && (
        <div className={`text-sm p-2 rounded flex items-center ${syncResult.success ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
            : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
          }`}>
          {syncResult.success ? (
            <CheckCircle className="h-4 w-4 mr-2 flex-shrink-0" />
          ) : (
            <AlertCircle className="h-4 w-4 mr-2 flex-shrink-0" />
          )}
          <span>
            {syncResult.message}
            {syncResult.success && syncResult.count !== undefined && (
              <span className="font-semibold"> ({syncResult.count} users)</span>
            )}
          </span>
        </div>
      )}
    </div>
  );
}