/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * Universal CRUD Modal Component
 * 
 * A sophisticated modal for creating and editing database records
 * Features:
 * - Dynamic form generation based on field definitions
 * - Multiple input types (text, number, select, textarea, date, boolean, file)
 * - Form validation with Zod
 * - File upload support
 * - Nested object editing
 * - Array field management
 */

// import { Badge } from '@/components/ui/badge'; // Unused, commented out
import {  Button  } from '@/components/ui/button';
import {  Checkbox  } from '@/components/ui/checkbox';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {  Input  } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {  Textarea  } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
// import { cn } from '@/lib/utils'; // Unused, commented out
import { zodResolver } from '@hookform/resolvers/zod';
import {
  Loader2,
  Plus,
  Trash2,
  X,
} from 'lucide-react';
import React, { useCallback, useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';

// Field definition interface
export interface FieldDef {
  name: string;
  label: string;
  type: 'text' | 'email' | 'number' | 'select' | 'textarea' | 'date' | 'boolean' | 'file' | 'array' | 'json';
  required?: boolean;
  placeholder?: string;
  description?: string;
  options?: { value: string; label: string }[];
  validation?: z.ZodType<any>;
  multiple?: boolean; // For arrays
  accept?: string; // For file inputs
  maxSize?: number; // For file inputs (in MB)
  arrayItemType?: 'text' | 'select' | 'object';
  arrayItemOptions?: { value: string; label: string }[];
  objectFields?: FieldDef[]; // For nested objects
  defaultValue?: unknown;
  disabled?: boolean;
  hidden?: boolean;
  width?: 'full' | 'half' | 'third';
}

// Modal props interface
export interface UniversalCrudModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  description?: string;
  fields: FieldDef[];
  initialData?: Record<string, any>;
  onSubmit: (data: Record<string, any>) => Promise<void>;
  isLoading?: boolean;
  submitLabel?: string;
  cancelLabel?: string;
  mode?: 'create' | 'edit';
}

export function UniversalCrudModal({
  isOpen,
  onClose,
  title,
  description,
  fields,
  initialData,
  onSubmit,
  isLoading = false,
  submitLabel,
  cancelLabel = 'Cancel',
  mode = 'create',
}: UniversalCrudModalProps) {
  const { toast } = useToast();
  const [uploadedFiles, setUploadedFiles] = useState<Record<string, File>>({});

  // Generate dynamic schema based on field definitions
  const generateSchema = useCallback(() => {
    const schemaFields: Record<string, z.ZodType<any>> = {};

    fields.forEach(field => {
      if (field.hidden) return;

      let fieldSchema: z.ZodType<any>;

      switch (field.type) {
        case 'email':
          fieldSchema = z.string().email('Invalid email address');
          break;
        case 'number':
          fieldSchema = z.coerce.number();
          break;
        case 'date':
          fieldSchema = z.string().or(z.date());
          break;
        case 'boolean':
          fieldSchema = z.boolean();
          break;
        case 'array':
          fieldSchema = z.array(z.string()).default([]);
          break;
        case 'json':
          fieldSchema = z.any();
          break;
        case 'file':
          fieldSchema = z.any().optional();
          break;
        default:
          fieldSchema = z.string();
      }

      if (field.validation) {
        fieldSchema = field.validation;
      }

      // Apply required validation for non-file, non-boolean fields
      if (field.required && field.type !== 'boolean' && field.type !== 'file') {
        if (field.type === 'text' || field.type === 'email' || field.type === 'textarea') {
          fieldSchema = (fieldSchema as z.ZodString).min(1, `${field.label} is required`);
        }
      } else if (!field.required) {
        fieldSchema = fieldSchema.optional();
      }

      schemaFields[field.name] = fieldSchema;
    });

    return z.object(schemaFields);
  }, [fields]);

  // Initialize form
  const form = useForm({
    resolver: zodResolver(generateSchema()),
    defaultValues: fields.reduce((acc, field) => {
      if (field.hidden) return acc;
      
      const initialValue = initialData?.[field.name] ?? field.defaultValue;
      
      switch (field.type) {
        case 'boolean':
          acc[field.name] = initialValue ?? false;
          break;
        case 'array':
          acc[field.name] = initialValue ?? [];
          break;
        case 'number':
          acc[field.name] = initialValue ?? '';
          break;
        default:
          acc[field.name] = initialValue ?? '';
      }
      
      return acc;
    }, {} as Record<string, any>),
  });

  // Reset form when modal opens/closes or initial data changes
  useEffect(() => {
    if (isOpen) {
      const defaultValues = fields.reduce((acc, field) => {
        if (field.hidden) return acc;
        
        const initialValue = initialData?.[field.name] ?? field.defaultValue;
        
        switch (field.type) {
          case 'boolean':
            acc[field.name] = initialValue ?? false;
            break;
          case 'array':
            acc[field.name] = initialValue ?? [];
            break;
          case 'number':
            acc[field.name] = initialValue ?? '';
            break;
          default:
            acc[field.name] = initialValue ?? '';
        }
        
        return acc;
      }, {} as Record<string, any>);

      form.reset(defaultValues);
      setUploadedFiles({});
    }
  }, [isOpen, initialData, fields, form]);

  // Handle form submission
  const handleSubmit = async (data: Record<string, any>) => {
    try {
      // Process uploaded files
      const processedData = { ...data };
      
      Object.entries(uploadedFiles).forEach(([fieldName, file]) => {
        // In a real app, you'd upload the file and get a URL
        // For now, we'll just add the file info
        processedData[fieldName] = {
          name: file.name,
          size: file.size,
          type: file.type,
          // url: uploadedUrl, // Would be set after upload
        };
      });

      await onSubmit(processedData);
      
      toast({
        title: `${mode === 'create' ? 'Created' : 'Updated'} successfully`,
        description: `Record has been ${mode === 'create' ? 'created' : 'updated'}.`,
      });
      
      onClose();
    } catch (error) {
      toast({
        title: `Failed to ${mode === 'create' ? 'create' : 'update'}`,
        description: error instanceof Error ? error.message : 'An error occurred',
        variant: 'destructive',
      });
    }
  };

  // Handle file upload
  const handleFileUpload = (fieldName: string, file: File | null) => {
    if (file) {
      setUploadedFiles(prev => ({
        ...prev,
        [fieldName]: file,
      }));
      form.setValue(fieldName, file.name);
    } else {
      setUploadedFiles(prev => {
        const newFiles = { ...prev };
        delete newFiles[fieldName];
        return newFiles;
      });
      form.setValue(fieldName, '');
    }
  };

  // Render array field
  const renderArrayField = (field: FieldDef, value: string[] = []) => {
    const addItem = () => {
      const newValue = [...value, ''];
      form.setValue(field.name, newValue);
    };

    const removeItem = (index: number) => {
      const newValue = value.filter((_, i) => i !== index);
      form.setValue(field.name, newValue);
    };

    const updateItem = (index: number, newItemValue: string) => {
      const newValue = [...value];
      newValue[index] = newItemValue;
      form.setValue(field.name, newValue);
    };

    return (
      <div className="space-y-2">
        {value.map((item, index) => (
          <div key={index} className="flex items-center gap-2">
            {field.arrayItemType === 'select' ? (
              <Select
                value={item}
                onValueChange={(newValue) => updateItem(index, newValue)}
              >
                <SelectTrigger className="flex-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {field.arrayItemOptions?.map(option => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Input
                value={item}
                onChange={(e) => updateItem(index, e.target.value)}
                placeholder={`${field.label} item`}
                className="flex-1"
              />
            )}
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => removeItem(index)}
            >
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        ))}
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={addItem}
          className="w-full"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add {field.label} Item
        </Button>
      </div>
    );
  };

  // Render field based on type
  const renderField = (field: FieldDef) => {
    if (field.hidden) return null;

    const widthClass = {
      full: 'col-span-2',
      half: 'col-span-1',
      third: 'col-span-1 md:col-span-1',
    }[field.width || 'full'];

    return (
      <FormField
        key={field.name}
        control={form.control}
        name={field.name}
        render={({ field: formField }) => (
          <FormItem className={widthClass}>
            <FormLabel className="flex items-center gap-2">
              {field.label}
              {field.required && <span className="text-red-500">*</span>}
            </FormLabel>
            <FormControl>
              {(() => {
                switch (field.type) {
                  case 'textarea':
                    return (
                      <Textarea
                        {...formField}
                        placeholder={field.placeholder}
                        disabled={field.disabled || isLoading}
                        className="min-h-[100px]"
                      />
                    );

                  case 'select':
                    return (
                      <Select
                        value={formField.value}
                        onValueChange={formField.onChange}
                        disabled={field.disabled || isLoading}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder={field.placeholder} />
                        </SelectTrigger>
                        <SelectContent>
                          {field.options?.map(option => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    );

                  case 'boolean':
                    return (
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          checked={formField.value}
                          onCheckedChange={formField.onChange}
                          disabled={field.disabled || isLoading}
                        />
                        <span className="text-sm text-muted-foreground">
                          {field.placeholder || 'Enable this option'}
                        </span>
                      </div>
                    );

                  case 'date':
                    return (
                      <Input
                        {...formField}
                        type="date"
                        disabled={field.disabled || isLoading}
                      />
                    );

                  case 'file':
                    return (
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Input
                            type="file"
                            accept={field.accept}
                            onChange={(e) => {
                              const file = e.target.files?.[0] || null;
                              handleFileUpload(field.name, file);
                            }}
                            disabled={field.disabled || isLoading}
                            className="flex-1"
                          />
                          {uploadedFiles[field.name] && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => handleFileUpload(field.name, null)}
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                        {uploadedFiles[field.name] && (
                          <div className="text-sm text-muted-foreground">
                            Selected: {uploadedFiles[field.name].name} (
                            {(uploadedFiles[field.name].size / 1024 / 1024).toFixed(2)} MB)
                          </div>
                        )}
                        {field.maxSize && (
                          <div className="text-xs text-muted-foreground">
                            Max size: {field.maxSize}MB
                          </div>
                        )}
                      </div>
                    );

                  case 'array':
                    return renderArrayField(field, formField.value);

                  case 'json':
                    return (
                      <Textarea
                        {...formField}
                        value={typeof formField.value === 'string' ? formField.value : JSON.stringify(formField.value, null, 2)}
                        onChange={(e) => {
                          try {
                            const parsed = JSON.parse(e.target.value);
                            formField.onChange(parsed);
                          } catch {
                            formField.onChange(e.target.value);
                          }
                        }}
                        placeholder={field.placeholder || 'Enter JSON...'}
                        disabled={field.disabled || isLoading}
                        className="min-h-[100px] font-mono text-sm"
                      />
                    );

                  default:
                    return (
                      <Input
                        {...formField}
                        type={field.type}
                        placeholder={field.placeholder}
                        disabled={field.disabled || isLoading}
                      />
                    );
                }
              })()}
            </FormControl>
            {field.description && (
              <FormDescription>{field.description}</FormDescription>
            )}
            {field.validation && (
              <span className="text-xs text-muted-foreground">
                {field.description || 'Validation rules apply'}
              </span>
            )}
            <FormMessage />
          </FormItem>
        )}
      />
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {fields.map(renderField)}
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
              >
                {cancelLabel}
              </Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                {submitLabel || (mode === 'create' ? 'Create' : 'Update')}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}