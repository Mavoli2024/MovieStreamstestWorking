import { logger } from '@shared/logger';
/**
 * Admin User Management Component
 * 
 * This component provides advanced user management capabilities for administrators,
 * including user synchronization between Supabase Auth and the application database.
 */

import {  Badge  } from '@/components/ui/badge';
import {  Button  } from '@/components/ui/button';
import {  Card, CardContent, CardDescription, CardHeader, CardTitle  } from '@/components/ui/card';
import {  Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow  } from '@/components/ui/table';
import {  Tabs, TabsContent, TabsList, TabsTrigger  } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { 
    RefreshCw,
    Shield,
    ShieldAlert,
    UserCheck,
    User as UserIcon,
    UserX
 } from 'lucide-react';
import { useState } from 'react';

// User type definition
interface User {
  id: number;
  username: string;
  email: string;
  role: string;
  createdAt: string;
  authId: string | null;
  displayName: string | null;
  avatarColor: string | null;
  lastLogin?: string;
  emailVerified?: boolean;
}

// Import the UserDetail component
import { 
    Dialog,
    DialogContent
 } from "@/components/ui/dialog";
import { UserDetail } from './user-detail';

export function UserManagement() {
  const [syncing, setSyncing] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<number | null>(null);
  const [showUserDetail, setShowUserDetail] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch all users
  const { data: users = [], isLoading, error } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
    staleTime: 10000, // 10 seconds
  });

  // Synchronize users from Supabase Auth
  const syncUsers = async () => {
    try {
      setSyncing(true);

      const response = await fetch('/api/admin/sync-users', { method: 'POST', credentials: 'include' });

      if (!response.ok) throw new Error('Failed to synchronize users');

      const data = await response.json();

      if (data && data.success) {
        // Show success toast
        toast({
          title: 'User synchronization successful',
          description: data.message,
        });

        // Refresh the user list
        queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      } else {
        toast({
          title: 'Synchronization failed',
          description: data?.message || 'Failed to synchronize users',
          variant: 'destructive'
        });
      }
    } catch (error) {
      if (import.meta.env.DEV) {
        // eslint-disable-next-line no-console
        logger.error('Error synchronizing users:', { arg1: error });
      }

      toast({
        title: 'Synchronization error',
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: 'destructive'
      });
    } finally {
      setSyncing(false);
    }
  };

  // Update user role
  const updateUserRole = async (userId: number, role: string) => {
    try {
      const response = await fetch(`/api/admin/users/${userId}/role`, {
        method: 'PUT',
        body: JSON.stringify({ role }),
        credentials: 'include'
      });

      if (!response.ok) throw new Error('Failed to update user role');

      const data = await response.json();

      if (data && data.success) {
        toast({
          title: 'Role updated',
          description: `User role updated to ${role}`
        });

        // Refresh the user list
        queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      } else {
        toast({
          title: 'Update failed',
          description: data?.message || 'Failed to update user role',
          variant: 'destructive'
        });
      }
    } catch (error) {
      if (import.meta.env.DEV) {
        // eslint-disable-next-line no-console
        logger.error('Error updating user role:', { arg1: error });
      }

      toast({
        title: 'Update error',
        description: error instanceof Error ? error.message : 'Unknown error occurred',
        variant: 'destructive'
      });
    }
  };

  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>User Management</CardTitle>
          <CardDescription>View and manage user accounts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="p-4 text-center text-red-500">
            Error loading users. Please try again.
          </div>
        </CardContent>
      </Card>
    );
  }

  // Function to show user details
  const handleShowUserDetails = (userId: number) => {
    setSelectedUserId(userId);
    setShowUserDetail(true);
  };

  // Function to close user details
  const handleCloseUserDetails = () => {
    setShowUserDetail(false);
    setSelectedUserId(null);
  };

  return (
    <>
      <Card>
        <CardHeader className="flex flex-col sm:flex-row sm:justify-between sm:items-center">
          <div>
            <CardTitle>User Management</CardTitle>
            <CardDescription>
              View and manage user accounts
            </CardDescription>
          </div>
          <div className="mt-4 sm:mt-0">
            <Button
              onClick={syncUsers}
              disabled={syncing}
              variant="outline"
              className="ml-auto"
            >
              {syncing ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-2 h-4 w-4" />
              )}
              Sync Users
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList className="mb-4">
              <TabsTrigger value="all">
                <UserCheck className="h-4 w-4 mr-2" />
                All Users
              </TabsTrigger>
              <TabsTrigger value="admins">
                <ShieldAlert className="h-4 w-4 mr-2" />
                Admins
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all">
              {renderUsersTable(users, isLoading, updateUserRole, handleShowUserDetails)}
            </TabsContent>

            <TabsContent value="admins">
              {renderUsersTable(users, isLoading, updateUserRole, handleShowUserDetails)}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* User Detail Dialog */}
      <Dialog open={showUserDetail} onOpenChange={setShowUserDetail}>
        <DialogContent className="max-w-4xl p-0 overflow-hidden">
          {selectedUserId && (
            <UserDetail
              userId={selectedUserId}
              onClose={handleCloseUserDetails}
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// Helper function to render the users table
function renderUsersTable(
  users: User[],
  isLoading: boolean,
  updateUserRole: (userId: number, role: string) => Promise<void>,
  showUserDetails: (userId: number) => void
) {
  if (isLoading) {
    return (
      <div className="py-8 flex justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <Table>
      <TableCaption>{users.length} users found</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead>ID</TableHead>
          <TableHead>Username</TableHead>
          <TableHead>Email</TableHead>
          <TableHead>Display Name</TableHead>
          <TableHead>Role</TableHead>
          <TableHead>Joined</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {users.length === 0 ? (
          <TableRow>
            <TableCell colSpan={7} className="text-center py-8">
              No users found
            </TableCell>
          </TableRow>
        ) : (
          users.map((user) => (
            <TableRow key={user.id} className="cursor-pointer hover:bg-muted/50" onClick={() => showUserDetails(user.id)}>
              <TableCell>{user.id}</TableCell>
              <TableCell className="font-medium">{user.username}</TableCell>
              <TableCell>{user.email}</TableCell>
              <TableCell>{user.displayName || user.username}</TableCell>
              <TableCell>
                <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                  {user.role}
                </Badge>
              </TableCell>
              <TableCell>{new Date(user.createdAt).toLocaleDateString()}</TableCell>
              <TableCell className="text-right">
                <div className="flex justify-end gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation(); // Prevent row click
                      showUserDetails(user.id);
                    }}
                  >
                    <UserIcon className="h-4 w-4 mr-2" />
                    Details
                  </Button>

                  {user.role === 'admin' ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent row click
                        updateUserRole(user.id, 'user');
                      }}
                    >
                      <UserX className="h-4 w-4 mr-2" />
                      Remove Admin
                    </Button>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent row click
                        updateUserRole(user.id, 'admin');
                      }}
                    >
                      <Shield className="h-4 w-4 mr-2" />
                      Make Admin
                    </Button>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );
}