import React, { useState, useEffect } from 'react';
import {  Card, CardContent, CardDescription, CardHeader, CardTitle  } from '@/components/ui/card';
import {  Button  } from '@/components/ui/button';
import {  Input  } from '@/components/ui/input';
import {  Label  } from '@/components/ui/label';
import {  Textarea  } from '@/components/ui/textarea';
import {  Tabs, TabsContent, TabsList, TabsTrigger  } from '@/components/ui/tabs';
import {  Calendar  } from '@/components/ui/calendar';
import {  Select, SelectContent, SelectItem, SelectTrigger, SelectValue  } from '@/components/ui/select';
import {  Checkbox  } from '@/components/ui/checkbox';
import {  Badge  } from '@/components/ui/badge';
import {  
  Calendar as CalendarIcon, 
  Clock, 
  Trash2, 
  Play, 
  Pause,
  FileVideo,
  Settings
 } from 'lucide-react';
import { format } from 'date-fns';

interface ScheduledContent {
  id: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl: string;
  scheduledDate: Date;
  status: 'scheduled' | 'published' | 'failed';
  category: string;
  tags: string[];
}

interface BulkOperation {
  id: string;
  type: 'upload' | 'update' | 'delete' | 'schedule';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  totalItems: number;
  completedItems: number;
  createdAt: Date;
}

export function ContentSchedulingManager() {
  const [scheduledContent, setScheduledContent] = useState<ScheduledContent[]>([]);
  const [bulkOperations, setBulkOperations] = useState<BulkOperation[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [isLoading, setIsLoading] = useState(false);

  // Form states for scheduling new content
  const [newContent, setNewContent] = useState({
    title: '',
    description: '',
    videoFile: null as File | null,
    thumbnailFile: null as File | null,
    scheduledDate: new Date(),
    scheduledTime: '12:00',
    category: '',
    tags: [] as string[],
    isPremium: false
  });

  useEffect(() => {
    loadScheduledContent();
    loadBulkOperations();
  }, []);

  const loadScheduledContent = async () => {
    try {
      const response = await fetch('/api/admin/scheduled-content');
      if (response.ok) {
        const data = await response.json();
        setScheduledContent(data);
      }
    } catch {
      // Handle error silently
    }
  };

  const loadBulkOperations = async () => {
    try {
      const response = await fetch('/api/admin/bulk-operations');
      if (response.ok) {
        const data = await response.json();
        setBulkOperations(data);
      }
    } catch {
      // Handle error silently
    }
  };

  const scheduleContent = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const formData = new FormData();
      formData.append('title', newContent.title);
      formData.append('description', newContent.description);
      formData.append('category', newContent.category);
      formData.append('tags', JSON.stringify(newContent.tags));
      formData.append('isPremium', String(newContent.isPremium));
      
      // Combine date and time
      const scheduledDateTime = new Date(newContent.scheduledDate);
      const [hours, minutes] = newContent.scheduledTime.split(':');
      scheduledDateTime.setHours(parseInt(hours), parseInt(minutes));
      formData.append('scheduledDate', scheduledDateTime.toISOString());

      if (newContent.videoFile) {
        formData.append('video', newContent.videoFile);
      }
      if (newContent.thumbnailFile) {
        formData.append('thumbnail', newContent.thumbnailFile);
      }

      const response = await fetch('/api/admin/schedule-content', {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        // Reset form and reload content
        setNewContent({
          title: '',
          description: '',
          videoFile: null,
          thumbnailFile: null,
          scheduledDate: new Date(),
          scheduledTime: '12:00',
          category: '',
          tags: [],
          isPremium: false
        });
        await loadScheduledContent();
      }
    } catch {
      // Handle error silently
    } finally {
      setIsLoading(false);
    }
  };

  const bulkUpload = async (files: FileList) => {
    const formData = new FormData();
    
    for (let i = 0; i < files.length; i++) {
      formData.append('videos', files[i]);
    }

    try {
      const response = await fetch('/api/admin/bulk-upload', {
        method: 'POST',
        body: formData
      });

      if (response.ok) {
        await loadBulkOperations();
      }
    } catch {
      // Handle error silently
    }
  };

  const deleteScheduledContent = async (id: string) => {
    try {
      const response = await fetch(`/api/admin/scheduled-content/${id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        await loadScheduledContent();
      }
    } catch {
      // Handle error silently
    }
  };

  const bulkUpdateStatus = async (ids: string[], status: string) => {
    try {
      const response = await fetch('/api/admin/bulk-update-status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids, status })
      });

      if (response.ok) {
        await loadScheduledContent();
      }
    } catch {
      // Handle error silently
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Content Scheduling</h1>
          <p className="text-muted-foreground">
            Schedule and manage content releases
          </p>
        </div>
      </div>

      <Tabs defaultValue="schedule" className="space-y-6">
        <TabsList>
          <TabsTrigger value="schedule">Schedule Content</TabsTrigger>
          <TabsTrigger value="bulk">Bulk Operations</TabsTrigger>
          <TabsTrigger value="calendar">Content Calendar</TabsTrigger>
          <TabsTrigger value="operations">Operation History</TabsTrigger>
        </TabsList>

        {/* Schedule Content Tab */}
        <TabsContent value="schedule" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Schedule Form */}
            <Card>
              <CardHeader>
                <CardTitle>Schedule New Content</CardTitle>
                <CardDescription>
                  Upload and schedule content for automatic release
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={scheduleContent} className="space-y-4">
                  <div>
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      value={newContent.title}
                      onChange={(e) => setNewContent(prev => ({ ...prev, title: e.target.value }))}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={newContent.description}
                      onChange={(e) => setNewContent(prev => ({ ...prev, description: e.target.value }))}
                      rows={3}
                    />
                  </div>

                  <div>
                    <Label htmlFor="video">Video File</Label>
                    <Input
                      id="video"
                      type="file"
                      accept="video/*"
                      onChange={(e) => setNewContent(prev => ({ 
                        ...prev, 
                        videoFile: e.target.files?.[0] || null 
                      }))}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="thumbnail">Thumbnail</Label>
                    <Input
                      id="thumbnail"
                      type="file"
                      accept="image/*"
                      onChange={(e) => setNewContent(prev => ({ 
                        ...prev, 
                        thumbnailFile: e.target.files?.[0] || null 
                      }))}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Scheduled Date</Label>
                      <Calendar
                        mode="single"
                        selected={newContent.scheduledDate}
                        onSelect={(date) => date && setNewContent(prev => ({ 
                          ...prev, 
                          scheduledDate: date 
                        }))}
                        disabled={(date) => date < new Date()}
                        className="rounded-md border"
                      />
                    </div>

                    <div>
                      <Label htmlFor="time">Time</Label>
                      <Input
                        id="time"
                        type="time"
                        value={newContent.scheduledTime}
                        onChange={(e) => setNewContent(prev => ({ 
                          ...prev, 
                          scheduledTime: e.target.value 
                        }))}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select value={newContent.category} onValueChange={(value) => 
                      setNewContent(prev => ({ ...prev, category: value }))
                    }>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="movies">Movies</SelectItem>
                        <SelectItem value="series">TV Series</SelectItem>
                        <SelectItem value="documentaries">Documentaries</SelectItem>
                        <SelectItem value="comedy">Comedy</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="premium"
                      checked={newContent.isPremium}
                      onCheckedChange={(checked) => 
                        setNewContent(prev => ({ ...prev, isPremium: checked as boolean }))
                      }
                    />
                    <Label htmlFor="premium">Premium Content</Label>
                  </div>

                  <Button type="submit" className="w-full" disabled={isLoading}>
                    {isLoading ? 'Scheduling...' : 'Schedule Content'}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Scheduled Content List */}
            <Card>
              <CardHeader>
                <CardTitle>Scheduled Content</CardTitle>
                <CardDescription>
                  Content scheduled for future release
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {scheduledContent.map((content) => (
                    <div key={content.id} className="flex items-center justify-between p-4 border rounded">
                      <div className="flex items-center gap-3">
                        <FileVideo className="h-8 w-8 text-muted-foreground" />
                        <div>
                          <h4 className="font-medium">{content.title}</h4>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <CalendarIcon className="h-4 w-4" />
                            {format(content.scheduledDate, 'MMM dd, yyyy')}
                            <Clock className="h-4 w-4 ml-2" />
                            {format(content.scheduledDate, 'HH:mm')}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge variant={
                          content.status === 'scheduled' ? 'default' :
                          content.status === 'published' ? 'secondary' : 'destructive'
                        }>
                          {content.status}
                        </Badge>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteScheduledContent(content.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Bulk Operations Tab */}
        <TabsContent value="bulk" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Bulk Upload</CardTitle>
                <CardDescription>
                  Upload multiple videos at once
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="bulk-upload">Select Videos</Label>
                  <Input
                    id="bulk-upload"
                    type="file"
                    accept="video/*"
                    multiple
                    onChange={(e) => {
                      if (e.target.files && e.target.files.length > 0) {
                        bulkUpload(e.target.files);
                      }
                    }}
                  />
                </div>
                
                <div className="text-sm text-muted-foreground">
                  Select multiple video files to upload. Each file will be processed and added to your content library.
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Bulk Actions</CardTitle>
                <CardDescription>
                  Perform actions on multiple items
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => bulkUpdateStatus([], 'published')}
                >
                  <Play className="h-4 w-4 mr-2" />
                  Publish Selected
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => bulkUpdateStatus([], 'draft')}
                >
                  <Pause className="h-4 w-4 mr-2" />
                  Unpublish Selected
                </Button>
                
                <Button
                  variant="outline"
                  className="w-full text-red-600"
                  onClick={() => bulkUpdateStatus([], 'deleted')}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Selected
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Content Calendar Tab */}
        <TabsContent value="calendar" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Content Calendar</CardTitle>
              <CardDescription>
                View scheduled content in calendar format
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-center">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={(date) => date && setSelectedDate(date)}
                  className="rounded-md border"
                />
              </div>
              
              <div className="mt-6">
                <h3 className="font-semibold mb-4">
                  Content for {format(selectedDate, 'MMMM dd, yyyy')}
                </h3>
                <div className="space-y-2">
                  {scheduledContent
                    .filter(content => 
                      format(content.scheduledDate, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd')
                    )
                    .map(content => (
                      <div key={content.id} className="flex items-center justify-between p-3 bg-muted rounded">
                        <div>
                          <h4 className="font-medium">{content.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {format(content.scheduledDate, 'HH:mm')}
                          </p>
                        </div>
                        <Badge variant="outline">{content.status}</Badge>
                      </div>
                    ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Operation History Tab */}
        <TabsContent value="operations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Operation History</CardTitle>
              <CardDescription>
                Track bulk operations and their progress
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {bulkOperations.map((operation) => (
                  <div key={operation.id} className="flex items-center justify-between p-4 border rounded">
                    <div className="flex items-center gap-3">
                      <Settings className="h-8 w-8 text-muted-foreground" />
                      <div>
                        <h4 className="font-medium capitalize">{operation.type} Operation</h4>
                        <div className="text-sm text-muted-foreground">
                          {operation.completedItems} of {operation.totalItems} items
                          • {format(operation.createdAt, 'MMM dd, yyyy HH:mm')}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <div className="w-32 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-blue-600 h-2 rounded-full" 
                          style={{ width: `${operation.progress}%` }}
                        ></div>
                      </div>
                      <Badge variant={
                        operation.status === 'completed' ? 'secondary' :
                        operation.status === 'failed' ? 'destructive' :
                        operation.status === 'processing' ? 'default' : 'secondary'
                      }>
                        {operation.status}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
