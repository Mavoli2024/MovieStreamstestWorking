import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { UniversalDataTable, type ColumnDef } from './universal-data-table';
import { UniversalCrudModal, type FieldDef } from './universal-crud-modal';
import { useAdminVideos } from '@/hooks/use-admin-videos';
import { Video } from 'lucide-react';
import type { Database } from '@/types/database-generated.types';

type VideoType = Database['public']['Tables']['videos']['Row'];

export function AdminVideosTab() {
  const {
    videos,
    videosLoading,
    createVideo,
    updateVideo,
    deleteVideo,
    isCreating,
    isUpdating,
    // isDeleting, // Unused, commented out
  } = useAdminVideos();

  const [showVideoModal, setShowVideoModal] = useState(false);
  const [editingVideo, setEditingVideo] = useState<VideoType | null>(null);

  const videoColumns: ColumnDef<VideoType>[] = [
    { id: 'title', header: 'Title', accessorKey: 'title', sortable: true, filterable: true },
    { id: 'genres', header: 'Genres', accessorKey: 'genres', sortable: true, filterable: true },
    { id: 'status', header: 'Status', accessorKey: 'status', sortable: true },
    { id: 'is_premium', header: 'Premium', accessorKey: 'is_premium', editable: true, editType: 'boolean' },
    { id: 'created_at', header: 'Created', accessorKey: 'created_at', sortable: true },
  ];

  const videoFields: FieldDef[] = [
    { name: 'title', label: 'Title', type: 'text', required: true },
    { name: 'description', label: 'Description', type: 'textarea' },
    { name: 'genre', label: 'Genre', type: 'text' },
    { name: 'bunny_video_id', label: 'Bunny Video ID', type: 'text' },
    { name: 'thumbnail_url', label: 'Thumbnail URL', type: 'text' },
    { name: 'is_premium', label: 'Premium Content', type: 'boolean' },
    { name: 'is_visible', label: 'Visible', type: 'boolean' },
  ];

  const handleVideoSubmit = async (data: Record<string, unknown>) => {
    if (editingVideo) {
      updateVideo({ id: editingVideo.id, data });
    } else {
      createVideo(data);
    }
    setShowVideoModal(false);
    setEditingVideo(null);
  };

  const handleInlineEdit = async (item: VideoType, field: string, value: unknown) => {
    updateVideo({ id: item.id, data: { [field]: value } });
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            <Video className="h-5 w-5" />
            Videos Management
          </CardTitle>
          <CardDescription>
            Manage video content, metadata, and visibility
          </CardDescription>
        </div>
        <Button onClick={() => setShowVideoModal(true)}>
          Add Video
        </Button>
      </CardHeader>
      <CardContent>
        <UniversalDataTable
          data={videos}
          columns={videoColumns}
          isLoading={videosLoading}
          onEdit={(item) => {
            setEditingVideo(item);
            setShowVideoModal(true);
          }}
          onDelete={(item) => deleteVideo(item.id)}
          onInlineEdit={handleInlineEdit}
        />

        <UniversalCrudModal
          isOpen={showVideoModal}
          onClose={() => {
            setShowVideoModal(false);
            setEditingVideo(null);
          }}
          title={editingVideo ? 'Edit Video' : 'Add Video'}
          fields={videoFields}
          initialData={editingVideo}
          onSubmit={handleVideoSubmit}
          isLoading={isCreating || isUpdating}
        />
      </CardContent>
    </Card>
  );
} 