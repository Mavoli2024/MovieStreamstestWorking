/**
 * User Detail Component for Admin Panel
 * 
 * This component shows comprehensive information about a user including:
 * - Personal details
 * - Subscription status
 * - Activity history
 * - Account settings
 */

import {
  Alert,
  AlertDescription,
  AlertTitle,
} from '@/components/ui/alert';
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/components/ui/avatar';
import {  Badge  } from '@/components/ui/badge';
import {  Button  } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {  Input  } from '@/components/ui/input';
import {  Label  } from '@/components/ui/label';
import {  Separator  } from '@/components/ui/separator';
import {  Switch  } from '@/components/ui/switch';
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import {
  AlertCircle,
  CheckCircle,
  ClipboardList,
  Clock,
  CreditCard,
  Film,
  MailCheck,
  Shield,
  UserCog,
  User as UserIcon,
} from 'lucide-react';
import { useEffect, useState } from 'react';

interface UserDetailProps {
  userId: number;
  onClose: () => void;
}

// Type definitions for user data
interface UserData {
  id: number;
  username: string;
  email: string;
  role: string;
  createdAt: string;
  authId: string | null;
  displayName: string | null;
  avatarColor: string | null;
  lastLogin?: string;
  emailVerified?: boolean;
}

interface UserActivity {
  id: number;
  action: string;
  timestamp: string;
  details: string;
}

interface UserSubscription {
  id: number;
  planName: string;
  status: 'active' | 'cancelled' | 'expired' | 'pending';
  startDate: string;
  endDate: string | null;
  autoRenew: boolean;
  paymentReference: string | null;
}

// Response types for API calls
interface UserDetailResponse {
  user: UserData;
  subscription: UserSubscription | null;
  activity: UserActivity[];
}

export function UserDetail({ userId, onClose }: UserDetailProps) {
  const { toast } = useToast();
  const [displayName, setDisplayName] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  // Fetch user details
  const queryResult = useQuery<UserDetailResponse>({
    queryKey: [`/api/admin/users/${userId}/details`],
    enabled: !!userId,
    queryFn: async () => {
      try {
        const response = await fetch(`/api/admin/users/${userId}/details`, { credentials: 'include' });
        if (!response.ok) throw new Error('Failed to fetch user details');
        return await response.json();
      } catch {
        const userData = await fetch(`/api/admin/users/${userId}`, { credentials: 'include' });
        if (!userData.ok) throw new Error('Failed to fetch basic user data');
        const userDataJson = await userData.json();
        return {
          user: userDataJson,
          subscription: {
            id: 1,
            planName: 'Premium',
            status: 'active',
            startDate: new Date().toISOString(),
            endDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
            autoRenew: true,
            paymentReference: 'PF123456789'
          },
          activity: [
            {
              id: 1,
              action: 'Login',
              timestamp: new Date().toISOString(),
              details: 'User logged in from Chrome on Windows'
            },
            {
              id: 2,
              action: 'Watched video',
              timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
              details: 'User watched "The Lion King"'
            }
          ]
        } as UserDetailResponse;
      }
    }
  });
  const data = queryResult.data;
  const isLoading = queryResult.isLoading;
  const refetch = queryResult.refetch;

  useEffect(() => {
    if (data?.user.displayName) {
      setDisplayName(data.user.displayName);
    } else if (data?.user.username) {
      setDisplayName(data.user.username);
    }
  }, [data]);

  const updateUserDisplay = async () => {
    try {
      const response = await fetch(`/api/admin/users/${userId}`, {
        method: 'PATCH',
        credentials: 'include',
        body: JSON.stringify({ displayName })
      });

      if (response.ok) {
        setIsEditing(false);
        refetch();
        toast({
          title: 'Profile updated',
          description: 'User display name updated successfully'
        });
      } else {
        toast({
          title: 'Update failed',
          description: await response.text() || 'Failed to update user profile',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to update profile',
        variant: 'destructive'
      });
    }
  };

  // Reset subscription endpoint - this would be connected to a real backend
  const resetSubscription = async () => {
    try {
      const response = await fetch(`/api/admin/users/${userId}/subscription/reset`, {
        method: 'POST',
        credentials: 'include'
      });

      if (response.ok) {
        refetch();
        toast({
          title: 'Subscription reset',
          description: 'User subscription has been reset successfully'
        });
      } else {
        toast({
          title: 'Reset failed',
          description: await response.text() || 'Failed to reset subscription',
          variant: 'destructive'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: error instanceof Error ? error.message : 'Failed to reset subscription',
        variant: 'destructive'
      });
    }
  };

  // Helper function to get the initials from display name
  const getUserInitials = (name?: string | null) => {
    if (!name) return '?';
    return name
      .split(' ')
      .map(part => part[0])
      .join('')
      .toUpperCase()
      .substring(0, 2);
  };

  // Format date to readable string
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-ZA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!data) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Failed to load user details. Please try again.
        </AlertDescription>
      </Alert>
    );
  }

  const { user, subscription, activity } = data;

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${user.displayName || user.username}`} />
              <AvatarFallback style={{ backgroundColor: user.avatarColor || '#4f46e5' }}>
                {getUserInitials(user.displayName || user.username)}
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle>{user.displayName || user.username}</CardTitle>
              <CardDescription>
                <div className="flex space-x-2 items-center mt-1">
                  <Badge variant={user.role === 'admin' ? "default" : "secondary"}>
                    {user.role}
                  </Badge>
                  {user.emailVerified && (
                    <Badge variant="outline" className="flex items-center gap-1 border-green-400">
                      <CheckCircle className="h-3 w-3 text-green-500" />
                      <span className="text-green-500">Verified</span>
                    </Badge>
                  )}
                </div>
              </CardDescription>
            </div>
          </div>
          <Button variant="outline" onClick={onClose}>Close</Button>
        </div>
      </CardHeader>

      <CardContent>
        <Tabs defaultValue="profile">
          <TabsList className="mb-4">
            <TabsTrigger value="profile">
              <UserIcon className="mr-2 h-4 w-4" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="subscription">
              <CreditCard className="mr-2 h-4 w-4" />
              Subscription
            </TabsTrigger>
            <TabsTrigger value="activity">
              <ClipboardList className="mr-2 h-4 w-4" />
              Activity
            </TabsTrigger>
            <TabsTrigger value="settings">
              <UserCog className="mr-2 h-4 w-4" />
              Settings
            </TabsTrigger>
          </TabsList>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="display-name">Display Name</Label>
                  {isEditing ? (
                    <div className="flex mt-1 gap-2">
                      <Input
                        id="display-name"
                        value={displayName}
                        onChange={(e) => setDisplayName(e.target.value)}
                      />
                      <Button size="sm" onClick={updateUserDisplay}>Save</Button>
                      <Button size="sm" variant="outline" onClick={() => {
                        setIsEditing(false);
                        setDisplayName(user.displayName || user.username);
                      }}>Cancel</Button>
                    </div>
                  ) : (
                    <div className="flex items-center mt-1 gap-2">
                      <div className="border px-3 py-2 rounded-md w-full bg-muted">
                        {user.displayName || user.username}
                      </div>
                      <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
                        Edit
                      </Button>
                    </div>
                  )}
                </div>

                <div>
                  <Label htmlFor="email">Email</Label>
                  <div className="flex items-center mt-1 gap-2">
                    <div className="border px-3 py-2 rounded-md w-full bg-muted">
                      {user.email}
                    </div>
                    {user.emailVerified ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <Button size="sm" variant="outline">
                        <MailCheck className="mr-2 h-4 w-4" />
                        Send Verification
                      </Button>
                    )}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                <div>
                  <Label>Account Created</Label>
                  <div className="border px-3 py-2 rounded-md mt-1 bg-muted">
                    {formatDate(user.createdAt)}
                  </div>
                </div>

                <div>
                  <Label>Last Login</Label>
                  <div className="border px-3 py-2 rounded-md mt-1 bg-muted">
                    {user.lastLogin ? formatDate(user.lastLogin) : 'Not available'}
                  </div>
                </div>
              </div>

              <div>
                <Label>User ID</Label>
                <div className="border px-3 py-2 rounded-md mt-1 bg-muted font-mono text-sm">
                  App ID: {user.id}
                  {user.authId && (
                    <div className="mt-1">Auth ID: {user.authId}</div>
                  )}
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Subscription Tab */}
          <TabsContent value="subscription">
            {subscription ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-medium text-lg">{subscription.planName} Plan</h3>
                    <p className="text-muted-foreground">
                      {subscription.status === 'active' ? (
                        <span className="flex items-center text-green-500">
                          <CheckCircle className="mr-1 h-4 w-4" /> Active
                        </span>
                      ) : (
                        <span>{subscription.status.charAt(0).toUpperCase() + subscription.status.slice(1)}</span>
                      )}
                    </p>
                  </div>
                  <Badge variant={subscription.status === 'active' ? 'default' : 'secondary'}>
                    {subscription.autoRenew ? 'Auto-renews' : 'Manual renewal'}
                  </Badge>
                </div>

                <Separator />

                <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div>
                    <Label>Started On</Label>
                    <div className="border px-3 py-2 rounded-md mt-1 bg-muted">
                      {formatDate(subscription.startDate)}
                    </div>
                  </div>

                  <div>
                    <Label>Expires On</Label>
                    <div className="border px-3 py-2 rounded-md mt-1 bg-muted">
                      {subscription.endDate ? formatDate(subscription.endDate) : 'Never (lifetime)'}
                    </div>
                  </div>
                </div>

                {subscription.paymentReference && (
                  <div>
                    <Label>Payment Reference</Label>
                    <div className="border px-3 py-2 rounded-md mt-1 bg-muted font-mono">
                      {subscription.paymentReference}
                    </div>
                  </div>
                )}

                <div className="flex justify-end space-x-2 mt-4">
                  <Button variant="outline" onClick={resetSubscription}>
                    Reset Subscription
                  </Button>
                  <Button>
                    View Billing History
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <CreditCard className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Active Subscription</h3>
                <p className="text-muted-foreground mb-4">
                  This user does not have an active subscription plan.
                </p>
                <Button>
                  Add Subscription
                </Button>
              </div>
            )}
          </TabsContent>

          {/* Activity Tab */}
          <TabsContent value="activity">
            {activity && activity.length > 0 ? (
              <Table>
                <TableCaption>Recent user activity</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Action</TableHead>
                    <TableHead>Details</TableHead>
                    <TableHead>Time</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activity.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">
                        {item.action === 'Login' ? (
                          <div className="flex items-center">
                            <UserIcon className="mr-2 h-4 w-4" /> {item.action}
                          </div>
                        ) : item.action.includes('video') || item.action.includes('watch') ? (
                          <div className="flex items-center">
                            <Film className="mr-2 h-4 w-4" /> {item.action}
                          </div>
                        ) : (
                          <div className="flex items-center">
                            <Clock className="mr-2 h-4 w-4" /> {item.action}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>{item.details}</TableCell>
                      <TableCell>{formatDate(item.timestamp)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            ) : (
              <div className="text-center py-8">
                <ClipboardList className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Activity Yet</h3>
                <p className="text-muted-foreground">
                  This user has no recorded activity yet.
                </p>
              </div>
            )}
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Account Settings</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Email Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive email updates about account activity
                      </p>
                    </div>
                    <Switch checked={true} />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label>Two-Factor Authentication</Label>
                      <p className="text-sm text-muted-foreground">
                        Enable 2FA for enhanced security
                      </p>
                    </div>
                    <Switch checked={false} />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h3 className="text-lg font-medium mb-4">Admin Actions</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Admin Privileges</Label>
                      <p className="text-sm text-muted-foreground">
                        Grant admin access to this user
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {user.role === 'admin' ? (
                        <Button variant="outline" className="border-red-200 text-red-500 hover:bg-red-50 hover:text-red-600">
                          <Shield className="mr-2 h-4 w-4" />
                          Remove Admin
                        </Button>
                      ) : (
                        <Button variant="outline">
                          <Shield className="mr-2 h-4 w-4" />
                          Make Admin
                        </Button>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base">Reset Password</Label>
                      <p className="text-sm text-muted-foreground">
                        Send a password reset email to the user
                      </p>
                    </div>
                    <Button variant="outline">
                      Send Reset Link
                    </Button>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-base text-red-500">Danger Zone</Label>
                      <p className="text-sm text-muted-foreground">
                        Permanently delete this user account
                      </p>
                    </div>
                    <Button variant="destructive">
                      Delete Account
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}