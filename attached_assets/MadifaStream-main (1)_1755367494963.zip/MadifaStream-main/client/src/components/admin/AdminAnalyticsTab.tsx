import React from 'react';
import {  Card, CardContent, CardDescription, CardHeader, CardTitle  } from '@/components/ui/card';
import {  BarChart3, Users, Video, Eye, Clock  } from 'lucide-react';
import {  Badge  } from '@/components/ui/badge';

export function AdminAnalyticsTab() {
  // Mock data for now - in real implementation, this would come from the database
  const analytics = {
    totalUsers: 1234,
    totalVideos: 567,
    totalViews: 98765,
    totalWatchTime: 45678, // in minutes
    activeSubscriptions: 456,
    revenue: 12345.67
  };

  const StatCard = ({ title, value, icon: Icon, description, badge }: {
    title: string;
    value: string | number;
    icon: React.ComponentType<{ className?: string }>;
    description?: string;
    badge?: string;
  }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        <Icon className="h-4 w-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground">{description}</p>
        )}
        {badge && (
          <Badge variant="secondary" className="mt-2">
            {badge}
          </Badge>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <BarChart3 className="h-6 w-6" />
          Analytics Dashboard
        </h2>
        <p className="text-muted-foreground">
          Overview of platform metrics and performance
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <StatCard
          title="Total Users"
          value={analytics.totalUsers.toLocaleString()}
          icon={Users}
          description="Registered platform users"
          badge="Active"
        />
        <StatCard
          title="Total Videos"
          value={analytics.totalVideos.toLocaleString()}
          icon={Video}
          description="Videos in library"
        />
        <StatCard
          title="Total Views"
          value={analytics.totalViews.toLocaleString()}
          icon={Eye}
          description="All-time video views"
          badge="+12% from last month"
        />
        <StatCard
          title="Watch Time"
          value={`${Math.round(analytics.totalWatchTime / 60).toLocaleString()}h`}
          icon={Clock}
          description="Total hours watched"
        />
        <StatCard
          title="Active Subscriptions"
          value={analytics.activeSubscriptions.toLocaleString()}
          icon={Users}
          description="Current paid subscribers"
          badge="Premium"
        />
        <StatCard
          title="Revenue"
          value={`R${analytics.revenue.toLocaleString()}`}
          icon={BarChart3}
          description="Total platform revenue"
          badge="This month"
        />
      </div>

      {/* Placeholder for future charts */}
      <Card>
        <CardHeader>
          <CardTitle>Analytics Charts</CardTitle>
          <CardDescription>
            Detailed charts and graphs will be implemented here
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <BarChart3 className="h-12 w-12 mx-auto mb-2" />
              <p>Charts and detailed analytics coming soon</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
} 