/**
 * Universal Data Table Component
 * 
 * A sophisticated, reusable table component for admin CRUD operations
 * Features:
 * - Sorting, filtering, and search
 * - Inline editing
 * - Bulk actions
 * - Create/Edit modals
 * - Pagination
 * - Export functionality
 * - Column visibility toggle
 */

/* eslint-disable @typescript-eslint/no-explicit-any */
// TODO: Refine generic types and remove this override.
// import { Badge } from '@/components/ui/badge'; // Unused, commented out
import {  Button  } from '@/components/ui/button';
import {  Checkbox  } from '@/components/ui/checkbox';
// import {
//   Dialog, // Unused, commented out
//   DialogContent, // Unused, commented out
//   DialogDescription, // Unused, commented out
//   DialogFooter, // Unused, commented out
//   DialogHeader, // Unused, commented out
//   DialogTitle, // Unused, commented out
// } from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {  Input  } from '@/components/ui/input';
// import { Label } from '@/components/ui/label'; // Unused, commented out
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {  Textarea  } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import {
  ArrowUpDown,
  // ChevronDown, // Unused, commented out
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  Download,
  Edit2,
  // Eye, // Unused, commented out
  MoreHorizontal,
  Plus,
  RefreshCw,
  Search,
  Settings2,
  Trash2,
  X,
} from 'lucide-react';
import React, { useState, useMemo } from 'react';

// Column definition interface
export interface ColumnDef<T> {
  id: string;
  header: string;
  accessorKey?: keyof T;
  cell?: (item: T) => React.ReactNode;
  sortable?: boolean;
  filterable?: boolean;
  editable?: boolean;
  editType?: 'text' | 'number' | 'select' | 'textarea' | 'date' | 'boolean';
  editOptions?: { value: string; label: string }[];
  hidden?: boolean;
  width?: string;
}

// Table props interface
export interface UniversalDataTableProps<T extends { id?: string | number }> {
  data: T[];
  columns: ColumnDef<T>[];
  onAdd?: () => void;
  onEdit?: (item: T) => void;
  onDelete?: (item: T) => void;
  onBulkDelete?: (items: T[]) => void;
  onRefresh?: () => void;
  onExport?: () => void;
  isLoading?: boolean;
  tableTitle?: string;
  tableDescription?: string;
  searchPlaceholder?: string;
  addButtonLabel?: string;
  emptyMessage?: string;
  pageSize?: number;
  enableSearch?: boolean;
  enableFilter?: boolean;
  enableSort?: boolean;
  enablePagination?: boolean;
  enableSelection?: boolean;
  enableColumnToggle?: boolean;
  enableExport?: boolean;
  enableInlineEdit?: boolean;
  onInlineEdit?: (item: T, field: keyof T, value: unknown) => void;
  customActions?: (item: T) => React.ReactNode;
  getRowId?: (item: T) => string;
}

export function UniversalDataTable<T extends { id?: string | number }>({
  data,
  columns,
  onAdd,
  onEdit,
  onDelete,
  onBulkDelete,
  onRefresh,
  onExport,
  isLoading = false,
  tableTitle,
  tableDescription,
  searchPlaceholder = "Search...",
  addButtonLabel = "Add New",
  emptyMessage = "No data found.",
  pageSize = 10,
  enableSearch = true,
  enableFilter = true,
  enableSort = true,
  enablePagination = true,
  enableSelection = true,
  enableColumnToggle = true,
  enableExport = true,
  enableInlineEdit = false,
  onInlineEdit,
  customActions,
  getRowId = (item) => item.id?.toString() || '',
}: UniversalDataTableProps<T>) {
  const { toast } = useToast();
  
  // State management
  const [searchQuery, setSearchQuery] = useState('');
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRows, setSelectedRows] = useState<Set<string>>(new Set());
  const [visibleColumns, setVisibleColumns] = useState<Set<string>>(
    new Set(columns.filter(col => !col.hidden).map(col => col.id))
  );
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [editingCell, setEditingCell] = useState<{ rowId: string; columnId: string } | null>(null);
  const [editValue, setEditValue] = useState<any>('');

  // Filter data based on search and filters
  const filteredData = useMemo(() => {
    let filtered = [...data];

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(item =>
        columns.some(col => {
          const value = col.accessorKey ? item[col.accessorKey] : '';
          return String(value).toLowerCase().includes(searchQuery.toLowerCase());
        })
      );
    }

    // Apply column filters
    Object.entries(filters).forEach(([columnId, filterValue]) => {
      if (filterValue) {
        filtered = filtered.filter(item => {
          const column = columns.find(col => col.id === columnId);
          if (!column || !column.accessorKey) return true;
          const value = item[column.accessorKey];
          return String(value).toLowerCase().includes(filterValue.toLowerCase());
        });
      }
    });

    return filtered;
  }, [data, searchQuery, filters, columns]);

  // Sort data
  const sortedData = useMemo(() => {
    if (!sortColumn) return filteredData;

    const column = columns.find(col => col.id === sortColumn);
    if (!column || !column.accessorKey) return filteredData;

    return [...filteredData].sort((a, b) => {
      const aValue = a[column.accessorKey!];
      const bValue = b[column.accessorKey!];

      if (aValue === bValue) return 0;
      
      const comparison = aValue < bValue ? -1 : 1;
      return sortDirection === 'asc' ? comparison : -comparison;
    });
  }, [filteredData, sortColumn, sortDirection, columns]);

  // Paginate data
  const paginatedData = useMemo(() => {
    if (!enablePagination) return sortedData;
    
    const startIndex = (currentPage - 1) * pageSize;
    return sortedData.slice(startIndex, startIndex + pageSize);
  }, [sortedData, currentPage, pageSize, enablePagination]);

  const totalPages = Math.ceil(sortedData.length / pageSize);

  // Handlers
  const handleSort = (columnId: string) => {
    if (!enableSort) return;
    
    if (sortColumn === columnId) {
      setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(columnId);
      setSortDirection('asc');
    }
  };

  const handleSelectAll = () => {
    if (selectedRows.size === paginatedData.length) {
      setSelectedRows(new Set());
    } else {
      setSelectedRows(new Set(paginatedData.map(item => getRowId(item))));
    }
  };

  const handleSelectRow = (rowId: string) => {
    const newSelected = new Set(selectedRows);
    if (newSelected.has(rowId)) {
      newSelected.delete(rowId);
    } else {
      newSelected.add(rowId);
    }
    setSelectedRows(newSelected);
  };

  const handleBulkDelete = () => {
    if (onBulkDelete && selectedRows.size > 0) {
      const itemsToDelete = data.filter(item => selectedRows.has(getRowId(item)));
      onBulkDelete(itemsToDelete);
      setSelectedRows(new Set());
    }
  };

  const handleInlineEdit = (rowId: string, columnId: string) => {
    if (!enableInlineEdit || !onInlineEdit) return;
    
    const item = data.find(d => getRowId(d) === rowId);
    const column = columns.find(col => col.id === columnId);
    
    if (item && column && column.editable && column.accessorKey) {
      setEditingCell({ rowId, columnId });
      setEditValue(item[column.accessorKey]);
    }
  };

  const saveInlineEdit = () => {
    if (!editingCell || !onInlineEdit) return;
    
    const item = data.find(d => getRowId(d) === editingCell.rowId);
    const column = columns.find(col => col.id === editingCell.columnId);
    
    if (item && column && column.accessorKey) {
      onInlineEdit(item, column.accessorKey, editValue);
      setEditingCell(null);
      setEditValue('');
    }
  };

  const cancelInlineEdit = () => {
    setEditingCell(null);
    setEditValue('');
  };

  // Export data to CSV
  const exportToCSV = () => {
    if (!onExport) {
      // Default export implementation
      const headers = columns
        .filter(col => visibleColumns.has(col.id))
        .map(col => col.header)
        .join(',');
      
      const rows = sortedData.map(item =>
        columns
          .filter(col => visibleColumns.has(col.id))
          .map(col => {
            const value = col.accessorKey ? item[col.accessorKey] : '';
            return `"${String(value).replace(/"/g, '""')}"`;
          })
          .join(',')
      );
      
      const csv = [headers, ...rows].join('\n');
      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${tableTitle || 'data'}-${new Date().toISOString()}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast({
        title: "Export successful",
        description: `Exported ${sortedData.length} records to CSV`,
      });
    } else {
      onExport();
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          {tableTitle && <h2 className="text-2xl font-bold">{tableTitle}</h2>}
          {tableDescription && <p className="text-muted-foreground">{tableDescription}</p>}
        </div>
        
        <div className="flex items-center gap-2">
          {onRefresh && (
            <Button
              variant="outline"
              size="sm"
              onClick={onRefresh}
              disabled={isLoading}
            >
              <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
            </Button>
          )}
          
          {enableExport && (
            <Button
              variant="outline"
              size="sm"
              onClick={exportToCSV}
            >
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          )}
          
          {onAdd && (
            <Button onClick={onAdd} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              {addButtonLabel}
            </Button>
          )}
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex flex-1 items-center gap-2">
          {enableSearch && (
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={searchPlaceholder}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8"
              />
            </div>
          )}
          
          {enableSelection && selectedRows.size > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">
                {selectedRows.size} selected
              </span>
              {onBulkDelete && (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleBulkDelete}
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </Button>
              )}
            </div>
          )}
        </div>
        
        {enableColumnToggle && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm">
                <Settings2 className="h-4 w-4 mr-2" />
                Columns
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel>Toggle columns</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {columns.map(column => (
                <DropdownMenuCheckboxItem
                  key={column.id}
                  checked={visibleColumns.has(column.id)}
                  onCheckedChange={(checked) => {
                    const newVisible = new Set(visibleColumns);
                    if (checked) {
                      newVisible.add(column.id);
                    } else {
                      newVisible.delete(column.id);
                    }
                    setVisibleColumns(newVisible);
                  }}
                >
                  {column.header}
                </DropdownMenuCheckboxItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </div>

      {/* Table */}
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {enableSelection && (
                <TableHead className="w-12">
                  <Checkbox
                    checked={selectedRows.size === paginatedData.length && paginatedData.length > 0}
                    onCheckedChange={handleSelectAll}
                  />
                </TableHead>
              )}
              
              {columns
                .filter(col => visibleColumns.has(col.id))
                .map(column => (
                  <TableHead
                    key={column.id}
                    className={cn(
                      column.sortable && enableSort && "cursor-pointer select-none",
                      column.width
                    )}
                    onClick={() => column.sortable && handleSort(column.id)}
                  >
                    <div className="flex items-center gap-2">
                      {column.header}
                      {column.sortable && enableSort && (
                        <ArrowUpDown className="h-4 w-4" />
                      )}
                    </div>
                    
                    {column.filterable && enableFilter && (
                      <Input
                        placeholder="Filter..."
                        value={filters[column.id] || ''}
                        onChange={(e) => setFilters(prev => ({
                          ...prev,
                          [column.id]: e.target.value
                        }))}
                        onClick={(e) => e.stopPropagation()}
                        className="mt-1 h-7 text-xs"
                      />
                    )}
                  </TableHead>
                ))}
              
              <TableHead className="w-20">Actions</TableHead>
            </TableRow>
          </TableHeader>
          
          <TableBody>
            {paginatedData.length === 0 ? (
              <TableRow>
                <TableCell
                  colSpan={columns.filter(col => visibleColumns.has(col.id)).length + (enableSelection ? 2 : 1)}
                  className="h-24 text-center"
                >
                  {emptyMessage}
                </TableCell>
              </TableRow>
            ) : (
              paginatedData.map(item => {
                const rowId = getRowId(item);
                return (
                  <TableRow key={rowId}>
                    {enableSelection && (
                      <TableCell>
                        <Checkbox
                          checked={selectedRows.has(rowId)}
                          onCheckedChange={() => handleSelectRow(rowId)}
                        />
                      </TableCell>
                    )}
                    
                    {columns
                      .filter(col => visibleColumns.has(col.id))
                      .map(column => (
                        <TableCell key={column.id}>
                          {editingCell?.rowId === rowId && editingCell?.columnId === column.id ? (
                            <div className="flex items-center gap-2">
                              {column.editType === 'select' ? (
                                <Select
                                  value={editValue}
                                  onValueChange={setEditValue}
                                >
                                  <SelectTrigger className="h-8">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {column.editOptions?.map(option => (
                                      <SelectItem key={option.value} value={option.value}>
                                        {option.label}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              ) : column.editType === 'textarea' ? (
                                <Textarea
                                  value={editValue}
                                  onChange={(e) => setEditValue(e.target.value)}
                                  className="min-h-[60px]"
                                />
                              ) : (
                                <Input
                                  type={column.editType || 'text'}
                                  value={editValue}
                                  onChange={(e) => setEditValue(e.target.value)}
                                  className="h-8"
                                />
                              )}
                              <Button size="sm" onClick={saveInlineEdit}>
                                Save
                              </Button>
                              <Button size="sm" variant="ghost" onClick={cancelInlineEdit}>
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          ) : (
                            <div
                              className={cn(
                                column.editable && enableInlineEdit && "cursor-pointer hover:bg-muted/50 px-2 py-1 rounded",
                              )}
                              onClick={() => column.editable && handleInlineEdit(rowId, column.id)}
                            >
                              {column.cell ? column.cell(item) : (
                                column.accessorKey ? String(item[column.accessorKey] || '') : ''
                              )}
                            </div>
                          )}
                        </TableCell>
                      ))}
                    
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {onEdit && (
                            <DropdownMenuItem onClick={() => onEdit(item)}>
                              <Edit2 className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                          )}
                          {onDelete && (
                            <DropdownMenuItem
                              onClick={() => onDelete(item)}
                              className="text-destructive"
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          )}
                          {customActions && (
                            <>
                              <DropdownMenuSeparator />
                              {customActions(item)}
                            </>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      {enablePagination && totalPages > 1 && (
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {((currentPage - 1) * pageSize) + 1} to{' '}
            {Math.min(currentPage * pageSize, sortedData.length)} of{' '}
            {sortedData.length} results
          </p>
          
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(1)}
              disabled={currentPage === 1}
            >
              <ChevronsLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            
            <div className="flex items-center gap-1">
              <Input
                type="number"
                value={currentPage}
                onChange={(e) => {
                  const page = parseInt(e.target.value) || 1;
                  setCurrentPage(Math.min(Math.max(1, page), totalPages));
                }}
                className="w-16 h-8 text-center"
              />
              <span className="text-sm text-muted-foreground">
                of {totalPages}
              </span>
            </div>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              disabled={currentPage === totalPages}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(totalPages)}
              disabled={currentPage === totalPages}
            >
              <ChevronsRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}