/**
 * Comprehensive Admin Dashboard
 * 
 * Refactored modular admin dashboard with separate tab components
 * Features:
 * - Videos management
 * - Users management
 * - Subscriptions management
 * - Analytics and reporting
 * - System settings
 */

import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  BarChart3,
  CreditCard,
  Settings,
  Users,
  Video,
} from 'lucide-react';
import React from 'react';
import {  AdminVideosTab  } from './AdminVideosTab';
import {  AdminUsersTab  } from './AdminUsersTab';
import {  AdminSubscriptionsTab  } from './AdminSubscriptionsTab';
import {  AdminAnalyticsTab  } from './AdminAnalyticsTab';

export function AdminDashboard() {
  return (
    <div className="container mx-auto p-6 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Admin Dashboard</h1>
        <p className="text-muted-foreground">
          Manage your streaming platform with comprehensive admin tools
        </p>
      </div>

      <Tabs defaultValue="analytics" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="videos" className="flex items-center gap-2">
            <Video className="h-4 w-4" />
            Videos
          </TabsTrigger>
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Users
          </TabsTrigger>
          <TabsTrigger value="subscriptions" className="flex items-center gap-2">
            <CreditCard className="h-4 w-4" />
            Subscriptions
          </TabsTrigger>
          <TabsTrigger value="settings" className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="analytics" className="space-y-4">
          <AdminAnalyticsTab />
        </TabsContent>

        <TabsContent value="videos" className="space-y-4">
          <AdminVideosTab />
        </TabsContent>

        <TabsContent value="users" className="space-y-4">
          <AdminUsersTab />
        </TabsContent>

        <TabsContent value="subscriptions" className="space-y-4">
          <AdminSubscriptionsTab />
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <div className="text-center py-12">
            <Settings className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Settings</h3>
            <p className="text-muted-foreground">
              System settings and configuration options coming soon
            </p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}