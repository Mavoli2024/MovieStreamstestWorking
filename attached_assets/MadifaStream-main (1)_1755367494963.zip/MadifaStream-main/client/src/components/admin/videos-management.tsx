// filepath: c:\Users\hp\Desktop\MadifaStream\client\src\components\admin\videos-management.tsx
import {  Button  } from "@/components/ui/button";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle
 } from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {  Input  } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {  Textarea  } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { zodResolver } from "@hookform/resolvers/zod";
import type {  Video  } from "@shared/schema"; // Updated to use Video type
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {  Edit, PlusCircle, Trash2  } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import {  VideoSyncButton  } from "./video-sync-button"; // Import the VideoSyncButton component
import {  Select, SelectContent, SelectItem, SelectTrigger, SelectValue  } from "@/components/ui/select";
import {  Badge  } from "@/components/ui/badge";
import {  X  } from "lucide-react";

// Video form schema (updated from videoSchema)
const videoSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  thumbnailUrl: z.string().url("Thumbnail URL must be a valid URL"),
  videoUrl: z.string().url("Video URL must be a valid URL"),
  trailerUrl: z.string().url("Trailer URL must be a valid URL").optional().or(z.literal("")),
  releaseYear: z.coerce.number().int().min(1900).max(new Date().getFullYear() + 5),
  duration: z.coerce.number().int().min(1, "Duration must be at least 1 minute"),
  ageRating: z.string().min(1, "Age rating is required"),
  genres: z.array(z.string()).min(1, "At least one genre is required"),
  cast: z.array(z.string()).optional(),
  director: z.string().optional(),
  availableResolutions: z.string().optional(),
  categoryId: z.string().uuid().optional(),
});

type VideoFormValues = z.infer<typeof videoSchema>;

interface VideosManagementProps {
  className?: string;
}

export function VideosManagement({ className }: VideosManagementProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient(); // Move to component level
  const [showAddVideoDialog, setShowAddVideoDialog] = useState(false);
  const [editVideoId, setEditVideoId] = useState<string | null>(null);
  const [genreInput, setGenreInput] = useState("");
  const [castInput, setCastInput] = useState("");

  const { data: videos = [], isLoading: isLoadingVideos, error: videosError } = useQuery<Video[]>({
    queryKey: ["/api/videos"],
    queryFn: async ({ queryKey }) => {
      const res = await fetch(queryKey[0] as string, {
        credentials: 'include'
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ message: "Failed to fetch videos" }));
        throw new Error(errorData.message);
      }
      return res.json();
    },
  });

  const videoForm = useForm<VideoFormValues>({
    resolver: zodResolver(videoSchema),
    defaultValues: {
      title: "",
      description: "",
      thumbnailUrl: "",
      videoUrl: "",
      trailerUrl: "",
      releaseYear: new Date().getFullYear(),
      duration: 90,
      ageRating: "PG",
      genres: [],
      cast: [],
      director: "",
      availableResolutions: "",
      categoryId: undefined,
    },
  });

  const createVideoMutation = useMutation({
    mutationFn: async (videoData: VideoFormValues) => {
      const res = await fetch("/api/videos", {
        method: "POST",
        credentials: 'include',
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(videoData)
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ message: "Failed to create video" }));
        throw new Error(errorData.message);
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      setShowAddVideoDialog(false);
      setEditVideoId(null);
      videoForm.reset();
      toast({
        title: "Video added",
        description: "The video has been added successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add video",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateVideoMutation = useMutation({
    mutationFn: async ({ id, videoData }: { id: string; videoData: VideoFormValues }) => {
      const res = await fetch(`/api/videos/${id}`, {
        method: "PUT",
        credentials: 'include',
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(videoData)
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ message: "Failed to update video" }));
        throw new Error(errorData.message);
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      setShowAddVideoDialog(false);
      setEditVideoId(null);
      videoForm.reset();
      toast({
        title: "Video updated",
        description: "The video has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update video",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteVideoMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await fetch(`/api/videos/${id}`, {
        method: "DELETE",
        credentials: 'include'
      });
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({ message: "Failed to delete video" }));
        throw new Error(errorData.message);
      }
      // No JSON to parse for a successful DELETE usually
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
      toast({
        title: "Video deleted",
        description: "The video has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete video",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addGenre = () => {
    if (genreInput && !videoForm.getValues("genres").includes(genreInput)) {
      videoForm.setValue("genres", [...videoForm.getValues("genres"), genreInput]);
      setGenreInput("");
    }
  };

  const removeGenre = (genreToRemove: string) => {
    videoForm.setValue("genres", videoForm.getValues("genres").filter((genre) => genre !== genreToRemove));
  };

  const addCastMember = () => {
    if (castInput && !(videoForm.getValues("cast") || []).includes(castInput)) {
      videoForm.setValue("cast", [...(videoForm.getValues("cast") || []), castInput]);
      setCastInput("");
    }
  };

  const removeCastMember = (memberToRemove: string) => {
    videoForm.setValue("cast", (videoForm.getValues("cast") || []).filter((member) => member !== memberToRemove));
  };

  const handleEditVideo = (video: Video) => {
    setEditVideoId(video.id);
    // Ensure all fields from Video type are mapped to VideoFormValues
    videoForm.reset({
      title: video.title,
      description: video.description,
      thumbnailUrl: video.thumbnail_url,
      videoUrl: video.video_url,
      trailerUrl: video.trailer_url || "",
      releaseYear: video.release_year,
      duration: video.duration,
      ageRating: video.age_rating,
      genres: video.genres || [],
      cast: Array.isArray(video.cast_members) ? video.cast_members : video.cast_members ? [video.cast_members] : [],
      director: video.director || "",
      availableResolutions: video.available_resolutions || "",
      categoryId: video.id || undefined,
    });
    setShowAddVideoDialog(true);
  };

  const handleDeleteVideo = (id: string) => {
    if (window.confirm("Are you sure you want to delete this video?")) {
      deleteVideoMutation.mutate(id);
    }
  };

  const onVideoSubmit = (data: VideoFormValues) => {
    if (editVideoId) {
      updateVideoMutation.mutate({ id: editVideoId, videoData: data });
    } else {
      createVideoMutation.mutate(data);
    }
  };

  const openAddVideoDialog = () => {
    setEditVideoId(null);
    videoForm.reset({ // Reset with default values for a new video
      title: "",
      description: "",
      thumbnailUrl: "",
      videoUrl: "",
      trailerUrl: "",
      releaseYear: new Date().getFullYear(),
      duration: 90,
      ageRating: "PG",
      genres: [],
      cast: [],
      director: "",
      availableResolutions: "",
      categoryId: undefined,
    });
    setShowAddVideoDialog(true);
  };

  const handleSyncComplete = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/videos"] });
  };

  return (
    <div className={`space-y-6 p-4 ${className || ''}`}>
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Videos Management</h2>
        <div className="flex space-x-2">
          <VideoSyncButton onSyncComplete={handleSyncComplete} />
          <Button onClick={openAddVideoDialog}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Video
          </Button>
        </div>
      </div>

      {isLoadingVideos && <p>Loading videos...</p>}
      {videosError && <p className="text-red-500">Error loading videos: {(videosError as Error).message}</p>}
      {!isLoadingVideos && !videosError && (
        <div className="overflow-x-auto"> {/* Added for table responsiveness */}
          <Table>
            <TableCaption>A list of your videos.</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Duration</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {videos.map((video) => (
                <TableRow key={video.id}>
                  <TableCell className="font-medium">{video.title}</TableCell>
                  <TableCell>{video.duration} min</TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="sm" onClick={() => handleEditVideo(video)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => handleDeleteVideo(video.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={showAddVideoDialog} onOpenChange={setShowAddVideoDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editVideoId ? "Edit Video" : "Add New Video"}</DialogTitle>
            <DialogDescription>
              {editVideoId ? "Update the video information." : "Fill in the details to add a new video."}
            </DialogDescription>
          </DialogHeader>
          <Form {...videoForm}>
            <form onSubmit={videoForm.handleSubmit(onVideoSubmit)} className="space-y-4">
              <FormField
                control={videoForm.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter video title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={videoForm.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Enter video description" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={videoForm.control}
                name="thumbnailUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Thumbnail URL</FormLabel>
                    <FormControl>
                      <Input placeholder="https://example.com/thumbnail.jpg" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={videoForm.control}
                name="videoUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Video URL</FormLabel>
                    <FormControl>
                      <Input placeholder="https://example.com/video.mp4" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={videoForm.control}
                name="trailerUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Trailer URL (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="https://example.com/trailer.mp4" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={videoForm.control}
                  name="releaseYear"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Release Year</FormLabel>
                      <FormControl>
                        <Input type="number" min="1900" max={new Date().getFullYear() + 5} {...field} onChange={(e) => field.onChange(parseInt(e.target.value))} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={videoForm.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duration (minutes)</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" {...field} onChange={(e) => field.onChange(parseInt(e.target.value))} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={videoForm.control}
                name="ageRating"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Age Rating</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select age rating" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="G">G</SelectItem>
                        <SelectItem value="PG">PG</SelectItem>
                        <SelectItem value="PG-13">PG-13</SelectItem>
                        <SelectItem value="R">R</SelectItem>
                        <SelectItem value="NC-17">NC-17</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Genres */}
              <FormField
                control={videoForm.control}
                name="genres"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Genres</FormLabel>
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Add genre"
                        value={genreInput}
                        onChange={(e) => setGenreInput(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            addGenre();
                          }
                        }}
                      />
                      <Button type="button" onClick={addGenre}>Add</Button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {field.value.map((genre) => (
                        <Badge key={genre} variant="secondary">
                          {genre}
                          <X className="ml-1 h-3 w-3 cursor-pointer" onClick={() => removeGenre(genre)} />
                        </Badge>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Cast */}
              <FormField
                control={videoForm.control}
                name="cast"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Cast</FormLabel>
                    <div className="flex space-x-2">
                      <Input
                        placeholder="Add cast member"
                        value={castInput}
                        onChange={(e) => setCastInput(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            addCastMember();
                          }
                        }}
                      />
                      <Button type="button" onClick={addCastMember}>Add</Button>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {(field.value || []).map((member) => (
                        <Badge key={member} variant="outline">
                          {member}
                          <X className="ml-1 h-3 w-3 cursor-pointer" onClick={() => removeCastMember(member)} />
                        </Badge>
                      ))}
                    </div>
                    <FormDescription>Add cast members one by one</FormDescription>
                  </FormItem>
                )}
              />
              
              <FormField
                control={videoForm.control}
                name="director"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Director</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter director name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={videoForm.control}
                name="availableResolutions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Available Resolutions</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 720p,1080p,4K" {...field} />
                    </FormControl>
                    <FormDescription>Comma-separated list of available resolutions</FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={videoForm.control}
                name="categoryId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category ID (Optional)</FormLabel>
                    <FormControl>
                      <Input type="text" placeholder="Category ID" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setShowAddVideoDialog(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createVideoMutation.isPending || updateVideoMutation.isPending}>
                  {createVideoMutation.isPending || updateVideoMutation.isPending ? "Saving..." : editVideoId ? "Update Video" : "Add Video"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
