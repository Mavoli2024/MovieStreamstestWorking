import React, { useState, useEffect, useCallback } from 'react';
import {  Card, CardContent, CardDescription, CardHeader, CardTitle  } from '@/components/ui/card';
import {  Tabs, TabsContent, TabsList, TabsTrigger  } from '@/components/ui/tabs';
import {  Button  } from '@/components/ui/button';
import {  Badge  } from '@/components/ui/badge';
import {  
  BarChart, 
  Bar, 
  LineChart, 
  Line, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer 
 } from 'recharts';
import {  
  Users, 
  Video, 
  Play, 
  DollarSign, 
  TrendingUp, 
  Clock, 
  Eye,
  RefreshCw
 } from 'lucide-react';

interface AnalyticsData {
  users: {
    total: number;
    active: number;
    new: number;
    premium: number;
  };
  content: {
    totalVideos: number;
    totalViews: number;
    totalWatchTime: number;
    avgWatchTime: number;
  };
  engagement: {
    dailyActiveUsers: Array<{ date: string; users: number }>;
    popularContent: Array<{ title: string; views: number; watchTime: number }>;
    deviceBreakdown: Array<{ device: string; users: number }>;
  };
  revenue: {
    monthlyRevenue: number;
    subscriptions: {
      active: number;
      cancelled: number;
      renewed: number;
    };
    revenueByPlan: Array<{ plan: string; revenue: number }>;
  };
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export function AdminAnalyticsDashboard() {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const loadAnalyticsData = useCallback(async () => {
    setIsLoading(true);
    try {
      // In a real implementation, this would fetch from your analytics API
      const response = await fetch('/api/admin/analytics');
      if (response.ok) {
        const data = await response.json();
        setAnalyticsData(data);
      } else {
        // Fallback with mock data for demo
        setAnalyticsData(getMockAnalyticsData());
      }    } catch {
      // Use mock data on error
      setAnalyticsData(getMockAnalyticsData());
    } finally {
      setIsLoading(false);
      setLastUpdated(new Date());
    }
  }, []);

  useEffect(() => {
    loadAnalyticsData();
  }, [loadAnalyticsData]);

  const getMockAnalyticsData = (): AnalyticsData => ({
    users: {
      total: 12450,
      active: 8320,
      new: 1240,
      premium: 3210
    },
    content: {
      totalVideos: 2840,
      totalViews: 456780,
      totalWatchTime: 89342, // in hours
      avgWatchTime: 24.5 // in minutes
    },
    engagement: {
      dailyActiveUsers: [
        { date: '2024-01-01', users: 7800 },
        { date: '2024-01-02', users: 8100 },
        { date: '2024-01-03', users: 8350 },
        { date: '2024-01-04', users: 7900 },
        { date: '2024-01-05', users: 8200 },
        { date: '2024-01-06', users: 8400 },
        { date: '2024-01-07', users: 8320 }
      ],
      popularContent: [
        { title: 'The Lion King', views: 45678, watchTime: 126.5 },
        { title: 'Black Panther', views: 38945, watchTime: 108.2 },
        { title: 'Coming to America', views: 32167, watchTime: 95.4 },
        { title: 'Sister Act', views: 28934, watchTime: 87.3 },
        { title: 'The Color Purple', views: 25678, watchTime: 78.9 }
      ],
      deviceBreakdown: [
        { device: 'Mobile', users: 5200 },
        { device: 'Desktop', users: 2100 },
        { device: 'Tablet', users: 820 },
        { device: 'Smart TV', users: 200 }
      ]
    },
    revenue: {
      monthlyRevenue: 89450,
      subscriptions: {
        active: 3210,
        cancelled: 145,
        renewed: 2890
      },
      revenueByPlan: [
        { plan: 'Basic', revenue: 23400 },
        { plan: 'Premium', revenue: 45650 },
        { plan: 'Family', revenue: 20400 }
      ]
    }
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold">Analytics Dashboard</h1>
          <div className="flex items-center gap-2">
            <RefreshCw className="h-4 w-4 animate-spin" />
            <span className="text-sm text-muted-foreground">Loading...</span>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardHeader className="animate-pulse">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  if (!analyticsData) {
    return (
      <div className="p-6">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Analytics Dashboard</h1>
          <p className="text-muted-foreground mb-4">Failed to load analytics data</p>
          <Button onClick={loadAnalyticsData}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Analytics Dashboard</h1>
          <p className="text-muted-foreground">
            Last updated: {lastUpdated.toLocaleString()}
          </p>
        </div>
        <Button onClick={loadAnalyticsData} variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.users.total.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">+{analyticsData.users.new}</span> new this month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Users</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.users.active.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((analyticsData.users.active / analyticsData.users.total) * 100)}% of total users
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Views</CardTitle>
            <Video className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.content.totalViews.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              Across {analyticsData.content.totalVideos} videos
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">R{analyticsData.revenue.monthlyRevenue.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              {analyticsData.revenue.subscriptions.active} active subscriptions
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Analytics */}
      <Tabs defaultValue="engagement" className="space-y-4">
        <TabsList>
          <TabsTrigger value="engagement">User Engagement</TabsTrigger>
          <TabsTrigger value="content">Content Performance</TabsTrigger>
          <TabsTrigger value="revenue">Revenue Analytics</TabsTrigger>
          <TabsTrigger value="devices">Device Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="engagement" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Daily Active Users</CardTitle>
                <CardDescription>User activity over the past week</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={analyticsData.engagement.dailyActiveUsers}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="users" stroke="#8884d8" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Watch Time Metrics</CardTitle>
                <CardDescription>Content consumption statistics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4" />
                    <span className="text-sm">Total Watch Time</span>
                  </div>
                  <Badge variant="secondary">
                    {analyticsData.content.totalWatchTime.toLocaleString()} hours
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4" />
                    <span className="text-sm">Average Watch Time</span>
                  </div>
                  <Badge variant="secondary">
                    {analyticsData.content.avgWatchTime} minutes
                  </Badge>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span className="text-sm">Premium Users</span>
                  </div>
                  <Badge variant="secondary">
                    {analyticsData.users.premium.toLocaleString()}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="content" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Popular Content</CardTitle>
              <CardDescription>Top performing videos by views and watch time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.engagement.popularContent.map((content, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <h4 className="font-medium">{content.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {content.views.toLocaleString()} views • {content.watchTime} hours watched
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline">
                      <Play className="h-3 w-3 mr-1" />
                      Popular
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue by Plan</CardTitle>
                <CardDescription>Monthly revenue breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={analyticsData.revenue.revenueByPlan}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, value }) => `${name}: R${value.toLocaleString()}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="revenue"
                    >
                      {analyticsData.revenue.revenueByPlan.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Subscription Metrics</CardTitle>
                <CardDescription>Current subscription status</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm">Active Subscriptions</span>
                  <Badge className="bg-green-100 text-green-800">
                    {analyticsData.revenue.subscriptions.active.toLocaleString()}
                  </Badge>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm">Renewed This Month</span>
                  <Badge className="bg-blue-100 text-blue-800">
                    {analyticsData.revenue.subscriptions.renewed.toLocaleString()}
                  </Badge>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm">Cancelled This Month</span>
                  <Badge className="bg-red-100 text-red-800">
                    {analyticsData.revenue.subscriptions.cancelled.toLocaleString()}
                  </Badge>
                </div>

                <div className="pt-4 border-t">
                  <div className="text-sm text-muted-foreground">Churn Rate</div>
                  <div className="text-2xl font-bold">
                    {Math.round((analyticsData.revenue.subscriptions.cancelled / analyticsData.revenue.subscriptions.active) * 100)}%
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="devices" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Device Usage</CardTitle>
              <CardDescription>How users access MadifaStream</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analyticsData.engagement.deviceBreakdown}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="device" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="users" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
