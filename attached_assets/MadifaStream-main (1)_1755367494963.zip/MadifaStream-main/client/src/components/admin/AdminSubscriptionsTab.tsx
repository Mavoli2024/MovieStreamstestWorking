import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { CreditCard } from 'lucide-react';
import { useAdminSubscriptions } from '@/hooks/use-admin-subscriptions';

interface Subscription {
  id: string;
  user_id: string;
  plan_type: string;
  status: string;
  created_at: string;
  expires_at: string;
  payment_method: string;
  amount: number;
  user_email?: string;
}

export function AdminSubscriptionsTab() {
  const { subscriptions, subscriptionsLoading, refetchSubscriptions } = useAdminSubscriptions();
  const [selectedSubscription, setSelectedSubscription] = useState<Subscription | null>(null);

  if (subscriptionsLoading) {
    return <div className="p-4">Loading subscriptions...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Subscription Management</h2>
        <Button onClick={() => refetchSubscriptions()}>Refresh</Button>
      </div>

      <div className="grid gap-4">
        {subscriptions?.map((subscription: Subscription) => (
          <Card key={subscription.id}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                {subscription.plan_type}
              </CardTitle>
              <CardDescription>
                User: {subscription.user_email || subscription.user_id}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <strong>Status:</strong> 
                  <Badge className="ml-2">{subscription.status}</Badge>
                </div>
                <div>
                  <strong>Amount:</strong> ${subscription.amount}
                </div>
                <div>
                  <strong>Created:</strong> {new Date(subscription.created_at).toLocaleDateString()}
                </div>
                <div>
                  <strong>Expires:</strong> {new Date(subscription.expires_at).toLocaleDateString()}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
} 