import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { UniversalDataTable, type ColumnDef } from './universal-data-table';
import { UniversalCrudModal, type FieldDef } from './universal-crud-modal';
import { useAdminUsers } from '@/hooks/use-admin-users';
import { Users } from 'lucide-react';
import type { Database } from '@/types/database-generated.types';

type ProfileType = Database['public']['Tables']['profiles']['Row'];

export function AdminUsersTab() {
  const {
    profiles,
    profilesLoading,
    updateProfile,
    deleteProfile,
    isUpdating,
    // isDeleting, // Unused, commented out
  } = useAdminUsers();

  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<ProfileType | null>(null);

  const userColumns: ColumnDef<ProfileType>[] = [
    { id: 'username', header: 'Username', accessorKey: 'username', sortable: true, filterable: true },
    { id: 'display_name', header: 'Display Name', accessorKey: 'display_name', sortable: true, filterable: true },
    { id: 'role', header: 'Role', accessorKey: 'role', editable: true, editType: 'select', 
      editOptions: [
        { value: 'user', label: 'User' },
        { value: 'admin', label: 'Admin' },
        { value: 'moderator', label: 'Moderator' }
      ]
    },
    { id: 'subscription_status', header: 'Subscription', accessorKey: 'subscription_status', editable: true, editType: 'select',
      editOptions: [
        { value: 'active', label: 'Active' },
        { value: 'inactive', label: 'Inactive' },
        { value: 'trialing', label: 'Trialing' }
      ]
    },
    { id: 'created_at', header: 'Created', accessorKey: 'created_at', sortable: true },
  ];

  const userFields: FieldDef[] = [
    { name: 'username', label: 'Username', type: 'text' },
    { name: 'display_name', label: 'Display Name', type: 'text' },
    { name: 'role', label: 'Role', type: 'select', 
      options: [
        { value: 'user', label: 'User' },
        { value: 'admin', label: 'Admin' },
        { value: 'moderator', label: 'Moderator' }
      ]
    },
    { name: 'subscription_status', label: 'Subscription Status', type: 'select',
      options: [
        { value: 'active', label: 'Active' },
        { value: 'inactive', label: 'Inactive' },
        { value: 'trialing', label: 'Trialing' }
      ]
    },
  ];

  const handleUserSubmit = async (data: Record<string, unknown>) => {
    if (editingUser) {
      updateProfile({ id: editingUser.id, data });
    }
    setShowUserModal(false);
    setEditingUser(null);
  };

  const handleInlineEdit = async (item: ProfileType, field: string, value: unknown) => {
    updateProfile({ id: item.id, data: { [field]: value } });
  };

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Users Management
          </CardTitle>
          <CardDescription>
            Manage user accounts, roles, and permissions
          </CardDescription>
        </div>
      </CardHeader>
      <CardContent>
        <UniversalDataTable
          data={profiles}
          columns={userColumns}
          isLoading={profilesLoading}
          onEdit={(item) => {
            setEditingUser(item);
            setShowUserModal(true);
          }}
          onDelete={(item) => deleteProfile(item.id)}
          onInlineEdit={handleInlineEdit}
          enableInlineEdit={true}
        />

        <UniversalCrudModal
          isOpen={showUserModal}
          onClose={() => {
            setShowUserModal(false);
            setEditingUser(null);
          }}
          title="Edit User"
          fields={userFields}
          initialData={editingUser}
          onSubmit={handleUserSubmit}
          isLoading={isUpdating}
          mode="edit"
        />
      </CardContent>
    </Card>
  );
} 