import { logger } from '@shared/logger';
/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, ChangeEvent } from 'react';
import axios from 'axios';
import {  Button  } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { api } from '@/lib/env';
import { useToast } from '@/hooks/use-toast';
import {  Loader2, Upload  } from 'lucide-react';

interface UploadVideoButtonProps {
  collectionId: string; // Bunny collection where the video should be stored
  onSuccess?: () => void; // optional callback after successful upload
}

/**
 * UploadVideoButton - SECURE VERSION
 * -----------------------------------
 * Admin-only helper that creates an upload session via our backend and then
 * uploads the file through our secure backend proxy endpoint.
 * 
 * SECURITY IMPROVEMENTS:
 * 1. The backend never exposes API keys to the frontend
 * 2. All uploads go through our authenticated backend proxy
 * 3. Proper access control and validation on the backend
 */
export function UploadVideoButton({ collectionId, onSuccess }: UploadVideoButtonProps) {
  const { toast } = useToast();
  const { session } = useAuth();
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !session) return;

    const title = file.name.replace(/\.[^/.]+$/, ""); // strip extension

    try {
      setUploading(true);
      setUploadProgress(0);
      
      // 1️⃣ Ask backend for an upload session (SECURE - no API key returned)
      const { data } = await axios.post<{
        videoGuid: string;
        libraryId: string;
        uploadUrl: string;
        videoId: string;
      }>(
        api('/api/bunny/create-upload-session'),
        { title, collectionId },
        { headers: { Authorization: `Bearer ${session.access_token}` } }
      );

      const { videoGuid } = data;

      // 2️⃣ Upload the file through our secure backend proxy
      const formData = new FormData();
      formData.append('video', file);

      await axios.post(
        api(`/api/bunny/upload/${videoGuid}`),
        file, // Send the file directly as binary data
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': file.type || 'application/octet-stream',
          },
          maxBodyLength: Infinity,
          maxContentLength: Infinity,
          onUploadProgress: ({ progress }) => {
            if (progress) {
              const percentage = Math.round(progress * 100);
              setUploadProgress(percentage);
            }
          },
        }
      );

      toast({
        title: 'Upload complete',
        description: `${title} was uploaded successfully and is processing.`,
      });

      if (onSuccess) onSuccess();
      
    } catch (error: any) {
      logger.error('Upload failed:', error);
      toast({
        title: "Upload Failed",
        description: error?.response?.data?.message || error?.message || "An unexpected error occurred",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      setUploadProgress(0);
      // reset file input so same file can be chosen again if needed
      e.target.value = '';
    }
  };

  return (
    <div>
      <label htmlFor="video-upload-input">
        <Button disabled={uploading} className="cursor-pointer">
          {uploading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Upload className="mr-2 h-4 w-4" />
          )}
          {uploading ? `Uploading… ${uploadProgress}%` : 'Upload Video'}
        </Button>
      </label>
      {uploading && (
        <div className="mt-2 text-sm text-muted-foreground">
          Uploading: {uploadProgress}%
        </div>
      )}
      <input
        id="video-upload-input"
        type="file"
        accept="video/*"
        className="hidden"
        onChange={handleFileChange}
      />
    </div>
  );
} 