import {  Badge  } from "@/components/ui/badge";
import {  Button  } from "@/components/ui/button";
import {  ThumbnailImage  } from "@/components/ui/thumbnail-image";
import { useBunnyCollections } from "@/hooks/use-bunny-collections";
import { useToast } from "@/hooks/use-toast";
import { extractBunnyGuid } from "@/lib/bunny-api";
import {  Check, Clock, Eye, Film, Play, Plus  } from "lucide-react";
import { useEffect, useState } from "react";
import {  Link  } from "wouter";
import type { Video } from "@shared/schema";
import { adaptVideoForUI } from "@/lib/type-adapters";
import { logger } from '@shared/logger';

interface StandardizedContentCardProps {
  video: Video;
  progress?: number; // as percentage 0-100
  isContinueWatching?: boolean;
  isInWatchlist?: boolean;
  isCompact?: boolean; // For more dense layouts
  profileId?: string;
  showControls?: boolean; // Show play and add to watchlist controls
  showMetadata?: boolean; // Show duration and other metadata
  onAddToWatchlist?: (videoId: string) => void;
  onRemoveFromWatchlist?: (videoId: string) => void;
  className?: string;
}

/**
 * Standardized content card component for consistent display across the platform
 * Uses the same layout, animations and data display everywhere
 */
export function StandardizedContentCard({
  video: rawVideo,
  progress = 0,
  isContinueWatching = false,
  isInWatchlist = false,
  isCompact = false,
  profileId,
  showControls = true,
  showMetadata = true,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  className = "",
}: StandardizedContentCardProps) {
  // Ensure video has all required fields with proper types
  const video = adaptVideoForUI(rawVideo as any);
  const { toast } = useToast();
  const [isHovered, setIsHovered] = useState(false);
  const [isTrailer, setIsTrailer] = useState(false);

  const { data: collections } = useBunnyCollections();
  // Determine if this is a trailer based on database flag, title, or collection
  useEffect(() => {
    // Prepare result without setting state multiple times
    let result = false;

    // Use the database flag if available (from our schema)
    if (video.is_trailer) {
      result = true;
    }
    // Fallback: check title for "trailer" keyword
    else if (video.title.toLowerCase().includes("trailer")) {
      result = true;
    }
    // Fallback: Check if video belongs to a trailer collection
    else if (collections && video.video_url) {
      const trailerCollection = collections.find(c =>
        c.name.toLowerCase().includes("trailer") || c.name.toLowerCase().includes("preview")
      );

      if (trailerCollection) {
        // Check if video's collection ID matches trailer collection
        if (video.collection_id === trailerCollection.guid) {
          result = true;
        }
        // Last resort: check if video GUID is in the trailer collection's preview videos
        else {
          const videoGuid = extractBunnyGuid(video.video_url);
          result = !!(videoGuid && trailerCollection.previewVideoIds?.includes(videoGuid));
        }
      }
    }

    // Only set state once after all checks
    setIsTrailer(result);

    // Use collections.length instead of collections to avoid infinite re-renders
    // when the collection object identity changes but content remains the same
  }, [video.is_trailer, video.title, video.video_url, video.collection_id,
  collections?.length, collections?.map(c => c.guid).join()]);

  // Format duration to hours:minutes:seconds (1:00:00 for 1 hour)
  const formatDuration = (seconds: number) => {
    if (!seconds || seconds <= 0) return "0:00";

    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = Math.floor(seconds % 60);

    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    } else {
      return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
    }
  };

  // Handle watchlist toggle
  const toggleWatchlist = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    if (!profileId) {
      toast({
        title: "Profile required",
        description: "Please select a profile first",
        variant: "destructive",
      });
      return;
    } try {
      if (isInWatchlist) {
        if (onRemoveFromWatchlist) {
          onRemoveFromWatchlist(video.id);
        } else {
          await fetch("/api/watchlist/" + profileId + "/" + video.id, {
            method: "DELETE",
            credentials: "include"
          });
          toast({
            title: "Removed from My List",
            description: `${video.title} was removed from your list`,
          });
        }
      } else {
        if (onAddToWatchlist) {
          onAddToWatchlist(video.id);
        } else {
          await fetch("/api/watchlist", {
            method: "POST",
            credentials: "include",
            headers: {
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              profileId,
              videoId: video.id,
            })
          });
          toast({
            title: "Added to My List",
            description: `${video.title} was added to your list`,
          });
        }
      }
    } catch (error) {
      logger.error("Error toggling watchlist:", { arg1: error });
      toast({
        title: "Error",
        description: "Failed to update your list",
        variant: "destructive",
      });
    }
  };

  return (
    <div
      className={`content-card relative group ${className || 'w-full min-w-[200px]'}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >      <Link href={`/watch/${video.id}`}>
        <div className="bg-card rounded-md overflow-hidden transition-transform duration-300 hover:scale-105 hover:z-10 shadow-lg">
          {/* Thumbnail with aspect ratio */}
          <div className="aspect-video bg-cover bg-center rounded-t overflow-hidden relative">
            {isTrailer ? (
              <video
                src={video.video_url || ''}
                autoPlay
                muted
                controls={false}
                className="w-full h-full object-cover"
                onEnded={() => { window.location.href = '/subscription'; }}
              />
            ) : (
              <ThumbnailImage
                src={video.thumbnail_url || ''}
                alt={video.title}
                title={video.title}
                className="w-full h-full"
              />
            )}

            {/* Progress bar for continue watching */}
            {isContinueWatching && progress > 0 && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-800">
                <div
                  className="h-full bg-secondary"
                  style={{ width: `${progress}%` }}
                />
              </div>
            )}

            {/* Trailer badge */}
            {isTrailer && (
              <div className="absolute top-2 left-2">
                <Badge variant="secondary" className="bg-secondary text-white text-xs">
                  Trailer
                </Badge>
              </div>
            )}

            {/* Play overlay on hover */}
            {showControls && (
              <div
                className={`absolute inset-0 flex items-center justify-center bg-black/40 transition-opacity duration-300 ${isHovered ? "opacity-100" : "opacity-0"
                  }`}
              >
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full bg-primary/90 border-2 border-white text-white hover:bg-primary"
                >
                  <Play className="h-6 w-6" fill="white" />
                </Button>
              </div>
            )}
          </div>

          {/* Content info */}
          <div className="p-2 bg-card/90">            {/* Title row with watchlist button */}
            <div className="flex justify-between items-start">
              <h3 className="font-medium text-sm line-clamp-1">{video.title}</h3>

              {showControls && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-8 w-8 rounded-full"
                  onClick={toggleWatchlist}
                >
                  {isInWatchlist ? (
                    <Check className="h-4 w-4 text-secondary" />
                  ) : (
                    <Plus className="h-4 w-4" />
                  )}
                </Button>
              )}
            </div>

            {/* Metadata row */}
            {showMetadata && (
              <div className="flex items-center mt-1 text-xs text-gray-400">
                <div className="flex items-center mr-2">
                  <Clock className="h-3 w-3 mr-1" />
                  <span>{formatDuration(((video as any).duration_minutes || 0) * 60)}</span>
                </div>

                {/* Release year intentionally omitted for cleaner card UI */}

                {/* Views if available from Bunny API */}
                {video.views && video.views > 0 && (
                  <div className="flex items-center">
                    <Eye className="h-3 w-3 mr-1" />
                    <span>{video.views.toLocaleString()}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </Link>
    </div>
  );
}