import React from "react";
import MADIFA_LOGO_URL from '../assets/madifa_logo.png'; // Correct path: one level up from components to src, then into assets

interface LogoProps {
  className?: string;
  showTagline?: boolean;
}

export function Logo({ className = "h-10", showTagline = false }: LogoProps) {
  // Directly render the logo image without SVG fallback
  return (
    <div className={`flex items-center ${className}`}>
      <div className="h-full relative flex items-center">
          <img
          src={MADIFA_LOGO_URL} // Use the imported URL
          alt="MADIFA Logo"
            className="h-full object-contain"
          />
      </div>
      {showTagline && (
        <span className="ml-3 text-lg font-semibold text-gray-700 dark:text-gray-300">
          Mzansi's Movies Unboxed
        </span>
      )}
    </div>
  );
}
