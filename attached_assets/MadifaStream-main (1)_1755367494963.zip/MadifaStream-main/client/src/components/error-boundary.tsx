import React, { Component, ReactNode, ErrorInfo } from 'react';
import {  AlertTriangle, RefreshCw  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';
import { logger } from '@shared/logger';

interface ErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
  onReset?: () => void;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error?: Error;
  errorInfo?: ErrorInfo;
  retryCount: number;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      retryCount: 0
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    // Update state to trigger fallback UI
    return { hasError: true, error, retryCount: 0 };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    // Log error information for debugging
    logger.error('Error caught by ErrorBoundary:', { arg1: error, arg2: errorInfo });
    this.setState({ error, errorInfo });
  }

  handleRetry = (): void => {
    // Increment retry count and reset error state
    this.setState(prev => ({
      hasError: false,
      retryCount: prev.retryCount + 1
    }));
    
    // Call custom reset handler if provided
    if (this.props.onReset) {
      this.props.onReset();
    }
  }

  render() {
    if (this.state.hasError) {
      // Custom fallback UI if provided
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // Default fallback UI
      return (
        <div className="min-h-[50vh] flex flex-col items-center justify-center p-6 text-center">
          <div className="bg-red-900/20 rounded-full p-6 mb-6">
            <AlertTriangle className="h-12 w-12 text-red-500" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Something went wrong</h2>
          <p className="text-muted-foreground mb-6 max-w-md">
            We encountered an error while trying to display this content. Please try again or contact support if the problem persists.
          </p>
          
          {this.state.error && (
            <div className="bg-gray-800 rounded-md p-4 mb-6 max-w-lg overflow-auto text-sm text-left">
              <p className="font-semibold text-red-400">Error: {this.state.error.message}</p>
            </div>
          )}
          
          <Button 
            onClick={this.handleRetry} 
            className="bg-primary hover:bg-red-700 flex items-center gap-2"
          >
            <RefreshCw className="h-4 w-4" />
            {this.state.retryCount === 0 ? 'Try Again' : `Retry (${this.state.retryCount})`}
          </Button>
        </div>
      );
    }

    // Normal component rendering when no error
    return this.props.children;
  }
}

export default ErrorBoundary;