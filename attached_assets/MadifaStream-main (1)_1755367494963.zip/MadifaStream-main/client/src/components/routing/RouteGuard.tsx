import React from 'react';
import { useLocation, Redirect } from 'wouter';
import { useAuthStore } from '../../stores/authStore';
import { useUIStore } from '../../stores/uiStore';
import { RouteDefinition } from '../../utils/navigation';

interface RouteGuardProps {
  children: React.ReactNode;
  route: RouteDefinition;
  fallback?: React.ReactNode;
  loadingFallback?: React.ReactNode;
}

export const RouteGuard: React.FC<RouteGuardProps> = ({
  children,
  route,
  fallback,
  loadingFallback,
}) => {
  const [location] = useLocation();
  const { isAuthenticated, isLoading, hasAnyRole } = useAuthStore();
  const { setGlobalLoading } = useUIStore();

  // Show loading fallback while auth is being determined
  if (isLoading) {
    return <>{loadingFallback || <div>Loading...</div>}</>;
  }

  // Check authentication requirement
  if (route.requiresAuth && !isAuthenticated) {
    const returnUrl = encodeURIComponent(location);
    return <Redirect to={`/login?returnUrl=${returnUrl}`} />;
  }

  // Check role requirements
  if (route.roles && route.roles.length > 0) {
    if (!hasAnyRole(route.roles)) {
      return <Redirect to="/403" />;
    }
  }

  // Check custom validation if provided
  if (route.validate) {
    const validationResult = route.validate();
    if (!validationResult.valid) {
      return <Redirect to={validationResult.redirectTo || '/403'} />;
    }
  }

  return <>{children}</>;
};

// Higher-order component for route protection
export const withRouteGuard = <P extends object>(
  Component: React.ComponentType<P>,
  route: RouteDefinition
) => {
  return (props: P) => (
    <RouteGuard route={route}>
      <Component {...props} />
    </RouteGuard>
  );
};

// Hook for checking route access
export const useRouteAccess = (route: RouteDefinition) => {
  const { isAuthenticated, hasAnyRole } = useAuthStore();

  const canAccess = React.useMemo(() => {
    // Check authentication
    if (route.requiresAuth && !isAuthenticated) {
      return false;
    }

    // Check roles
    if (route.roles && route.roles.length > 0 && !hasAnyRole(route.roles)) {
      return false;
    }

    // Check custom validation
    if (route.validate) {
      const validationResult = route.validate();
      return validationResult.valid;
    }

    return true;
  }, [route, isAuthenticated, hasAnyRole]);

  return { canAccess };
};

// Component for conditional rendering based on route access
export const ProtectedContent: React.FC<{
  children: React.ReactNode;
  route: RouteDefinition;
  fallback?: React.ReactNode;
}> = ({ children, route, fallback = null }) => {
  const { canAccess } = useRouteAccess(route);

  if (!canAccess) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};

// Role-based content protection
export const RoleProtectedContent: React.FC<{
  children: React.ReactNode;
  requiredRoles: string[];
  fallback?: React.ReactNode;
  requireAll?: boolean;
}> = ({ children, requiredRoles, fallback = null, requireAll = false }) => {
  const { hasAnyRole, hasRole } = useAuthStore();

  const hasAccess = React.useMemo(() => {
    if (requireAll) {
      return requiredRoles.every(role => hasRole(role));
    }
    return hasAnyRole(requiredRoles);
  }, [requiredRoles, hasAnyRole, hasRole, requireAll]);

  if (!hasAccess) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};

// Permission-based content protection
export const PermissionProtectedContent: React.FC<{
  children: React.ReactNode;
  requiredPermission: string;
  fallback?: React.ReactNode;
}> = ({ children, requiredPermission, fallback = null }) => {
  const { hasPermission } = useAuthStore();

  if (!hasPermission(requiredPermission)) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};
