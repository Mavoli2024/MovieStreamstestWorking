/**
 * UNIFIED ROUTER COMPONENT
 * 
 * Single router implementation that uses the unified route configuration
 * and provides consistent navigation behavior across the application.
 * 
 * Features:
 * - Single source of truth routing
 * - Consistent authentication guards
 * - Error boundaries per route
 * - Loading states
 * - SEO metadata management
 * - Layout management
 */

import React, { Suspense } from 'react';
import { Router, Switch, Route, Redirect } from 'wouter';
import { Helmet } from 'react-helmet-async';
import { useLocation } from 'wouter';

import { UNIFIED_ROUTES, RouteUtils, RouteAccess, UnifiedRouteDefinition } from '@/config/unified-routes';
import { useAuthStore } from '@/stores/authStore';
import { RouteErrorBoundary } from '@/components/error-boundary/GlobalErrorBoundary';
import { AdaptiveLayout } from '@/components/layouts/AdaptiveLayout';

// Loading component
const RouteLoader: React.FC = () => (
  <div className="min-h-screen flex items-center justify-center bg-background">
    <div className="flex flex-col items-center gap-4">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      <p className="text-muted-foreground">Loading...</p>
    </div>
  </div>
);

// SEO Head component
interface SEOHeadProps {
  route: UnifiedRouteDefinition;
  params?: Record<string, string>;
}

const SEOHead: React.FC<SEOHeadProps> = ({ route, params }) => {
  // Dynamic title generation
  let title = route.title;
  if (params && route.path.includes(':')) {
    // Replace parameter placeholders in title if needed
    Object.entries(params).forEach(([key, value]) => {
      title = title.replace(`:${key}`, value);
    });
  }

  return (
    <Helmet>
      <title>{title}</title>
      {route.description && <meta name="description" content={route.description} />}
      {route.keywords && <meta name="keywords" content={route.keywords.join(', ')} />}
      {route.ogImage && <meta property="og:image" content={route.ogImage} />}
      {route.canonical && <link rel="canonical" href={route.canonical} />}
      <meta property="og:title" content={title} />
      <meta property="og:type" content="website" />
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={title} />
      {route.description && <meta name="twitter:description" content={route.description} />}
    </Helmet>
  );
};

// Route Guard component
interface RouteGuardProps {
  route: UnifiedRouteDefinition;
  children: React.ReactNode;
}

const RouteGuard: React.FC<RouteGuardProps> = ({ route, children }) => {
  const { user, isLoading } = useAuthStore();
  const [location] = useLocation();

  // Allow auth-callback to always pass through
  if (route.id === 'auth-callback') {
    return <>{children}</>;
  }

  // Show loading while authentication is being determined
  if (isLoading) {
    return <RouteLoader />;
  }

  // Check route access
  const canAccess = RouteAccess.canAccess(route, user);
  
  if (!canAccess) {
    const redirectPath = RouteAccess.getRedirectFor(route, user);
    
    // For auth-required routes, include return URL
    if (!user && route.requiresAuth) {
      // Store current location for post-auth redirect
      localStorage.setItem('authRedirectUrl', location);
      const returnUrl = encodeURIComponent(location);
      return <Redirect to={`/auth?returnUrl=${returnUrl}`} />;
    }
    
    return <Redirect to={redirectPath} />;
  }

  // User is authenticated and trying to access auth page, redirect to home
  if (user && route.id === 'auth') {
    return <Redirect to="/home" />;
  }

  return <>{children}</>;
};

// Layout wrapper component
interface LayoutWrapperProps {
  route: UnifiedRouteDefinition;
  children: React.ReactNode;
}

const LayoutWrapper: React.FC<LayoutWrapperProps> = ({ route, children }) => {
  // Determine which routes need layout - exclude pricing and subscription modals
  const needsLayout = !['landing', 'auth', 'pricing', 'plans', 'subscription', 'payment-success', 'payment-cancel'].includes(route.id);
  
  if (needsLayout) {
    return <AdaptiveLayout>{children}</AdaptiveLayout>;
  }
  
  return <>{children}</>;
};

// Individual route renderer
interface RouteRendererProps {
  route: UnifiedRouteDefinition;
}

const RouteRenderer: React.FC<RouteRendererProps> = ({ route }) => {
  const [location] = useLocation();
  
  // Extract route parameters
  const params = RouteUtils.extractParams(route.path, location);
  
  return (
    <RouteErrorBoundary>
      <SEOHead route={route} params={params} />
      <RouteGuard route={route}>
        <LayoutWrapper route={route}>
          <Suspense fallback={<RouteLoader />}>
            <route.component {...params} />
          </Suspense>
        </LayoutWrapper>
      </RouteGuard>
    </RouteErrorBoundary>
  );
};

// Main Unified Router component
export const UnifiedRouter: React.FC = () => {
  return (
    <Router>
      <Switch>
        {UNIFIED_ROUTES.map((route) => (
          <Route
            key={route.id}
            path={route.path}
          >
            <RouteRenderer route={route} />
          </Route>
        ))}
      </Switch>
    </Router>
  );
};

// Navigation utilities for components
export const useUnifiedNavigation = () => {
  const [, setLocation] = useLocation();
  
  const navigate = (routeId: string, params?: Record<string, string>) => {
    const path = RouteUtils.generatePath(routeId, params || {});
    setLocation(path);
  };
  
  const navigateToPath = (path: string) => {
    setLocation(path);
  };
  
  const goBack = () => {
    window.history.back();
  };
  
  const getCurrentRoute = (): UnifiedRouteDefinition | undefined => {
    const [location] = useLocation();
    return RouteUtils.findByPath(location);
  };
  
  return {
    navigate,
    navigateToPath,
    goBack,
    getCurrentRoute,
    routes: UNIFIED_ROUTES,
    utils: RouteUtils,
  };
};

// Route-based navigation helpers
export const NavigationHelpers = {
  goToHome: () => RouteUtils.generatePath('home', {}),
  goToWatch: (videoId: string) => RouteUtils.generatePath('watch', { id: videoId }),
  goToBrowse: (category?: string) => 
    category 
      ? RouteUtils.generatePath('browse-category', { category })
      : RouteUtils.generatePath('browse', {}),
  goToProfile: () => RouteUtils.generatePath('profile', {}),
  goToAuth: (returnUrl?: string) => {
    const path = RouteUtils.generatePath('auth', {});
    return returnUrl ? `${path}?returnUrl=${encodeURIComponent(returnUrl)}` : path;
  },
  goToSettings: () => RouteUtils.generatePath('settings', {}),
  goToWatchlist: () => RouteUtils.generatePath('watchlist', {}),
  goToHistory: () => RouteUtils.generatePath('history', {}),
  goToSubscription: () => RouteUtils.generatePath('subscription', {}),
  goToSearch: (query?: string) => {
    const path = RouteUtils.generatePath('search', {});
    return query ? `${path}?q=${encodeURIComponent(query)}` : path;
  },
};

export default UnifiedRouter;