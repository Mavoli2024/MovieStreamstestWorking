import React, { useState, useEffect } from 'react';
import {  Card, CardContent, CardDescription, CardHeader, CardTitle  } from '@/components/ui/card';
import {  Switch  } from '@/components/ui/switch';
import {  Button  } from '@/components/ui/button';
import {  Bell, BellOff  } from 'lucide-react';
import { notificationService } from '@/services/pushNotificationService';

interface NotificationPreferences {
  newContent: boolean;
  subscriptionReminders: boolean;
  downloadComplete: boolean;
  recommendations: boolean;
}

export function NotificationSettings() {
  const [preferences, setPreferences] = useState<NotificationPreferences>({
    newContent: true,
    subscriptionReminders: true,
    downloadComplete: true,
    recommendations: true
  });
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPreferences();
    checkNotificationStatus();
  }, []);

  const loadPreferences = async () => {
    try {
      const prefs = await notificationService.getNotificationPreferences();
      if (prefs) {
        setPreferences(prefs);
      }    } catch {
      // Handle error silently
    } finally {
      setIsLoading(false);
    }
  };

  const checkNotificationStatus = async () => {
    if ('Notification' in window) {
      setNotificationsEnabled(Notification.permission === 'granted');
    }
  };

  const enableNotifications = async () => {
    const success = await notificationService.initializeNotifications();
    setNotificationsEnabled(success);
  };

  const disableNotifications = async () => {
    await notificationService.unsubscribeFromNotifications();
    setNotificationsEnabled(false);
  };

  const updatePreference = async (key: keyof NotificationPreferences, value: boolean) => {
    const newPreferences = { ...preferences, [key]: value };
    setPreferences(newPreferences);
    await notificationService.updateNotificationPreferences(newPreferences);
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Notification Settings</CardTitle>
          <CardDescription>Loading...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Notification Settings
        </CardTitle>
        <CardDescription>
          Manage your push notification preferences
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Enable/Disable Notifications */}
        <div className="flex items-center justify-between p-4 border rounded-lg">
          <div className="flex items-center gap-3">
            {notificationsEnabled ? (
              <Bell className="h-5 w-5 text-green-600" />
            ) : (
              <BellOff className="h-5 w-5 text-gray-400" />
            )}
            <div>
              <h3 className="font-medium">
                {notificationsEnabled ? 'Notifications Enabled' : 'Notifications Disabled'}
              </h3>
              <p className="text-sm text-muted-foreground">
                {notificationsEnabled 
                  ? 'You will receive push notifications based on your preferences below'
                  : 'Enable notifications to receive important updates'
                }
              </p>
            </div>
          </div>
          <Button
            variant={notificationsEnabled ? "outline" : "default"}
            onClick={notificationsEnabled ? disableNotifications : enableNotifications}
          >
            {notificationsEnabled ? 'Disable' : 'Enable'}
          </Button>
        </div>

        {/* Notification Preferences */}
        {notificationsEnabled && (
          <div className="space-y-4">
            <h3 className="font-medium">Notification Types</h3>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium">New Content</label>
                  <p className="text-sm text-muted-foreground">
                    Get notified when new videos are added
                  </p>
                </div>
                <Switch
                  checked={preferences.newContent}
                  onCheckedChange={(checked) => updatePreference('newContent', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium">Subscription Reminders</label>
                  <p className="text-sm text-muted-foreground">
                    Reminders about subscription renewals and payments
                  </p>
                </div>
                <Switch
                  checked={preferences.subscriptionReminders}
                  onCheckedChange={(checked) => updatePreference('subscriptionReminders', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium">Download Complete</label>
                  <p className="text-sm text-muted-foreground">
                    Notifications when video downloads finish
                  </p>
                </div>
                <Switch
                  checked={preferences.downloadComplete}
                  onCheckedChange={(checked) => updatePreference('downloadComplete', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <label className="font-medium">Recommendations</label>
                  <p className="text-sm text-muted-foreground">
                    Personalized content recommendations
                  </p>
                </div>
                <Switch
                  checked={preferences.recommendations}
                  onCheckedChange={(checked) => updatePreference('recommendations', checked)}
                />
              </div>
            </div>
          </div>
        )}

        {/* Browser Support Info */}
        {!('Notification' in window) && (
          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              Your browser doesn't support push notifications. Please use a modern browser like Chrome, Firefox, or Safari.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
