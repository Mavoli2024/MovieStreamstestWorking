/**
 * Subscription Details Component
 * 
 * Displays current subscription information with status, billing details,
 * and renewal information. Handles error states gracefully.
 */

import React from 'react';
import { useQuery } from '@tanstack/react-query';
import type {  Subscription, SubscriptionPlan  } from '@shared/schema';
import {  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle  } from '@/components/ui/card';
import {  Badge  } from '@/components/ui/badge';
import {  Button  } from '@/components/ui/button';
import {  FormApiError  } from '@/components/error-boundary/FormErrorBoundary';
import {  DataErrorBoundary  } from '@/components/error-boundary/DataErrorBoundary';
import {  Loader2, Calendar, CreditCard, CheckCircle, AlertCircle, RefreshCw  } from 'lucide-react';
import { format } from 'date-fns';

interface SubscriptionDetailsProps {
  userId: string;
  onManageSubscription?: () => void;
}

/**
 * Displays current subscription details with error handling
 */
export function SubscriptionDetails({ userId, onManageSubscription }: SubscriptionDetailsProps) {
  // Fetch subscription data
  const { 
    data: subscription, 
    isLoading: isLoadingSubscription, 
    error: subscriptionError,
    refetch: refetchSubscription 
  } = useQuery({
    queryKey: ['/api/subscriptions', userId],
    queryFn: async () => {
      const res = await fetch(`/api/subscriptions/user/${userId}`, {
        credentials: 'include'
      });
      
      if (!res.ok) throw new Error('Failed to fetch subscription');
      
      return res.json() as Promise<Subscription & {
        plan: SubscriptionPlan;
      }>;
    }
  });
  
  // Handle loading state
  if (isLoadingSubscription) {
    return (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  // Handle error state
  if (subscriptionError) {
    return (
      <FormApiError 
        message="Could not load subscription information" 
        onRetry={() => refetchSubscription()}
      />
    );
  }
  
  // If no subscription exists
  if (!subscription) {
    return (
      <Card className="border-dashed">
        <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle className="text-lg">No active subscription</CardTitle>
            <CardDescription>You don't have an active subscription plan</CardDescription>
          </div>
          <AlertCircle className="h-5 w-5 text-muted-foreground" />
        </CardHeader>
        <CardContent className="pt-4">
          <p className="text-sm text-muted-foreground mb-4">
            Subscribe to a plan to enjoy premium features and ad-free viewing.
          </p>
          <Button
            onClick={onManageSubscription}
            className="w-full"
          >
            Browse plans
          </Button>
        </CardContent>
      </Card>
    );
  }
  
  // Calculate subscription status and next billing date
  const now = new Date();
  const startDate = new Date(subscription.start_date);
  const endDate = subscription.end_date ? new Date(subscription.end_date) : null;
  const isActive = subscription.is_active && (!endDate || endDate > now);
  
  return (
    <DataErrorBoundary
      onReset={() => refetchSubscription()}
      resourceName="subscription details"
    >
      <Card>
        <CardHeader className="flex-row items-center justify-between space-y-0 pb-2">
          <div>
            <CardTitle className="text-lg">{subscription.plan.name} Plan</CardTitle>
            <CardDescription>
              {isActive 
                ? 'Your current subscription plan'
                : 'Your subscription has ended'
              }
            </CardDescription>
          </div>
          <Badge variant={isActive ? "default" : "outline"}>
            {isActive ? 'Active' : 'Inactive'}
          </Badge>
        </CardHeader>
        
        <CardContent className="pt-4">
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  Start date
                </span>
                <span className="text-sm font-medium">
                  {format(startDate, 'dd MMM yyyy')}
                </span>
              </div>
              
              <div className="flex flex-col">
                <span className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  {isActive ? 'Renewal date' : 'End date'}
                </span>
                <span className="text-sm font-medium">
                  {endDate 
                    ? format(endDate, 'dd MMM yyyy')
                    : 'Auto-renewal'
                  }
                </span>
              </div>
            </div>
            
            <div className="pt-2">
              <span className="text-xs text-muted-foreground mb-1 flex items-center gap-1">
                <CreditCard className="h-3 w-3" />
                Plan details
              </span>
              <div className="bg-muted/40 rounded-md p-3 mt-1">
                <div className="flex justify-between items-center">
                  <span className="text-sm">Price</span>
                  <span className="font-medium">R{(Number(subscription.plan.price) / 100).toFixed(2)}</span>
                </div>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-sm">Video quality</span>
                  <span className="font-medium">{subscription.plan.video_quality}</span>
                </div>
                
                <div className="flex justify-between items-center mt-2">
                  <span className="text-sm">Max devices</span>
                  <span className="font-medium">{subscription.plan.max_devices}</span>
                </div>
                
                {subscription.plan.features && (
                  <div className="mt-3 pt-3 border-t border-muted">
                    <span className="text-xs font-medium">Features</span>
                    <ul className="mt-1 space-y-1">
                      {(subscription.plan.features as string[]).map((feature, i) => (
                        <li key={i} className="text-xs flex items-start gap-1.5">
                          <CheckCircle className="h-3 w-3 text-success mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="flex justify-between pt-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => refetchSubscription()}
            className="gap-1"
          >
            <RefreshCw className="h-3.5 w-3.5" />
            <span>Refresh</span>
          </Button>
          
          <Button
            size="sm"
            onClick={onManageSubscription}
          >
            {isActive ? 'Manage subscription' : 'Renew subscription'}
          </Button>
        </CardFooter>
      </Card>
    </DataErrorBoundary>
  );
}