import { BunnyVideoMetadata, extractBunnyGuid, formatFileSize, formatVideoLength, getVideoMetadata } from "@/lib/bunny-api";
import type {  Video  } from "@shared/schema";
import {  Clock, Eye, FileText, Film, Play, VideoIcon  } from "lucide-react";
import { useEffect, useState } from "react";
import { logger } from '@shared/logger';

interface BunnyContentCardProps {
  video: Video;
  onClick?: (videoId: string) => void;
}

/**
 * A content card that displays video information exactly like BunnyStream
 */
export function BunnyContentCard({ video, onClick }: BunnyContentCardProps) {
  const [metadata, setMetadata] = useState<BunnyVideoMetadata | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    const fetchMetadata = async () => {
      if (!video.video_url) {
        setError("No video URL available");
        setIsLoading(false);
        return;
      }
      
      const guid = extractBunnyGuid(video.video_url);
      if (!guid) {
        setError("Invalid video URL");
        setIsLoading(false);
        return;
      }
      
      try {
        const data = await getVideoMetadata(guid);
        setMetadata(data);
      } catch (err) {
        setError("Failed to load video metadata");
        logger.api("Error fetching video metadata:", { arg1: err });
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchMetadata();
  }, [video.video_url]);
  
  const handleClick = () => {
    if (onClick) {
      onClick(video.id);
    } else {
      window.location.href = `/watch/${video.id}`;
    }
  };
  
  return (
    <button 
      className="bunny-content-card w-full bg-card rounded-md overflow-hidden shadow-lg transition-transform hover:scale-105 text-left focus:outline-primary" 
      onClick={handleClick}
      aria-label={`Watch ${video.title}`}
    >
      <div className="relative">
        {/* Thumbnail with overlay */}
        <div className="aspect-video w-full bg-black relative">
          {isLoading ? (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : error ? (
            <div className="absolute inset-0 flex items-center justify-center bg-card">
              <div className="text-center p-4">
                <VideoIcon className="h-10 w-10 mx-auto mb-2 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">{error}</p>
              </div>
            </div>
          ) : (
            <>
              {/* Bunny's actual thumbnail */}
              <img 
                src={metadata?.thumbnailUrl} 
                alt={video.title} 
                className="w-full h-full object-cover"
                onError={(e) => {
                  e.currentTarget.onerror = null;
                  e.currentTarget.src = `/api/videos/${video.id}/thumbnail`;
                }}
              />
              
              {/* View count overlay */}
              <div className="absolute top-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded flex items-center">
                <Eye className="h-3 w-3 mr-1" />
                {metadata?.views || 0} views
              </div>
              
              {/* Play button overlay on hover */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity bg-black/30">
                <div className="rounded-full bg-primary p-3">
                  <Play className="h-6 w-6 text-white" fill="white" />
                </div>
              </div>
            </>
          )}
        </div>
        
        {/* Video info bar */}
        <div className="p-3 bg-card">
          <h3 className="font-medium text-sm line-clamp-1">{video.title}</h3>
          
          <div className="mt-2 flex flex-wrap gap-y-1 text-xs text-muted-foreground">
            {metadata && (
              <>
                <div className="flex items-center mr-3">
                  <Clock className="h-3 w-3 mr-1" />
                  {formatVideoLength(metadata.length)}
                </div>
                <div className="flex items-center mr-3">
                  <FileText className="h-3 w-3 mr-1" />
                  {formatFileSize(metadata.storageSize)}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </button>
  );
}