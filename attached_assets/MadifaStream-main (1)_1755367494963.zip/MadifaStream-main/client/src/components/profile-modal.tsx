import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiClient, queryKeys } from "@/lib/api";
import { profileColors } from "@/constants/colors";
import type { Profile } from "@shared/schema";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { LogOut, Pencil, Settings, User, UserPlus, X } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useLocation } from "wouter";

interface ProfileModalProps {
  onClose: () => void;
  onProfileSelect?: (profileId: string) => void;
}

export function ProfileModal({ onClose, onProfileSelect }: ProfileModalProps) {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [location, navigate] = useLocation();
  const [isEditMode, setIsEditMode] = useState(false);
  const [showAddProfile, setShowAddProfile] = useState(false);
  const [newProfileName, setNewProfileName] = useState("");
  const [isKidsProfile, setIsKidsProfile] = useState(false);
  const [selectedColor, setSelectedColor] = useState(profileColors[0]);
  const mainModalRef = useRef<HTMLDivElement>(null);
  const addProfileModalRef = useRef<HTMLDivElement>(null);

  // Fetch user profiles
  const { data: profiles = [], isLoading } = useQuery<Profile[]>({
    queryKey: queryKeys.profiles.all(user?.id),
    queryFn: () => apiClient.get<Profile[]>("/api/profiles"),
    enabled: !!user,
  });

  const queryClient = useQueryClient();

  // Create profile mutation
  const createProfileMutation = useMutation({
    mutationFn: (profileData: { name: string; avatarColor: string; isKids: boolean }) =>
      apiClient.post("/api/profiles", profileData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.profiles.all(user?.id) });
      setShowAddProfile(false);
      setNewProfileName("");
      setIsKidsProfile(false);
      setSelectedColor(profileColors[0]);
      toast({
        title: "Profile created",
        description: "Your new profile has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Profile creation failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Delete profile mutation
  const deleteProfileMutation = useMutation({
    mutationFn: (profileId: string) =>
      apiClient.delete(`/api/profiles/${profileId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.profiles.all(user?.id) });
      setIsEditMode(false);
      toast({
        title: "Profile deleted",
        description: "The profile has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Profile deletion failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const handleProfileSelect = (profileId: string) => {
    if (isEditMode) return;

    if (onProfileSelect) {
      onProfileSelect(profileId);
    }
    onClose();
  };

  const handleCreateProfile = (e: React.FormEvent) => {
    e.preventDefault();

    if (!newProfileName.trim()) {
      toast({
        title: "Profile name required",
        description: "Please enter a name for the profile.",
        variant: "destructive",
      });
      return;
    }

    createProfileMutation.mutate({
      name: newProfileName,
      avatarColor: selectedColor,
      isKids: isKidsProfile,
    });
  };

  const handleDeleteProfile = (profileId: string) => {
    // TODO: Replace with custom AlertDialog component
    if (confirm("Are you sure you want to delete this profile? This action cannot be undone.")) {
      deleteProfileMutation.mutate(profileId);
    }
  };

  const handleLogout = () => {
    logoutMutation.mutate(undefined);
    onClose();
  };

  useEffect(() => {
    if (showAddProfile) {
      addProfileModalRef.current?.focus();
    } else {
      mainModalRef.current?.focus();
    }
  }, [showAddProfile]);

  if (showAddProfile) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50" onClick={onClose}>
        <div 
          ref={addProfileModalRef}
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-profile-title"
          tabIndex={-1}
          className="bg-card rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto outline-none" 
          onClick={(e) => e.stopPropagation()}
        >
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 id="add-profile-title" className="text-2xl font-bold">Add Profile</h2>
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:text-primary"
                onClick={() => setShowAddProfile(false)}
              >
                <X />
              </Button>
            </div>

            <form onSubmit={handleCreateProfile}>
              <div className="flex flex-col items-center mb-6">
                <div
                  className="w-24 h-24 rounded-md flex items-center justify-center mb-4"
                  style={{ backgroundColor: selectedColor }}
                >
                  <User className="h-10 w-10 text-white" />
                </div>

                <div className="flex gap-2 mb-4">
                  {profileColors.map(color => (
                    <button   
                      key={color}
                      type="button"
                      className={`w-6 h-6 rounded-full ${selectedColor === color ? 'ring-2 ring-white' : ''}`}
                      style={{ backgroundColor: color }}
                      onClick={() => setSelectedColor(color)}
                    />
                  ))}
                </div>

                <div className="w-full space-y-4">
                  <div>
                    <Label htmlFor="profileName" className="text-sm text-gray-400">Profile Name</Label>
                    <Input
                      id="profileName"
                      value={newProfileName}
                      onChange={(e) => setNewProfileName(e.target.value)}
                      placeholder="Enter a profile name"
                      className="bg-gray-700 border-gray-600 mt-1"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="kidsProfile" className="text-sm text-gray-400">Kids Profile</Label>
                    <Switch
                      id="kidsProfile"
                      checked={isKidsProfile}
                      onCheckedChange={setIsKidsProfile}
                    />
                  </div>

                  {isKidsProfile && (
                    <p className="text-xs text-gray-400">
                      This profile will only have access to movies and TV shows that are appropriate for children.
                    </p>
                  )}
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowAddProfile(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createProfileMutation.isPending}
                >
                  {createProfileMutation.isPending ? (
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-b-2 border-white mr-2"></div>
                      Creating...
                    </div>
                  ) : (
                    "Save Profile"
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50" onClick={onClose}>
      <div 
        ref={mainModalRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="profile-modal-title"
        tabIndex={-1}
        className="bg-card rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto outline-none" 
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 id="profile-modal-title" className="text-2xl font-bold">{isEditMode ? "Manage Profiles" : "Who's Watching?"}</h2>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:text-primary"
              onClick={onClose}
            >
              <X />
            </Button>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-10">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-6 mb-8">
                {profiles.map((profile) => {
                  const isSelectable = !isEditMode;
                  return (
                    <div
                      key={profile.id}
                      role={isSelectable ? 'button' : undefined}
                      tabIndex={isSelectable ? 0 : -1}
                      aria-label={`Select profile ${profile.display_name}`}
                      className={`flex flex-col items-center ${isSelectable ? 'cursor-pointer group focus:outline-primary' : ''}`}
                      onClick={() => isSelectable && handleProfileSelect(profile.id)}
                      onKeyDown={(e) => {
                        if (isSelectable && (e.key === 'Enter' || e.key === ' ')) {
                          e.preventDefault();
                          handleProfileSelect(profile.id);
                        }
                      }}
                    >
                      <div className="relative">
                        <div 
                          className="w-24 h-24 rounded-md flex items-center justify-center group-hover:ring-2 group-hover:ring-white transition-shadow"
                          style={{ backgroundColor: profile.avatarColor || '#f97316' }}
                        >
                          <User className="h-10 w-10 text-white" />
                        </div>

                        {isEditMode && (
                          <div 
                            role="button"
                            tabIndex={0}
                            aria-label={`Delete profile ${profile.display_name}`}
                            className="absolute inset-0 bg-black bg-opacity-70 flex flex-col items-center justify-center cursor-pointer focus:outline-primary"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteProfile(profile.id);
                            }}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' || e.key === ' ') {
                                e.stopPropagation();
                                e.preventDefault();
                                handleDeleteProfile(profile.id);
                              }
                            }}
                          >
                            <button className="text-red-500 hover:text-red-400">
                              <X className="h-6 w-6"/>
                            </button>
                            <span className="text-xs mt-1 text-red-400">Delete</span>
                          </div>
                        )}
                      </div>
                      <span className="mt-2 text-gray-400 group-hover:text-white">{profile.display_name}</span>
                    </div>
                )})}

                {profiles.length < 5 && (
                  <button 
                    className="flex flex-col items-center cursor-pointer group focus:outline-primary" 
                    onClick={() => setShowAddProfile(true)}
                    aria-label="Add a new profile"
                  >
                    <div className="w-24 h-24 rounded-md flex items-center justify-center bg-gray-700 group-hover:bg-gray-600 transition-colors">
                      <UserPlus className="h-10 w-10 text-white" />
                    </div>
                    <span className="mt-2 text-gray-400 group-hover:text-white">Add Profile</span>
                  </button>
                )}
              </div>

              <div className="border-t border-gray-700 pt-6">
                {!isEditMode ? (
                  <>
                    <Button
                      variant="ghost"
                      className="flex items-center text-gray-400 hover:text-white mb-4 w-full justify-start"
                      onClick={() => setIsEditMode(true)}
                    >
                      <Pencil className="mr-2 h-4 w-4" />
                      <span>Manage Profiles</span>
                    </Button>

                    <Button
                      variant="ghost"
                      className="flex items-center text-gray-400 hover:text-white mb-4 w-full justify-start"
                      onClick={() => navigate("/profile/settings")}
                    >
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Account Settings</span>
                    </Button>

                    <Button
                      variant="ghost"
                      className="flex items-center text-gray-400 hover:text-white w-full justify-start"
                      onClick={handleLogout}
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      <span>Sign Out</span>
                    </Button>
                  </>
                ) : (
                  <Button
                    variant="default"
                    className="w-full"
                    onClick={() => setIsEditMode(false)}
                  >
                    Done
                  </Button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
