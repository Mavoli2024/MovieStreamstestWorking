import {  Helmet  } from 'react-helmet-async';

interface SEOHeadProps {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
  type?: 'website' | 'video' | 'article';
  video?: {
    url: string;
    duration?: number;
    thumbnail?: string;
  };
  noIndex?: boolean;
}

export function SEOHead({
  title = 'MadifaStream - Premium South African Streaming',
  description = 'Watch the best South African movies, series, and documentaries. Premium streaming platform with HD quality and offline downloads.',
  image = '/og-image.png',
  url,
  type = 'website',
  video,
  noIndex = false
}: SEOHeadProps) {
  const fullTitle = title.includes('MadifaStream') ? title : `${title} | MadifaStream`;
  const canonicalUrl = url || window.location.href;

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content="South African streaming, movies, series, documentaries, HD streaming, offline downloads" />
      
      {/* Canonical URL */}
      <link rel="canonical" href={canonicalUrl} />
      
      {/* Robots */}
      {noIndex && <meta name="robots" content="noindex,nofollow" />}
      
      {/* Open Graph */}
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:image" content={image} />
      <meta property="og:url" content={canonicalUrl} />
      <meta property="og:type" content={type} />
      <meta property="og:site_name" content="MadifaStream" />
      <meta property="og:locale" content="en_ZA" />
      
      {/* Video specific Open Graph */}
      {video && (
        <>
          <meta property="og:video" content={video.url} />
          <meta property="og:video:type" content="video/mp4" />
          <meta property="og:video:width" content="1920" />
          <meta property="og:video:height" content="1080" />
          {video.duration && <meta property="og:video:duration" content={video.duration.toString()} />}
          {video.thumbnail && <meta property="og:image" content={video.thumbnail} />}
        </>
      )}
      
      {/* Twitter Card */}
      <meta name="twitter:card" content={video ? "player" : "summary_large_image"} />
      <meta name="twitter:site" content="@MadifaStream" />
      <meta name="twitter:creator" content="@MadifaStream" />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={image} />
      
      {video && (
        <>
          <meta name="twitter:player" content={video.url} />
          <meta name="twitter:player:width" content="1920" />
          <meta name="twitter:player:height" content="1080" />
        </>
      )}
      
      {/* App Links for Mobile */}
      <meta property="al:android:package" content="co.za.madifa.app" />
      <meta property="al:android:app_name" content="MadifaStream" />
      <meta property="al:android:url" content={canonicalUrl} />
      
      {/* Schema.org JSON-LD */}
      <script type="application/ld+json">
        {JSON.stringify({
          "@context": "https://schema.org",
          "@type": type === 'video' ? 'VideoObject' : 'WebSite',
          "name": fullTitle,
          "description": description,
          "url": canonicalUrl,
          "image": image,
          ...(type === 'website' && {
            "potentialAction": {
              "@type": "SearchAction",
              "target": {
                "@type": "EntryPoint",
                "urlTemplate": `${window.location.origin}/search?q={search_term_string}`
              },
              "query-input": "required name=search_term_string"
            }
          }),
          ...(video && {
            "contentUrl": video.url,
            "thumbnailUrl": video.thumbnail || image,
            "uploadDate": new Date().toISOString(),
            "duration": video.duration ? `PT${video.duration}S` : undefined
          })
        })}
      </script>
      
      {/* Favicon and App Icons */}
      <link rel="icon" type="image/x-icon" href="/favicon.ico" />
      <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
      <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
      <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
      <link rel="manifest" href="/manifest.json" />
      <meta name="theme-color" content="#000000" />
      <meta name="apple-mobile-web-app-capable" content="yes" />
      <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
      
      {/* Preconnect to external domains */}
      <link rel="preconnect" href="https://fonts.googleapis.com" />
      <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
      <link rel="preconnect" href="https://vz-685277f9-aa1.b-cdn.net" />
      <link rel="dns-prefetch" href="//iframe.mediadelivery.net" />
    </Helmet>
  );
} 