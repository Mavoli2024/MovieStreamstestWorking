/**
 * Registration Form Component
 * 
 * A complete user registration form with validation, error handling, and user feedback
 * using our enhanced form system.
 */

import React, { useState } from 'react';
import { EnhancedForm } from '@/components/form/enhanced-form';
import { FormInput } from '@/components/form/form-input';
import { Button } from '@/components/ui/button';
import { authSchemas, RegisterFormValues } from '@/lib/form-validation';
import { useFormSubmission } from '@/lib/form-submission';
import FormErrorBoundary, { FormApiError, FormValidationError } from '@/components/error-boundary/FormErrorBoundary';
import { Link } from 'wouter';
import { AtSign, User, Lock, Loader2, Eye, EyeOff, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface RegisterFormProps {
  onSuccess?: () => void;
  redirectTo?: string;
}

/**
 * Registration form with validation and error handling
 */
export function RegisterForm({ onSuccess, redirectTo = '/login' }: RegisterFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const { toast } = useToast();
  
  // Form submission handler
  const { 
    submitForm, 
    isSubmitting, 
    formError, 
    fieldErrors,
    resetErrors
  } = useFormSubmission<{ success: boolean; message: string }>(
    async (data: RegisterFormValues) => {
      // Step 1: Register user in Supabase Auth
      const { data: supaData, error: supaError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          data: { username: data.username }
        }
      });
      if (supaError) {
        throw new Error(supaError.message || 'Supabase registration failed');
      }
      if (!supaData?.user?.id) {
        throw new Error('Supabase registration succeeded but no user data returned.');
      }
      // Step 2: Register user in local users table
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: data.username,
          email: data.email,
          authId: supaData.user.id
        }),
        credentials: 'include'
      });
      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.message || 'Registration failed');
      }
      return result;
    },
    {
      showToasts: false,
      onSuccess: (data) => {
        setSuccessMessage(data.message || 'Registration successful! Please check your email to verify your account.');
        
        toast({
          title: 'Account created!',
          description: 'Your account has been created successfully. Please check your email to verify your account.',
        });
        
        // Redirect after a short delay to allow the user to see the success message
        if (redirectTo) {
          setTimeout(() => {
            window.location.href = redirectTo;
          }, 3000);
        }
        
        if (onSuccess) {
          onSuccess();
        }
      }
    }
  );
  
  // Toggle password visibility
  const toggleShowPassword = () => setShowPassword(!showPassword);
  const toggleShowConfirmPassword = () => setShowConfirmPassword(!showConfirmPassword);
  
  // Format field errors for display
  const getValidationErrors = () => {
    const errors: string[] = [];
    Object.entries(fieldErrors).forEach(([field, message]) => {
      errors.push(`${field}: ${message}`);
    });
    return errors;
  };
  
  return (
    <FormErrorBoundary formName="registration" onReset={resetErrors}>
      {successMessage ? (
        <div className="bg-success/10 text-success p-4 rounded-lg border border-success/20 my-4">
          <div className="flex items-start gap-3">
            <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium">Registration Successful</h3>
              <p className="text-sm mt-1">{successMessage}</p>
              <p className="text-sm mt-2">Redirecting you to login...</p>
            </div>
          </div>
        </div>
      ) : (
        <EnhancedForm
          schema={authSchemas.registerSchema}
          onSubmit={submitForm}
          defaultValues={{
            email: '',
            username: '',
            password: '',
            confirmPassword: '',
            agreeTerms: false
          }}
          className="space-y-4"
          id="register-form"
        >
          {(form) => (
            <>
              {formError && (
                <FormApiError message={formError} />
              )}
              
              {Object.keys(fieldErrors).length > 0 && (
                <FormValidationError errors={getValidationErrors()} />
              )}
              
              <FormInput
                form={form}
                name="email"
                label="Email"
                type="email"
                leftIcon={<AtSign className="h-4 w-4" />}
                placeholder="Your email address"
                autoComplete="email"
                requiredIndicator
              />
              
              <FormInput
                form={form}
                name="username"
                label="Username"
                leftIcon={<User className="h-4 w-4" />}
                placeholder="Choose a username"
                autoComplete="username"
                helperText="This will be visible to other users"
                requiredIndicator
              />
              
              <FormInput
                form={form}
                name="password"
                label="Password"
                type={showPassword ? 'text' : 'password'}
                leftIcon={<Lock className="h-4 w-4" />}
                rightIcon={
                  <button 
                    type="button"
                    onClick={toggleShowPassword}
                    className="focus:outline-none"
                    tabIndex={-1}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                }
                placeholder="Create a strong password"
                autoComplete="new-password"
                helperText="At least 8 characters with uppercase, lowercase & numbers"
                requiredIndicator
              />
              
              <FormInput
                form={form}
                name="confirmPassword"
                label="Confirm Password"
                type={showConfirmPassword ? 'text' : 'password'}
                leftIcon={<Lock className="h-4 w-4" />}
                rightIcon={
                  <button 
                    type="button"
                    onClick={toggleShowConfirmPassword}
                    className="focus:outline-none"
                    tabIndex={-1}
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                }
                placeholder="Confirm your password"
                autoComplete="new-password"
                requiredIndicator
              />
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="agree-terms"
                  className="rounded border-gray-300 text-primary focus:ring-primary"
                  {...(form as any).register('agreeTerms')}
                />
                <label htmlFor="agree-terms" className="text-sm text-gray-600">
                  I agree to the{' '}
                  <Link href="/terms" className="text-primary hover:underline">
                    Terms of Service
                  </Link>{' '}
                  and{' '}
                  <Link href="/privacy" className="text-primary hover:underline">
                    Privacy Policy
                  </Link>
                </label>
              </div>
              
              <Button
                type="submit"
                className="w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Creating account...
                  </>
                ) : 'Create Account'}
              </Button>
              
              <div className="text-center text-sm">
                <span className="text-gray-600">Already have an account?</span>{' '}
                <Link href="/auth?tab=login" className="text-primary hover:underline font-medium">
                  Sign in
                </Link>
              </div>
            </>
          )}
        </EnhancedForm>
      )}
    </FormErrorBoundary>
  );
}