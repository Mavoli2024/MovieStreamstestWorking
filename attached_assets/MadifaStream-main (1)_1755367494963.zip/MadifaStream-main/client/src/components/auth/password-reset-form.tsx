/**
 * Password Reset Form Components
 * 
 * Provides two forms:
 * 1. Request password reset form (enters email)
 * 2. Complete password reset form (enters new password)
 */

import React, { useState } from 'react';
import {  EnhancedForm  } from '@/components/form/enhanced-form';
import {  FormInput  } from '@/components/form/form-input';
import {  Button  } from '@/components/ui/button';
import { authSchemas, ResetPasswordRequestValues, ResetPasswordConfirmValues } from '@/lib/form-validation';
import { useFormSubmission } from '@/lib/form-submission';
import FormErrorBoundary, { FormApiError } from '@/components/error-boundary/FormErrorBoundary';
import {  Link  } from 'wouter';
import {  AtSign, Lock, Loader2, Eye, EyeOff, Check, ArrowLeft  } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

interface PasswordResetRequestFormProps {
  onSuccess?: () => void;
}

/**
 * Form to request a password reset by entering your email
 */
export function PasswordResetRequestForm({ onSuccess }: PasswordResetRequestFormProps) {
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const { toast } = useToast();
  
  // Form submission handler
  const { 
    submitForm, 
    isSubmitting, 
    formError, 
    resetErrors
  } = useFormSubmission<{ success: boolean; message: string }>(
    async (data: ResetPasswordRequestValues) => {
      const response = await fetch('/api/auth/reset-password/request', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Password reset request failed');
      }
      
      return result;
    },
    {
      showToasts: false,
      onSuccess: (data) => {
        setSuccessMessage(data.message || 'Password reset email sent! Please check your inbox.');
        toast({
          title: 'Email sent',
          description: 'If an account exists with that email, you will receive reset instructions.',
        });
        
        if (onSuccess) {
          onSuccess();
        }
      }
    }
  );
  
  return (
    <FormErrorBoundary formName="password reset request" onReset={resetErrors}>
      {successMessage ? (
        <div className="bg-success/10 text-success p-4 rounded-lg border border-success/20 my-4">
          <div className="flex items-start gap-3">
            <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium">Check your email</h3>
              <p className="text-sm mt-1">{successMessage}</p>
              <Link href="/auth?tab=login">
                <Button 
                  variant="link" 
                  className="p-0 mt-2 h-auto text-sm text-success"
                >
                  Return to login
                </Button>
              </Link>
            </div>
          </div>
        </div>
      ) : (
        <EnhancedForm
          schema={authSchemas.resetPasswordRequestSchema}
          onSubmit={submitForm}
          defaultValues={{
            email: '',
          }}
          className="space-y-4"
          id="password-reset-request-form"
        >
          {(form) => (
            <>
              {formError && (
                <FormApiError message={formError} />
              )}
              
              <div className="text-center mb-4">
                <h2 className="text-xl font-semibold">Reset your password</h2>
                <p className="text-sm text-gray-600 mt-1">
                  Enter your email address and we'll send you a link to reset your password
                </p>
              </div>
              
              <FormInput
                form={form}
                name="email"
                label="Email"
                type="email"
                leftIcon={<AtSign className="h-4 w-4" />}
                placeholder="Your email address"
                autoComplete="email"
                requiredIndicator
              />
              
              <Button
                type="submit"
                className="w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Sending...
                  </>
                ) : 'Send reset link'}
              </Button>
              
              <div className="text-center text-sm">
                <Link href="/auth?tab=login" className="text-primary hover:underline flex items-center justify-center gap-1 mt-2">
                  <ArrowLeft className="h-3 w-3" />
                  Back to login
                </Link>
              </div>
            </>
          )}
        </EnhancedForm>
      )}
    </FormErrorBoundary>
  );
}

interface PasswordResetConfirmFormProps {
  token: string;
  onSuccess?: () => void;
  redirectTo?: string;
}

/**
 * Form to complete a password reset by entering a new password
 */
export function PasswordResetConfirmForm({ token, onSuccess, redirectTo = '/login' }: PasswordResetConfirmFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const { toast } = useToast();
  
  // Form submission handler
  const { 
    submitForm, 
    isSubmitting, 
    formError, 
    resetErrors
  } = useFormSubmission<{ success: boolean; message: string }>(
    async (data: ResetPasswordConfirmValues) => {
      // Remove confirmPassword before sending to the server
      const { confirmPassword, ...submitData } = data;
      
      const response = await fetch('/api/auth/reset-password/confirm', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          ...submitData,
          token
        })
      });
      
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.message || 'Password reset failed');
      }
      
      return result;
    },
    {
      showToasts: false,
      onSuccess: (data) => {
        setSuccessMessage(data.message || 'Your password has been reset successfully!');
        
        toast({
          title: 'Password reset complete',
          description: 'Your password has been changed. You can now log in with your new password.',
        });
        
        // Redirect after a short delay to allow the user to see the success message
        if (redirectTo) {
          setTimeout(() => {
            window.location.href = redirectTo;
          }, 3000);
        }
        
        if (onSuccess) {
          onSuccess();
        }
      }
    }
  );
  
  // Toggle password visibility
  const toggleShowPassword = () => setShowPassword(!showPassword);
  const toggleShowConfirmPassword = () => setShowConfirmPassword(!showConfirmPassword);
  
  return (
    <FormErrorBoundary formName="password reset" onReset={resetErrors}>
      {successMessage ? (
        <div className="bg-success/10 text-success p-4 rounded-lg border border-success/20 my-4">
          <div className="flex items-start gap-3">
            <Check className="h-5 w-5 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="font-medium">Password Reset Complete</h3>
              <p className="text-sm mt-1">{successMessage}</p>
              <p className="text-sm mt-2">Redirecting you to login...</p>
            </div>
          </div>
        </div>
      ) : (
        <EnhancedForm
          schema={authSchemas.resetPasswordConfirmSchema}
          onSubmit={submitForm}
          defaultValues={{
            password: '',
            confirmPassword: '',
          }}
          className="space-y-4"
          id="password-reset-confirm-form"
        >
          {(form) => (
            <>
              {formError && (
                <FormApiError message={formError} />
              )}
              
              <div className="text-center mb-4">
                <h2 className="text-xl font-semibold">Create new password</h2>
                <p className="text-sm text-gray-600 mt-1">
                  Please enter your new password below
                </p>
              </div>
              
              <FormInput
                form={form}
                name="password"
                label="New Password"
                type={showPassword ? 'text' : 'password'}
                leftIcon={<Lock className="h-4 w-4" />}
                rightIcon={
                  <button 
                    type="button"
                    onClick={toggleShowPassword}
                    className="focus:outline-none"
                    tabIndex={-1}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                }
                placeholder="Create a strong password"
                autoComplete="new-password"
                helperText="At least 8 characters with uppercase, lowercase & numbers"
                requiredIndicator
              />
              
              <FormInput
                form={form}
                name="confirmPassword"
                label="Confirm New Password"
                type={showConfirmPassword ? 'text' : 'password'}
                leftIcon={<Lock className="h-4 w-4" />}
                rightIcon={
                  <button 
                    type="button"
                    onClick={toggleShowConfirmPassword}
                    className="focus:outline-none"
                    tabIndex={-1}
                  >
                    {showConfirmPassword ? (
                      <EyeOff className="h-4 w-4" />
                    ) : (
                      <Eye className="h-4 w-4" />
                    )}
                  </button>
                }
                placeholder="Confirm your new password"
                autoComplete="new-password"
                requiredIndicator
              />
              
              <Button
                type="submit"
                className="w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Resetting password...
                  </>
                ) : 'Reset Password'}
              </Button>
            </>
          )}
        </EnhancedForm>
      )}
    </FormErrorBoundary>
  );
}