import { useState } from 'react';
import {  Button  } from '@/components/ui/button';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { logger } from '@shared/logger';

interface GoogleSignInButtonProps {
  mode: 'signin' | 'signup';
  className?: string;
}

export function GoogleSignInButton({ mode, className = '' }: GoogleSignInButtonProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleGoogleSignIn = async () => {
    try {
      setIsLoading(true);
      
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/auth/callback`,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          }
        }
      });

      if (error) {
        throw error;
      }

      // The user will be redirected to Google for authentication
              logger.info('Redirecting to Google for authentication', data);
    } catch (error: unknown) {
      const err = error as Error;
      logger.error('Google sign-in error:', err);
      toast({
        title: 'Authentication Error',
        description: err.message || 'Failed to sign in with Google',
        variant: 'destructive',
      });
      setIsLoading(false);
    }
  };

  return (
    <Button
      type="button"
      variant="outline"
      className={`w-full flex items-center justify-center gap-2 ${className}`}
      onClick={handleGoogleSignIn}
      disabled={isLoading}
    >
      <svg
        xmlns="http://www.w3.org/2000/svg"
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="text-red-500"
      >
        <path d="M1 12c0-5 4-9 9-9s9 4 9 9-4 9-9 9-9-4-9-9z"></path>
        <path d="M8 12h8"></path>
        <path d="M12 8v8"></path>
      </svg>
      {isLoading
        ? 'Please wait...'
        : mode === 'signin'
        ? 'Sign in with Google'
        : 'Sign up with Google'}
    </Button>
  );
}