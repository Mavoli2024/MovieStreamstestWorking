import { Button } from "@/components/ui/button";
import { FcGoogle } from "react-icons/fc";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { Spinner } from "@/components/ui/spinner";
import { logger } from '@shared/logger';

interface SocialAuthButtonsProps {
  callbackUrl?: string;
}

export function SocialAuthButtons({ callbackUrl }: SocialAuthButtonsProps) {
  const { signInWithGoogle } = useAuth();
  const [isGoogleLoading, setIsGoogleLoading] = useState(false);

  const handleGoogleSignIn = async () => {
    try {
      setIsGoogleLoading(true);
      await signInWithGoogle();
    } catch (error) {
      logger.auth("Google sign in error:", { arg1: error });
      setIsGoogleLoading(false);
    }
  };

  return (
    <div className="grid gap-3">
      <Button 
        type="button" 
        variant="outline" 
        onClick={handleGoogleSignIn}
        disabled={isGoogleLoading}
        className="flex items-center justify-center gap-2"
      >
        {isGoogleLoading ? (
          <Spinner className="mr-2 h-4 w-4" />
        ) : (
          <FcGoogle className="h-5 w-5" />
        )}
        <span>Continue with Google</span>
      </Button>
    </div>
  );
}