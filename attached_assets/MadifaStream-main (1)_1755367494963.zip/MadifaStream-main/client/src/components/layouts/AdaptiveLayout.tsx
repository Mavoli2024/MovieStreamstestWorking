import { useState, useEffect, type ReactNode } from 'react';
import { RobustMainLayout } from './RobustMainLayout';
import { MobileMainLayout } from '../mobile/MobileMainLayout';

interface AdaptiveLayoutProps {
  children: ReactNode;
}

/**
 * Adaptive Layout Component
 * Detects device type and renders the appropriate layout
 * Prevents double navigation on mobile devices
 */
export function AdaptiveLayout({ children }: AdaptiveLayoutProps) {
  const [isMobile, setIsMobile] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const detectMobile = () => {
      // Check for mobile user agent
      const mobileUserAgent = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      
      // Check for touch capability and screen size
      const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
      const isSmallScreen = window.innerWidth <= 768;
      
      // Check for Capacitor environment (mobile app)
      const isCapacitor = !!(window as any).Capacitor;
      
      // Determine if mobile
      const mobile = mobileUserAgent || isCapacitor || (isTouchDevice && isSmallScreen);
      
      setIsMobile(mobile);
      setIsLoading(false);
    };

    // Initial detection
    detectMobile();

    // Listen for resize events to handle device orientation changes
    const handleResize = () => {
      detectMobile();
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Show minimal loading state during detection
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  // Render appropriate layout based on device detection
  if (isMobile) {
    return <MobileMainLayout>{children}</MobileMainLayout>;
  } else {
    return <RobustMainLayout>{children}</RobustMainLayout>;
  }
} 