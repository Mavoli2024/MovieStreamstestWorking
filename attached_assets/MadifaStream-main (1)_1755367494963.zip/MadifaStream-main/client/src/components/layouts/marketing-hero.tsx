import {  Logo  } from "@/components/logo";

export function MarketingHero() {
  return (
    <div className="hidden md:block md:flex-1 relative overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center" 
        style={{ 
          backgroundImage: "url('https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080')",
          filter: "brightness(0.7)"
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-r from-[#2D1B4E]/90 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-primary/30" />
      
      <div className="relative z-10 flex flex-col justify-center h-full p-12">
        <div className="flex items-center mb-8">
          <Logo className="h-24 w-24 rounded-full mr-4 shadow-lg ring-2 ring-secondary" />
          <div>
            <h2 className="text-4xl font-bold mb-2 text-white">
              <span className="text-secondary">Madifa</span>
            </h2>
            <p className="text-xl text-gray-200">Mzansi Movies Unboxed</p>
          </div>
        </div>
        
        <p className="text-xl text-gray-200 mb-6 max-w-md border-l-4 border-secondary pl-4">
          Experience the best of South African cinema with unlimited streaming access to exclusive videos and TV shows.
        </p>
        
        <ul className="space-y-4 mb-8">
          <li className="flex items-center text-gray-200 bg-primary/20 p-2 rounded-md backdrop-blur-sm">
            <svg className="w-5 h-5 mr-3 text-secondary" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            Watch on any device, anytime
          </li>
          <li className="flex items-center text-gray-200 bg-primary/20 p-2 rounded-md backdrop-blur-sm">
            <svg className="w-5 h-5 mr-3 text-secondary" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            Exclusive South African content
          </li>
          <li className="flex items-center text-gray-200 bg-primary/20 p-2 rounded-md backdrop-blur-sm">
            <svg className="w-5 h-5 mr-3 text-secondary" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            Create profiles for the whole family
          </li>
          <li className="flex items-center text-gray-200 bg-primary/20 p-2 rounded-md backdrop-blur-sm">
            <svg className="w-5 h-5 mr-3 text-secondary" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
            </svg>
            Premium plan for only R59/month
          </li>
        </ul>
        
        <div className="mt-2 bg-secondary/20 p-3 rounded-lg backdrop-blur-sm inline-block">
          <p className="text-sm text-white font-medium">
            Visit us at <span className="font-bold text-secondary">madifa.co.za</span>
          </p>
        </div>
      </div>
    </div>
  );
} 