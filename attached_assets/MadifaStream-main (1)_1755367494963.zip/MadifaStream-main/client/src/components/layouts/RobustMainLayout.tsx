import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Alert, AlertDescription } from '@/components/ui/alert';
import { RobustErrorBoundary } from '@/components/error-boundary/RobustErrorBoundary';
import { NetworkStatus } from '@/components/ui/robust-loading';
import { useAuth } from "@/hooks/use-auth";
import { useBunnyCollections } from "@/hooks/use-bunny-collections";
import { useSubscription } from "@/hooks/use-subscription";
import { robustApi } from '@/services/robust-api';
import { 
    Bookmark,
    Crown,
    Download,
    Film,
    Home,
    Menu,
    Search,
    AlertTriangle,
    Wifi,
    WifiOff,
    RefreshCw
} from "lucide-react";
import type { ReactNode } from "react";
import { Logo } from "../logo";
import { UserMenu } from "../navigation/user-menu";
import { Helmet } from "react-helmet-async";
import { logger } from '@shared/logger';

type MainLayoutProps = {
  children: ReactNode;
};

type NavigationLink = {
  label: string;
  href: string;
  icon?: React.ReactNode;
  count?: number;
  hideOnMobile?: boolean;
};

export function RobustMainLayout({ children }: MainLayoutProps) {
  const { user, loading: authLoading } = useAuth();
  const [location] = useLocation();
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [apiStatus, setApiStatus] = useState({ healthy: true, lastCheck: 0 });
  const [healthCheckError, setHealthCheckError] = useState<string | null>(null);
  const [retryingConnection, setRetryingConnection] = useState(false);

  const isAuthPage = location.startsWith("/auth");
  const isHomePage = location === "/home" || location === "/";
  
  const { data: collections, error: collectionsError } = useBunnyCollections();
  const { hasPremiumAccess, loading: subscriptionLoading } = useSubscription();

  // Monitor network status
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      logger.info('Network connection restored');
      checkApiHealth();
    };

    const handleOffline = () => {
      setIsOnline(false);
      logger.warn('Network connection lost');
      setApiStatus(prev => ({ ...prev, healthy: false }));
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // API health check with retry logic
  const checkApiHealth = async (showRetrying = false) => {
    if (!isOnline) return;

    if (showRetrying) {
      setRetryingConnection(true);
    }

    try {
      const healthy = await robustApi.healthCheck();
      const status = robustApi.getStatus();
      setApiStatus(status);
      setHealthCheckError(healthy ? null : 'API service unavailable');
      
      if (healthy) {
        logger.info('API health check successful');
      }
    } catch (error) {
      logger.error('Health check failed:', error);
      setHealthCheckError('Unable to connect to services');
      setApiStatus({ healthy: false, lastCheck: Date.now(), hasAuth: !!user });
    } finally {
      setRetryingConnection(false);
    }
  };

  // Periodic health check
  useEffect(() => {
    const interval = setInterval(() => checkApiHealth(), 60000); // Check every minute
    checkApiHealth(); // Initial check

    return () => clearInterval(interval);
  }, [user, isOnline]);

  // Main navigation links
  const mainNavLinks: NavigationLink[] = [
    { label: "Home", href: "/home", icon: <Home className="h-4 w-4 mr-2" /> },
    { label: "Browse", href: "/browse", icon: <Film className="h-4 w-4 mr-2" /> },
    ...(user ? [
      { label: "My List", href: "/my-list", icon: <Bookmark className="h-4 w-4 mr-2" /> },
      { label: "Downloads", href: "/downloads", icon: <Download className="h-4 w-4 mr-2" /> }
    ] : [])
  ];
  
  // Collection links for the mobile menu
  const collectionLinks: NavigationLink[] = 
    collections && !collectionsError ? 
      collections.map(collection => ({
        label: collection.name,
        href: `/browse?collection=${collection.guid}`,
        icon: <Film className="h-4 w-4 mr-2" />,
        count: collection.videoCount,
        hideOnMobile: true
      })) : [];
  
  // All navigation links for mobile menu
  const allNavigationLinks: NavigationLink[] = [
    ...mainNavLinks,
    ...collectionLinks,
  ];

  // System status checks
  const showSystemAlert = !isOnline || !apiStatus.healthy;
  const hasCollectionsError = collectionsError && isOnline;

  // SEO fallback
  const defaultTitle = "Madifa Films | Stream African Stories";
  const defaultDescription = "Watch premium African movies and series on Madifa Films.";

  const handleRetryConnection = () => {
    checkApiHealth(true);
  };

  return (
    <RobustErrorBoundary level="page">
      <>
        <Helmet>
          <title>{defaultTitle}</title>
          <meta name="description" content={defaultDescription} />
          <meta name="viewport" content="width=device-width, initial-scale=1" />
          <meta charSet="utf-8" />
        </Helmet>
        
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
          {/* Network Status Banner */}
          <NetworkStatus isOnline={isOnline} />

          {/* System Status Alert */}
          {showSystemAlert && isOnline && (
            <Alert className="rounded-none border-x-0 border-t-0 border-yellow-200 bg-yellow-50">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800 flex items-center justify-between">
                <span>{healthCheckError || 'Some features may not work properly. Our team is investigating.'}</span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleRetryConnection}
                  disabled={retryingConnection}
                  className="ml-4 text-yellow-800 border-yellow-300 hover:bg-yellow-100"
                >
                  {retryingConnection ? (
                    <>
                      <RefreshCw className="w-3 h-3 mr-1 animate-spin" />
                      Retrying...
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Retry
                    </>
                  )}
                </Button>
              </AlertDescription>
            </Alert>
          )}

          {/* Collections Error Alert */}
          {hasCollectionsError && (
            <Alert className="rounded-none border-x-0 border-orange-200 bg-orange-50">
              <AlertTriangle className="h-4 w-4 text-orange-600" />
              <AlertDescription className="text-orange-800">
                Unable to load content categories. Some browse features may be limited.
              </AlertDescription>
            </Alert>
          )}

          {/* Header with enhanced reliability */}
          <header className={`top-0 z-[60] w-full bg-black/80 backdrop-blur-lg border-b border-gray-800/50 ${isHomePage ? 'absolute' : 'sticky'}`}>
            <div className="container mx-auto px-4">
              <div className="flex h-16 items-center justify-between">
                {/* Logo with error boundary */}
                <RobustErrorBoundary level="component">
                  <div className="flex items-center space-x-3">
                    <Link href={user ? "/home" : "/"} className="flex items-center space-x-3 cursor-pointer">
                      <Logo className="h-8 w-8" />
                      <span className="hidden sm:block text-xl font-bold tracking-tight text-white">
                        Madifa Films
                      </span>
                    </Link>
                  </div>
                </RobustErrorBoundary>

                {/* Desktop Navigation with loading states */}
                <nav className="hidden md:flex items-center space-x-2">
                  {!isAuthPage && (
                    authLoading ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-4 h-4 border-2 border-gray-300 border-t-transparent rounded-full animate-spin"></div>
                        <span className="text-sm text-gray-400">Loading...</span>
                      </div>
                    ) : (
                      mainNavLinks.map((link) => (
                        <RobustErrorBoundary key={link.href} level="component">
                          <Link
                            href={link.href}
                            className={`text-sm font-medium transition-colors cursor-pointer flex items-center px-3 py-2 rounded-md ${
                              location === link.href || (link.href !== '/home' && location.startsWith(link.href))
                                ? "text-primary bg-primary/10"
                                : "text-white hover:text-primary hover:bg-white/5"
                            }`}
                          >
                            {link.icon}
                            {link.label}
                          </Link>
                        </RobustErrorBoundary>
                      ))
                    )
                  )}
                </nav>

                {/* Right-aligned items with status indicators */}
                <div className="flex items-center gap-4">
                  {/* Connection status indicator */}
                  <div className="hidden sm:flex items-center space-x-2">
                    {!isOnline ? (
                      <WifiOff className="h-4 w-4 text-red-500" title="Offline" />
                    ) : !apiStatus.healthy ? (
                      <AlertTriangle className="h-4 w-4 text-yellow-500" title="Service issues" />
                    ) : (
                      <Wifi className="h-4 w-4 text-green-500" title="Connected" />
                    )}
                  </div>

                  {/* Search Button */}
                  <RobustErrorBoundary level="component">
                    <Link href="/search">
                      <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                        <Search className="h-5 w-5" />
                      </Button>
                    </Link>
                  </RobustErrorBoundary>

                  {/* User Menu / Auth Buttons with loading states */}
                  <RobustErrorBoundary level="component">
                    {authLoading ? (
                      <Button variant="ghost" size="sm" disabled>
                        <div className="w-4 h-4 border-2 border-gray-300 border-t-transparent rounded-full animate-spin"></div>
                        <span className="ml-2 hidden sm:inline">Loading...</span>
                      </Button>
                    ) : user ? (
                      <UserMenu />
                    ) : !isAuthPage ? (
                      <div className="hidden sm:flex items-center space-x-2">
                        <Link href="/auth?tab=login">
                          <Button variant="ghost" className="text-white hover:bg-white/10">
                            Sign In
                          </Button>
                        </Link>
                        <Link href="/auth?tab=register">
                          <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                            Sign Up
                          </Button>
                        </Link>
                      </div>
                    ) : null}
                  </RobustErrorBoundary>

                  {/* Enhanced Mobile Menu */}
                  <div className="md:hidden">
                    <RobustErrorBoundary level="component">
                      <Sheet>
                        <SheetTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                            <Menu className="h-6 w-6" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </SheetTrigger>
                        <SheetContent side="left" className="w-[280px] bg-black/95 backdrop-blur-lg border-gray-800 text-white">
                          <div className="flex flex-col h-full">
                            {/* Mobile Logo */}
                            <div className="flex items-center space-x-3 p-4 border-b border-gray-800">
                              <Logo className="h-8 w-8" />
                              <span className="text-lg font-bold">Madifa Films</span>
                            </div>
                            
                            {/* Connection status for mobile */}
                            <div className="p-2 border-b border-gray-800">
                              <div className="flex items-center space-x-2 text-xs">
                                {!isOnline ? (
                                  <>
                                    <WifiOff className="h-3 w-3 text-red-500" />
                                    <span className="text-red-400">Offline</span>
                                  </>
                                ) : !apiStatus.healthy ? (
                                  <>
                                    <AlertTriangle className="h-3 w-3 text-yellow-500" />
                                    <span className="text-yellow-400">Service issues</span>
                                  </>
                                ) : (
                                  <>
                                    <Wifi className="h-3 w-3 text-green-500" />
                                    <span className="text-green-400">Connected</span>
                                  </>
                                )}
                              </div>
                            </div>
                            
                            {/* Mobile Navigation Links */}
                            <nav className="flex-1 space-y-2 p-2">
                              {!isAuthPage && (
                                authLoading ? (
                                  <div className="flex items-center justify-center py-8">
                                    <div className="w-6 h-6 border-2 border-gray-300 border-t-transparent rounded-full animate-spin"></div>
                                    <span className="ml-2 text-sm text-gray-400">Loading navigation...</span>
                                  </div>
                                ) : (
                                  allNavigationLinks
                                    .filter(link => !link.hideOnMobile)
                                    .map((link) => (
                                      <RobustErrorBoundary key={link.href} level="component">
                                        <Link 
                                          href={link.href}
                                          className={`flex items-center px-4 py-3 text-sm hover:bg-muted cursor-pointer transition-colors rounded-lg ${
                                            location === link.href || (link.href !== '/home' && location.startsWith(link.href))
                                              ? "bg-primary/10 text-primary"
                                              : "text-white hover:bg-white/5"
                                          }`}
                                        >
                                          {link.icon}
                                          <span>{link.label}</span>
                                          {link.count !== undefined && link.count > 0 && (
                                            <span className="ml-auto text-xs bg-primary/20 text-primary px-1.5 py-0.5 rounded-full">
                                              {link.count}
                                            </span>
                                          )}
                                        </Link>
                                      </RobustErrorBoundary>
                                    ))
                                )
                              )}
                              
                              {/* Mobile subscription status */}
                              <div className="p-2">
                                <RobustErrorBoundary level="component">
                                  {subscriptionLoading ? (
                                    <div className="p-4 rounded-lg bg-gray-800/60 text-center">
                                      <div className="w-4 h-4 border-2 border-gray-300 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                                      <span className="text-xs text-gray-400">Loading subscription...</span>
                                    </div>
                                  ) : (
                                    <div className={`p-4 rounded-lg ${hasPremiumAccess ? 'bg-gradient-to-r from-amber-500/20 to-yellow-500/20' : 'bg-gray-800/60'}`}>
                                      <div className="flex items-center gap-3 mb-3">
                                        <Crown className={`h-6 w-6 ${hasPremiumAccess ? 'text-amber-400' : 'text-gray-500'}`} />
                                        <div>
                                          <p className="font-semibold text-white">{hasPremiumAccess ? 'Premium' : 'Free Tier'}</p>
                                          <p className="text-xs text-gray-400">{hasPremiumAccess ? 'Full access to all content' : 'Limited access to trailers'}</p>
                                        </div>
                                      </div>
                                      {!hasPremiumAccess && (
                                        <Link href="/subscription">
                                          <Button size="sm" className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                                            Upgrade
                                          </Button>
                                        </Link>
                                      )}
                                    </div>
                                  )}
                                </RobustErrorBoundary>
                              </div>
                            </nav>
                            
                            {/* User profile section at bottom */}
                            {user && (
                              <div className="p-2 border-t border-gray-800">
                                <RobustErrorBoundary level="component">
                                  <UserMenu />
                                </RobustErrorBoundary>
                              </div>
                            )}
                          </div>
                        </SheetContent>
                      </Sheet>
                    </RobustErrorBoundary>
                  </div>
                </div>
              </div>
            </div>
          </header>

          {/* Main Content with comprehensive error boundary */}
          <main className="flex-grow">
            <RobustErrorBoundary level="page">
              {children}
            </RobustErrorBoundary>
          </main>

          {/* Enhanced Footer */}
          <footer className="bg-black/60 backdrop-blur-sm border-t border-gray-800/50 mt-auto">
            <RobustErrorBoundary level="component">
              <div className="container mx-auto px-4 py-8">
                {/* Main footer content */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                  {/* Brand section */}
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3">
                      <Logo className="h-8 w-8" />
                      <span className="text-xl font-bold">Madifa Films</span>
                    </div>
                    <p className="text-sm text-gray-400 max-w-xs">
                      Discover amazing South African content. Stream movies, series, and documentaries with premium quality.
                    </p>
                    
                    {/* System status in footer for development */}
                    {process.env.NODE_ENV === 'development' && (
                      <div className="text-xs text-gray-500 space-y-1">
                        <p>Status: {isOnline ? 'Online' : 'Offline'}</p>
                        <p>API: {apiStatus.healthy ? 'Healthy' : 'Issues'}</p>
                        <p>Auth: {user ? 'Authenticated' : 'Guest'}</p>
                      </div>
                    )}
                  </div>
                  
                  {/* Navigation sections */}
                  <div>
                    <h3 className="text-white font-medium mb-4">Discover</h3>
                    <ul className="space-y-2">
                      <li><Link href="/browse" className="text-gray-400 hover:text-secondary text-sm transition-colors">Browse Content</Link></li>
                      <li><Link href="/discover" className="text-gray-400 hover:text-secondary text-sm transition-colors">Discover</Link></li>
                      <li><Link href="/search" className="text-gray-400 hover:text-secondary text-sm transition-colors">Search</Link></li>
                      <li><Link href="/pricing" className="text-gray-400 hover:text-secondary text-sm transition-colors">Pricing</Link></li>
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-white font-medium mb-4">Account</h3>
                    <ul className="space-y-2">
                      {user ? (
                        <>
                          <li><Link href="/profile" className="text-gray-400 hover:text-secondary text-sm transition-colors">Profile</Link></li>
                          <li><Link href="/my-list" className="text-gray-400 hover:text-secondary text-sm transition-colors">My List</Link></li>
                          <li><Link href="/downloads" className="text-gray-400 hover:text-secondary text-sm transition-colors">Downloads</Link></li>
                          <li><Link href="/settings" className="text-gray-400 hover:text-secondary text-sm transition-colors">Settings</Link></li>
                        </>
                      ) : (
                        <>
                          <li><Link href="/auth?tab=login" className="text-gray-400 hover:text-secondary text-sm transition-colors">Sign In</Link></li>
                          <li><Link href="/auth?tab=register" className="text-gray-400 hover:text-secondary text-sm transition-colors">Sign Up</Link></li>
                        </>
                      )}
                    </ul>
                  </div>
                  
                  <div>
                    <h3 className="text-white font-medium mb-4">Support</h3>
                    <ul className="space-y-2">
                      <li><Link href="/feedback" className="text-gray-400 hover:text-secondary text-sm transition-colors">Feedback</Link></li>
                      <li><Link href="/accessibility" className="text-gray-400 hover:text-secondary text-sm transition-colors">Accessibility</Link></li>
                      <li><Link href="/sitemap" className="text-gray-400 hover:text-secondary text-sm transition-colors">Sitemap</Link></li>
                    </ul>
                  </div>
                </div>
                
                {/* Bottom Footer Links */}
                <div className="mt-8 pt-8 border-t border-gray-800 flex flex-wrap justify-between items-center text-sm text-gray-500 gap-4">
                  <p>&copy; {new Date().getFullYear()} Madifa Films. All rights reserved.</p>
                  <div className="flex items-center space-x-4">
                    <Link href="/terms" className="hover:text-secondary transition-colors">Terms</Link>
                    <Link href="/privacy" className="hover:text-secondary transition-colors">Privacy</Link>
                    <Link href="/cookies" className="hover:text-secondary transition-colors">Cookies</Link>
                    <Link href="/accessibility" className="hover:text-secondary transition-colors">Accessibility</Link>
                    <Link href="/sitemap" className="hover:text-secondary transition-colors">Sitemap</Link>
                    <Link href="/feedback" className="hover:text-secondary transition-colors">Feedback</Link>
                  </div>
                </div>
              </div>
            </RobustErrorBoundary>
          </footer>
        </div>
      </>
    </RobustErrorBoundary>
  );
}