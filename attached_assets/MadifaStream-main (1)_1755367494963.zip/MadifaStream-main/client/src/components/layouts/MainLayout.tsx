import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useAuth } from "@/hooks/use-auth";
import { useBunnyCollections } from "@/hooks/use-bunny-collections";
import { useSubscription } from "@/hooks/use-subscription";
import { 
    Bookmark,
    Crown,
    Download,
    Film,
    Home,
    Menu,
    Search
} from "lucide-react";
import type { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { Logo } from "../logo";
import { UserMenu } from "../navigation/user-menu";
import { Helmet } from "react-helmet-async";

type MainLayoutProps = {
  children: ReactNode;
};

// Define the navigation link type
type NavigationLink = {
  label: string;
  href: string;
  icon?: React.ReactNode;
  count?: number;
  hideOnMobile?: boolean;
};

export function MainLayout({ children }: MainLayoutProps) {
  const { user } = useAuth();
  const [location] = useLocation();
  // Determine if the current route is an authentication-related page
  // This prevents navigation elements from rendering on login / signup screens
  const isAuthPage = location.startsWith("/auth");
  const isHomePage = location === "/home" || location === "/";
  const { data: collections } = useBunnyCollections();
  const { hasPremiumAccess } = useSubscription();

  // CONSOLIDATED: Main navigation links - streamlined and standardized
  const mainNavLinks: NavigationLink[] = [
    { label: "Home", href: "/home", icon: <Home className="h-4 w-4 mr-2" /> },
    { label: "Browse", href: "/browse", icon: <Film className="h-4 w-4 mr-2" /> },
    // Only show these links if user is logged in
    ...(user ? [
      { label: "My List", href: "/my-list", icon: <Bookmark className="h-4 w-4 mr-2" /> },
      { label: "Downloads", href: "/downloads", icon: <Download className="h-4 w-4 mr-2" /> }
    ] : [])
  ];
  
  // Collection links for the mobile menu and dropdown
  const collectionLinks: NavigationLink[] = 
    collections ? 
      collections.map(collection => ({
        label: collection.name,
        href: `/browse?collection=${collection.guid}`,
        icon: <Film className="h-4 w-4 mr-2" />,
        count: collection.videoCount,
        hideOnMobile: true
      })) : [];
  
  // All navigation links for mobile menu
  const allNavigationLinks: NavigationLink[] = [
    ...mainNavLinks,
    ...collectionLinks,
  ];

  // Default SEO fallback
  const defaultTitle = "Madifa Films | Stream African Stories";
  const defaultDescription = "Watch premium African movies and series on Madifa Films.";

  return (
    <>
      <Helmet>
        <title>{defaultTitle}</title>
        <meta name="description" content={defaultDescription} />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta charSet="utf-8" />
      </Helmet>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">        {/* Header */}
        <header className={`top-0 z-[60] w-full bg-black/80 backdrop-blur-lg border-b border-gray-800/50 ${isHomePage ? 'absolute' : 'sticky'}`}>
          <div className="container mx-auto px-4">
            <div className="flex h-16 items-center justify-between">
              {/* Logo */}
              <div className="flex items-center space-x-3">
                <Link href={user ? "/home" : "/"} className="flex items-center space-x-3 cursor-pointer">
                  <Logo className="h-8 w-8" />
                  <span className="hidden sm:block text-xl font-bold tracking-tight text-white">
                    Madifa Films
                  </span>
                </Link>
              </div>

              {/* Desktop Navigation */}
              <nav className="hidden md:flex items-center space-x-2">
                {!isAuthPage && (
                  // Show main navigation links
                  mainNavLinks.map((link) => (
                    <Link
                      key={link.href}
                      href={link.href}
                      className={`text-sm font-medium transition-colors cursor-pointer flex items-center px-3 py-2 rounded-md ${
                        location === link.href || (link.href !== '/home' && location.startsWith(link.href))
                          ? "text-primary bg-primary/10"
                          : "text-white hover:text-primary hover:bg-white/5"
                      }`}
                    >
                      {link.icon}
                      {link.label}
                    </Link>
                  ))
                )}
              </nav>

              {/* Right-aligned items */}
              <div className="flex items-center gap-4">
                 {/* Search Button */}
                 <Link href="/search">
                    <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                      <Search className="h-5 w-5" />
                    </Button>
                 </Link>

                {/* User Menu / Auth Buttons */}
                {user ? (
                  <UserMenu />
                ) : !isAuthPage ? (
                  <div className="hidden sm:flex items-center space-x-2">
                    <Link href="/auth?tab=login">
                      <Button variant="ghost" className="text-white hover:bg-white/10">
                        Sign In
                      </Button>
                    </Link>
                    <Link href="/auth?tab=register">
                      <Button className="bg-primary text-primary-foreground hover:bg-primary/90">
                        Sign Up
                      </Button>
                    </Link>
                  </div>
                ) : null}

                {/* Mobile Menu */}
                <div className="md:hidden">
                  <Sheet>
                    <SheetTrigger asChild>
                      <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                        <Menu className="h-6 w-6" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </SheetTrigger>
                    <SheetContent side="left" className="w-[280px] bg-black/95 backdrop-blur-lg border-gray-800 text-white">
                      <div className="flex flex-col h-full">
                        {/* Mobile Logo */}
                        <div className="flex items-center space-x-3 p-4 border-b border-gray-800">
                          <Logo className="h-8 w-8" />
                          <span className="text-lg font-bold">Madifa Films</span>
                        </div>
                        
                        {/* Mobile Navigation Links */}
                        <nav className="flex-1 space-y-2 p-2">
                          {!isAuthPage && (
                            // Mobile navigation links
                            allNavigationLinks
                              .filter(link => !link.hideOnMobile)
                              .map((link) => (
                                <Link 
                                  key={link.href}
                                  href={link.href}
                                  className={`flex items-center px-4 py-3 text-sm hover:bg-muted cursor-pointer transition-colors rounded-lg ${
                                    location === link.href || (link.href !== '/home' && location.startsWith(link.href))
                                      ? "bg-primary/10 text-primary"
                                      : "text-white hover:bg-white/5"
                                  }`}
                                >
                                  {link.icon}
                                  <span>{link.label}</span>
                                  {link.count !== undefined && link.count > 0 && (
                                    <span className="ml-auto text-xs bg-primary/20 text-primary px-1.5 py-0.5 rounded-full">
                                      {link.count}
                                    </span>
                                  )}
                                </Link>
                              ))
                          )}
                          
                          {/* Mobile subscription status & action */}
                          <div className="p-2">
                            <div className={`p-4 rounded-lg ${hasPremiumAccess ? 'bg-gradient-to-r from-amber-500/20 to-yellow-500/20' : 'bg-gray-800/60'}`}>
                              <div className="flex items-center gap-3 mb-3">
                                <Crown className={`h-6 w-6 ${hasPremiumAccess ? 'text-amber-400' : 'text-gray-500'}`} />
                                <div>
                                  <p className="font-semibold text-white">{hasPremiumAccess ? 'Premium' : 'Free Tier'}</p>
                                  <p className="text-xs text-gray-400">{hasPremiumAccess ? 'Full access to all content' : 'Limited access to trailers'}</p>
                                </div>
                              </div>
                              {!hasPremiumAccess && (
                                <Link href="/subscription">
                                  <Button size="sm" className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                                    Upgrade
                                  </Button>
                                </Link>
                              )}
                            </div>
                          </div>
                        </nav>
                        
                        {/* User profile section at bottom */}
                        {user && (
                          <div className="p-2 border-t border-gray-800">
                            <UserMenu />
                          </div>
                        )}
                      </div>
                    </SheetContent>
                  </Sheet>
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-grow">{children}</main>

        {/* Footer */}
        <footer className="bg-black/60 backdrop-blur-sm border-t border-gray-800/50 mt-auto">
          <div className="container mx-auto px-4 py-8">
            {/* Main footer content */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {/* Brand section */}
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Logo className="h-8 w-8" />
                  <span className="text-xl font-bold">Madifa Films</span>
                </div>
                <p className="text-sm text-gray-400 max-w-xs">
                  Discover amazing South African content. Stream movies, series, and documentaries with premium quality.
                </p>
              </div>
              
              {/* Navigation sections */}
              <div>
                <h3 className="text-white font-medium mb-4">Discover</h3>
                <ul className="space-y-2">
                  <li><Link href="/browse" className="text-gray-400 hover:text-secondary text-sm transition-colors">Browse Content</Link></li>
                  <li><Link href="/discover" className="text-gray-400 hover:text-secondary text-sm transition-colors">Discover</Link></li>
                  <li><Link href="/search" className="text-gray-400 hover:text-secondary text-sm transition-colors">Search</Link></li>
                  <li><Link href="/pricing" className="text-gray-400 hover:text-secondary text-sm transition-colors">Pricing</Link></li>
                </ul>
              </div>
              
              <div>
                <h3 className="text-white font-medium mb-4">Account</h3>
                <ul className="space-y-2">
                  {user ? (
                    <>
                      <li><Link href="/profile" className="text-gray-400 hover:text-secondary text-sm transition-colors">Profile</Link></li>
                      <li><Link href="/my-list" className="text-gray-400 hover:text-secondary text-sm transition-colors">My List</Link></li>
                      <li><Link href="/downloads" className="text-gray-400 hover:text-secondary text-sm transition-colors">Downloads</Link></li>
                      <li><Link href="/settings" className="text-gray-400 hover:text-secondary text-sm transition-colors">Settings</Link></li>
                    </>
                  ) : (
                    <>
                      <li><Link href="/auth?tab=login" className="text-gray-400 hover:text-secondary text-sm transition-colors">Sign In</Link></li>
                      <li><Link href="/auth?tab=register" className="text-gray-400 hover:text-secondary text-sm transition-colors">Sign Up</Link></li>
                    </>
                  )}
                </ul>
              </div>
              
              <div>
                <h3 className="text-white font-medium mb-4">Support</h3>
                <ul className="space-y-2">
                  <li><Link href="/feedback" className="text-gray-400 hover:text-secondary text-sm transition-colors">Feedback</Link></li>
                  <li><Link href="/accessibility" className="text-gray-400 hover:text-secondary text-sm transition-colors">Accessibility</Link></li>
                  <li><Link href="/sitemap" className="text-gray-400 hover:text-secondary text-sm transition-colors">Sitemap</Link></li>
                </ul>
              </div>
            </div>
            
            {/* Bottom Footer Links */}
            <div className="mt-8 pt-8 border-t border-gray-800 flex flex-wrap justify-between items-center text-sm text-gray-500 gap-4">
              <p>&copy; {new Date().getFullYear()} Madifa Films. All rights reserved.</p>
              <div className="flex items-center space-x-4">
                <Link href="/terms" className="hover:text-secondary transition-colors">Terms</Link>
                <Link href="/privacy" className="hover:text-secondary transition-colors">Privacy</Link>
                <Link href="/cookies" className="hover:text-secondary transition-colors">Cookies</Link>
                <Link href="/accessibility" className="hover:text-secondary transition-colors">Accessibility</Link>
                <Link href="/sitemap" className="hover:text-secondary transition-colors">Sitemap</Link>
                <Link href="/feedback" className="hover:text-secondary transition-colors">Feedback</Link>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </>
  );
}
