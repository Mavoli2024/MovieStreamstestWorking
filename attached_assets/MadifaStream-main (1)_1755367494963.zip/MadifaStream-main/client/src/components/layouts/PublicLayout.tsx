import {  Logo  } from "@/components/logo";
import {  Button  } from "@/components/ui/button";
import {  Sheet, SheetContent, SheetTrigger  } from "@/components/ui/sheet";
import {  Link  } from "wouter";
import {  Menu  } from "lucide-react";

export function PublicLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between p-4 md:p-6 bg-gray-900/90 backdrop-blur-md border-b border-gray-800/50">
        <div className="flex items-center space-x-3">
          <Logo className="h-8 md:h-10 w-auto" />
          <h1 className="text-xl md:text-2xl font-bold tracking-tighter">Madifa</h1>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-6">
          <a href="#features" className="text-lg font-medium hover:text-primary transition-colors">Features</a>
          <a href="#pricing" className="text-lg font-medium hover:text-primary transition-colors">Pricing</a>
          <a href="#about" className="text-lg font-medium hover:text-primary transition-colors">About</a>
        </nav>

        {/* Desktop Auth Buttons */}
        <div className="hidden md:flex items-center space-x-4">
          <Link to="/auth">
            <Button variant="ghost" className="text-lg font-medium">Sign In</Button>
          </Link>
          <Link to="/auth">
            <Button className="font-semibold text-lg bg-primary hover:bg-primary/90">Sign Up Free</Button>
          </Link>
        </div>

        {/* Mobile Menu */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <Menu className="h-6 w-6" />
                <span className="sr-only">Open menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[280px] bg-gray-900/95 backdrop-blur-lg border-gray-800 text-white">
              <div className="flex flex-col h-full">
                {/* Mobile Logo */}
                <div className="flex items-center space-x-3 p-4 border-b border-gray-800">
                  <Logo className="h-8 w-8" />
                  <span className="text-lg font-bold">Madifa Films</span>
                </div>
                
                {/* Mobile Navigation Links */}
                <nav className="flex-1 space-y-2 p-4">
                  <a href="#features" className="block px-4 py-3 text-white hover:bg-white/5 rounded-lg transition-colors">Features</a>
                  <a href="#pricing" className="block px-4 py-3 text-white hover:bg-white/5 rounded-lg transition-colors">Pricing</a>
                  <a href="#about" className="block px-4 py-3 text-white hover:bg-white/5 rounded-lg transition-colors">About</a>
                </nav>
                
                {/* Mobile Auth Buttons */}
                <div className="p-4 border-t border-gray-800 space-y-3">
                  <Link to="/auth">
                    <Button variant="ghost" className="w-full text-white hover:bg-white/10">
                      Sign In
                    </Button>
                  </Link>
                  <Link to="/auth">
                    <Button className="w-full bg-primary hover:bg-primary/90">
                      Sign Up Free
                    </Button>
                  </Link>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="py-8 bg-gray-800 border-t border-gray-700">
        <div className="container mx-auto px-4 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Madifa. All Rights Reserved.</p>
          <div className="flex justify-center space-x-6 mt-4">
            <a href="#" className="hover:text-white">Terms of Service</a>
            <a href="#" className="hover:text-white">Privacy Policy</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
