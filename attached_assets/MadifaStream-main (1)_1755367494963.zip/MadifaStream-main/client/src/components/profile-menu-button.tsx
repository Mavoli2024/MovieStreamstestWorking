import { useState } from "react";
import {  Link  } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useSubscription } from "@/hooks/use-subscription";
import {
  Bell,
  Crown,
  Lock,
  LogOut,
  Settings,
  User as UserIcon,
} from "lucide-react";
import {  Button  } from "@/components/ui/button";

export function ProfileMenuButton() {
  const { user, logoutMutation } = useAuth();
  const { hasPremiumAccess } = useSubscription();
  const [isOpen, setIsOpen] = useState(false);

  if (!user) return null;

  return (
    <div className="relative">
      <Button
        variant="ghost"
        className="relative h-8 w-8 rounded-full overflow-hidden"
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="bg-primary flex items-center justify-center w-full h-full rounded-full">
          <UserIcon size={16} className="text-white" />
        </div>
      </Button>
      
      {isOpen && (
        <div className="absolute right-0 mt-2 w-56 bg-popover rounded-md shadow-md border border-border p-1 z-50">
          <div className="flex items-center justify-start p-2">
            <div className="flex flex-col space-y-1">
              {user?.username && (
                <p className="text-sm font-medium">{user.username}</p>
              )}
              <p className="text-xs text-muted-foreground">
                {hasPremiumAccess ? 'Premium Account' : 'Free Account'}
              </p>
            </div>
          </div>
          
          <div className="h-px bg-border my-1" />
          
          <Link href="/profile" onClick={() => setIsOpen(false)}>
            <div className="flex items-center px-2 py-1.5 text-sm hover:bg-accent rounded cursor-pointer">
              <UserIcon className="mr-2 h-4 w-4" />
              <span>Profile</span>
            </div>
          </Link>
          
          <Link href="/settings" onClick={() => setIsOpen(false)}>
            <div className="flex items-center px-2 py-1.5 text-sm hover:bg-accent rounded cursor-pointer">
              <Settings className="mr-2 h-4 w-4" />
              <span>Settings</span>
            </div>
          </Link>
          
          <div className="flex items-center px-2 py-1.5 text-sm hover:bg-accent rounded cursor-pointer">
            <Bell className="mr-2 h-4 w-4" />
            <span>Notifications</span>
          </div>
          
          <div className="h-px bg-border my-1" />
          
          <Link href="/subscription" onClick={() => setIsOpen(false)}>
            <div className="flex items-center px-2 py-1.5 text-sm hover:bg-accent rounded cursor-pointer">
              {hasPremiumAccess ? 
                <Crown className="mr-2 h-4 w-4 text-secondary" /> : 
                <Lock className="mr-2 h-4 w-4" />
              }
              <span>Subscription</span>
            </div>
          </Link>
          
          <div className="h-px bg-border my-1" />
          
          <div 
            className="flex items-center px-2 py-1.5 text-sm hover:bg-accent rounded cursor-pointer"
            onClick={() => {
              logoutMutation.mutate(undefined);
              setIsOpen(false);
            }}
          >
            <LogOut className="mr-2 h-4 w-4" />
            <span>Sign Out</span>
          </div>
        </div>
      )}
    </div>
  );
}