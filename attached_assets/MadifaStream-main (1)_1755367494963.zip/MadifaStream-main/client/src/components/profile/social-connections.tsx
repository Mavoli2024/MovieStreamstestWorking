import React, { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { logger } from '../../shared/logger.js';
import { Github, Twitter, Instagram, Linkedin, Link2, CheckCircle2 } from 'lucide-react';
import { SiGoogle } from 'react-icons/si';
import { supabase } from '@/lib/supabase';
import type { User } from '@supabase/supabase-js';

interface SocialConnection {
  provider: string;
  connected: boolean;
  email?: string;
  id?: string;
}

export function SocialConnections() {
  const [connections, setConnections] = useState<SocialConnection[]>([]);
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const loadUserAndConnections = async () => {
      try {
        setLoading(true);
        
        // Get the current user
        const { data: { user } } = await supabase.auth.getUser();
        setUser(user);

        if (user) {
          // Check which providers the user is connected to
          const googleConnected = user.app_metadata?.providers?.includes('google') || false;
          
          setConnections([
            {
              provider: 'google',
              connected: googleConnected,
              email: googleConnected ? user.email : undefined,
              id: user.id
            }
          ]);
        }
      } catch (error) {
        logger.error('Error loading user connections:', { arg1: error });
      } finally {
        setLoading(false);
      }
    };

    loadUserAndConnections();
  }, []);

  const connectProvider = async (provider: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithOAuth({
        provider: provider as 'google',
        options: {
          redirectTo: `${window.location.origin}/profile`,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          }
        }
      });

      if (error) throw error;
      
      // User will be redirected to provider auth page
      // console.log(`Connecting to ${provider}`, data);
    } catch (error: unknown) {
      toast({
        title: 'Connection Error',
        description: (error as any).message || `Failed to connect to ${provider}`,
        variant: 'destructive',
      });
    }
  };

  const disconnectProvider = async (provider: string) => {
    try {
      // This requires server-side API with admin privileges to unlink identities
      // Client-side unlinking is not supported directly by Supabase
      toast({
        title: 'Not Supported',
        description: `Unlinking ${provider} requires server-side implementation. Please contact support.`,
        variant: 'destructive',
      });
    } catch (error: unknown) {
      toast({
        title: 'Disconnection Error',
        description: (error as any).message || `Failed to disconnect from ${provider}`,
        variant: 'destructive',
      });
    }
  };

  const getProviderIcon = (provider: string) => {
    switch (provider) {
      case 'google':
        return <SiGoogle className="h-5 w-5" />;
      default:
        return null;
    }
  };

  const handleSocial = (e: React.ChangeEvent<HTMLInputElement>) => {
    // console.log('Social connection event', e);
  };

  if (loading) {
    return <div className="flex justify-center p-4">Loading social connections...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Social Connections</CardTitle>
        <CardDescription>
          Connect your account to social providers for easier login
        </CardDescription>
      </CardHeader>
      <CardContent>
        {connections.length === 0 ? (
          <p className="text-muted-foreground text-sm">No social connections available</p>
        ) : (
          <div className="space-y-4">
            {connections.map((connection) => (
              <div 
                key={connection.provider}
                className="flex items-center justify-between rounded-lg border p-4"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
                    {getProviderIcon(connection.provider)}
                  </div>
                  <div>
                    <p className="font-medium capitalize">{connection.provider}</p>
                    {connection.connected && connection.email && (
                      <p className="text-xs text-muted-foreground">{connection.email}</p>
                    )}
                  </div>
                </div>
                <Button
                  variant={connection.connected ? "destructive" : "outline"}
                  size="sm"
                  onClick={() => connection.connected 
                    ? disconnectProvider(connection.provider)
                    : connectProvider(connection.provider)
                  }
                >
                  {connection.connected ? "Disconnect" : "Connect"}
                </Button>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between border-t pt-4">
        <p className="text-xs text-muted-foreground">
          Connecting accounts allows for simplified login and account recovery
        </p>
      </CardFooter>
    </Card>
  );
}