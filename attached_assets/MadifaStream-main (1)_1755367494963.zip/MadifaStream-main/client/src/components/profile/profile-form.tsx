/**
 * Profile Update Form
 * 
 * A form for users to update their profile information
 * using our enhanced form validation system.
 */

import React from 'react';
import {  EnhancedForm  } from '@/components/form/enhanced-form';
import {  FormInput  } from '@/components/form/form-input';
import {  FormTextarea  } from '@/components/form/form-textarea';
import {  Button  } from '@/components/ui/button';
import { profileSchemas } from '@/lib/form-validation';
import { useFormSubmission, submitToApi } from '@/lib/form-submission';
import FormErrorBoundary, { FormApiError } from '@/components/error-boundary/FormErrorBoundary';
import type {  User  } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';
import {  Loader2, User as UserIcon, AtSign, Phone, InfoIcon  } from 'lucide-react';

interface ProfileUpdateFormProps {
  userId: string;
  onSuccess?: () => void;
}

/**
 * Profile update form with validation and error handling
 */
export function ProfileUpdateForm({ userId, onSuccess }: ProfileUpdateFormProps) {
  // Fetch current user profile data
  const { data: userProfile, isLoading, error } = useQuery({
    queryKey: ['/api/users', userId],
    queryFn: async () => {
      const res = await fetch(`/api/users/${userId}`, {
        credentials: 'include'
      });
      if (!res.ok) throw new Error('Failed to fetch user profile');
      return res.json() as Promise<User>;
    }
  });
  
  // Form submission handler
  const { 
    submitForm, 
    isSubmitting, 
    formError, 
    fieldErrors,
    resetErrors
  } = useFormSubmission(
    async (data) => {
      return submitToApi<User>(`/api/users/${userId}`, data, 'PATCH');
    },
    {
      successMessage: 'Profile updated successfully',
      errorMessage: 'Failed to update profile',
      showToasts: true,
      invalidateQueries: ['/api/users', userId],
      onSuccess
    }
  );
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  if (error || !userProfile) {
    return (
      <FormApiError 
        message="Could not load your profile information" 
        onRetry={() => window.location.reload()}
      />
    );
  }
  
  return (
    <FormErrorBoundary formName="profile" onReset={resetErrors}>
      <EnhancedForm
        schema={profileSchemas.profileUpdateSchema}
        onSubmit={submitForm}
        defaultValues={{
          username: userProfile.username || '',
          displayName: userProfile.displayName || userProfile.display_name || '',
          avatarColor: userProfile.avatarColor || ''
        }}
        className="space-y-4 relative"
      >
        {(form) => (
          <>
            {formError && (
              <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-md mb-4">
                {formError}
              </div>
            )}
            
            <div className="grid gap-6 md:grid-cols-2">
              <FormInput
                form={form}
                name="username"
                label="Username"
                leftIcon={<AtSign className="h-4 w-4" />}
                placeholder="Your unique username"
                helperText={fieldErrors.username || "This will be visible to other users"}
                requiredIndicator
              />
              
              <FormInput
                form={form}
                name="displayName"
                label="Display Name"
                leftIcon={<UserIcon className="h-4 w-4" />}
                placeholder="Your public display name"
                helperText={fieldErrors.displayName || "How you'll appear to others"}
              />
            </div>
            
            <div className="flex items-center space-x-4 mt-4 p-4 bg-muted/30 rounded-md">
              <InfoIcon className="h-5 w-5 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                You can customize your profile with a display name that appears to other users. 
                Your username is used for login purposes.
              </p>
            </div>
            
            <div className="flex justify-end space-x-3 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => form.reset()}
                disabled={isSubmitting}
              >
                Cancel
              </Button>
              
              <Button
                type="submit"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : 'Save Changes'}
              </Button>
            </div>
          </>
        )}
      </EnhancedForm>
    </FormErrorBoundary>
  );
}