/**
 * Subscription-Gated Video Player
 * 
 * Advanced video player that enforces subscription requirements for premium content
 * and provides trailer-to-video linking functionality
 */

import React, { useState } from 'react';
import { useAuth } from '@/hooks/use-auth';
import { useSubscription } from '@/hooks/use-subscription';
import {  ModernVideoPlayer  } from './ModernVideoPlayer';
import {  Button  } from '@/components/ui/button';
import {  Card, CardContent, CardDescription, CardHeader, CardTitle  } from '@/components/ui/card';
import {  Crown, Lock  } from 'lucide-react';

interface SubscriptionGatedPlayerProps {
  videoId: string;
  title: string;
  thumbnail?: string;
  isPremium?: boolean;
  onUpgrade?: () => void;
}

export function SubscriptionGatedPlayer({
  videoId,
  title,
  thumbnail,
  isPremium = false,
  onUpgrade,
}: SubscriptionGatedPlayerProps) {
  const { user } = useAuth();
  const { subscription, isLoading } = useSubscription();
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);

  // Check if user can access premium content
  const canAccessPremium = user && subscription?.isActive;

  // If content is not premium, show regular player
  if (!isPremium) {
    return (
      <ModernVideoPlayer
        videoId={videoId}
        title={title}
        thumbnail={thumbnail}
      />
    );
  }

  // If user can access premium content, show player
  if (canAccessPremium) {
    return (
      <ModernVideoPlayer
        videoId={videoId}
        title={title}
        thumbnail={thumbnail}
      />
    );
  }

  // Show subscription gate
  return (
    <div className="aspect-video bg-black rounded-lg relative overflow-hidden">
      {/* Background thumbnail */}
      {thumbnail && (
        <img
          src={thumbnail}
          alt={title}
          className="absolute inset-0 w-full h-full object-cover opacity-50 blur-sm"
        />
      )}
      
      {/* Overlay */}
      <div className="absolute inset-0 bg-black/70 flex items-center justify-center p-6">
        <Card className="max-w-md w-full bg-background/95 backdrop-blur">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Crown className="h-6 w-6 text-primary" />
            </div>
            <CardTitle className="flex items-center justify-center gap-2">
              <Lock className="h-5 w-5" />
              Premium Content
            </CardTitle>
            <CardDescription>
              This content is available exclusively for premium subscribers
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-4">
                Upgrade to Premium to enjoy unlimited access to our exclusive content library
              </p>
              
              <div className="space-y-2">
                <Button 
                  className="w-full" 
                  onClick={onUpgrade || (() => setShowUpgradePrompt(true))}
                >
                  <Crown className="mr-2 h-4 w-4" />
                  Upgrade to Premium
                </Button>
                
                {!user && (
                  <Button variant="outline" className="w-full">
                    Sign In
                  </Button>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}