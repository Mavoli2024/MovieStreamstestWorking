/**
 * Lazy Video Components
 * 
 * Lazy loading for video-related components with optimized loading states
 */

import React, { lazy, Suspense } from 'react';
import {  Loader2  } from 'lucide-react';

// Loading components
const VideoCardLoader = () => (
  <div className="aspect-[2/3] bg-muted rounded-lg animate-pulse">
    <div className="h-full flex items-center justify-center">
      <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
    </div>
  </div>
);

const VideoPlayerLoader = () => (
  <div className="aspect-video bg-black rounded-lg flex items-center justify-center">
    <div className="flex flex-col items-center gap-2 text-white">
      <Loader2 className="h-8 w-8 animate-spin" />
      <p className="text-sm">Loading player...</p>
    </div>
  </div>
);

const GridLoader = () => (
  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
    {Array.from({ length: 10 }).map((_, i) => (
      <VideoCardLoader key={i} />
    ))}
  </div>
);

// Lazy loaded components
export const LazyModernVideoPlayer = lazy(() => 
  import('@/components/video/ModernVideoPlayer').then(module => ({
    default: module.ModernVideoPlayer
  }))
);

export const LazyModernContentGrid = lazy(() => 
  import('@/components/content/ModernContentGrid').then(module => ({
    default: module.ModernContentGrid
  }))
);

export const LazyThumbnailImage = lazy(() => 
  import('./thumbnail-image').then(module => ({
    default: module.ThumbnailImage
  }))
);

export const LazyVideoMetadata = lazy(() => 
  import('./VideoMetadata').then(module => ({
    default: module.VideoMetadata
  }))
);

// CastManager is not implemented yet - placeholder for future feature
export const LazyCastManager = lazy(() => 
  Promise.resolve({ default: () => <div>Cast feature coming soon</div> })
);

// Component wrappers with loading states
export const ModernVideoPlayer: React.FC<any> = (props) => (
  <Suspense fallback={<VideoPlayerLoader />}>
    <LazyModernVideoPlayer {...props} />
  </Suspense>
);

export const ModernContentGrid: React.FC<any> = (props) => (
  <Suspense fallback={<GridLoader />}>
    <LazyModernContentGrid {...props} />
  </Suspense>
);

export const ThumbnailImage: React.FC<any> = (props) => (
  <Suspense fallback={<VideoCardLoader />}>
    <LazyThumbnailImage {...props} />
  </Suspense>
);

export const VideoMetadata: React.FC<any> = (props) => (
  <Suspense fallback={<div className="animate-pulse h-16 bg-muted rounded" />}>
    <LazyVideoMetadata {...props} />
  </Suspense>
);

export const CastManager: React.FC<any> = (props) => (
  <Suspense fallback={<div className="animate-pulse h-8 bg-muted rounded w-32" />}>
    <LazyCastManager {...props} />
  </Suspense>
);

// Preload functions
export const preloadVideoComponents = () => {
  if (typeof window !== 'undefined') {
    // Preload critical video components
    setTimeout(() => {
      import('@/components/video/ModernVideoPlayer');
      import('@/components/content/ModernContentGrid');
    }, 1000);
  }
};

// Initialize preloading
if (typeof window !== 'undefined') {
  // Preload on page load
  window.addEventListener('load', preloadVideoComponents);
} 