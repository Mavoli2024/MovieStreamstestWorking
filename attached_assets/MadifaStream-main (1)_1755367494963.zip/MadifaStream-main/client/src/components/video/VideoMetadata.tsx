import {  Badge  } from "@/components/ui/badge";
import {  Button  } from "@/components/ui/button";
import {  Crown, Play  } from "lucide-react";
import { Video } from "@/lib/supabase-api";

interface VideoMetadataProps {
  video: Video;
  onPlayClick?: () => void;
}

export const VideoMetadata = ({ video, onPlayClick }: VideoMetadataProps) => {
  const formatDuration = (duration: number) => {
    const hours = Math.floor(duration / 3600);
    const minutes = Math.floor((duration % 3600) / 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  return (
    <div className="mt-6">
      <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
        {video.title}
      </h1>
      
      <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted-foreground">
        {video.duration && (
          <span>{formatDuration(video.duration)}</span>
        )}
        {video.release_year && (
          <>
            <span className="text-gray-500">•</span>
            <span>{video.release_year}</span>
          </>
        )}
        {video.is_premium && (
          <>
            <span className="text-gray-500">•</span>
            <Badge className="bg-amber-500 text-black">
              <Crown className="mr-1 h-3 w-3" />
              Premium
            </Badge>
          </>
        )}
        {video.is_trailer && (
          <>
            <span className="text-gray-500">•</span>
            <Badge variant="secondary">Trailer</Badge>
          </>
        )}
      </div>
      
      {video.description && (
        <p className="mt-4 text-base text-foreground/80">
          {video.description}
        </p>
      )}

      <div className="mt-6">
        <Button size="lg" onClick={onPlayClick}>
          <Play className="mr-2 h-5 w-5" /> Play
        </Button>
      </div>
    </div>
  );
}; 