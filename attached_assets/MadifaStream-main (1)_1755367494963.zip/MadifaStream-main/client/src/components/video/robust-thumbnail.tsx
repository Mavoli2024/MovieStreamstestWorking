import { useState, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { logger } from '@shared/logger';

interface RobustThumbnailProps {
  videoId?: string;
  videoTitle: string;
  thumbnailUrl?: string;
  className?: string;
  alt?: string;
  width?: number;
  height?: number;
  priority?: boolean;
  variant?: 'grid' | 'hero' | 'list';
}

/**
 * RobustThumbnail - Centralized thumbnail component with comprehensive fallback system
 * 
 * Handles all thumbnail scenarios:
 * 1. Direct thumbnail URL (from database)
 * 2. API endpoint fallback (/api/videos/:id/thumbnail)
 * 3. Generated SVG placeholder
 * 
 * This replaces all other thumbnail components for consistency.
 */
export function RobustThumbnail({
  videoId,
  videoTitle,
  thumbnailUrl,
  className = '',
  alt,
  width,
  height,
  priority = false,
  variant = 'grid'
}: RobustThumbnailProps) {
  const [currentSrc, setCurrentSrc] = useState<string>(thumbnailUrl || '');
  const [fallbackStep, setFallbackStep] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  // Generate SVG placeholder as final fallback
  const generatePlaceholder = useCallback(() => {
    const dimensions = {
      grid: { width: 480, height: 270 },
      hero: { width: 1280, height: 720 },
      list: { width: 320, height: 180 }
    };
    
    const { width: svgWidth, height: svgHeight } = dimensions[variant];
    const initials = videoTitle.split(' ').map(word => word[0]).join('').substring(0, 2).toUpperCase();
    
    // Generate consistent color from title
    let hash = 0;
    for (let i = 0; i < videoTitle.length; i++) {
      hash = videoTitle.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = Math.abs(hash % 360);
    
    return `data:image/svg+xml,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${svgWidth} ${svgHeight}" width="${svgWidth}" height="${svgHeight}">
        <defs>
          <linearGradient id="grad-${videoId || 'default'}" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:hsl(${hue}, 70%, 45%);stop-opacity:1" />
            <stop offset="100%" style="stop-color:hsl(${hue}, 70%, 25%);stop-opacity:1" />
          </linearGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#grad-${videoId || 'default'})"/>
        <circle cx="50%" cy="40%" r="${Math.min(svgWidth, svgHeight) * 0.08}" fill="rgba(255,255,255,0.2)"/>
        <polygon points="45%,35% 45%,45% 55%,40%" fill="rgba(255,255,255,0.8)"/>
        <text x="50%" y="65%" dominant-baseline="middle" text-anchor="middle" 
              fill="white" font-size="${Math.min(svgWidth, svgHeight) * 0.08}" 
              font-weight="bold" font-family="Arial, sans-serif">
          ${initials}
        </text>
        <text x="50%" y="80%" dominant-baseline="middle" text-anchor="middle" 
              fill="rgba(255,255,255,0.9)" font-size="${Math.min(svgWidth, svgHeight) * 0.04}" 
              font-family="Arial, sans-serif">
          ${videoTitle.length > 24 ? videoTitle.substring(0, 21) + '...' : videoTitle}
        </text>
      </svg>
    `)}`;
  }, [videoTitle, videoId, variant]);

  // Handle image load errors with progressive fallback
  const handleError = useCallback(() => {
    if (fallbackStep === 0 && videoId) {
      // Step 1: Try API endpoint
      if (import.meta.env.DEV) {
        logger.api(`Thumbnail failed for "${videoTitle}", trying API endpoint`);
      }
      setFallbackStep(1);
      setCurrentSrc(`/api/videos/${videoId}/thumbnail`);
    } else {
      // Step 2: Use SVG placeholder
      if (import.meta.env.DEV) {
        logger.info(`All thumbnail sources failed for "${videoTitle}", using placeholder`);
      }
      setHasError(true);
      setCurrentSrc(generatePlaceholder());
    }
  }, [fallbackStep, videoId, videoTitle, generatePlaceholder]);

  const handleLoad = useCallback(() => {
    setIsLoading(false);
    setHasError(false);
  }, []);

  // Initialize source
  const getInitialSrc = () => {
    if (thumbnailUrl) return thumbnailUrl;
    if (videoId) return `/api/videos/${videoId}/thumbnail`;
    return generatePlaceholder();
  };

  // Set initial source if not set
  if (!currentSrc) {
    setCurrentSrc(getInitialSrc());
  }

  const aspectRatio = variant === 'hero' ? '16/9' : variant === 'list' ? '16/9' : '16/9';

  return (
    <div 
      className={cn("relative overflow-hidden bg-gray-900", className)}
      style={{ 
        aspectRatio,
        width: width ? `${width}px` : undefined,
        height: height ? `${height}px` : undefined
      }}
    >
      {isLoading && !hasError && (
        <div className="absolute inset-0 bg-gray-800 animate-pulse flex items-center justify-center">
          <div className="w-8 h-8 border-2 border-white/20 border-t-white/60 rounded-full animate-spin" />
        </div>
      )}
      
      <img
        src={currentSrc}
        alt={alt || `${videoTitle} thumbnail`}
        className={cn(
          "w-full h-full object-cover transition-opacity duration-300",
          isLoading ? "opacity-0" : "opacity-100"
        )}
        onError={handleError}
        onLoad={handleLoad}
        loading={priority ? "eager" : "lazy"}
        width={width}
        height={height}
      />
      
      {/* Optional quality indicator for debugging */}
      {process.env.NODE_ENV === 'development' && (
        <div className="absolute top-1 left-1 bg-black/50 text-white text-xs px-1 rounded">
          {hasError ? 'SVG' : fallbackStep === 1 ? 'API' : 'DB'}
        </div>
      )}
    </div>
  );
} 