/**
 * Unified Video Display Components
 * 
 * Container components that use the UnifiedVideoCard as SSOT
 * but provide specific layouts for different use cases.
 */

import React, { useRef } from 'react';
import {  Button  } from '@/components/ui/button';
import {  ChevronLeft, ChevronRight, Crown, Play, Plus, X  } from 'lucide-react';
import { cn } from '@/lib/utils';
import {  
  UnifiedVideoCard, 
  VideoGridCard, 
  VideoCarouselCard, 
  VideoHeroCard
 } from './unified-video-card';
import type { Database } from '@/types/database-generated.types';

type Video = Database['public']['Tables']['videos']['Row'];

// Common props for all display components
interface BaseVideoDisplayProps {
  videos: Video[];
  watchProgress?: Record<string, number>;
  watchlist?: Set<string>;
  onPlay?: (video: Video) => void;
  onAddToWatchlist?: (videoId: string) => void;
  onRemoveFromWatchlist?: (videoId: string) => void;
  onInfo?: (video: Video) => void;
  className?: string;
}

// Video Carousel Row Component
interface VideoCarouselRowProps extends BaseVideoDisplayProps {
  title: string;
  showScrollButtons?: boolean;
  showSeeMore?: boolean;
  initialCount?: number;
  onSeeMore?: () => void;
}

export const UnifiedVideoCarousel: React.FC<VideoCarouselRowProps> = ({
  title,
  videos,
  watchProgress = {},
  watchlist = new Set(),
  onPlay,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onInfo,
  showScrollButtons = true,
  showSeeMore = true,
  initialCount = 3,
  onSeeMore,
  className
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  
  // Show only initial count for landing page, all for other pages
  const displayVideos = showSeeMore ? videos.slice(0, initialCount) : videos;

  const scrollLeft = () => {
    scrollRef.current?.scrollBy({ left: -400, behavior: 'smooth' });
  };

  const scrollRight = () => {
    scrollRef.current?.scrollBy({ left: 400, behavior: 'smooth' });
  };

  if (!videos || videos.length === 0) return null;

  return (
    <section className={cn("py-8", className)}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold text-white">{title}</h2>
          {showSeeMore && videos.length > initialCount && onSeeMore && (
            <Button
              variant="outline"
              size="sm"
              onClick={onSeeMore}
              className="text-primary border-primary hover:bg-primary hover:text-white"
            >
              See More
            </Button>
          )}
        </div>
        
        <div className="relative">
          <div
            ref={scrollRef}
            className="flex space-x-4 overflow-x-hidden pb-4"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {displayVideos.map((video) => (
              <VideoCarouselCard
                key={video.id}
                video={video}
                progress={watchProgress[video.id]}
                isInWatchlist={watchlist.has(video.id)}
                onPlay={onPlay}
                onAddToWatchlist={onAddToWatchlist}
                onRemoveFromWatchlist={onRemoveFromWatchlist}
                onInfo={onInfo}
              />
            ))}
          </div>

          {showScrollButtons && !showSeeMore && videos.length > 4 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-2 top-1/2 transform -translate-y-1/2 hidden md:flex bg-black bg-opacity-50 text-white rounded-full h-10 w-10 z-10"
                onClick={scrollLeft}
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 hidden md:flex bg-black bg-opacity-50 text-white rounded-full h-10 w-10 z-10"
                onClick={scrollRight}
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </>
          )}
        </div>
      </div>
    </section>
  );
};

// Video Grid Component
interface VideoGridProps extends BaseVideoDisplayProps {
  columns?: 2 | 3 | 4 | 5 | 6;
  showHero?: boolean;
}

export const UnifiedVideoGrid: React.FC<VideoGridProps> = ({
  videos,
  watchProgress = {},
  watchlist = new Set(),
  onPlay,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onInfo,
  columns = 4,
  showHero = false,
  className
}) => {
  if (!videos || videos.length === 0) return null;

  const [heroVideo, ...gridVideos] = videos;
  const gridCols = {
    2: 'grid-cols-2',
    3: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3',
    4: 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4',
    5: 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5',
    6: 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6'
  };

  return (
    <div className={cn("space-y-8", className)}>
      {/* Hero Video */}
      {showHero && heroVideo && (
        <VideoHeroCard
          video={heroVideo}
          progress={watchProgress[heroVideo.id]}
          isInWatchlist={watchlist.has(heroVideo.id)}
          onPlay={onPlay}
          onAddToWatchlist={onAddToWatchlist}
          onRemoveFromWatchlist={onRemoveFromWatchlist}
          onInfo={onInfo}
        />
      )}

      {/* Grid Videos */}
      <div className={cn("grid gap-4", gridCols[columns])}>
        {(showHero ? gridVideos : videos).map((video) => (
          <VideoGridCard
            key={video.id}
            video={video}
            progress={watchProgress[video.id]}
            isInWatchlist={watchlist.has(video.id)}
            onPlay={onPlay}
            onAddToWatchlist={onAddToWatchlist}
            onRemoveFromWatchlist={onRemoveFromWatchlist}
            onInfo={onInfo}
          />
        ))}
      </div>
    </div>
  );
};

// Video List Component (for admin or detailed views)
interface VideoListProps extends BaseVideoDisplayProps {
  showAdminActions?: boolean;
  onEdit?: (video: Video) => void;
  onDelete?: (video: Video) => void;
}

export const UnifiedVideoList: React.FC<VideoListProps> = ({
  videos,
  watchProgress = {},
  watchlist = new Set(),
  onPlay,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onInfo,
  showAdminActions = false,
  onEdit,
  onDelete,
  className
}) => {
  if (!videos || videos.length === 0) return null;

  return (
    <div className={cn("space-y-4", className)}>
      {videos.map((video) => (
        <div key={video.id} className="flex items-center gap-4">
          <UnifiedVideoCard
            video={video}
            variant="list"
            progress={watchProgress[video.id]}
            isInWatchlist={watchlist.has(video.id)}
            onPlay={onPlay}
            onAddToWatchlist={onAddToWatchlist}
            onRemoveFromWatchlist={onRemoveFromWatchlist}
            onInfo={onInfo}
            className="flex-1"
          />
          
          {showAdminActions && (
            <div className="flex gap-2">
              {onEdit && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onEdit(video)}
                >
                  Edit
                </Button>
              )}
              {onDelete && (
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() => onDelete(video)}
                >
                  Delete
                </Button>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};

// Featured Hero Component (for landing/home pages)
/**
 * Displays a prominent featured video, typically at the top of a page.
 * Note: This component is designed for hero images with a 16:9 aspect ratio.
 * Please refer to IMAGE_SPECS.md for detailed image requirements.
 */
interface FeaturedHeroProps {
  video: Video;
  isInWatchlist?: boolean;
  onPlay?: (video: Video) => void;
  onAddToWatchlist?: (videoId: string) => void;
  onRemoveFromWatchlist?: (videoId: string) => void;
  onInfo?: (video: Video) => void;
  className?: string;
}

export const UnifiedFeaturedHero: React.FC<FeaturedHeroProps> = ({
  video,
  isInWatchlist = false,
  onPlay,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onInfo,
  className,
}) => {
  // Get the hero image URL - try thumbnail_url first, then fallback
  const heroImageUrl = video.thumbnail_url || 
    `https://vz-f5c9bae3-d51.b-cdn.net/${video.id}/thumbnail.jpg` ||
    '/splash-screen.svg';

  return (
    <div className={cn("relative w-full h-full overflow-hidden", className)}>
      {/* Full-bleed background image */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImageUrl})` }}
      />

      {/* Dark overlay for better text readability */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-black/20" />

      {/* Content overlay */}
      <div className="absolute inset-0 flex flex-col justify-end p-8 md:p-12 lg:p-16">
        <div className="max-w-2xl">
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white mb-4">
            {video.title}
          </h1>
          
          {video.description && (
            <p className="text-lg text-gray-200 mb-6 line-clamp-3">
              {video.description}
            </p>
          )}

          {/* Metadata */}
          <div className="flex items-center gap-4 mb-6 text-sm text-gray-300">
            {video.release_year && (
              <span>{video.release_year}</span>
            )}
            {(video as any).duration_minutes && (
              <span>{Math.floor((video as any).duration_minutes / 60)}h {(video as any).duration_minutes % 60}m</span>
            )}
            {video.is_premium && (
              <span className="flex items-center">
                <Crown className="w-4 h-4 mr-1" />
                Premium
              </span>
            )}
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-4">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-white px-8 py-3"
              onClick={() => onPlay?.(video)}
            >
              <Play className="w-5 h-5 mr-2" fill="white" />
              Play
            </Button>
            
            {onAddToWatchlist && onRemoveFromWatchlist && (
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-black px-6 py-3"
                onClick={() => {
                  if (isInWatchlist) {
                    onRemoveFromWatchlist(video.id);
                  } else {
                    onAddToWatchlist(video.id);
                  }
                }}
              >
                {isInWatchlist ? (
                  <X className="w-5 h-5 mr-2" />
                ) : (
                  <Plus className="w-5 h-5 mr-2" />
                )}
                {isInWatchlist ? 'Remove from List' : 'Add to List'}
              </Button>
            )}
            
            {onInfo && (
              <Button
                variant="outline"
                size="lg"
                className="border-white text-white hover:bg-white hover:text-black px-6 py-3"
                onClick={() => onInfo(video)}
              >
                More Info
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Export the unified card for direct use
export { UnifiedVideoCard };
