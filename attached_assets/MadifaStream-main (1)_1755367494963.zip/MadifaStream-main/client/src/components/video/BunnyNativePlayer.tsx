/**
 * Bunny Native Video Player
 * 
 * Uses Bunny's native iframe player with Player.js for programmatic control
 * Includes subscription gating and authentication integration
 */

import React, { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'react-hot-toast';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/use-auth';
import { useSubscription } from '@/hooks/use-subscription';
import { logger } from '@shared/logger';

// Icons
import { 
  Play, Pause, Volume2, VolumeX, Maximize, 
  Loader2, AlertCircle, Crown, Lock, Shield
} from 'lucide-react';

// UI Components
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface BunnyNativePlayerProps {
  videoId: string;
  bunnyVideoId: string;
  bunnyLibraryId: string;
  title: string;
  thumbnail?: string;
  isPremium?: boolean;
  autoplay?: boolean;
  className?: string;
  onComplete?: () => void;
  onError?: (error: Error) => void;
  onUpgrade?: () => void;
}

interface PlayerState {
  isReady: boolean;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isFullscreen: boolean;
  isLoading: boolean;
  hasError: boolean;
  errorMessage?: string;
}

// Player.js types
declare global {
  interface Window {
    playerjs?: {
      Player: new (element: HTMLIFrameElement) => {
        on: (event: string, callback: (data?: any) => void) => void;
        play: () => void;
        pause: () => void;
        setCurrentTime: (time: number) => void;
        getCurrentTime: (callback: (time: number) => void) => void;
        getDuration: (callback: (duration: number) => void) => void;
        setVolume: (volume: number) => void;
        getVolume: (callback: (volume: number) => void) => void;
        mute: () => void;
        unmute: () => void;
        getPaused: (callback: (paused: boolean) => void) => void;
      };
    };
  }
}

export function BunnyNativePlayer({
  videoId,
  bunnyVideoId,
  bunnyLibraryId,
  title,
  thumbnail,
  isPremium = false,
  autoplay = false,
  className,
  onComplete,
  onError,
  onUpgrade,
}: BunnyNativePlayerProps) {
  // Refs
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const playerRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Auth and subscription hooks
  const { user } = useAuth();
  const { subscription, isLoading: subscriptionLoading } = useSubscription();

  // State
  const [playerState, setPlayerState] = useState<PlayerState>({
    isReady: false,
    isPlaying: false,
    currentTime: 0,
    duration: 0,
    volume: 1,
    isMuted: false,
    isFullscreen: false,
    isLoading: true,
    hasError: false,
  });

  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [showUpgradePrompt, setShowUpgradePrompt] = useState(false);
  const [isPlayerJsLoaded, setIsPlayerJsLoaded] = useState(false);

  // Check access permissions
  const canAccessVideo = !isPremium || (user && subscription?.isActive);

  // Load Player.js library
  useEffect(() => {
    if (window.playerjs) {
      setIsPlayerJsLoaded(true);
      return;
    }

    const script = document.createElement('script');
    script.src = '//assets.mediadelivery.net/playerjs/player-0.1.0.min.js';
    script.async = true;
    script.onload = () => {
      setIsPlayerJsLoaded(true);
    };
    script.onerror = () => {
      logger.error('Failed to load Player.js library');
      setPlayerState(prev => ({
        ...prev,
        hasError: true,
        errorMessage: 'Failed to load video player library',
        isLoading: false,
      }));
    };

    document.head.appendChild(script);

    return () => {
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
    };
  }, []);

  // Generate secure embed URL with token
  const generateEmbedUrl = useCallback(async (): Promise<string> => {
    if (!canAccessVideo) {
      throw new Error('Access denied: Premium subscription required');
    }

    try {
      // CRITICAL FIX: Get access token from localStorage and include in Authorization header
      const authToken = localStorage.getItem('auth_token');
      
      // Get access token from backend
      const response = await fetch(`/api/videos/${videoId}/embed-token`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(authToken ? { Authorization: `Bearer ${authToken}` } : {}),
        },
        credentials: 'include',
      });

      if (!response.ok) {
        throw new Error(`Failed to get embed token: ${response.statusText}`);
      }

      const data = await response.json();
      setAccessToken(data.token);

      // Build embed URL with parameters
      const params = new URLSearchParams({
        autoplay: autoplay.toString(),
        preload: 'true',
        muted: autoplay.toString(), // Mute for autoplay to work
        showHeatmap: 'true',
        rememberPosition: 'true',
        showSpeed: 'true',
        ...(data.token && { token: data.token }),
        ...(data.expires && { expires: data.expires.toString() }),
      });

      return `https://iframe.mediadelivery.net/embed/${bunnyLibraryId}/${bunnyVideoId}?${params}`;
    } catch (error) {
      logger.error('Error generating embed URL:', error);
      throw error;
    }
  }, [videoId, bunnyVideoId, bunnyLibraryId, autoplay, canAccessVideo]);

  // Initialize player
  useEffect(() => {
    if (!isPlayerJsLoaded || !iframeRef.current || !canAccessVideo) {
      return;
    }

    const initializePlayer = async () => {
      try {
        setPlayerState(prev => ({ ...prev, isLoading: true, hasError: false }));

        const embedUrl = await generateEmbedUrl();
        
        // Set iframe source
        if (iframeRef.current) {
          iframeRef.current.src = embedUrl;
        }

        // Wait for iframe to load
        const iframe = iframeRef.current;
        if (!iframe) return;

        iframe.onload = () => {
          if (!window.playerjs) {
            logger.error('Player.js not available');
            return;
          }

          // Initialize Player.js
          const player = new window.playerjs.Player(iframe);
          playerRef.current = player;

          // Set up event listeners
          player.on('ready', () => {
            logger.info('Bunny player ready');
            setPlayerState(prev => ({
              ...prev,
              isReady: true,
              isLoading: false,
            }));

            // Get initial player state
            player.getDuration((duration) => {
              setPlayerState(prev => ({ ...prev, duration }));
            });

            player.getVolume((volume) => {
              setPlayerState(prev => ({ ...prev, volume: volume / 100 }));
            });
          });

          player.on('play', () => {
            setPlayerState(prev => ({ ...prev, isPlaying: true }));
          });

          player.on('pause', () => {
            setPlayerState(prev => ({ ...prev, isPlaying: false }));
          });

          player.on('timeupdate', (data) => {
            try {
              const timeData = typeof data === 'string' ? JSON.parse(data) : data;
              setPlayerState(prev => ({
                ...prev,
                currentTime: timeData.seconds || 0,
                duration: timeData.duration || prev.duration,
              }));
            } catch (error) {
              logger.warn('Error parsing timeupdate data:', error);
            }
          });

          player.on('ended', () => {
            setPlayerState(prev => ({ ...prev, isPlaying: false }));
            onComplete?.();
          });

          player.on('error', (error) => {
            logger.error('Bunny player error:', error);
            setPlayerState(prev => ({
              ...prev,
              hasError: true,
              errorMessage: 'Video playback error',
              isLoading: false,
            }));
            onError?.(new Error('Video playback error'));
          });
        };

        iframe.onerror = () => {
          setPlayerState(prev => ({
            ...prev,
            hasError: true,
            errorMessage: 'Failed to load video player',
            isLoading: false,
          }));
        };

      } catch (error) {
        logger.error('Error initializing player:', error);
        setPlayerState(prev => ({
          ...prev,
          hasError: true,
          errorMessage: error instanceof Error ? error.message : 'Failed to initialize player',
          isLoading: false,
        }));
        onError?.(error instanceof Error ? error : new Error('Failed to initialize player'));
      }
    };

    initializePlayer();

    return () => {
      if (playerRef.current) {
        playerRef.current = null;
      }
    };
  }, [isPlayerJsLoaded, canAccessVideo, generateEmbedUrl, onComplete, onError]);

  // Player control functions
  const handlePlay = useCallback(() => {
    if (playerRef.current && playerState.isReady) {
      playerRef.current.play();
    }
  }, [playerState.isReady]);

  const handlePause = useCallback(() => {
    if (playerRef.current && playerState.isReady) {
      playerRef.current.pause();
    }
  }, [playerState.isReady]);

  const togglePlayPause = useCallback(() => {
    if (playerState.isPlaying) {
      handlePause();
    } else {
      handlePlay();
    }
  }, [playerState.isPlaying, handlePlay, handlePause]);

  const handleSeek = useCallback((time: number) => {
    if (playerRef.current && playerState.isReady) {
      playerRef.current.setCurrentTime(time);
    }
  }, [playerState.isReady]);

  const toggleMute = useCallback(() => {
    if (playerRef.current && playerState.isReady) {
      if (playerState.isMuted) {
        playerRef.current.unmute();
        setPlayerState(prev => ({ ...prev, isMuted: false }));
      } else {
        playerRef.current.mute();
        setPlayerState(prev => ({ ...prev, isMuted: true }));
      }
    }
  }, [playerState.isReady, playerState.isMuted]);

  // Render access denied screen
  if (!canAccessVideo) {
    return (
      <div className={cn('relative bg-black rounded-lg overflow-hidden aspect-video', className)}>
        <div className="absolute inset-0 flex items-center justify-center">
          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
                {isPremium ? <Crown className="w-8 h-8 text-primary" /> : <Lock className="w-8 h-8 text-muted-foreground" />}
              </div>
              <CardTitle className="text-xl">
                {isPremium ? 'Premium Content' : 'Login Required'}
              </CardTitle>
              <CardDescription>
                {isPremium 
                  ? 'This video requires an active subscription to view'
                  : 'Please log in to access this content'
                }
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              {isPremium && (
                <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                  <Shield className="w-4 h-4" />
                  <span>Protected premium content</span>
                </div>
              )}
              
              <div className="space-y-2">
                {!user ? (
                  <Button className="w-full" onClick={() => window.location.href = '/login'}>
                    Sign In to Watch
                  </Button>
                ) : isPremium ? (
                  <>
                    <Button className="w-full" onClick={onUpgrade || (() => window.location.href = '/pricing')}>
                      <Crown className="w-4 h-4 mr-2" />
                      Upgrade to Premium
                    </Button>
                    <p className="text-xs text-muted-foreground">
                      Get unlimited access to all premium content
                    </p>
                  </>
                ) : (
                  <Button className="w-full" onClick={() => window.location.reload()}>
                    Retry
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Background thumbnail */}
        {thumbnail && (
          <div className="absolute inset-0 -z-10">
            <img 
              src={thumbnail} 
              alt={title}
              className="w-full h-full object-cover opacity-20 blur-sm"
            />
            <div className="absolute inset-0 bg-black/60" />
          </div>
        )}
      </div>
    );
  }

  // Render error state
  if (playerState.hasError) {
    return (
      <div className={cn('relative bg-black rounded-lg overflow-hidden aspect-video flex items-center justify-center', className)}>
        <div className="text-center text-white space-y-4">
          <AlertCircle className="w-12 h-12 mx-auto text-red-500" />
          <div>
            <h3 className="text-lg font-semibold">Playback Error</h3>
            <p className="text-sm text-gray-300 mt-1">
              {playerState.errorMessage || 'Unable to load video'}
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => window.location.reload()}
            className="bg-white/10 border-white/20 text-white hover:bg-white/20"
          >
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className={cn(
        'relative bg-black rounded-lg overflow-hidden aspect-video group',
        'focus:outline-none focus:ring-2 focus:ring-primary',
        className
      )}
      tabIndex={0}
    >
      {/* Bunny iframe player */}
      <iframe
        ref={iframeRef}
        className="w-full h-full"
        frameBorder="0"
        allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture"
        allowFullScreen
        loading="lazy"
        title={title}
        style={{ border: 'none' }}
      />

      {/* Loading overlay */}
      <AnimatePresence>
        {playerState.isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-black/50 z-10"
          >
            <div className="text-center text-white space-y-4">
              <Loader2 className="w-12 h-12 mx-auto animate-spin" />
              <div>
                <h3 className="text-lg font-semibold">Loading Video</h3>
                <p className="text-sm text-gray-300">Please wait...</p>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Video info overlay */}
      {playerState.isReady && (
        <div className="absolute top-4 left-4 right-4 flex items-start justify-between z-20 pointer-events-none">
          <div className="bg-black/60 backdrop-blur-sm rounded-lg px-3 py-2 max-w-[70%]">
            <h3 className="text-white font-semibold text-sm truncate">{title}</h3>
            {isPremium && (
              <Badge variant="secondary" className="mt-1 bg-primary/20 text-primary border-primary/30">
                <Crown className="w-3 h-3 mr-1" />
                Premium
              </Badge>
            )}
          </div>
          
          {accessToken && (
            <div className="bg-green-500/20 backdrop-blur-sm rounded-lg px-2 py-1">
              <Badge variant="outline" className="border-green-500/50 text-green-400 text-xs">
                <Shield className="w-3 h-3 mr-1" />
                Secured
              </Badge>
            </div>
          )}
        </div>
      )}

      {/* Player controls overlay (minimal, since Bunny player has its own controls) */}
      {!playerState.isReady && !playerState.isLoading && !playerState.hasError && (
        <div className="absolute inset-0 flex items-center justify-center">
          <Button
            size="lg"
            onClick={handlePlay}
            className="w-20 h-20 rounded-full bg-white/20 backdrop-blur hover:bg-white/30 transition-all duration-300"
          >
            <Play className="w-10 h-10 text-white fill-white ml-1" />
          </Button>
        </div>
      )}
    </div>
  );
} 