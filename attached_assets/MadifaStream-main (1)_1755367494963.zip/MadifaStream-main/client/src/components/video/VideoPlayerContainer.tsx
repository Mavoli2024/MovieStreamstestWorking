import React from 'react';
import {  ModernVideoPlayer  } from './ModernVideoPlayer';

interface VideoPlayerContainerProps {
  videoId: string;
  title?: string;
  thumbnail?: string;
  autoplay?: boolean;
  onComplete?: () => void;
  onError?: (error: Error) => void;
  className?: string;
}

export function VideoPlayerContainer({
  videoId,
  title,
  thumbnail,
  autoplay = false,
  onComplete,
  onError,
  className,
}: VideoPlayerContainerProps) {
  return (
    <div className={className}>
      <ModernVideoPlayer
        videoId={videoId}
        title={title}
        thumbnail={thumbnail}
        autoplay={autoplay}
        onComplete={onComplete}
        onError={onError}
      />
    </div>
  );
} 