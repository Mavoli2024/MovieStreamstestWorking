import { cn } from '@/lib/utils';
import type { Video } from '@shared/schema';
import React, { useState, useCallback } from 'react';
import { logger } from '@shared/logger';

interface ThumbnailImageProps {
  video: Video;
  className?: string;
  variant?: 'hero' | 'list' | 'grid' | 'small';
  alt?: string;
  loading?: 'lazy' | 'eager';
}

export function ThumbnailImage({ 
  video, 
  className = '', 
  variant = 'grid',
  alt,
  loading = 'lazy'
}: ThumbnailImageProps) {
  const [currentFallbackIndex, setCurrentFallbackIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  // Generate multiple fallback thumbnail URLs
  const getThumbnailFallbacks = useCallback((): string[] => {
    const fallbacks: string[] = [];

    // Primary: Database-provided thumbnail URL
    if (video.thumbnail_url && video.thumbnail_url.trim()) {
      fallbacks.push(video.thumbnail_url);
    }

    // Secondary: Bunny.net direct thumbnail (if we have bunny_video_id)
    if (video.bunny_video_id && video.bunny_library_id) {
      fallbacks.push(`https://vz-${video.bunny_library_id}.b-cdn.net/${video.bunny_video_id}/thumbnail.jpg`);
    }

    // Tertiary: Direct CDN thumbnail (generic fallback)
    if (video.id) {
      fallbacks.push(`https://vz-f5c9bae3-d51.b-cdn.net/${video.id}/thumbnail.jpg`);
    }

    // Final: Generated SVG placeholder (always works)
    fallbacks.push(generatePlaceholder());

    return fallbacks;
  }, [video]);

  const generatePlaceholder = useCallback((): string => {
    const dimensions = {
      hero: { width: 1280, height: 720 },
      list: { width: 320, height: 180 },
      grid: { width: 480, height: 270 },
      small: { width: 160, height: 90 }
    };
    
    const { width, height } = dimensions[variant] || dimensions.grid;
    const title = video.title || 'Video';
    const initials = title.split(' ')
      .map((word: string) => word[0])
      .join('')
      .substring(0, 3)
      .toUpperCase() || 'VID';
    
    // Generate consistent color from title
    let hash = 0;
    for (let i = 0; i < title.length; i++) {
      hash = title.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = Math.abs(hash % 360);
    const lightColor = `hsl(${hue}, 65%, 50%)`;
    const darkColor = `hsl(${hue}, 65%, 30%)`;
    
    // Truncate title for display
    const displayTitle = title.length > 25 ? title.substring(0, 22) + '...' : title;
    
    // Add premium indicator
    const premiumIndicator = video.is_premium ? '👑' : '';
    const trailerIndicator = video.is_trailer ? '▶️' : '🎬';
    
    return `data:image/svg+xml,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">
        <defs>
          <linearGradient id="grad-${video.id || 'default'}" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:${lightColor};stop-opacity:1" />
            <stop offset="100%" style="stop-color:${darkColor};stop-opacity:1" />
          </linearGradient>
          <filter id="shadow">
            <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="rgba(0,0,0,0.3)"/>
          </filter>
        </defs>
        
        <!-- Background -->
        <rect width="100%" height="100%" fill="url(#grad-${video.id || 'default'})"/>
        
        <!-- Film strip effect -->
        <rect x="0" y="0" width="100%" height="20" fill="rgba(0,0,0,0.2)"/>
        <rect x="0" y="${height - 20}" width="100%" height="20" fill="rgba(0,0,0,0.2)"/>
        
        <!-- Play button circle -->
        <circle cx="50%" cy="40%" r="${Math.min(width, height) * 0.08}" fill="rgba(255,255,255,0.9)" filter="url(#shadow)"/>
        <polygon points="45%,35% 45%,45% 55%,40%" fill="${darkColor}"/>
        
        <!-- Title initials -->
        <text x="50%" y="65%" dominant-baseline="middle" text-anchor="middle" 
              fill="white" font-size="${Math.min(width, height) * 0.08}" 
              font-weight="bold" font-family="Arial, sans-serif" filter="url(#shadow)">
          ${initials}
        </text>
        
        <!-- Video title -->
        <text x="50%" y="80%" dominant-baseline="middle" text-anchor="middle" 
              fill="rgba(255,255,255,0.95)" font-size="${Math.min(width, height) * 0.035}" 
              font-family="Arial, sans-serif" filter="url(#shadow)">
          ${displayTitle}
        </text>
        
        <!-- Indicators -->
        <text x="85%" y="15%" dominant-baseline="middle" text-anchor="middle" 
              font-size="${Math.min(width, height) * 0.06}">
          ${premiumIndicator}
        </text>
        <text x="15%" y="15%" dominant-baseline="middle" text-anchor="middle" 
              font-size="${Math.min(width, height) * 0.05}">
          ${trailerIndicator}
        </text>
        
        <!-- Duration indicator (if available) -->
        ${video.duration ? `
        <rect x="${width - 60}" y="${height - 30}" width="55" height="20" rx="10" fill="rgba(0,0,0,0.7)"/>
        <text x="${width - 32}" y="${height - 18}" dominant-baseline="middle" text-anchor="middle" 
              fill="white" font-size="10" font-family="Arial, sans-serif">
          ${Math.floor(video.duration / 60)}:${(video.duration % 60).toString().padStart(2, '0')}
        </text>
        ` : ''}
      </svg>
    `)}`;
  }, [video, variant]);

  const thumbnailFallbacks = getThumbnailFallbacks();
  const currentThumbnail = thumbnailFallbacks[currentFallbackIndex] || generatePlaceholder();

  const handleImageError = useCallback(() => {
    const currentUrl = thumbnailFallbacks[currentFallbackIndex];
    
    // Try next fallback
    if (currentFallbackIndex < thumbnailFallbacks.length - 1) {
      setCurrentFallbackIndex(prev => prev + 1);
      setIsLoading(true);
      setHasError(false);
      if (import.meta.env.DEV) {
        logger.warn(`Thumbnail failed for "${video.title}", trying fallback ${currentFallbackIndex + 2}/${thumbnailFallbacks.length}`);
      }
    } else {
      setHasError(true);
      setIsLoading(false);
      if (import.meta.env.DEV) {
        logger.error(`All thumbnail fallbacks failed for "${video.title}"`);
      }
    }
  }, [currentFallbackIndex, thumbnailFallbacks, video.title]);

  const handleImageLoad = useCallback(() => {
    setIsLoading(false);
    setHasError(false);
    
    // Log successful load for monitoring
    if (currentFallbackIndex > 0) {
      if (import.meta.env.DEV) {
        logger.info(`Thumbnail loaded for "${video.title}" using fallback ${currentFallbackIndex + 1}/${thumbnailFallbacks.length}`);
      }
    }
  }, [currentFallbackIndex, thumbnailFallbacks.length, video.title]);

  // Reset fallback index when video changes
  React.useEffect(() => {
    setCurrentFallbackIndex(0);
    setIsLoading(true);
    setHasError(false);
  }, [video.id]);

  return (
    <div className={cn("relative overflow-hidden", className)}>
      {/* Loading indicator */}
      {isLoading && !hasError && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted animate-pulse">
          <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}
      
      {/* Main thumbnail image */}
      <img
        src={currentThumbnail}
        alt={alt || `${video.title} thumbnail`}
        className={cn(
          "w-full h-full object-cover transition-opacity duration-300",
          isLoading ? "opacity-0" : "opacity-100"
        )}
        onError={handleImageError}
        onLoad={handleImageLoad}
        loading={loading}
        crossOrigin="anonymous"
      />
      
      {/* Premium badge overlay */}
      {video.is_premium && (
        <div className="absolute top-2 right-2 bg-amber-500 text-black px-2 py-1 rounded text-xs font-semibold flex items-center gap-1">
          👑 Premium
        </div>
      )}
      
      {/* Trailer badge overlay */}
      {video.is_trailer && (
        <div className="absolute top-2 left-2 bg-blue-500 text-white px-2 py-1 rounded text-xs font-semibold flex items-center gap-1">
          ▶️ Trailer
        </div>
      )}
      
      {/* Duration overlay */}
      {video.duration && (
        <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-xs">
          {Math.floor(video.duration / 60)}:{(video.duration % 60).toString().padStart(2, '0')}
        </div>
      )}
      
      {/* Error state (should rarely be seen due to SVG fallback) */}
      {hasError && (
        <div className="absolute inset-0 flex items-center justify-center bg-muted text-muted-foreground">
          <div className="text-center">
            <div className="text-2xl mb-1">📹</div>
            <div className="text-xs">No Image</div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ThumbnailImage; 