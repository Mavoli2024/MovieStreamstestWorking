import {  Badge  } from '@/components/ui/badge';
import {  Button  } from '@/components/ui/button';
import {  ThumbnailImage  } from '@/components/ui/thumbnail-image';
import {  Clock, Eye, Play  } from 'lucide-react';
import { useState, memo } from 'react';
import type { Database } from '@/types/database-generated.types';
import { useInView } from '@/hooks/use-in-view';
import { getVideoThumbnailUrl } from '@/utils/thumbnail-utils';

// Supabase typed row
type Video = Database['public']['Tables']['videos']['Row'];

interface VideoGridCardProps {
  video: Partial<Video>;
  progress?: number; // 0-100
  isContinueWatching?: boolean;
  className?: string;
}

/**
 * VideoGridCard – reusable card for browse & collection grids.
 * Omits age-rating, release-year and share button per UX spec.
 */
export const VideoGridCard = memo(function VideoGridCard({
  video,
  progress = 0,
  isContinueWatching,
  className = '',
}: VideoGridCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [ref, inView] = useInView<HTMLDivElement>();
  const formatDuration = (durationInput?: number) => {
    if (!durationInput || durationInput <= 0) return '0m';
    
    // Handle duration - could be in seconds or minutes depending on data source
    let totalMinutes = durationInput;
    
    // If duration seems to be in seconds (>300 = 5 hours), convert to minutes
    if (durationInput > 300) {
      totalMinutes = Math.floor(durationInput / 60);
    }
    
    const hours = Math.floor(totalMinutes / 60);
    const minutes = Math.floor(totalMinutes % 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else {
      return `${totalMinutes}m`;
    }
  };

  const duration = (video as any).duration_minutes ?? (video as any).duration ?? 0;

  return (
    <div
      ref={ref}
      style={{ willChange: 'transform' }}
      className={`relative group w-full min-w-[200px] transition-opacity transform duration-500 ease-out ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-3'} ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <a href={`/watch/${video.id}`}> {/* native anchor for SEO */}
        <div className="bg-card rounded-lg overflow-hidden transition-transform duration-300 hover:scale-105 hover:z-10 shadow-lg">
          {/* thumb */}
          <div className="aspect-video relative">
            <ThumbnailImage
              src={getVideoThumbnailUrl(video)}
              video={video}
              alt={video.title || 'Video thumbnail'}
              title={video.title || 'Video'}
              className="w-full h-full"
            />

            {/* continue-watching bar */}
            {isContinueWatching && progress > 0 && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-800">
                <div
                  className="h-full bg-secondary"
                  style={{ width: `${progress}%` }}
                />
              </div>
            )}

            {/* hover overlay */}
            <div
              className={`absolute inset-0 flex items-center justify-center bg-black/40 transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`}
            >
              <Button
                variant="ghost"
                size="icon"
                className="rounded-full bg-primary/90 border-2 border-white text-white hover:bg-primary"
              >
                <Play className="h-6 w-6" fill="white" />
              </Button>
            </div>
          </div>

          {/* info */}
          <div className="p-2 bg-card/90">
            <h3 className="font-medium text-sm line-clamp-1">{video.title}</h3>
            <div className="flex items-center mt-1 text-xs text-gray-400">              {duration > 0 && (
                <div className="flex items-center mr-2">
                  <Clock className="h-3 w-3 mr-1" />
                  <span>{formatDuration(duration)}</span>
                </div>
              )}
              {video.views && (
                <div className="flex items-center">
                  <Eye className="h-3 w-3 mr-1" />
                  <span>{video.views.toLocaleString()}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </a>
    </div>
  );
});