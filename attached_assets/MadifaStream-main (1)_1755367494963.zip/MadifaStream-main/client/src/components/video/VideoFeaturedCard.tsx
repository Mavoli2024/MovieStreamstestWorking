import {  Button  } from '@/components/ui/button';
import {  ThumbnailImage  } from '@/components/ui/thumbnail-image';
import {  Play  } from 'lucide-react';
import { useState } from 'react';
import { useInView } from '@/hooks/use-in-view';
import { getVideoThumbnailUrl } from '@/utils/thumbnail-utils';
import type { Database } from '@/types/database-generated.types';

// Supabase row type
type Video = Database['public']['Tables']['videos']['Row'];

interface VideoUI {
  id: string;
  title: string;
  thumbnail_url?: string;
  thumbnailUrl?: string;
  duration_minutes?: number;
  duration?: number;
  video_url?: string;
  videoUrl?: string;
  description?: string;
  [key: string]: unknown;
}

interface VideoFeaturedCardProps {
  video: VideoUI;
  onPlay?: (v: VideoUI) => void;
  onInfo?: (v: VideoUI) => void;
  className?: string;
}

/**
 * VideoFeaturedCard – wide, visually prominent card for trending/showcase rows.
 * Responsive: 100% on mobile, 60vw on desktop.
 */
export function VideoFeaturedCard({ video, onPlay, onInfo, className = '' }: VideoFeaturedCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const [ref, inView] = useInView<HTMLDivElement>();

  const formatDuration = (seconds?: number) => {
    if (!seconds) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const thumb = getVideoThumbnailUrl(video);
  const duration = video.duration_minutes ?? video.duration ?? 0;
  return (
    <div
      ref={ref}
      style={{ willChange: 'transform' }}
      className={`relative group w-full md:w-[60vw] max-w-3xl aspect-video rounded-xl overflow-hidden shadow-lg transition-transform duration-300 hover:scale-105 hover:shadow-primary/30 transition-opacity duration-500 ease-out ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'} ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <a href={`/watch/${video.id}`}> {/* native anchor for SEO */}
        <ThumbnailImage
          src={thumb}
          alt={video.title}
          title={video.title}
          className="w-full h-full object-cover"
        />
        {/* gradient overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
        {/* content overlay */}
        <div className="absolute left-0 bottom-0 p-6 z-10 flex flex-col gap-3 max-w-[70%]">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-1 line-clamp-2 drop-shadow-lg">{video.title}</h2>
          {video.description && (
            <p className="text-base md:text-lg text-gray-200 mb-2 line-clamp-2 drop-shadow">{video.description}</p>
          )}
          <div className="flex items-center gap-4">
            {duration > 0 && (
              <span className="text-xs text-gray-300">
                {formatDuration(duration * 60)}
              </span>
            )}
            <Button
              size="sm"
              className="bg-primary hover:bg-primary/90 text-white font-medium rounded-full px-4 py-2"
              onClick={e => {
                e.preventDefault();
                if (onPlay) onPlay(video);
                else window.location.href = `/watch/${video.id}`;
              }}
            >
              <Play className="mr-2 h-4 w-4" fill="white" />
              Play
            </Button>
            {onInfo && (
              <Button
                variant="outline"
                size="sm"
                className="bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white border-0 rounded-full px-4 py-2"
                onClick={e => {
                  e.preventDefault();
                  onInfo(video);
                }}
              >
                More Info
              </Button>
            )}
          </div>
        </div>
      </a>
    </div>
  );
} 