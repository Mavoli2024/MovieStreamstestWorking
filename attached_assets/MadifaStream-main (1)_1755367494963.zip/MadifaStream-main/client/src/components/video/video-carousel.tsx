import React from 'react';
import {  ModernContentGrid  } from '@/components/content/ModernContentGrid';

interface VideoCarouselProps {
  videos: Array<{ id: string; title: string; thumbnail_url?: string; duration_minutes?: number; is_premium?: boolean; genres?: string[] }>;
  title?: string;
  className?: string;
}

export function VideoCarousel({ videos, title, className }: VideoCarouselProps) {
  if (!videos || videos.length === 0) {
    return null;
  }

  return (
    <div className={className}>
      {title && (
        <h2 className="text-xl font-semibold mb-4">{title}</h2>
      )}
      <ModernContentGrid
        items={videos}
        variant="carousel"
        columns={5}
        className="gap-4"
      />
    </div>
  );
} 