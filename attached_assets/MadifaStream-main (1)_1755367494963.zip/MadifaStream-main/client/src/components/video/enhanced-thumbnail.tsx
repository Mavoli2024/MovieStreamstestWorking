import { cn } from '@/lib/utils';
import type { Video } from '@shared/schema';
import React, { useState } from 'react';
import { logger } from '@shared/logger';

interface EnhancedThumbnailProps {
  video: Video;
  className?: string;
  variant?: 'hero' | 'list' | 'grid';
  alt?: string;
}

export function EnhancedThumbnail({ 
  video, 
  className = '', 
  variant = 'grid',
  alt 
}: EnhancedThumbnailProps) {
  const [_failedUrls, _setFailedUrls] = useState<Set<string>>(new Set());
  const [currentFallbackIndex, setCurrentFallbackIndex] = useState(0);

  // Generate multiple fallback thumbnail URLs with better error handling
  const getThumbnailFallbacks = (): string[] => {
    const fallbacks: string[] = [];

    // Primary: Database-provided thumbnail URL
    if (video.thumbnail_url && video.thumbnail_url.trim()) {
      fallbacks.push(video.thumbnail_url);
    }

    // Secondary: Backend thumbnail proxy (robust API endpoint)
    if (video.id) {
      fallbacks.push(`/api/videos/${video.id}/thumbnail`);
    }

    // Tertiary: Generated SVG placeholder (always works)
    fallbacks.push(generatePlaceholder());

    return fallbacks;
  };

  const generatePlaceholder = (): string => {
    const dimensions = {
      hero: { width: 1280, height: 720 },
      list: { width: 320, height: 180 },
      grid: { width: 480, height: 270 }
    };
    
    const { width, height } = dimensions[variant] || dimensions.grid;
    const title = video.title || 'Video';
    const initials = title.split(' ')
      .map((word: string) => word[0])
      .join('')
      .substring(0, 2)
      .toUpperCase() || 'V';
    
    // Generate consistent color from title with better distribution
    let hash = 0;
    for (let i = 0; i < title.length; i++) {
      hash = title.charCodeAt(i) + ((hash << 5) - hash);
    }
    const hue = Math.abs(hash % 360);
    const lightColor = `hsl(${hue}, 70%, 45%)`;
    const darkColor = `hsl(${hue}, 70%, 25%)`;
    
    // Truncate title for display
    const displayTitle = title.length > 20 ? title.substring(0, 17) + '...' : title;
    
    return `data:image/svg+xml,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">
        <defs>
          <linearGradient id="grad-${video.id || 'default'}" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:${lightColor};stop-opacity:1" />
            <stop offset="100%" style="stop-color:${darkColor};stop-opacity:1" />
          </linearGradient>
        </defs>
        <rect width="100%" height="100%" fill="url(#grad-${video.id || 'default'})"/>
        <circle cx="50%" cy="40%" r="${Math.min(width, height) * 0.08}" fill="rgba(255,255,255,0.2)"/>
        <polygon points="45%,35% 45%,45% 55%,40%" fill="rgba(255,255,255,0.8)"/>
        <text x="50%" y="65%" dominant-baseline="middle" text-anchor="middle" 
              fill="white" font-size="${Math.min(width, height) * 0.08}" 
              font-weight="bold" font-family="Arial, sans-serif">
          ${initials}
        </text>
        <text x="50%" y="80%" dominant-baseline="middle" text-anchor="middle" 
              fill="rgba(255,255,255,0.9)" font-size="${Math.min(width, height) * 0.04}" 
              font-family="Arial, sans-serif">
          ${displayTitle}
        </text>
      </svg>
    `)}`;
  };

  const thumbnailFallbacks = getThumbnailFallbacks();
  const currentThumbnail = thumbnailFallbacks[currentFallbackIndex] || generatePlaceholder();

  const handleImageError = () => {
    const currentUrl = thumbnailFallbacks[currentFallbackIndex];
    
    // Mark current URL as failed
    _setFailedUrls(prev => new Set([...prev, currentUrl]));
    
    // Try next fallback
    if (currentFallbackIndex < thumbnailFallbacks.length - 1) {
      setCurrentFallbackIndex(prev => prev + 1);
      if (import.meta.env.DEV) {
        logger.warn(`Thumbnail failed for "${video.title}", trying fallback ${currentFallbackIndex + 2}/${thumbnailFallbacks.length}`);
      }
    } else {
      if (import.meta.env.DEV) {
        logger.error(`All thumbnail fallbacks failed for "${video.title}"`);
      }
    }
  };

  const handleImageLoad = () => {
    // Reset on successful load (for retries)
    if (currentFallbackIndex > 0) {
      if (import.meta.env.DEV) {
        logger.info(`Thumbnail loaded successfully for "${video.title}" using fallback ${currentFallbackIndex + 1}`);
      }
    }
  };

  return (
    <img
      src={currentThumbnail}
      alt={alt || video.title}
      className={cn(
        "transition-opacity duration-300",
        className
      )}
      onError={handleImageError}
      onLoad={handleImageLoad}
      loading="lazy"
    />
  );
}

export default EnhancedThumbnail; 