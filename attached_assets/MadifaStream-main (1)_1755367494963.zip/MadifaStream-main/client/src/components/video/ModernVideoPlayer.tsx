import { logger } from '@shared/logger';
/**
 * Modern Video Player Component
 * 
 * Production-grade video player with:
 * - Robust error handling and recovery
 * - Smooth, responsive controls
 * - Mobile-first design
 * - Network-aware quality adaptation
 * - Comprehensive analytics
 */

import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'react-hot-toast';
import { cn } from '@/lib/utils';
import { videoPlayerService } from '@/services/video-player-service';
import { useAuth } from '@/hooks/use-auth';
import { useWatchProgress } from '@/hooks/use-watch-progress';

// Icons
import { 
  Play, Pause, Volume2, VolumeX, Maximize, Minimize,
  SkipBack, SkipForward, Settings, Loader2, AlertCircle,
  RotateCcw, Subtitles, PictureInPicture, Cast,
  ChevronLeft, ChevronRight, Check
 } from 'lucide-react';

// UI Components
import {  Button  } from '@/components/ui/button';
import {  Slider  } from '@/components/ui/slider';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import {  Badge  } from '@/components/ui/badge';

interface ModernVideoPlayerProps {
  videoId: string;
  title: string;
  thumbnail?: string;
  onComplete?: () => void;
  onError?: (error: Error) => void;
  className?: string;
  autoplay?: boolean;
  startTime?: number;
}

type PlayerState = 'idle' | 'loading' | 'ready' | 'playing' | 'paused' | 'ended' | 'error';
type ControlsVisibility = 'visible' | 'hiding' | 'hidden';

const CONTROLS_HIDE_DELAY = 3000;
const SEEK_STEP = 10;
const VOLUME_STEP = 0.1;

export function ModernVideoPlayer({
  videoId,
  title,
  thumbnail,
  onComplete,
  onError,
  className,
  autoplay = false,
  startTime = 0,
}: ModernVideoPlayerProps) {
  // Refs
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const controlsTimeoutRef = useRef<NodeJS.Timeout>();
  const lastActivityRef = useRef<number>(Date.now());

  // State
  const [playerState, setPlayerState] = useState<PlayerState>('idle');
  const [streamUrl, setStreamUrl] = useState<string>('');
  const [currentTime, setCurrentTime] = useState(startTime);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isPiP, setIsPiP] = useState(false);
  const [controlsVisibility, setControlsVisibility] = useState<ControlsVisibility>('visible');
  const [quality, setQuality] = useState<string>('auto');
  const [playbackRate, setPlaybackRate] = useState(1);
  const [showSubtitles, setShowSubtitles] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [retryCount, setRetryCount] = useState(0);

  // Hooks
  const { user } = useAuth();
  // TODO: Fix watch progress hook interface
  const savedProgress = 0;
  const saveProgress = (time: number, completed?: boolean) => {};
  const forceSave = (time: number, completed?: boolean) => {};
  const isProgressLoading = false;

  // Computed values
  const progress = duration > 0 ? (currentTime / duration) * 100 : 0;
  const bufferedPercentage = duration > 0 ? (buffered / duration) * 100 : 0;
  const remainingTime = duration - currentTime;
  const isPlaying = playerState === 'playing';
  const canPlay = ['ready', 'playing', 'paused', 'ended'].includes(playerState);

  // Initialize player
  useEffect(() => {
    let mounted = true;
    let healthMonitor: (() => void) | null = null;

    const initPlayer = async () => {
      try {
        setPlayerState('loading');
        setError(null);

        const url = await videoPlayerService.getStreamUrl({ videoId });
        
        if (!mounted) return;

        setStreamUrl(url);
        setPlayerState('ready');

        // Set up health monitoring
        if (videoRef.current) {
          healthMonitor = videoPlayerService.monitorStreamHealth(
            videoId,
            videoRef.current,
            (newQuality) => {
              if (quality === 'auto') {
                setQuality(newQuality);
                toast.success(`Quality adjusted to ${newQuality}`);
              }
            }
          );
        }

        // Load saved progress
        if (savedProgress && savedProgress > 0 && savedProgress < duration * 0.95) {
          setCurrentTime(savedProgress);
          if (videoRef.current) {
            videoRef.current.currentTime = savedProgress;
          }
        }
      } catch (err) {
        if (!mounted) return;

        const errorMessage = err instanceof Error ? err.message : 'Failed to load video';
        setError(errorMessage);
        setPlayerState('error');
        onError?.(err instanceof Error ? err : new Error(errorMessage));

        // Show user-friendly error
        if (errorMessage.includes('Subscription required')) {
          toast.error('This content requires a subscription');
        } else {
          toast.error('Failed to load video. Please try again.');
        }
      }
    };

    initPlayer();

    return () => {
      mounted = false;
      healthMonitor?.();
      videoPlayerService.cleanup(videoId);
    };
  }, [videoId, quality, savedProgress, duration, onError]);

  // Video event handlers
  const handleLoadedMetadata = useCallback(() => {
    if (!videoRef.current) return;
    
    setDuration(videoRef.current.duration);
    
    if (currentTime > 0) {
      videoRef.current.currentTime = currentTime;
    }
    
    if (autoplay) {
      handlePlay();
    }
  }, [currentTime, autoplay]);

  const handleTimeUpdate = useCallback(() => {
    if (!videoRef.current) return;
    
    const time = videoRef.current.currentTime;
    setCurrentTime(time);
    
    // Update buffered
    if (videoRef.current.buffered.length > 0) {
      const bufferedEnd = videoRef.current.buffered.end(videoRef.current.buffered.length - 1);
      setBuffered(bufferedEnd);
    }
    
    // Save progress periodically
    if (time > 5 && Math.floor(time) % 10 === 0) {
      saveProgress(time);
    }
  }, [videoId, duration, saveProgress]);

  const handlePlay = useCallback(async () => {
    if (!videoRef.current || !canPlay) return;
    
    try {
      await videoRef.current.play();
      setPlayerState('playing');
      showControlsTemporarily();
    } catch (err) {
      logger.error('Play failed:', { arg1: err });
      toast.error('Unable to play video');
    }
  }, [canPlay]);

  const handlePause = useCallback(() => {
    if (!videoRef.current) return;
    
    videoRef.current.pause();
    setPlayerState('paused');
    setControlsVisibility('visible');
  }, []);

  const handleEnded = useCallback(() => {
    setPlayerState('ended');
    setControlsVisibility('visible');
    saveProgress(duration, true);
    onComplete?.();
  }, [duration, saveProgress, onComplete]);

  const handleError = useCallback((e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    const video = e.currentTarget;
    const error = video.error;
    
    logger.error('Video error:', { arg1: error });
    
    let errorMessage = 'Video playback failed';
    if (error) {
      switch (error.code) {
        case 1: // MEDIA_ERR_ABORTED
          errorMessage = 'Video playback was aborted';
          break;
        case 2: // MEDIA_ERR_NETWORK
          errorMessage = 'Network error occurred';
          break;
        case 3: // MEDIA_ERR_DECODE
          errorMessage = 'Video decoding failed';
          break;
        case 4: // MEDIA_ERR_SRC_NOT_SUPPORTED
          errorMessage = 'Video format not supported';
          break;
      }
    }
    
    setPlayerState('error');
    setError(errorMessage);
    onError?.(new Error(errorMessage));
  }, [onError]);

  // Control handlers
  const togglePlayPause = useCallback(() => {
    if (isPlaying) {
      handlePause();
    } else {
      handlePlay();
    }
  }, [isPlaying, handlePlay, handlePause]);

  const handleSeek = useCallback((newTime: number) => {
    if (!videoRef.current || !canPlay) return;
    
    const clampedTime = Math.max(0, Math.min(newTime, duration));
    videoRef.current.currentTime = clampedTime;
    setCurrentTime(clampedTime);
    showControlsTemporarily();
  }, [duration, canPlay]);

  const handleProgressClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!progressRef.current) return;
    
    const rect = progressRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const percentage = x / rect.width;
    const newTime = percentage * duration;
    
    handleSeek(newTime);
  }, [duration, handleSeek]);

  const handleVolumeChange = useCallback((newVolume: number[]) => {
    if (!videoRef.current) return;
    
    const volume = newVolume[0];
    videoRef.current.volume = volume;
    setVolume(volume);
    setIsMuted(volume === 0);
  }, []);

  const toggleMute = useCallback(() => {
    if (!videoRef.current) return;
    
    if (isMuted) {
      videoRef.current.volume = volume || 0.5;
      setIsMuted(false);
    } else {
      videoRef.current.volume = 0;
      setIsMuted(true);
    }
  }, [isMuted, volume]);

  const toggleFullscreen = useCallback(async () => {
    if (!containerRef.current) return;
    
    try {
      if (isFullscreen) {
        await document.exitFullscreen();
      } else {
        await containerRef.current.requestFullscreen();
      }
    } catch (err) {
      logger.error('Fullscreen error:', { arg1: err });
    }
  }, [isFullscreen]);

  const togglePiP = useCallback(async () => {
    if (!videoRef.current) return;
    
    try {
      if (isPiP) {
        await document.exitPictureInPicture();
      } else {
        await videoRef.current.requestPictureInPicture();
      }
    } catch (err) {
      logger.error('PiP error:', { arg1: err });
      toast.error('Picture-in-Picture not supported');
    }
  }, [isPiP]);

  const handlePlaybackRateChange = useCallback((rate: number) => {
    if (!videoRef.current) return;
    
    videoRef.current.playbackRate = rate;
    setPlaybackRate(rate);
    toast.success(`Playback speed: ${rate}x`);
  }, []);

  const handleQualityChange = useCallback((newQuality: string) => {
    setQuality(newQuality);
    toast.success(`Quality: ${newQuality}`);
    // Quality change would trigger re-initialization
  }, []);

  // Controls visibility
  const showControlsTemporarily = useCallback(() => {
    lastActivityRef.current = Date.now();
    setControlsVisibility('visible');
    
    if (controlsTimeoutRef.current) {
      clearTimeout(controlsTimeoutRef.current);
    }
    
    if (isPlaying) {
      controlsTimeoutRef.current = setTimeout(() => {
        if (Date.now() - lastActivityRef.current >= CONTROLS_HIDE_DELAY) {
          setControlsVisibility('hiding');
          setTimeout(() => setControlsVisibility('hidden'), 300);
        }
      }, CONTROLS_HIDE_DELAY);
    }
  }, [isPlaying]);

  const handleMouseMove = useCallback(() => {
    showControlsTemporarily();
  }, [showControlsTemporarily]);

  const handleMouseLeave = useCallback(() => {
    if (isPlaying) {
      setControlsVisibility('hiding');
      setTimeout(() => setControlsVisibility('hidden'), 300);
    }
  }, [isPlaying]);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!canPlay) return;
      
      switch (e.key) {
        case ' ':
        case 'k':
          e.preventDefault();
          togglePlayPause();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          handleSeek(currentTime - SEEK_STEP);
          break;
        case 'ArrowRight':
          e.preventDefault();
          handleSeek(currentTime + SEEK_STEP);
          break;
        case 'ArrowUp':
          e.preventDefault();
          handleVolumeChange([Math.min(volume + VOLUME_STEP, 1)]);
          break;
        case 'ArrowDown':
          e.preventDefault();
          handleVolumeChange([Math.max(volume - VOLUME_STEP, 0)]);
          break;
        case 'm':
          e.preventDefault();
          toggleMute();
          break;
        case 'f':
          e.preventDefault();
          toggleFullscreen();
          break;
        case 'p':
          e.preventDefault();
          togglePiP();
          break;
        case 'c':
          e.preventDefault();
          setShowSubtitles(!showSubtitles);
          break;
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    canPlay, togglePlayPause, currentTime, volume, showSubtitles,
    handleSeek, handleVolumeChange, toggleMute, toggleFullscreen, togglePiP
  ]);

  // Fullscreen change listener
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  // PiP change listener
  useEffect(() => {
    const handlePiPChange = () => {
      setIsPiP(document.pictureInPictureElement === videoRef.current);
    };
    
    document.addEventListener('enterpictureinpicture', handlePiPChange);
    document.addEventListener('leavepictureinpicture', handlePiPChange);
    
    return () => {
      document.removeEventListener('enterpictureinpicture', handlePiPChange);
      document.removeEventListener('leavepictureinpicture', handlePiPChange);
    };
  }, []);

  // Format time
  const formatTime = (seconds: number): string => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    
    if (h > 0) {
      return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  // Render error state
  if (playerState === 'error') {
    return (
      <div className={cn(
        'relative bg-black rounded-lg overflow-hidden aspect-video flex items-center justify-center',
        className
      )}>
        <div className="text-center p-8">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-white mb-2">Unable to play video</h3>
          <p className="text-gray-400 mb-4">{error || 'An unexpected error occurred'}</p>
          <Button
            onClick={() => window.location.reload()}
            className="bg-white text-black hover:bg-gray-200"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className={cn(
        'relative bg-black rounded-lg overflow-hidden aspect-video group',
        'focus:outline-none focus:ring-2 focus:ring-primary',
        className
      )}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      tabIndex={0}
    >
      {/* Video element */}
      <video
        ref={videoRef}
        className="w-full h-full"
        src={streamUrl}
        poster={thumbnail}
        onLoadedMetadata={handleLoadedMetadata}
        onTimeUpdate={handleTimeUpdate}
        onPlay={() => setPlayerState('playing')}
        onPause={() => setPlayerState('paused')}
        onEnded={handleEnded}
        onError={handleError}
        onWaiting={() => setPlayerState('loading')}
        onCanPlay={() => playerState === 'loading' && setPlayerState('ready')}
        playsInline
      />

      {/* Loading overlay */}
      <AnimatePresence>
        {playerState === 'loading' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 flex items-center justify-center bg-black/50"
          >
            <Loader2 className="w-12 h-12 text-white animate-spin" />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Controls overlay */}
      <AnimatePresence>
        {controlsVisibility !== 'hidden' && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: controlsVisibility === 'visible' ? 1 : 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30"
          >
            {/* Top bar */}
            <div className="absolute top-0 left-0 right-0 p-4 flex items-center justify-between">
              <h2 className="text-white font-semibold text-lg truncate flex-1 mr-4">
                {title}
              </h2>
              
              <div className="flex items-center gap-2">
                {quality !== 'auto' && (
                  <Badge variant="secondary" className="bg-black/50 text-white">
                    {quality}
                  </Badge>
                )}
                
                {playbackRate !== 1 && (
                  <Badge variant="secondary" className="bg-black/50 text-white">
                    {playbackRate}x
                  </Badge>
                )}
              </div>
            </div>

            {/* Center play button */}
            {!isPlaying && playerState !== 'loading' && (
              <div className="absolute inset-0 flex items-center justify-center">
                <Button
                  size="lg"
                  onClick={togglePlayPause}
                  className="w-20 h-20 rounded-full bg-white/20 backdrop-blur hover:bg-white/30"
                >
                  <Play className="w-10 h-10 text-white fill-white ml-1" />
                </Button>
              </div>
            )}

            {/* Bottom controls */}
            <div className="absolute bottom-0 left-0 right-0 p-4 space-y-2">
              {/* Progress bar */}
              <div
                ref={progressRef}
                className="relative h-1 bg-white/20 rounded-full cursor-pointer group/progress"
                onClick={handleProgressClick}
              >
                {/* Buffered */}
                <div
                  className="absolute inset-y-0 left-0 bg-white/30 rounded-full"
                  style={{ width: `${bufferedPercentage}%` }}
                />
                
                {/* Progress */}
                <div
                  className="absolute inset-y-0 left-0 bg-primary rounded-full"
                  style={{ width: `${progress}%` }}
                />
                
                {/* Hover indicator */}
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-primary rounded-full opacity-0 group-hover/progress:opacity-100 transition-opacity"
                  style={{ left: `${progress}%` }}
                />
              </div>

              {/* Control buttons */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {/* Play/Pause */}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={togglePlayPause}
                    className="text-white hover:bg-white/20"
                  >
                    {isPlaying ? (
                      <Pause className="w-5 h-5" />
                    ) : (
                      <Play className="w-5 h-5 fill-white" />
                    )}
                  </Button>

                  {/* Skip buttons */}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleSeek(currentTime - SEEK_STEP)}
                    className="text-white hover:bg-white/20"
                  >
                    <SkipBack className="w-5 h-5" />
                  </Button>
                  
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => handleSeek(currentTime + SEEK_STEP)}
                    className="text-white hover:bg-white/20"
                  >
                    <SkipForward className="w-5 h-5" />
                  </Button>

                  {/* Volume */}
                  <div className="flex items-center gap-2 group/volume">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={toggleMute}
                      className="text-white hover:bg-white/20"
                    >
                      {isMuted || volume === 0 ? (
                        <VolumeX className="w-5 h-5" />
                      ) : (
                        <Volume2 className="w-5 h-5" />
                      )}
                    </Button>
                    
                    <div className="w-0 group-hover/volume:w-24 transition-all duration-300 overflow-hidden">
                      <Slider
                        value={[isMuted ? 0 : volume]}
                        onValueChange={handleVolumeChange}
                        max={1}
                        step={0.05}
                        className="cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Time */}
                  <div className="text-white text-sm font-mono">
                    {formatTime(currentTime)} / {formatTime(duration)}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {/* Subtitles */}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => setShowSubtitles(!showSubtitles)}
                    className={cn(
                      'text-white hover:bg-white/20',
                      showSubtitles && 'bg-white/20'
                    )}
                  >
                    <Subtitles className="w-5 h-5" />
                  </Button>

                  {/* Settings */}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-white hover:bg-white/20"
                      >
                        <Settings className="w-5 h-5" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48">
                      <DropdownMenuLabel>Quality</DropdownMenuLabel>
                      {['auto', '1080p', '720p', '480p', '360p'].map((q) => (
                        <DropdownMenuItem
                          key={q}
                          onClick={() => handleQualityChange(q)}
                        >
                          <span className="flex-1">{q}</span>
                          {quality === q && <Check className="w-4 h-4" />}
                        </DropdownMenuItem>
                      ))}
                      
                      <DropdownMenuSeparator />
                      
                      <DropdownMenuLabel>Playback Speed</DropdownMenuLabel>
                      {[0.5, 0.75, 1, 1.25, 1.5, 2].map((speed) => (
                        <DropdownMenuItem
                          key={speed}
                          onClick={() => handlePlaybackRateChange(speed)}
                        >
                          <span className="flex-1">{speed}x</span>
                          {playbackRate === speed && <Check className="w-4 h-4" />}
                        </DropdownMenuItem>
                      ))}
                    </DropdownMenuContent>
                  </DropdownMenu>

                  {/* PiP */}
                  {document.pictureInPictureEnabled && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={togglePiP}
                      className={cn(
                        'text-white hover:bg-white/20',
                        isPiP && 'bg-white/20'
                      )}
                    >
                      <PictureInPicture className="w-5 h-5" />
                    </Button>
                  )}

                  {/* Cast */}
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-white hover:bg-white/20"
                  >
                    <Cast className="w-5 h-5" />
                  </Button>

                  {/* Fullscreen */}
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={toggleFullscreen}
                    className="text-white hover:bg-white/20"
                  >
                    {isFullscreen ? (
                      <Minimize className="w-5 h-5" />
                    ) : (
                      <Maximize className="w-5 h-5" />
                    )}
                  </Button>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
} 