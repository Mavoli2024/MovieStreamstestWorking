import {  Button  } from '@/components/ui/button';
import {  DirectHeroImage  } from '@/components/ui/direct-hero-image';
import {  Play, Film  } from 'lucide-react';
import { extractBunnyGuid } from '@/lib/utils';
import type { Video } from '@shared/schema';

interface VideoHeroBannerProps {
  video: Video;
  onInfo?: (v: Video) => void;
}

/**
 * Full-width hero banner for featured video.
 * Handles gradients, CTA buttons and is mobile-friendly.
 */
export function VideoHeroBanner({ video, onInfo }: VideoHeroBannerProps) {
  const videoId = extractBunnyGuid(video.video_url || '');

  return (
    <div className="relative w-full h-[70vh] overflow-hidden">
      {/* background */}
      <div className="absolute inset-0">
        <DirectHeroImage
          videoId={videoId || null}
          title={video.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-transparent" />
      </div>

      {/* content */}
      <div className="relative z-10 container mx-auto h-full flex flex-col justify-end p-6 md:p-12">
        <div className="max-w-2xl">
          <h1 className="text-3xl md:text-5xl lg:text-6xl font-extrabold mb-3 text-white" style={{ textShadow: '0 2px 10px rgba(0,0,0,0.5)' }}>
            {video.title}
          </h1>
          {video.description && (
            <p className="text-lg md:text-xl text-gray-200 mb-6 line-clamp-2">{video.description}</p>
          )}
          <div className="flex flex-wrap gap-3 mb-8">
            <Button
              size="lg"
              className="bg-primary hover:bg-primary/90 text-white font-medium rounded-full"
              onClick={() => {
                window.location.href = `/watch/${video.id}`;
              }}
            >
              <Play className="mr-2 h-5 w-5" fill="white" />
              Play
            </Button>
            {onInfo && (
              <Button
                variant="outline"
                size="lg"
                className="bg-white/20 hover:bg-white/30 backdrop-blur-sm text-white border-0 rounded-full"
                onClick={() => onInfo(video)}
              >
                <Film className="mr-2 h-5 w-5" />
                More Info
              </Button>
            )}
          </div>
          {(video.duration_minutes || video.duration) && (
            <span className="text-sm text-gray-300">
              {Math.floor((video.duration_minutes ?? video.duration ?? 0))} min
            </span>
          )}
        </div>
      </div>
    </div>
  );
} 