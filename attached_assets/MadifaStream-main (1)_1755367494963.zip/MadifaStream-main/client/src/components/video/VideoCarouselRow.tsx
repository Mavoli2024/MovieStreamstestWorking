import React, { useRef } from 'react';
import {  Button  } from '@/components/ui/button';
import {  ChevronLeft, ChevronRight  } from 'lucide-react';
import {  UnifiedVideoCard  } from './unified-video-card';
import type { Database } from '@/types/database-generated.types';

type Video = Database['public']['Tables']['videos']['Row'];

interface VideoCarouselRowProps {
  title: string;
  videos: Video[];
  className?: string;
  showSeeMore?: boolean;
  onSeeMore?: () => void;
  onPlay?: (video: Video) => void;
  onInfo?: (video: Video) => void;
}

/**
 * VideoCarouselRow – horizontally scrollable row using UnifiedVideoCard for consistent visuals.
 */
export const VideoCarouselRow: React.FC<VideoCarouselRowProps> = ({
  title,
  videos,
  className = '',
  showSeeMore = false,
  onSeeMore,
  onPlay,
  onInfo,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scrollLeft = () => {
    scrollRef.current?.scrollBy({ left: -500, behavior: 'smooth' });
  };

  const scrollRight = () => {
    scrollRef.current?.scrollBy({ left: 500, behavior: 'smooth' });
  };

  if (!videos || videos.length === 0) return null;

  return (
    <section className={`py-8 ${className}`}>
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-semibold text-white">{title}</h2>
          {showSeeMore && onSeeMore && (
            <Button
              variant="outline"
              size="sm"
              onClick={onSeeMore}
              className="text-primary border-primary hover:bg-primary hover:text-white"
            >
              See More
            </Button>
          )}
        </div>
        <div className="relative">
          <div
            ref={scrollRef}
            className="flex space-x-4 overflow-x-auto no-scrollbar pb-4"
          >
            {videos.map((video) => (
              <UnifiedVideoCard
                key={video.id}
                video={video}
                variant="carousel"
                onPlay={onPlay}
                onInfo={onInfo}
              />
            ))}
          </div>

          {!showSeeMore && videos.length > 4 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-2 top-1/2 transform -translate-y-1/2 hidden md:flex bg-black bg-opacity-50 text-white rounded-full h-10 w-10"
                onClick={scrollLeft}
              >
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 hidden md:flex bg-black bg-opacity-50 text-white rounded-full h-10 w-10"
                onClick={scrollRight}
              >
                <ChevronRight className="h-5 w-5" />
              </Button>
            </>
          )}
        </div>
      </div>
    </section>
  );
};
