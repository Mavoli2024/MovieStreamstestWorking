/**
 * Unified Video Card Component with Class Variance Authority
 * 
 * Single Source of Truth for all video displays across the app.
 * Supports multiple variants while maintaining consistent behavior.
 */

import {  Badge  } from '@/components/ui/badge';
import {  Button  } from '@/components/ui/button';
import {  ThumbnailImage  } from '@/components/ui/thumbnail-image';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { adaptVideoForUI } from '@/lib/type-adapters';
import { cva, type VariantProps } from 'class-variance-authority';
import {  
  Clock, 
  Crown, 
  Eye, 
  Film, 
  Play, 
  Plus, 
  X
 } from 'lucide-react';
// Added useVideos hook to determine linked trailer/full movie
import { useVideos } from '@/hooks/use-videos';
import React, { useState } from 'react';
import type { Database } from '@/types/database-generated.types';

// Base video type from Supabase
type Video = Database['public']['Tables']['videos']['Row'];

// Video card variants using CVA
const videoCardVariants = cva(
  "relative group flex flex-col overflow-hidden transition-all duration-300 hover:shadow-lg",
  {
    variants: {
      variant: {
        grid: "w-full bg-card rounded-xl shadow-md hover:shadow-primary/20 hover:scale-[1.02]",
        list: "flex-row bg-card/50 rounded-xl hover:bg-card/70 backdrop-blur-sm",
        hero: "h-[100vh] bg-black",
        carousel: "w-56 bg-transparent rounded-xl hover:scale-[1.05] transition-transform duration-300",
        admin: "bg-card/30 rounded-xl border border-border hover:border-primary/50"
      },
    },
    defaultVariants: {
      variant: "grid",
    }
  }
);

// Content (thumbnail) container variants
const contentVariants = cva(
  "relative w-full overflow-hidden",
  {
    variants: {
      variant: {
        grid: "aspect-video rounded-t-xl",
        list: "w-48 aspect-video flex-shrink-0 rounded-l-xl",
        hero: "absolute inset-0",
        carousel: "aspect-video rounded-xl shadow-lg group-hover:shadow-xl transition-shadow duration-300",
        admin: "aspect-video rounded-t-xl"
      }
    }
  }
);

// Info section variants
const infoVariants = cva(
  "flex flex-col",
  {
    variants: {
      variant: {
        grid: "p-4 flex-1 space-y-2",
        list: "p-4 flex-1 space-y-2",
        hero: "absolute inset-0 z-20 p-8 md:p-12 lg:p-16 justify-end bg-gradient-to-t from-black/80 via-black/30 to-transparent",
        carousel: "pt-3 px-1 space-y-1",
        admin: "p-4 border-t border-border space-y-2"
      }
    }
  }
);

export interface UnifiedVideoCardProps extends VariantProps<typeof videoCardVariants> {
  video: Video;
  progress?: number; // 0-100
  isInWatchlist?: boolean;
  showProgress?: boolean;
  showGenres?: boolean;
  showDuration?: boolean;
  showViews?: boolean;
  showPremiumBadge?: boolean;
  onPlay?: (video: Video) => void;
  onAddToWatchlist?: (videoId: string) => void;
  onRemoveFromWatchlist?: (videoId: string) => void;
  onInfo?: (video: Video) => void;
  className?: string;
  imagePriority?: boolean;
}

/**
 * Unified Video Card - Single Source of Truth for all video displays
 */
export const UnifiedVideoCard: React.FC<UnifiedVideoCardProps> = ({
  video,
  variant,
  progress = 0,
  isInWatchlist = false,
  showProgress = true,
  showGenres = true,
  showDuration = true,
  showViews = false,
  showPremiumBadge = true,
  onPlay,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onInfo,
  className,
  imagePriority = false,
}) => {
  const { toast } = useToast();
  const [isHovered, setIsHovered] = useState(false);  // Helper functions
  const adaptedVideo = adaptVideoForUI(video);
  const duration = adaptedVideo.duration_minutes || 0;
  const isPremium = video.is_premium;
  const isTrailer = video.is_trailer;

  // Fetch all videos to analyse trailer/full relationships
  const { data: allVideos } = useVideos();

  // Helper functions
  const formatDuration = (minutes?: number) => {
    if (!minutes) return '';
    
    // Handle case where duration might be in seconds (from Bunny API)
    let totalMinutes = minutes;
    if (minutes > 300) { // Assume it's seconds if over 5 hours in "minutes"
      totalMinutes = Math.floor(minutes / 60);
    }
    
    const hours = Math.floor(totalMinutes / 60);
    const mins = Math.floor(totalMinutes % 60);
    
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    } else {
      return `${mins}m`;
    }
  };

  // If this is a trailer, find matching full movie whose trailer_url references this trailer
  const fullMovie = React.useMemo(() => {
    if (!isTrailer || !allVideos) return null;
    return allVideos.find(
      (v) =>
        !v.is_trailer &&
        v.trailer_url &&
        (v.trailer_url === video.video_url || v.trailer_url.includes(video.id))
    ) || null;
  }, [isTrailer, allVideos, video.video_url, video.id]);

  // If this is a full movie, find its trailer (if any)
  const linkedTrailer = React.useMemo(() => {
    if (isTrailer || !video.trailer_url || !allVideos) return null;
    return allVideos.find(
      (v) => v.is_trailer && (v.video_url === video.trailer_url || v.id === video.trailer_url)
    ) || null;
  }, [isTrailer, video.trailer_url, allVideos]);

  // Play handlers (defined after we know linked videos)
  const handlePlay = (e?: React.MouseEvent) => {
    e?.stopPropagation();

    if (isTrailer && fullMovie) {
      window.location.href = `/watch/${fullMovie.id}`;
      return;
    }

    if (onPlay) {
      onPlay(video);
    } else {
      window.location.href = `/watch/${video.id}`;
    }
  };

  const handleWatchTrailer = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!linkedTrailer) return;
    window.location.href = `/watch/${linkedTrailer.id}`;
  };

  const handleWatchFullMovie = (e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!fullMovie) return;
    window.location.href = `/watch/${fullMovie.id}`;
  };

  const handleWatchlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isInWatchlist && onRemoveFromWatchlist) {
      onRemoveFromWatchlist(video.id);
    } else if (!isInWatchlist && onAddToWatchlist) {
      onAddToWatchlist(video.id);
    }
  };

  return (
    <div
      className={cn(videoCardVariants({ variant }), className)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handlePlay}
      style={{ cursor: 'pointer' }}
    >
      {/* --- THUMBNAIL & OVERLAYS --- */}
      <div className={cn(contentVariants({ variant }))}>
        <ThumbnailImage
          video={video}
          alt={video.title}
          title={video.title}
          className="w-full h-full object-cover"
          priority={imagePriority || variant === 'carousel'}
        />

        {/* Progress Bar */}
        {showProgress && progress > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-500/50">
            <div className="h-full bg-primary" style={{ width: `${progress}%` }} />
          </div>
        )}

        {/* Play Button Overlay */}
        <div className={cn(
          "absolute inset-0 flex items-center justify-center transition-all duration-300",
          "bg-black/0 group-hover:bg-black/40",
          { "opacity-0 group-hover:opacity-100": variant !== 'hero' }
        )}>
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "rounded-full text-white transition-all duration-300",
              "bg-black/30 backdrop-blur-sm border-white/50 border-2",
              "hover:bg-primary hover:border-primary hover:scale-110",
              "scale-0 group-hover:scale-100",
              "h-12 w-12 shadow-lg"
            )}
            onClick={(e) => {
              e.stopPropagation();
              handlePlay(e);
            }}
          >
            <Play className="h-5 w-5 ml-0.5 fill-white" />
          </Button>
        </div>

        {/* Badge Overlays */}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          {showPremiumBadge && isPremium && (
            <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-black text-xs font-bold border-none shadow-lg">
              <Crown className="w-3 h-3 mr-1" />
              Premium
            </Badge>
          )}
          {isTrailer && (
            <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs font-bold border-none shadow-lg">
              <Film className="w-3 h-3 mr-1" />
              Free
            </Badge>
          )}
        </div>
      </div>

      {/* --- INFO SECTION --- */}
      <div className={cn(infoVariants({ variant }))}>
        {/* Carousel gets a simplified, clean info display */}
        {variant === 'carousel' && (
          <>
            <h3 className="font-semibold text-white text-sm leading-tight line-clamp-2 mb-1">
              {video.title}
            </h3>
            <div className="flex items-center justify-between text-xs text-gray-400">
              {video.release_year && <span className="font-medium">{video.release_year}</span>}
              {showDuration && duration > 0 && (
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  <span>{formatDuration(duration)}</span>
                </div>
              )}
            </div>
          </>
        )}

        {/* Grid and List variants get a more detailed info display */}
        {(variant === 'grid' || variant === 'list') && (
          <div className="flex flex-col flex-1">
            <h3 className="font-semibold text-foreground text-base leading-tight line-clamp-2">
              {video.title}
            </h3>
            
            <div className="flex-grow" />

            {showGenres && video.genres && video.genres.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {video.genres.slice(0, 2).map((genre) => (
                  <Badge key={genre} variant="outline" className="text-xs">{genre}</Badge>
                ))}
              </div>
            )}
            
            <div className="flex items-center justify-between text-xs text-muted-foreground mt-2">
              {showDuration && duration > 0 && (
                <div className="flex items-center">
                  <Clock className="w-3 h-3 mr-1" />
                  <span>{formatDuration(duration)}</span>
                </div>
              )}
              {video.release_year && <span>{video.release_year}</span>}
            </div>
          </div>
        )}
        
        {/* Hero variant gets its own rich content display */}
        {variant === 'hero' && (
          <>
            <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold text-white mb-4">
              {video.title}
            </h1>
            <p className="text-lg text-gray-200 mb-6 line-clamp-3 max-w-2xl">
              {video.description}
            </p>
            <div className="flex items-center gap-4">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-white font-semibold"
                onClick={handlePlay}
              >
                <Play className="w-5 h-5 mr-2" fill="white" />
                {isTrailer ? 'Play Trailer' : 'Play'}
              </Button>

              {/* Trailer card: Watch Full Movie (disabled if not available) */}
              {isTrailer && (
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/50 text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
                  onClick={handleWatchFullMovie}
                  disabled={!fullMovie}
                  title={fullMovie ? '' : 'Full movie not available yet'}
                >
                  Watch Full Movie
                </Button>
              )}

              {/* Full movie card: Watch Trailer (disabled if not available) */}
              {!isTrailer && (
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white/50 text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
                  onClick={handleWatchTrailer}
                  disabled={!linkedTrailer}
                  title={linkedTrailer ? '' : 'Trailer not available'}
                >
                  Watch Trailer
                </Button>
              )}
              {onAddToWatchlist && onRemoveFromWatchlist && (
                 <Button
                    variant="outline"
                    size="icon"
                    className="text-white border-white/50 hover:bg-white/10 hover:border-white"
                    onClick={handleWatchlist}
                  >
                    {isInWatchlist ? <X className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
                  </Button>
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
};

// Convenience wrapper components for specific use cases
export const VideoGridCard = (props: Omit<UnifiedVideoCardProps, 'variant'>) => (
  <UnifiedVideoCard {...props} variant="grid" />
);

export const VideoListCard = (props: Omit<UnifiedVideoCardProps, 'variant'>) => (
  <UnifiedVideoCard {...props} variant="list" />
);

export const VideoHeroCard = (props: Omit<UnifiedVideoCardProps, 'variant'>) => (
  <UnifiedVideoCard {...props} variant="hero" />
);

export const VideoCarouselCard = (props: Omit<UnifiedVideoCardProps, 'variant'>) => (
  <UnifiedVideoCard {...props} variant="carousel" showGenres={false} />
);

export const VideoAdminCard = (props: Omit<UnifiedVideoCardProps, 'variant'>) => (
  <UnifiedVideoCard {...props} variant="admin" />
);


// Default export for module compatibility
export default UnifiedVideoCard;