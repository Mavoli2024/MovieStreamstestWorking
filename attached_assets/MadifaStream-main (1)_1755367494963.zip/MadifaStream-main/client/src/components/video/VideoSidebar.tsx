interface VideoSidebarProps {
  className?: string;
}

export const VideoSidebar = ({ className }: VideoSidebarProps) => {
  return (
    <aside className={className}>
      <div className="sticky top-8 rounded-lg bg-muted/30 p-4">
        <h3 className="text-lg font-semibold text-foreground">
          Up Next
        </h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Related videos will be displayed here in a future update.
        </p>
      </div>
    </aside>
  );
}; 