import React, { useState, useMemo } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RobustErrorBoundary } from '@/components/error-boundary/RobustErrorBoundary';
import { RobustLoadingState, InlineLoading } from '@/components/ui/robust-loading';
import { useRobustVideos } from '@/hooks/use-robust-data';
import { Play, Clock, Star, AlertCircle, RefreshCw } from 'lucide-react';
import { logger } from '@shared/logger';

interface Video {
  id: string;
  title: string;
  description?: string;
  thumbnail_url?: string;
  duration?: number;
  view_count?: number;
  rating?: number;
  is_premium?: boolean;
  category?: string;
  created_at?: string;
}

interface VideoCardProps {
  video: Video;
  onPlay?: (video: Video) => void;
  onError?: (error: Error) => void;
  className?: string;
}

function VideoCard({ video, onPlay, onError, className = '' }: VideoCardProps) {
  const [imageLoading, setImageLoading] = useState(true);
  const [imageError, setImageError] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  
  const MAX_RETRIES = 2;

  const handleImageLoad = () => {
    setImageLoading(false);
    setImageError(false);
  };

  const handleImageError = () => {
    setImageLoading(false);
    
    if (retryCount < MAX_RETRIES) {
      // Retry loading the image
      setRetryCount(prev => prev + 1);
      setImageError(false);
      setImageLoading(true);
      
      // Force reload with cache busting
      const img = new Image();
      img.onload = handleImageLoad;
      img.onerror = () => setImageError(true);
      img.src = `${video.thumbnail_url}?retry=${retryCount + 1}`;
    } else {
      setImageError(true);
      logger.warn(`Failed to load thumbnail for video ${video.id} after ${MAX_RETRIES} retries`);
    }
  };

  const handlePlay = () => {
    try {
      logger.info(`Playing video: ${video.id} - ${video.title}`);
      onPlay?.(video);
    } catch (error) {
      const err = error instanceof Error ? error : new Error('Failed to play video');
      logger.error(`Error playing video ${video.id}:`, err);
      onError?.(err);
    }
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds) return null;
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const fallbackImage = '/fallback-thumbnail.svg';
  const thumbnailSrc = video.thumbnail_url || fallbackImage;

  return (
    <Card className={`group hover:shadow-lg transition-all duration-200 overflow-hidden ${className}`}>
      <CardContent className="p-0">
        {/* Thumbnail Section */}
        <div className="relative aspect-video bg-gray-100 overflow-hidden">
          {imageLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
              <div className="w-6 h-6 border-2 border-gray-300 border-t-transparent rounded-full animate-spin"></div>
            </div>
          )}
          
          {imageError ? (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-100 text-gray-400">
              <AlertCircle className="w-8 h-8 mb-2" />
              <span className="text-sm">No image</span>
            </div>
          ) : (
            <img
              src={thumbnailSrc}
              alt={video.title}
              className={`w-full h-full object-cover transition-transform duration-200 group-hover:scale-105 ${imageLoading ? 'opacity-0' : 'opacity-100'}`}
              onLoad={handleImageLoad}
              onError={handleImageError}
              loading="lazy"
            />
          )}
          
          {/* Play Button Overlay */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors duration-200 flex items-center justify-center">
            <Button
              onClick={handlePlay}
              size="lg"
              className="opacity-0 group-hover:opacity-100 transition-opacity duration-200 bg-white/90 hover:bg-white text-black"
            >
              <Play className="w-6 h-6" />
            </Button>
          </div>
          
          {/* Duration Badge */}
          {video.duration && (
            <Badge
              variant="secondary"
              className="absolute bottom-2 right-2 bg-black/70 text-white border-0"
            >
              <Clock className="w-3 h-3 mr-1" />
              {formatDuration(video.duration)}
            </Badge>
          )}
          
          {/* Premium Badge */}
          {video.is_premium && (
            <Badge
              variant="default"
              className="absolute top-2 left-2 bg-gradient-to-r from-yellow-400 to-yellow-600 text-black border-0"
            >
              <Star className="w-3 h-3 mr-1" />
              Premium
            </Badge>
          )}
        </div>
        
        {/* Content Section */}
        <div className="p-4 space-y-2">
          <h3 className="font-semibold text-sm line-clamp-2 leading-tight">
            {video.title || 'Untitled Video'}
          </h3>
          
          {video.description && (
            <p className="text-xs text-gray-600 line-clamp-2">
              {video.description}
            </p>
          )}
          
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span>{video.category || 'General'}</span>
            {video.view_count && (
              <span>{video.view_count.toLocaleString()} views</span>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

interface RobustVideoGridProps {
  onVideoPlay?: (video: Video) => void;
  className?: string;
  gridClassName?: string;
  emptyMessage?: string;
  showCategories?: boolean;
  category?: string;
}

export function RobustVideoGrid({
  onVideoPlay,
  className = '',
  gridClassName = '',
  emptyMessage = 'No videos available at the moment.',
  showCategories = false,
  category,
}: RobustVideoGridProps) {
  const [selectedCategory, setSelectedCategory] = useState(category || 'all');
  
  const {
    data: videos,
    loading,
    error,
    refetch,
    retryCount,
    isRetrying,
  } = useRobustVideos({
    onError: (error) => {
      logger.error('Failed to load videos:', error);
    },
    onSuccess: (data) => {
      logger.info(`Loaded ${data?.length || 0} videos successfully`);
    },
  });

  const filteredVideos = useMemo(() => {
    if (!videos || !Array.isArray(videos)) return [];
    
    return videos.filter((video: Video) => {
      if (!video || typeof video !== 'object') return false;
      if (selectedCategory === 'all') return true;
      return video.category?.toLowerCase() === selectedCategory.toLowerCase();
    });
  }, [videos, selectedCategory]);

  const categories = useMemo(() => {
    if (!videos || !Array.isArray(videos)) return [];
    
    const uniqueCategories = [...new Set(
      videos
        .map((video: Video) => video?.category)
        .filter(Boolean)
    )];
    
    return ['all', ...uniqueCategories];
  }, [videos]);

  const handleVideoPlay = (video: Video) => {
    if (!video?.id) {
      logger.error('Invalid video object:', video);
      return;
    }
    
    onVideoPlay?.(video);
  };

  const handleVideoError = (error: Error) => {
    logger.error('Video card error:', error);
  };

  const isEmpty = !loading && !error && (!filteredVideos || filteredVideos.length === 0);

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Category Filter */}
      {showCategories && categories.length > 1 && (
        <div className="flex flex-wrap gap-2">
          {categories.map((cat) => (
            <Button
              key={cat}
              variant={selectedCategory === cat ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSelectedCategory(cat)}
              className="capitalize"
            >
              {cat === 'all' ? 'All Categories' : cat}
            </Button>
          ))}
        </div>
      )}

      {/* Loading/Error/Empty State */}
      <RobustLoadingState
        loading={loading}
        error={error}
        onRetry={refetch}
        isEmpty={isEmpty}
        emptyMessage={emptyMessage}
        retryCount={retryCount}
        loadingMessage={isRetrying ? 'Retrying...' : 'Loading videos...'}
      >
        {/* Video Grid */}
        <div className={`grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 ${gridClassName}`}>
          {filteredVideos.map((video: Video) => (
            <RobustErrorBoundary key={video.id} level="component">
              <VideoCard
                video={video}
                onPlay={handleVideoPlay}
                onError={handleVideoError}
              />
            </RobustErrorBoundary>
          ))}
        </div>
      </RobustLoadingState>

      {/* Retry Status */}
      {isRetrying && (
        <div className="flex items-center justify-center py-4">
          <InlineLoading
            loading={true}
            className="text-blue-600"
          />
          <span className="ml-2 text-sm text-gray-600">
            Attempting to reload videos... ({retryCount}/3)
          </span>
        </div>
      )}
    </div>
  );
}

// Wrapped with error boundary
export default function RobustVideoGridWithBoundary(props: RobustVideoGridProps) {
  return (
    <RobustErrorBoundary level="component">
      <RobustVideoGrid {...props} />
    </RobustErrorBoundary>
  );
}