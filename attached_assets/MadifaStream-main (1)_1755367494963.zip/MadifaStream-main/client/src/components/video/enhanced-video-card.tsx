import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Play, Plus, X, Heart, Share2, Info, Star, Clock, Eye, Crown, Volume2, PlayCircle } from 'lucide-react';
import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Skeleton } from '@/components/ui/skeleton';
import ThumbnailImage from './thumbnail-image';
import type { Database } from "@/types/database-generated.types";
import { adaptVideoForUI, UIVideo } from '@/lib/type-adapters';
import { useSubscription } from '@/hooks/use-subscription';
import { useLocation } from 'wouter';
import { SubscriptionModal } from '@/components/subscription-modal';

type Video = Database['public']['Tables']['videos']['Row'];

// Type adapter to convert Database Video to Shared Schema Video format
const adaptVideoForThumbnail = (video: Video) => {
  const adapted = adaptVideoForUI(video);
  return {
    id: adapted.id,
    user_id: '', // Default empty - not available in database type
    title: adapted.title,
    description: adapted.description || '',
    thumbnail_url: adapted.thumbnail_url || '',
    video_url: adapted.video_url || '',
    trailer_url: adapted.trailer_url,
    duration: adapted.duration_minutes || 0,
    release_year: adapted.release_year || new Date().getFullYear(),
    director: adapted.director,
    cast_members: adapted.cast || [],
    genres: adapted.genres || [],
    age_rating: adapted.age_rating || 'PG',
    is_premium: adapted.is_premium || false,
    is_trailer: adapted.is_trailer || false,
    status: adapted.status || 'published',
    views: adapted.views || 0,
    created_at: new Date(adapted.created_at || new Date()),
    updated_at: new Date(adapted.updated_at || new Date()),
    bunny_video_id: adapted.bunny_video_id || '', 
    bunny_playback_id: adapted.bunny_playback_id || '',
    bunny_guid: adapted.bunny_guid || '',
    bunny_library_id: adapted.bunny_library_id || '',
    collection_id: adapted.collection_id || null,
    collection_name: adapted.collection_name || null,
    source_height: null,
    source_width: null,
    source_framerate: null,
    encode_progress: null,
    storage_size: null,
    raw_bunny_status: null,
    metadata_json: adapted.metadata_json || null,
    available_resolutions: '',
    average_watch_time: 0,
    total_watch_time: 0
  };
};

// Loading Skeleton Component for enhanced loading states
const VideoCardSkeleton: React.FC<{ variant?: string; size?: string }> = ({ variant = 'grid-comfortable', size = 'medium' }) => {
  const isListVariant = variant.startsWith('list');
  const isTableVariant = variant === 'table-row';
  
  if (isTableVariant) {
    return (
      <div className="flex items-center bg-background border-b border-border py-2 px-4">
        <Skeleton className="w-16 h-10 rounded flex-shrink-0" />
        <div className="flex-1 px-4">
          <Skeleton className="h-4 w-48 mb-1" />
          <Skeleton className="h-3 w-32" />
        </div>
        <div className="flex items-center gap-4">
          <Skeleton className="h-3 w-12" />
          <Skeleton className="h-3 w-16" />
          <Skeleton className="h-8 w-8" />
        </div>
      </div>
    );
  }
  
  if (isListVariant) {
    return (
      <div className="flex bg-background border border-border rounded-lg overflow-hidden">
        <Skeleton className="w-32 h-20 flex-shrink-0" />
        <div className="flex-1 p-4">
          <Skeleton className="h-4 w-48 mb-2" />
          <Skeleton className="h-3 w-32 mb-2" />
          <div className="flex gap-2">
            <Skeleton className="h-5 w-12" />
            <Skeleton className="h-5 w-16" />
          </div>
        </div>
      </div>
    );
  }
  
  // Grid variants
  const maxWidth = size === 'small' ? 'max-w-[200px]' : size === 'large' ? 'max-w-[350px]' : 'max-w-[280px]';
  
  return (
    <div className={cn("flex flex-col bg-background border border-border rounded-lg overflow-hidden", maxWidth)}>
      <Skeleton className="aspect-video w-full" />
      <div className="p-4">
        <Skeleton className="h-4 w-full mb-2" />
        <Skeleton className="h-3 w-3/4 mb-2" />
        <div className="flex gap-2">
          <Skeleton className="h-5 w-12" />
          <Skeleton className="h-5 w-16" />
        </div>
      </div>
    </div>
  );
};

// Enhanced responsive videoCardVariants with advanced mobile-first design
const videoCardVariants = cva(
  "group relative bg-gray-800 rounded-xl overflow-hidden transition-all duration-300 cursor-pointer",
  {
    variants: {
      variant: {
        'hero': "w-full h-[50vh] sm:h-[60vh] md:h-[70vh] lg:h-[80vh] xl:h-[85vh]",
        'grid-comfortable': "aspect-[16/9] hover:scale-[1.02] sm:hover:scale-105 hover:shadow-xl sm:hover:shadow-2xl hover:shadow-primary/20 sm:hover:shadow-primary/25",
        'grid-compact': "aspect-[16/9] hover:scale-[1.01] sm:hover:scale-102 hover:shadow-md sm:hover:shadow-lg",
        'grid-cozy': "aspect-[4/3] hover:scale-[1.015] sm:hover:scale-103 hover:shadow-lg sm:hover:shadow-xl",
        'list-detailed': "flex flex-col xs:flex-row h-auto xs:h-28 sm:h-32 md:h-36 lg:h-40 xl:h-44",
        'list-compact': "flex flex-col xs:flex-row h-auto xs:h-20 sm:h-24 md:h-28 lg:h-32",
        'table-row': "flex items-center h-12 xs:h-14 sm:h-16 md:h-20 bg-transparent hover:bg-gray-800/30 sm:hover:bg-gray-800/50 rounded-lg px-1 xs:px-2 sm:px-4",
        'masonry': "aspect-[16/9] hover:scale-105 hover:shadow-2xl hover:shadow-primary/25",
        'carousel': "aspect-[16/9] hover:scale-102 hover:shadow-lg",
        'featured': "aspect-[16/9] hover:scale-105 hover:shadow-2xl hover:shadow-primary/25",
        'premium': "aspect-[16/9] hover:scale-105 hover:shadow-2xl hover:shadow-primary/25"
      },
      size: {
        small: "w-full max-w-[280px] sm:max-w-xs",
        medium: "w-full max-w-[320px] sm:max-w-sm",
        large: "w-full max-w-[380px] sm:max-w-md",
        xl: "w-full max-w-[440px] sm:max-w-lg"
      }
    },
    defaultVariants: {
      variant: 'grid-comfortable',
      size: 'medium'
    }
  }
);

// Enhanced responsive thumbnailVariants with better mobile optimization
const thumbnailVariants = cva(
  "relative overflow-hidden",
  {
    variants: {
      variant: {
        'hero': "w-full h-full",
        'grid-comfortable': "w-full aspect-[16/9] rounded-t-xl",
        'grid-compact': "w-full aspect-[16/9] rounded-t-lg",
        'grid-cozy': "w-full aspect-[4/3] rounded-t-lg",
        'list-detailed': "w-full xs:w-28 sm:w-32 md:w-40 lg:w-48 xl:w-52 aspect-[16/9] xs:aspect-[4/3] flex-shrink-0 rounded-t-xl xs:rounded-l-xl xs:rounded-tr-none",
        'list-compact': "w-full xs:w-20 sm:w-24 md:w-28 lg:w-32 aspect-[16/9] xs:aspect-[4/3] flex-shrink-0 rounded-t-lg xs:rounded-l-lg xs:rounded-tr-none",
        'table-row': "w-8 xs:w-10 sm:w-12 md:w-16 lg:w-20 h-6 xs:h-8 sm:h-10 md:h-12 lg:h-14 flex-shrink-0 rounded",
        'masonry': "w-full aspect-[16/9] rounded-t-xl",
        'carousel': "w-full aspect-[16/9] rounded-t-lg",
        'featured': "w-full aspect-[16/9] rounded-t-xl",
        'premium': "w-full aspect-[16/9] rounded-t-xl"
      }
    },
    defaultVariants: {
      variant: 'grid-comfortable'
    }
  }
);

const infoVariants = cva(
  "flex flex-col transition-all duration-300 relative z-10",
  {
    variants: {
      variant: {
        'grid-comfortable': "p-4 flex-1",
        'grid-compact': "p-3 flex-1",
        'grid-cozy': "p-5 flex-1",
        'list-detailed': "flex-1 p-4",
        'list-compact': "flex-1 p-3",
        'table-row': "flex-1 px-4",
        'masonry': "p-4 flex-1",
        'hero': "absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/60 to-transparent p-8 text-white",
        'carousel': "p-3 flex-1",
        'featured': "p-4 flex-1",
        'premium': "p-4 flex-1"
      }
    }
  }
);

export interface EnhancedVideoCardProps extends VariantProps<typeof videoCardVariants> {
  video: Video;
  progress?: number; // 0-100
  isInWatchlist?: boolean;
  isLiked?: boolean;
  showProgress?: boolean;
  showGenres?: boolean;
  showDuration?: boolean;
  showViews?: boolean;
  showRating?: boolean;
  showPremiumBadge?: boolean;
  showActions?: boolean;
  showTooltip?: boolean;
  enableHoverPreview?: boolean;
  enableLazyLoading?: boolean;
  onPlay?: (video: Video) => void;
  onAddToWatchlist?: (videoId: string) => void;
  onRemoveFromWatchlist?: (videoId: string) => void;
  onLike?: (videoId: string) => void;
  onUnlike?: (videoId: string) => void;
  onInfo?: (video: Video) => void;
  onShare?: (video: Video) => void;
  onSubscriptionRequired?: (video: Video) => void;
  className?: string;
  imagePriority?: boolean;
  'data-testid'?: string;
  isLoading?: boolean;
  showSubscriptionPrompt?: boolean;
  onSubscriptionClick?: () => void;
}

export const EnhancedVideoCard: React.FC<EnhancedVideoCardProps> = ({
  video,
  variant = 'grid-comfortable',
  size = 'medium',
  progress = 0,
  isInWatchlist = false,
  isLiked = false,
  showProgress = true,
  showGenres = true,
  showDuration = true,
  showViews = false,
  showRating = false,
  showPremiumBadge = true,
  showActions = true,
  showTooltip = false,
  enableHoverPreview = false,
  enableLazyLoading = true,
  onPlay,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onLike,
  onUnlike,
  onInfo,
  onShare,
  onSubscriptionRequired,
  className,
  imagePriority = false,
  'data-testid': testId,
  isLoading = false,
  showSubscriptionPrompt = false,
  onSubscriptionClick,
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [isVisible, setIsVisible] = useState(!enableLazyLoading);
  const [showActionsState, setShowActionsState] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const hoverTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const [, setLocation] = useLocation();
  const { hasPremiumAccess } = useSubscription();

  // Intersection Observer for lazy loading
  useEffect(() => {
    if (!enableLazyLoading || isVisible) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, [enableLazyLoading, isVisible]);

  // Enhanced hover handling with debouncing
  const handleMouseEnter = useCallback(() => {
    setIsHovered(true);
    if (enableHoverPreview) {
      hoverTimeoutRef.current = setTimeout(() => {
        setShowActionsState(true);
      }, 300);
    }
  }, [enableHoverPreview]);

  const handleMouseLeave = useCallback(() => {
    setIsHovered(false);
    setShowActionsState(false);
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
    }
  }, []);

  // Action handlers
  const handleClick = useCallback(() => {
    if (video.is_premium && !hasPremiumAccess) {
      setShowSubscriptionModal(true);
      return;
    }
    
    if (onPlay) {
      onPlay(video);
    } else {
      setLocation(`/watch/${video.id}`);
    }
  }, [video, onPlay, hasPremiumAccess, setLocation]);

  const handleWatchlist = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (isInWatchlist && onRemoveFromWatchlist) {
      onRemoveFromWatchlist(video.id);
    } else if (!isInWatchlist && onAddToWatchlist) {
      onAddToWatchlist(video.id);
    }
  }, [isInWatchlist, video.id, onAddToWatchlist, onRemoveFromWatchlist]);

  const handleLike = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (isLiked && onUnlike) {
      onUnlike(video.id);
    } else if (!isLiked && onLike) {
      onLike(video.id);
    }
  }, [isLiked, video.id, onLike, onUnlike]);

  const handleShare = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (onShare) {
      onShare(video);
    }
  }, [video, onShare]);

  const handleInfo = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (onInfo) {
      onInfo(video);
    }
  }, [video, onInfo]);

  // Utility functions
  const formatDuration = useCallback((minutes?: number) => {
    if (!minutes) return '';
    
    // Handle case where duration might be in seconds (from Bunny API)
    let totalMinutes = minutes;
    if (minutes > 300) { // Assume it's seconds if over 5 hours in "minutes"
      totalMinutes = Math.floor(minutes / 60);
    }
    
    const hours = Math.floor(totalMinutes / 60);
    const mins = Math.floor(totalMinutes % 60);
    return hours > 0 ? `${hours}h ${mins}m` : `${totalMinutes}m`;
  }, []);

  const formatViews = useCallback((views?: number) => {
    if (!views) return '0 views';
    if (views >= 1000000) return `${(views / 1000000).toFixed(1)}M views`;
    if (views >= 1000) return `${(views / 1000).toFixed(1)}K views`;
    return `${views} views`;
  }, []);

  const adaptedVideo = adaptVideoForUI(video);
  const duration = adaptedVideo.duration_minutes || 0;
  const isPremium = video.is_premium;
  const isTrailer = video.is_trailer;
  // Note: rating and view_count are not directly on video table - they come from separate tables
  // For now, default to 0 or we could pass these as props from parent components
  const rating = 0; // Should come from content_metrics.average_rating or be passed as prop
  const views = video.views || 0; // Use the optional views field or 0

  const requiresSubscription = isPremium && !hasPremiumAccess;
  const canPlay = !requiresSubscription;

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleClick();
    }
  }, [handleClick]);

  // Different layouts for different variants
  const renderTableRow = () => (
    <div className={cn(videoCardVariants({ variant }), className)} ref={cardRef} data-testid={testId}>
      <div className={cn(thumbnailVariants({ variant }))}>
        {isVisible && (
          <ThumbnailImage
            video={adaptVideoForThumbnail(video)}
            alt={video.title}
            className="w-full h-full object-cover"
            loading={enableLazyLoading ? 'lazy' : 'eager'}
            variant="small"
          />
        )}
      </div>
      
      <div className="flex-1 flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-foreground truncate">{video.title}</h3>
          <p className="text-sm text-muted-foreground truncate">{video.description}</p>
        </div>
        
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          {showDuration && duration > 0 && <span>{formatDuration(duration)}</span>}
          {showViews && <span>{formatViews(views)}</span>}
          {showRating && rating > 0 && (
            <div className="flex items-center gap-1">
              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
              <span>{rating.toFixed(1)}</span>
            </div>
          )}
          {showPremiumBadge && isPremium && (
            <Badge className="bg-amber-500 text-black">
              <Crown className="w-3 h-3 mr-1" />
              Premium
            </Badge>
          )}
        </div>
        
        <div className="flex items-center gap-2 ml-4">
          <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleClick(); }}>
            <Play className="w-4 h-4" />
          </Button>
          {showActions && onAddToWatchlist && (
            <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleWatchlist(e); }}>
              {isInWatchlist ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
            </Button>
          )}
        </div>
      </div>
    </div>
  );

  const renderListView = () => (
    <div 
      className={cn(videoCardVariants({ variant }), className)}
      ref={cardRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={(e) => { e.stopPropagation(); handleClick(); }}
      onKeyDown={handleKeyDown}
      data-testid={testId}
    >
      <div className={cn(thumbnailVariants({ variant }))}>
        {isVisible && (
          <ThumbnailImage
            video={adaptVideoForThumbnail(video)}
            alt={video.title}
            className="w-full h-full object-cover"
            loading={enableLazyLoading ? 'lazy' : 'eager'}
            variant="list"
          />
        )}
        
        {/* Progress Bar */}
        {showProgress && progress > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-500/50">
            <div className="h-full bg-primary" style={{ width: `${progress}%` }} />
          </div>
        )}

        {/* Premium Badge */}
        {showPremiumBadge && isPremium && (
          <div className="absolute top-2 right-2">
            <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-black text-xs">
              <Crown className="w-3 h-3 mr-1" />
              Premium
            </Badge>
          </div>
        )}
      </div>

      <div className={cn(infoVariants({ variant }))}>
        <div className="flex-1">
          <h3 className="font-semibold text-foreground text-base leading-tight line-clamp-2 mb-1 relative z-10 bg-background/80 p-1 rounded">
            {video.title}
          </h3>
          
          {variant === 'list-detailed' && video.description && (
            <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
              {video.description}
            </p>
          )}
          
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            {showDuration && duration > 0 && (
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>{formatDuration(duration)}</span>
              </div>
            )}
            {showViews && (
              <div className="flex items-center gap-1">
                <Eye className="w-3 h-3" />
                <span>{formatViews(views)}</span>
              </div>
            )}
            {showRating && rating > 0 && (
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                <span>{rating.toFixed(1)}</span>
              </div>
            )}
            {video.release_year && <span>{video.release_year}</span>}
          </div>

          {showGenres && video.genres && video.genres.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {video.genres.slice(0, 3).map((genre) => (
                <Badge key={genre} variant="outline" className="text-xs">{genre}</Badge>
              ))}
            </div>
          )}
        </div>

        {/* Action buttons for list view */}
        {showActions && (isHovered || showActionsState) && (
          <div className="flex items-center gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button variant="ghost" size="sm" onClick={(e) => { e.stopPropagation(); handleWatchlist(e); }}>
              {isInWatchlist ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
            </Button>
            {onLike && (
              <Button variant="ghost" size="sm" onClick={handleLike}>
                <Heart className={cn("w-4 h-4", isLiked && "fill-red-500 text-red-500")} />
              </Button>
            )}
            {onShare && (
              <Button variant="ghost" size="sm" onClick={handleShare}>
                <Share2 className="w-4 h-4" />
              </Button>
            )}
            {onInfo && (
              <Button variant="ghost" size="sm" onClick={handleInfo}>
                <Info className="w-4 h-4" />
              </Button>
            )}
          </div>
        )}
      </div>
    </div>
  );

  const renderGridView = () => (
    <div 
      className={cn(videoCardVariants({ variant, size }), className)}
      ref={cardRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={(e) => { e.stopPropagation(); handleClick(); }}
      onKeyDown={handleKeyDown}
      data-testid={testId}
    >
      <div className={cn(thumbnailVariants({ variant }))}>
        {isVisible && (
          <ThumbnailImage
            video={adaptVideoForThumbnail(video)}
            alt={video.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            loading={enableLazyLoading ? 'lazy' : 'eager'}
            variant="grid"
          />
        )}

        {/* Progress Bar */}
        {showProgress && progress > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-500/50">
            <div className="h-full bg-primary" style={{ width: `${progress}%` }} />
          </div>
        )}

        {/* Play Button Overlay */}
        <div className={cn(
          "absolute inset-0 flex items-center justify-center transition-all duration-300",
          "bg-black/0 group-hover:bg-black/40"
        )}>
          <Button
            variant="ghost"
            size="icon"
            className={cn(
              "rounded-full text-white transition-all duration-300",
              "bg-black/30 backdrop-blur-sm border-white/50 border-2",
              "hover:bg-primary hover:border-primary hover:scale-110",
              "scale-0 group-hover:scale-100",
              "h-12 w-12 shadow-lg"
            )}
            onClick={(e) => {
              e.stopPropagation();
              handleClick();
            }}
          >
            <Play className="h-5 w-5 ml-0.5 fill-white" />
          </Button>
        </div>

        {/* Action buttons overlay */}
        {showActions && (isHovered || showActionsState) && (
          <div className="absolute top-3 left-3 flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button variant="ghost" size="sm" className="bg-black/50 text-white hover:bg-black/70" onClick={(e) => { e.stopPropagation(); handleWatchlist(e); }}>
              {isInWatchlist ? <X className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
            </Button>
            {onLike && (
              <Button variant="ghost" size="sm" className="bg-black/50 text-white hover:bg-black/70" onClick={handleLike}>
                <Heart className={cn("w-4 h-4", isLiked && "fill-red-500 text-red-500")} />
              </Button>
            )}
          </div>
        )}

        {/* Badge Overlays */}
        <div className="absolute top-3 right-3 flex flex-col gap-2">
          {showPremiumBadge && isPremium && (
            <Badge className="bg-gradient-to-r from-amber-500 to-orange-500 text-black text-xs font-bold border-none shadow-lg">
              <Crown className="w-3 h-3 mr-1" />
              Premium
            </Badge>
          )}
          {isTrailer && (
            <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs font-bold border-none shadow-lg">
              <PlayCircle className="w-3 h-3 mr-1" />
              Free
            </Badge>
          )}
          {showRating && rating > 4 && (
            <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black text-xs font-bold border-none shadow-lg">
              <Star className="w-3 h-3 mr-1 fill-current" />
              {rating.toFixed(1)}
            </Badge>
          )}
        </div>
      </div>

      <div className={cn(infoVariants({ variant }))}>
        <div className="flex-1">
          <h3 className="font-semibold text-foreground text-base leading-tight line-clamp-2 mb-2 relative z-10 bg-background/80 p-1 rounded">
            {video.title}
          </h3>
          
          {variant === 'grid-cozy' && video.description && (
            <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
              {video.description}
            </p>
          )}

          <div className="flex items-center justify-between text-xs text-muted-foreground mb-2">
            {showDuration && duration > 0 && (
              <div className="flex items-center gap-1">
                <Clock className="w-3 h-3" />
                <span>{formatDuration(duration)}</span>
              </div>
            )}
            {video.release_year && <span>{video.release_year}</span>}
          </div>

          {showViews && (
            <div className="flex items-center gap-1 text-xs text-muted-foreground mb-2">
              <Eye className="w-3 h-3" />
              <span>{formatViews(views)}</span>
            </div>
          )}

          {showGenres && video.genres && video.genres.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {video.genres.slice(0, variant === 'grid-cozy' ? 3 : 2).map((genre) => (
                <Badge key={genre} variant="outline" className="text-xs">{genre}</Badge>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderHeroView = () => (
    <div 
      className={cn(videoCardVariants({ variant }), className)}
      ref={cardRef}
      data-testid={testId}
    >
      <div className={cn(thumbnailVariants({ variant }))}>
        {isVisible && (
          <ThumbnailImage
            video={adaptVideoForThumbnail(video)}
            alt={video.title}
            className="w-full h-full object-cover"
            loading="eager"
            variant="hero"
          />
        )}
      </div>

      <div className={cn(infoVariants({ variant }))}>
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-4 drop-shadow-lg">
          {video.title}
        </h1>
        {video.description && (
          <p className="text-lg text-gray-200 mb-6 line-clamp-3 max-w-2xl drop-shadow">
            {video.description}
          </p>
        )}
        
        <div className="flex items-center gap-4 mb-6">
          {showRating && rating > 0 && (
            <div className="flex items-center gap-1 text-white">
              <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
              <span className="font-semibold">{rating.toFixed(1)}</span>
            </div>
          )}
          {video.release_year && <span className="text-white font-semibold">{video.release_year}</span>}
          {showDuration && duration > 0 && (
            <div className="flex items-center gap-1 text-white">
              <Clock className="w-4 h-4" />
              <span>{formatDuration(duration)}</span>
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-4">
          <Button
            size="lg"
            className="bg-primary hover:bg-primary/90 text-white font-semibold text-lg px-8 py-3"
            onClick={(e) => { e.stopPropagation(); handleClick(); }}
          >
            <Play className="w-6 h-6 mr-2" fill="white" />
            {isPremium ? 'Subscribe to Watch' : 'Play Now'}
          </Button>
          
          {showActions && onAddToWatchlist && onRemoveFromWatchlist && (
            <Button
              variant="outline"
              size="lg"
              className="text-white border-white/50 hover:bg-white/10 hover:border-white font-semibold px-6 py-3"
              onClick={(e) => { e.stopPropagation(); handleWatchlist(e); }}
            >
              {isInWatchlist ? <X className="h-5 w-5 mr-2" /> : <Plus className="h-5 w-5 mr-2" />}
              {isInWatchlist ? 'Remove' : 'Watchlist'}
            </Button>
          )}
          
          {onInfo && (
            <Button
              variant="ghost"
              size="lg"
              className="text-white hover:bg-white/10 font-semibold px-6 py-3"
              onClick={(e) => { e.stopPropagation(); onInfo(video); }}
            >
              <Info className="h-5 w-5 mr-2" />
              More Info
            </Button>
          )}
        </div>
      </div>
    </div>
  );

  // Route to appropriate render method based on variant
  if (variant === 'table-row') return renderTableRow();
  if (variant?.startsWith('list-')) return renderListView();
  if (variant === 'hero') return renderHeroView();
  
  // Default to grid view for all grid variants, carousel, featured, premium, masonry
  return renderGridView();
};

// Convenience wrapper components for specific use cases
export const VideoGridCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="grid-comfortable" />
);

export const VideoCompactCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="grid-compact" />
);

export const VideoCozyCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="grid-cozy" />
);

export const VideoListCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="list-detailed" />
);

export const VideoCompactListCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="list-compact" />
);

export const VideoTableRow = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="table-row" />
);

export const VideoHeroCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="hero" />
);

export const VideoCarouselCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="carousel" showGenres={false} />
);

export const VideoFeaturedCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="featured" />
);

export const VideoPremiumCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="premium" />
);

export const VideoMasonryCard = (props: Omit<EnhancedVideoCardProps, 'variant'>) => (
  <EnhancedVideoCard {...props} variant="masonry" />
);

export default EnhancedVideoCard; 