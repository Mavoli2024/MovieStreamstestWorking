// Simplified VideoGrid wrapper.
// Use UnifiedVideoGrid for single source of truth moving forward.
export { UnifiedVideoGrid as VideoGrid } from "./unified-video-displays"; 