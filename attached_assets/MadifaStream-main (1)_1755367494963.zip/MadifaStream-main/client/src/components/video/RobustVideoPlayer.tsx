import React, { useState, useEffect, useRef, useCallback } from 'react'
import { VideoErrorBoundary } from '../error-boundary/GlobalErrorBoundary'
import { BunnyNativePlayer } from './BunnyNativePlayer'
import { AdaptiveVideoPlayer } from './AdaptiveVideoPlayer'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Play, RefreshCw, AlertTriangle, Volume2, VolumeX, Maximize, Minimize } from 'lucide-react'
import { useLocalStorage } from '@/hooks/use-local-storage'

interface RobustVideoPlayerProps {
  videoId: string
  title?: string
  thumbnail?: string
  autoPlay?: boolean
  onError?: (error: Error) => void
  onPlay?: () => void
  onPause?: () => void
  onEnd?: () => void
}

type PlayerType = 'bunny' | 'adaptive' | 'html5' | 'iframe'

interface VideoSource {
  url: string
  type: PlayerType
  quality?: string
}

export function RobustVideoPlayer({ 
  videoId, 
  title, 
  thumbnail, 
  autoPlay = false,
  onError,
  onPlay,
  onPause,
  onEnd
}: RobustVideoPlayerProps) {
  const [currentPlayer, setCurrentPlayer] = useState<PlayerType>('bunny')
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [retryCount, setRetryCount] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [videoSources, setVideoSources] = useState<VideoSource[]>([])
  const [preferredPlayer] = useLocalStorage<PlayerType>('preferred-video-player', 'bunny')
  
  const playerRef = useRef<HTMLDivElement>(null)
  const fallbackTimeoutRef = useRef<NodeJS.Timeout>()
  const retryTimeoutRef = useRef<NodeJS.Timeout>()

  // Video sources in order of preference
  const getVideoSources = useCallback((videoId: string): VideoSource[] => {
    const baseUrl = import.meta.env.VITE_BUNNY_CDN_URL || 'https://stream.bunnycdn.com'
    
    return [
      {
        url: `${baseUrl}/videos/${videoId}/iframe`,
        type: 'bunny',
        quality: 'auto'
      },
      {
        url: `${baseUrl}/videos/${videoId}/adaptive`,
        type: 'adaptive',
        quality: 'auto'
      },
      {
        url: `${baseUrl}/videos/${videoId}/mp4`,
        type: 'html5',
        quality: '720p'
      },
      {
        url: `${baseUrl}/videos/${videoId}/embed`,
        type: 'iframe',
        quality: 'auto'
      }
    ]
  }, [])

  // Initialize video sources
  useEffect(() => {
    const sources = getVideoSources(videoId)
    setVideoSources(sources)
    
    // Use preferred player if available
    const preferredSource = sources.find(s => s.type === preferredPlayer)
    if (preferredSource) {
      setCurrentPlayer(preferredPlayer)
    }
  }, [videoId, preferredPlayer, getVideoSources])

  // Handle player errors with automatic fallback
  const handlePlayerError = useCallback((playerError: Error, playerType: PlayerType) => {
    console.error(`${playerType} player error:`, playerError)
    
    setError(`${playerType} player failed: ${playerError.message}`)
    onError?.(playerError)
    
    // Try next player type
    const currentIndex = videoSources.findIndex(s => s.type === playerType)
    const nextSource = videoSources[currentIndex + 1]
    
    if (nextSource && retryCount < 3) {
      console.log(`Falling back to ${nextSource.type} player`)
      setCurrentPlayer(nextSource.type)
      setRetryCount(prev => prev + 1)
      setError(null)
      
      // Clear any existing timeout
      if (fallbackTimeoutRef.current) {
        clearTimeout(fallbackTimeoutRef.current)
      }
      
      // Set timeout for fallback
      fallbackTimeoutRef.current = setTimeout(() => {
        handlePlayerError(new Error('Player timeout'), nextSource.type)
      }, 10000) // 10 second timeout
    } else {
      // All players failed
      setError('All video players failed. Please try refreshing the page.')
      setIsLoading(false)
    }
  }, [videoSources, retryCount, onError])

  // Handle successful player load
  const handlePlayerLoad = useCallback(() => {
    setIsLoading(false)
    setError(null)
    
    // Clear fallback timeout
    if (fallbackTimeoutRef.current) {
      clearTimeout(fallbackTimeoutRef.current)
    }
  }, [])

  // Manual retry function
  const handleRetry = useCallback(() => {
    setRetryCount(0)
    setError(null)
    setIsLoading(true)
    setCurrentPlayer('bunny') // Start with preferred player
  }, [])

  // Player control handlers
  const handlePlay = useCallback(() => {
    setIsPlaying(true)
    onPlay?.()
  }, [onPlay])

  const handlePause = useCallback(() => {
    setIsPlaying(false)
    onPause?.()
  }, [onPause])

  const handleEnd = useCallback(() => {
    setIsPlaying(false)
    onEnd?.()
  }, [onEnd])

  const toggleMute = useCallback(() => {
    setIsMuted(prev => !prev)
  }, [])

  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      playerRef.current?.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }, [])

  // Cleanup timeouts on unmount
  useEffect(() => {
    return () => {
      if (fallbackTimeoutRef.current) {
        clearTimeout(fallbackTimeoutRef.current)
      }
      if (retryTimeoutRef.current) {
        clearTimeout(retryTimeoutRef.current)
      }
    }
  }, [])

  // Render current player
  const renderPlayer = () => {
    const currentSource = videoSources.find(s => s.type === currentPlayer)
    if (!currentSource) return null

    const commonProps = {
      videoId,
      autoPlay,
      onError: (error: Error) => handlePlayerError(error, currentPlayer),
      onLoad: handlePlayerLoad,
      onPlay: handlePlay,
      onPause: handlePause,
      onEnd: handleEnd,
      muted: isMuted
    }

    switch (currentPlayer) {
      case 'bunny':
        return <BunnyNativePlayer 
          bunnyVideoId={videoId}
          bunnyLibraryId="default"
          title={title || 'Video'}
          {...commonProps} 
        />
      
      case 'adaptive':
        return <AdaptiveVideoPlayer 
          title={title || 'Video'}
          {...commonProps} 
        />
      
      case 'html5':
        return (
          <video
            controls
            autoPlay={autoPlay}
            muted={isMuted}
            poster={thumbnail}
            className="w-full h-full"
            onError={(e) => handlePlayerError(new Error('HTML5 video error'), 'html5')}
            onLoadedData={handlePlayerLoad}
            onPlay={handlePlay}
            onPause={handlePause}
            onEnded={handleEnd}
          >
            <source src={currentSource.url} type="video/mp4" />
            Your browser does not support the video tag.
          </video>
        )
      
      case 'iframe':
        return (
          <iframe
            src={currentSource.url}
            className="w-full h-full"
            frameBorder="0"
            allowFullScreen
            onError={(e) => handlePlayerError(new Error('Iframe player error'), 'iframe')}
            onLoad={handlePlayerLoad}
          />
        )
      
      default:
        return null
    }
  }

  if (error && retryCount >= 3) {
    return (
      <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center">
        <div className="text-center p-6 max-w-md">
          <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <AlertTriangle className="w-8 h-8 text-red-600" />
          </div>
          <h3 className="text-lg font-semibold text-white mb-2">
            Video Playback Error
          </h3>
          <p className="text-gray-300 mb-4 text-sm">
            {error}
          </p>
          <div className="space-y-2">
            <Button onClick={handleRetry} className="w-full">
              <RefreshCw className="w-4 h-4 mr-2" />
              Try Again
            </Button>
            <Button 
              variant="outline" 
              onClick={() => window.location.reload()}
              className="w-full"
            >
              Refresh Page
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <VideoErrorBoundary>
      <div 
        ref={playerRef}
        className="relative aspect-video bg-black rounded-lg overflow-hidden group"
      >
        {/* Loading state */}
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto mb-4"></div>
              <p className="text-white text-sm">
                Loading video... (Player: {currentPlayer})
              </p>
              {retryCount > 0 && (
                <p className="text-gray-400 text-xs mt-1">
                  Retry {retryCount}/3
                </p>
              )}
            </div>
          </div>
        )}

        {/* Error state */}
        {error && retryCount < 3 && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
            <Alert className="max-w-md mx-4">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                {error}
                <div className="mt-2">
                  <Button size="sm" onClick={handleRetry}>
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Retry
                  </Button>
                </div>
              </AlertDescription>
            </Alert>
          </div>
        )}

        {/* Player */}
        {!error && renderPlayer()}

        {/* Custom controls overlay */}
        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={toggleMute}
                className="text-white hover:bg-white/20"
              >
                {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
            </div>
            
            <div className="flex items-center space-x-2">
              <span className="text-white text-xs">
                {currentPlayer.toUpperCase()}
              </span>
              <Button
                size="sm"
                variant="ghost"
                onClick={toggleFullscreen}
                className="text-white hover:bg-white/20"
              >
                {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Title overlay */}
        {title && (
          <div className="absolute top-0 left-0 right-0 bg-gradient-to-b from-black/80 to-transparent p-4 opacity-0 group-hover:opacity-100 transition-opacity">
            <h3 className="text-white font-medium truncate">{title}</h3>
          </div>
        )}
      </div>
    </VideoErrorBoundary>
  )
} 