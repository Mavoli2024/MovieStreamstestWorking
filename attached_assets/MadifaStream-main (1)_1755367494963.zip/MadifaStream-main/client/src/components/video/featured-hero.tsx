import {  Button  } from '@/components/ui/button';
import { EnhancedVideoMetadata } from '@/services/enhanced-video-service';
import {  Info, PlayCircle  } from 'lucide-react';
import React from 'react';
import {  Link  } from 'wouter';

interface FeaturedHeroProps {
  video: EnhancedVideoMetadata;
  onInfo?: (video: EnhancedVideoMetadata) => void;
  onPlay?: (video: EnhancedVideoMetadata) => void;
}

export const FeaturedHero: React.FC<FeaturedHeroProps> = ({ video, onInfo, onPlay }) => {
  if (!video) {
    return (
        <div className="w-full h-[50vh] bg-gray-900 flex items-center justify-center">
            <p className="text-white">Loading featured content...</p>
        </div>
    );
  }

  const thumbnailUrl = video.thumbnail_url || '/placeholder.png';

  return (
    <div
      className="relative h-[60vh] md:h-[70vh] w-full mb-12 rounded-lg overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(to right, rgba(0,0,0,0.8) 0%, rgba(0,0,0,0) 100%), url(${thumbnailUrl})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <div className="absolute inset-0 flex flex-col justify-center p-8 md:p-12 lg:p-16">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white mb-4 max-w-2xl" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}>
          {video.title}
        </h1>
        <p className="text-lg text-gray-200 mb-6 max-w-xl" style={{ textShadow: '1px 1px 2px rgba(0,0,0,0.5)' }}>
          {video.description}
        </p>
        <div className="flex space-x-4">
          <Button
            size="lg"
            className="bg-primary hover:bg-primary/90 text-primary-foreground"
            onClick={() => {
              if (onPlay) {
                onPlay(video);
              } else {
                window.location.href = `/watch/${video.id}`;
              }
            }}
          >
            <PlayCircle className="mr-2 h-6 w-6" />
            Watch Now
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="text-white border-white hover:bg-white/10"
            onClick={() => onInfo?.(video)}
          >
            <Info className="mr-2 h-6 w-6" />
            More Info
          </Button>
        </div>
      </div>
    </div>
  );
}; 