import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Play, Pause, Volume2, VolumeX, Maximize, AlertCircle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { RobustErrorBoundary } from '@/components/error-boundary/RobustErrorBoundary';
import { robustApi } from '@/services/robust-api';
import { logger } from '@shared/logger';

interface ReliableVideoPlayerProps {
  videoId: string;
  poster?: string;
  autoPlay?: boolean;
  onError?: (error: Error) => void;
  onPlay?: () => void;
  onPause?: () => void;
  className?: string;
}

interface VideoState {
  loading: boolean;
  playing: boolean;
  muted: boolean;
  error: string | null;
  signedUrl: string | null;
  retryCount: number;
  duration: number;
  currentTime: number;
}

const MAX_RETRIES = 3;
const RETRY_DELAY = 2000;

export function ReliableVideoPlayer({
  videoId,
  poster,
  autoPlay = false,
  onError,
  onPlay,
  onPause,
  className = '',
}: ReliableVideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [state, setState] = useState<VideoState>({
    loading: true,
    playing: false,
    muted: false,
    error: null,
    signedUrl: null,
    retryCount: 0,
    duration: 0,
    currentTime: 0,
  });

  const updateState = useCallback((updates: Partial<VideoState>) => {
    setState(prev => ({ ...prev, ...updates }));
  }, []);

  const loadVideoUrl = useCallback(async (retry = false) => {
    if (!videoId) {
      updateState({ error: 'No video ID provided', loading: false });
      return;
    }

    if (retry) {
      updateState({ retryCount: state.retryCount + 1 });
    } else {
      updateState({ loading: true, error: null, retryCount: 0 });
    }

    try {
      logger.info(`Loading video URL for: ${videoId}`);
      
      const response = await robustApi.getSignedVideoUrl(videoId);
      
      if (!response.signedUrl) {
        throw new Error('No video URL received from server');
      }

      updateState({
        signedUrl: response.signedUrl,
        loading: false,
        error: null,
      });

      logger.info(`Video URL loaded successfully for: ${videoId}`);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Failed to load video';
      
      logger.error(`Video URL loading failed for ${videoId}:`, error);
      
      // Auto-retry with exponential backoff
      if (state.retryCount < MAX_RETRIES) {
        const delay = RETRY_DELAY * Math.pow(2, state.retryCount);
        logger.info(`Retrying video load in ${delay}ms (attempt ${state.retryCount + 1}/${MAX_RETRIES})`);
        
        setTimeout(() => {
          loadVideoUrl(true);
        }, delay);
        return;
      }

      updateState({
        error: errorMessage,
        loading: false,
      });

      if (onError) {
        onError(new Error(errorMessage));
      }
    }
  }, [videoId, state.retryCount, onError, updateState]);

  // Initialize video loading
  useEffect(() => {
    loadVideoUrl();
  }, [videoId]);

  const handleVideoError = useCallback((event: React.SyntheticEvent<HTMLVideoElement>) => {
    const video = event.currentTarget;
    const error = video.error;
    
    let errorMessage = 'Video playback failed';
    
    if (error) {
      switch (error.code) {
        case MediaError.MEDIA_ERR_ABORTED:
          errorMessage = 'Video loading was aborted';
          break;
        case MediaError.MEDIA_ERR_NETWORK:
          errorMessage = 'Network error occurred while loading video';
          break;
        case MediaError.MEDIA_ERR_DECODE:
          errorMessage = 'Video format not supported or corrupted';
          break;
        case MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED:
          errorMessage = 'Video format not supported by your browser';
          break;
        default:
          errorMessage = 'Unknown video error occurred';
      }
    }

    logger.error('Video element error:', errorMessage, error);
    
    updateState({ error: errorMessage, loading: false, playing: false });
    
    if (onError) {
      onError(new Error(errorMessage));
    }
  }, [onError, updateState]);

  const handleCanPlay = useCallback(() => {
    updateState({ loading: false, error: null });
    
    if (autoPlay && videoRef.current) {
      videoRef.current.play().catch(handlePlayError);
    }
  }, [autoPlay]);

  const handlePlayError = useCallback((error: any) => {
    logger.error('Video play error:', error);
    
    let errorMessage = 'Failed to play video';
    
    if (error.name === 'NotAllowedError') {
      errorMessage = 'Browser blocked autoplay. Please click play button.';
    } else if (error.name === 'NotSupportedError') {
      errorMessage = 'Video format not supported';
    }
    
    updateState({ error: errorMessage, playing: false });
  }, [updateState]);

  const togglePlay = useCallback(async () => {
    if (!videoRef.current || state.loading || state.error) return;

    try {
      if (state.playing) {
        videoRef.current.pause();
        updateState({ playing: false });
        onPause?.();
      } else {
        await videoRef.current.play();
        updateState({ playing: true, error: null });
        onPlay?.();
      }
    } catch (error) {
      handlePlayError(error);
    }
  }, [state.playing, state.loading, state.error, onPlay, onPause, handlePlayError, updateState]);

  const toggleMute = useCallback(() => {
    if (videoRef.current) {
      videoRef.current.muted = !videoRef.current.muted;
      updateState({ muted: videoRef.current.muted });
    }
  }, [updateState]);

  const toggleFullscreen = useCallback(() => {
    if (videoRef.current) {
      if (document.fullscreenElement) {
        document.exitFullscreen();
      } else {
        videoRef.current.requestFullscreen();
      }
    }
  }, []);

  const retryVideo = useCallback(() => {
    setState({
      loading: true,
      playing: false,
      muted: false,
      error: null,
      signedUrl: null,
      retryCount: 0,
      duration: 0,
      currentTime: 0,
    });
    loadVideoUrl();
  }, [loadVideoUrl]);

  const handleTimeUpdate = useCallback(() => {
    if (videoRef.current) {
      updateState({
        currentTime: videoRef.current.currentTime,
        duration: videoRef.current.duration || 0,
      });
    }
  }, [updateState]);

  // Error state
  if (state.error) {
    return (
      <Card className={`${className} relative bg-black`}>
        <CardContent className="flex items-center justify-center h-64 p-6">
          <div className="text-center space-y-4">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto" />
            <div className="space-y-2">
              <h3 className="text-white font-semibold">Video Error</h3>
              <p className="text-gray-300 text-sm max-w-md">{state.error}</p>
              {state.retryCount < MAX_RETRIES && (
                <p className="text-gray-400 text-xs">
                  Retrying... ({state.retryCount + 1}/{MAX_RETRIES})
                </p>
              )}
            </div>
            <Button
              onClick={retryVideo}
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Try Again
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Loading state
  if (state.loading || !state.signedUrl) {
    return (
      <Card className={`${className} relative bg-black`}>
        <CardContent className="flex items-center justify-center h-64">
          <div className="text-center space-y-4">
            <div className="w-8 h-8 border-2 border-white border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="text-white text-sm">Loading video...</p>
            {state.retryCount > 0 && (
              <p className="text-gray-400 text-xs">
                Retry attempt {state.retryCount}/{MAX_RETRIES}
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`${className} relative bg-black overflow-hidden group`}>
      <CardContent className="p-0 relative">
        <video
          ref={videoRef}
          src={state.signedUrl}
          poster={poster}
          className="w-full h-auto"
          onError={handleVideoError}
          onCanPlay={handleCanPlay}
          onPlay={() => updateState({ playing: true })}
          onPause={() => updateState({ playing: false })}
          onTimeUpdate={handleTimeUpdate}
          onLoadStart={() => updateState({ loading: true })}
          onLoadedData={() => updateState({ loading: false })}
          crossOrigin="anonymous"
          preload="metadata"
        />
        
        {/* Controls overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Button
                size="sm"
                variant="ghost"
                onClick={togglePlay}
                className="text-white hover:bg-white/20"
              >
                {state.playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </Button>
              
              <Button
                size="sm"
                variant="ghost"
                onClick={toggleMute}
                className="text-white hover:bg-white/20"
              >
                {state.muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              </Button>
              
              {state.duration > 0 && (
                <span className="text-white text-sm">
                  {Math.floor(state.currentTime / 60)}:{String(Math.floor(state.currentTime % 60)).padStart(2, '0')} / {Math.floor(state.duration / 60)}:{String(Math.floor(state.duration % 60)).padStart(2, '0')}
                </span>
              )}
            </div>
            
            <Button
              size="sm"
              variant="ghost"
              onClick={toggleFullscreen}
              className="text-white hover:bg-white/20"
            >
              <Maximize className="w-4 h-4" />
            </Button>
          </div>
        </div>
        
        {/* Click to play overlay */}
        {!state.playing && !state.loading && (
          <div 
            className="absolute inset-0 flex items-center justify-center cursor-pointer"
            onClick={togglePlay}
          >
            <div className="bg-black/50 rounded-full p-4">
              <Play className="w-8 h-8 text-white" />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Wrapped with error boundary
export default function ReliableVideoPlayerWithBoundary(props: ReliableVideoPlayerProps) {
  return (
    <RobustErrorBoundary level="video">
      <ReliableVideoPlayer {...props} />
    </RobustErrorBoundary>
  );
}