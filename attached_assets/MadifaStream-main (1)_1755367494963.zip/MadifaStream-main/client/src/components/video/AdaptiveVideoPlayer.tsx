/**
 * Adaptive Video Player
 * 
 * Intelligently switches between custom ModernVideoPlayer and BunnyNativePlayer
 * based on video properties, user preferences, and performance considerations
 */

import React, { useState, useEffect } from 'react';
import { ModernVideoPlayer } from './ModernVideoPlayer';
import { BunnyNativePlayer } from './BunnyNativePlayer';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Settings, Zap, Shield } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useLocalStorage } from '@/hooks/use-local-storage';

interface AdaptiveVideoPlayerProps {
  videoId: string;
  bunnyVideoId?: string;
  bunnyLibraryId?: string;
  title: string;
  thumbnail?: string;
  isPremium?: boolean;
  autoplay?: boolean;
  className?: string;
  onComplete?: () => void;
  onError?: (error: Error) => void;
  onUpgrade?: () => void;
  // Player preference
  preferredPlayer?: 'auto' | 'native' | 'custom';
  // Force specific player
  forcePlayer?: 'native' | 'custom';
}

type PlayerType = 'native' | 'custom';

interface PlayerOption {
  type: PlayerType;
  name: string;
  description: string;
  icon: React.ReactNode;
  badge?: string;
  pros: string[];
  cons: string[];
  requirements?: string[];
}

const PLAYER_OPTIONS: PlayerOption[] = [
  {
    type: 'native',
    name: 'Bunny Native Player',
    description: 'Optimized iframe player with built-in features',
    icon: <Zap className="w-4 h-4" />,
    badge: 'Recommended',
    pros: [
      'Faster loading and better performance',
      'Built-in adaptive bitrate streaming',
      'Automatic quality adjustment',
      'Native mobile optimizations',
      'Built-in analytics and heatmaps',
      'Chromecast and AirPlay support',
      'Less development maintenance'
    ],
    cons: [
      'Less customization control',
      'Dependent on Bunny infrastructure',
      'Limited custom branding options'
    ],
    requirements: [
      'Valid Bunny video ID and library ID',
      'Player.js library support'
    ]
  },
  {
    type: 'custom',
    name: 'Custom Video Player',
    description: 'Full-featured custom player with advanced controls',
    icon: <Settings className="w-4 h-4" />,
    pros: [
      'Complete UI/UX customization',
      'Advanced error handling',
      'Custom analytics integration',
      'Offline support capabilities',
      'Full branding control',
      'Custom keyboard shortcuts'
    ],
    cons: [
      'Requires more development effort',
      'Manual quality management',
      'Larger bundle size',
      'More complex error handling'
    ],
    requirements: [
      'Video stream URL available',
      'Modern browser support'
    ]
  }
];

export function AdaptiveVideoPlayer({
  videoId,
  bunnyVideoId,
  bunnyLibraryId,
  title,
  thumbnail,
  isPremium = false,
  autoplay = false,
  className,
  onComplete,
  onError,
  onUpgrade,
  preferredPlayer = 'auto',
  forcePlayer,
}: AdaptiveVideoPlayerProps) {
  // User preference storage
  const [userPreference, setUserPreference] = useLocalStorage<PlayerType>('video-player-preference', 'native');
  const [showPlayerSelector, setShowPlayerSelector] = useState(false);
  const [currentPlayer, setCurrentPlayer] = useState<PlayerType>('native');

  // Determine which player to use
  useEffect(() => {
    if (forcePlayer) {
      setCurrentPlayer(forcePlayer);
      return;
    }

    let selectedPlayer: PlayerType = 'native';

    switch (preferredPlayer) {
      case 'native':
        selectedPlayer = 'native';
        break;
      case 'custom':
        selectedPlayer = 'custom';
        break;
      case 'auto':
      default:
        // Auto-selection logic
        if (bunnyVideoId && bunnyLibraryId) {
          // Prefer native player if Bunny IDs are available
          selectedPlayer = userPreference === 'custom' ? 'custom' : 'native';
        } else {
          // Fall back to custom player if no Bunny IDs
          selectedPlayer = 'custom';
        }
        break;
    }

    setCurrentPlayer(selectedPlayer);
  }, [preferredPlayer, forcePlayer, bunnyVideoId, bunnyLibraryId, userPreference]);

  // Check if native player is available
  const isNativePlayerAvailable = !!(bunnyVideoId && bunnyLibraryId);

  // Handle player switch
  const handlePlayerSwitch = (playerType: PlayerType) => {
    if (playerType === 'native' && !isNativePlayerAvailable) {
      onError?.(new Error('Native player not available for this video'));
      return;
    }

    setCurrentPlayer(playerType);
    setUserPreference(playerType);
    setShowPlayerSelector(false);
  };

  // Enhanced error handling
  const handlePlayerError = (error: Error) => {
    console.error(`${currentPlayer} player error:`, error);
    
    // Auto-fallback logic
    if (currentPlayer === 'native' && isNativePlayerAvailable) {
      console.log('Native player failed, falling back to custom player');
      setCurrentPlayer('custom');
      return;
    }

    onError?.(error);
  };

  // Render player selector
  const renderPlayerSelector = () => (
    <div className="absolute top-4 right-4 z-30">
      {showPlayerSelector ? (
        <div className="bg-black/90 backdrop-blur-sm rounded-lg p-4 min-w-80 max-w-sm">
          <h3 className="text-white font-semibold mb-3 flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Choose Player
          </h3>
          
          <div className="space-y-3">
            {PLAYER_OPTIONS.map((option) => {
              const isAvailable = option.type === 'custom' || isNativePlayerAvailable;
              const isSelected = currentPlayer === option.type;
              
              return (
                <button
                  key={option.type}
                  onClick={() => isAvailable && handlePlayerSwitch(option.type)}
                  disabled={!isAvailable}
                  className={cn(
                    'w-full text-left p-3 rounded-lg border transition-all',
                    isSelected 
                      ? 'bg-primary/20 border-primary text-white' 
                      : isAvailable
                        ? 'bg-white/5 border-white/20 text-white hover:bg-white/10'
                        : 'bg-gray-500/20 border-gray-500/20 text-gray-400 cursor-not-allowed',
                  )}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      {option.icon}
                      <span className="font-medium text-sm">{option.name}</span>
                      {isSelected && <Badge variant="secondary" className="text-xs">Active</Badge>}
                    </div>
                    {option.badge && (
                      <Badge variant="outline" className="text-xs border-primary text-primary">
                        {option.badge}
                      </Badge>
                    )}
                  </div>
                  
                  <p className="text-xs text-gray-300 mb-2">{option.description}</p>
                  
                  {!isAvailable && (
                    <p className="text-xs text-red-400">
                      Not available for this video
                    </p>
                  )}
                </button>
              );
            })}
          </div>
          
          <div className="mt-4 pt-3 border-t border-white/20">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowPlayerSelector(false)}
              className="w-full text-white hover:bg-white/10"
            >
              Close
            </Button>
          </div>
        </div>
      ) : (
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setShowPlayerSelector(true)}
          className="bg-black/50 backdrop-blur-sm text-white hover:bg-black/70 border border-white/20"
        >
          <Settings className="w-4 h-4 mr-2" />
          Player
        </Button>
      )}
    </div>
  );

  // Render current player info badge
  const renderPlayerInfo = () => {
    const currentOption = PLAYER_OPTIONS.find(opt => opt.type === currentPlayer);
    if (!currentOption) return null;

    return (
      <div className="absolute top-4 left-4 z-20 pointer-events-none">
        <Badge 
          variant="secondary" 
          className="bg-black/60 backdrop-blur-sm text-white border-white/20"
        >
          {currentOption.icon}
          <span className="ml-1">{currentOption.name}</span>
          {isPremium && <Shield className="w-3 h-3 ml-1" />}
        </Badge>
      </div>
    );
  };

  return (
    <div className={cn('relative', className)}>
      {/* Player selector */}
      {!forcePlayer && renderPlayerSelector()}
      
      {/* Player info badge */}
      {renderPlayerInfo()}

      {/* Render appropriate player */}
      {currentPlayer === 'native' && isNativePlayerAvailable ? (
        <BunnyNativePlayer
          videoId={videoId}
          bunnyVideoId={bunnyVideoId!}
          bunnyLibraryId={bunnyLibraryId!}
          title={title}
          thumbnail={thumbnail}
          isPremium={isPremium}
          autoplay={autoplay}
          onComplete={onComplete}
          onError={handlePlayerError}
          onUpgrade={onUpgrade}
        />
      ) : (
        <ModernVideoPlayer
          videoId={videoId}
          title={title}
          thumbnail={thumbnail}
          autoplay={autoplay}
          onComplete={onComplete}
          onError={handlePlayerError}
        />
      )}
    </div>
  );
} 