import {  Button  } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type {  SubscriptionPlan  } from "@shared/schema";
import { useMutation } from "@tanstack/react-query";
import {  Check, Loader2, X, Zap  } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import axios from "axios";
import { api } from "@/lib/env";

const PAYFAST_SANDBOX_URL = 'https://sandbox.payfast.co.za/eng/process';
import { logger } from '@shared/logger';

interface SubscriptionModalProps {
  /**
   * Controls the visibility of the modal. When omitted the modal is treated as open (back-compat).
   */
  isOpen?: boolean;
  onClose: () => void;
  videoId?: string; // Make videoId optional as it might not always be relevant
}

const defaultPlans: SubscriptionPlan[] = [
  {
    id: "00000000-0000-0000-0000-000000000001",
    name: "Free",
    price: "0",
    video_quality: "SD",
    max_devices: 1,
    offline_downloads: false,
    max_downloads: null,
    duration_months: null,
    features: ["Limited content", "SD quality", "With ads"],
  },
  {
    id: "00000000-0000-0000-0000-000000000002",
    name: "Premium",
    price: "59.00",
    video_quality: "HD",
    max_devices: 4,
    offline_downloads: true,
    max_downloads: null,
    duration_months: null,
    features: ["All content", "HD quality", "No ads", "Download for offline"],
  },
];

export function SubscriptionModal({ isOpen = true, onClose, videoId }: SubscriptionModalProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const [plans, setPlans] = useState<SubscriptionPlan[]>(defaultPlans);

  // Derive specific plans for UI references
  const freePlan = plans.find((p) => p.name.toLowerCase() === "free");
  const premiumPlan = plans.find((p) => p.name.toLowerCase() === "premium");

  // Simple helper to format ZAR prices
  const formatPrice = (price: string | number) => {
    if (price === "0" || price === 0) return "Free";
    return `R${price}`;
  };

  // Ref to manage initial focus when modal opens
  const modalRef = useRef<HTMLDivElement>(null);

  // Set focus to the dialog when it mounts for screen-reader announcement
  useEffect(() => {
    if (isOpen) {
      modalRef.current?.focus();
    }
  }, [isOpen]);

  // Load subscription plans from API (fallback to defaults on error)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { data } = await axios.get(api('/api/payfast/plans'), {
          withCredentials: true,
        });
        if (!cancelled && Array.isArray(data?.plans) && data.plans.length > 0) {
          setPlans(data.plans);
        }
      } catch (error) {
        logger.warn('Failed to load plans from API, using defaults');
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const initiatePaymentMutation = useMutation({
    mutationFn: async (planId: string) => {
      if (!user) {
        throw new Error("Please sign in to subscribe to premium content.");
      }
      
      // Use authenticated flow; backend requires a valid Bearer token
      logger.payment('Initiating payment for plan:', { arg1: { planId } });
      const token = localStorage.getItem('auth_token');
      const response = await axios.post(
        api('/api/payfast/initiate-payment'),
        { planId },
        {
          headers: {
            'Content-Type': 'application/json',
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
          },
          withCredentials: true,
        }
      );
      return response.data;
    },
    onSuccess: (data) => {
      logger.payment('Payment initiation response:', { arg1: data });
      const { formData, success } = data;
      if (!success || !formData) {
        toast({ 
          title: "Payment Setup Failed", 
          description: "Failed to prepare payment form. Please try again.", 
          variant: "destructive" 
        });
        return;
      }
      
      logger.payment('Creating PayFast form with data:', { arg1: formData });
      
      // Create and submit PayFast form
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = PAYFAST_SANDBOX_URL;
      form.style.display = 'none';
      
      for (const key in formData) {
        const input = document.createElement('input');
        input.type = 'hidden';
        input.name = key;
        input.value = formData[key];
        form.appendChild(input);
        logger.info(`Form field: ${key} = ${formData[key]}`);
      }
      
      document.body.appendChild(form);
      logger.payment('Submitting PayFast form to:', { arg1: form.action });
      form.submit();
      document.body.removeChild(form);
    },
    onError: (error: unknown) => {
      const errorResponse = (error as any).response?.data;
      const errorCode = errorResponse?.code;
      const errorMessage = errorResponse?.message || "Could not start the payment process. Please try again.";
      
      // Handle specific error cases
      if (errorCode === 'AUTH_REQUIRED' || (error as any).response?.status === 401) {
        toast({
          title: "Authentication Required",
          description: "Please sign in to subscribe to premium content.",
          variant: "destructive",
        });
        
        // Close modal and redirect to auth
        onClose();
        // You can add navigation logic here if needed
        window.location.href = '/auth?redirect=' + encodeURIComponent(window.location.pathname);
        return;
      }
      
      if (errorCode === 'MISSING_PLAN') {
        toast({
          title: "Plan Selection Required",
          description: "Please select a subscription plan to continue.",
          variant: "destructive",
        });
        return;
      }
      
      if (errorCode === 'INVALID_PLAN') {
        toast({
          title: "Invalid Plan",
          description: "The selected subscription plan is not available. Please try again.",
          variant: "destructive",
        });
        return;
      }
      
      if (errorCode === 'GATEWAY_CONFIG_ERROR') {
        toast({
          title: "Payment Service Unavailable",
          description: "Payment processing is temporarily unavailable. Please try again later.",
          variant: "destructive",
        });
        return;
      }
      
      // Generic error handling
      toast({
        title: "Payment Initiation Failed",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const handleSubscribeClick = () => {
    if (!selectedPlanId) {
      toast({
        title: "No Plan Selected",
        description: "Please select a subscription plan to continue.",
        variant: "destructive",
      });
      return;
    }
    initiatePaymentMutation.mutate(selectedPlanId);
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center overflow-y-auto"
      onClick={onClose}
    >
      {/*
        The dialog is given role="dialog" and aria-modal to convey that it is a modal to assistive technologies.
        We also give it tabIndex={-1} so it can receive programmatic focus when it mounts.
      */}
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="subscription-modal-title"
        tabIndex={-1}
        ref={modalRef}
        className="bg-card rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto my-8 outline-none"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h2 id="subscription-modal-title" className="text-2xl font-bold">Choose Your Plan</h2>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:text-primary text-2xl"
              onClick={(e) => { e.stopPropagation(); onClose(); }}
            >
              <X />
            </Button>
          </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {freePlan && (
                <div className="border border-gray-700 rounded-lg p-6 relative bg-gray-800/50">
                  <div className="absolute top-0 right-6 transform -translate-y-1/2 bg-gray-600 text-white text-xs uppercase font-bold py-1 px-3 rounded-full">
                    Current Plan
                  </div>
                  <h3 className="text-xl font-medium mb-2">{freePlan.name}</h3>
                  <p className="text-primary text-2xl font-bold mb-4">
                    {formatPrice(freePlan.price)}
                  </p>
                  <ul className="space-y-2 text-sm text-gray-300">
                    {freePlan.features?.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check className="text-green-500 mt-1 mr-2 h-4 w-4" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button variant="secondary" className="w-full opacity-75 cursor-not-allowed" disabled>
                    Your Current Plan
                  </Button>
                </div>
              )}

              {premiumPlan && (() => {
                const isSelected = selectedPlanId === premiumPlan.id;
                return (
                  <div
                    key={premiumPlan.id}
                    role="button"
                    tabIndex={0}
                    aria-pressed={isSelected}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' || e.key === ' ') {
                        e.preventDefault();
                        setSelectedPlanId(premiumPlan.id);
                      }
                    }}
                    className={`rounded-lg p-6 transition-colors relative cursor-pointer border-2 focus:outline-primary ${isSelected ? "border-primary" : "border-gray-700 hover:border-primary"}`}
                    onClick={() => setSelectedPlanId(premiumPlan.id)}
                  >
                    <div className="absolute top-0 right-6 transform -translate-y-1/2 bg-primary text-white text-xs uppercase font-bold py-1 px-3 rounded-full">
                      Recommended
                    </div>
                    <h3 className="text-xl font-medium mb-2">{premiumPlan.name}</h3>
                    <p className="text-primary text-2xl font-bold mb-4">
                      {formatPrice(premiumPlan.price)}
                      <span className="text-sm text-gray-400 font-normal"> / month</span>
                    </p>
                    <ul className="space-y-2 text-sm text-gray-300">
                      {premiumPlan.features?.map((feature, index) => (
                        <li key={index} className="flex items-start">
                          <Check className="text-green-500 mt-1 mr-2 h-4 w-4" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })()}
            </div>

          <div className="bg-gray-800 p-6 rounded-lg flex flex-col items-center">
            <h3 className="text-lg font-medium mb-4">Complete Your Upgrade</h3>
            <p className="text-muted-foreground text-center mb-6 max-w-md">
              You will be securely redirected to PayFast to complete your payment. Select the premium plan above to get started.
            </p>
                  <Button
              onClick={handleSubscribeClick}
              disabled={initiatePaymentMutation.isPending || !selectedPlanId}
              className="w-full max-w-sm bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white"
              size="lg"
              aria-disabled={initiatePaymentMutation.isPending || !selectedPlanId}
            >
              {initiatePaymentMutation.isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Zap className="mr-2 h-4 w-4" />
              )}
              {initiatePaymentMutation.isPending ? 'Redirecting...' : 'Proceed to PayFast'}
                      </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
