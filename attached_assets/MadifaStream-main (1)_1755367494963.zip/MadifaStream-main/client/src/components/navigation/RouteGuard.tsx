import React from 'react';
import { Redirect } from 'wouter';
import { useAuthStore } from '@/stores/authStore';

// Legacy props expected by older code/tests
interface LegacyRouteGuardProps {
  children: React.ReactNode;
  /** Whether the route requires authentication */
  requireAuth?: boolean;
  /** Single required role (legacy API) */
  requiredRole?: string;
  /** Path to redirect unauthorised users */
  redirectTo?: string;
  /** Fallback element while checking auth */
  fallback?: React.ReactNode;
}

/**
 * Back-compat wrapper so legacy imports using `@/components/navigation/RouteGuard`
 * with `requireAuth`/`requiredRole` props continue to work.
 * Internally delegates to the new `RouteGuard` implementation when possible.
 */
export const RouteGuard: React.FC<LegacyRouteGuardProps> = ({
  children,
  requireAuth = false,
  requiredRole,
  redirectTo = '/auth',
  fallback = null,
}) => {
  const { user, isLoading } = useAuthStore();

  if (isLoading) return <>{fallback || <div>Loading...</div>}</>;

  // Redirect authenticated users away from auth pages (legacy behaviour)
  if (!requireAuth && user) {
    return <Redirect to={redirectTo} />;
  }

  // Authentication gate
  if (requireAuth && !user) {
    return <Redirect to={redirectTo} />;
  }

  // Role gate (legacy single-role check)
  if (requiredRole && user?.role !== requiredRole) {
    return <Redirect to={redirectTo} />;
  }

  // No additional legacy checks needed – render children.
  return <>{children}</>;
};
