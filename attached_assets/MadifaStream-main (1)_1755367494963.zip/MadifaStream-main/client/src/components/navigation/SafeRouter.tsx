import React, { useEffect, useState, useCallback } from 'react'
import { useLocation } from 'wouter'
import { RouteErrorBoundary } from '../error-boundary/GlobalErrorBoundary'

interface SafeRouterProps {
  children: React.ReactNode
}

export function SafeRouter({ children }: SafeRouterProps) {
  const [location, setLocation] = useLocation()
  const [navigationHistory, setNavigationHistory] = useState<string[]>([])
  const [isNavigating, setIsNavigating] = useState(false)

  // Track navigation history
  useEffect(() => {
    setNavigationHistory(prev => {
      const newHistory = [...prev, location]
      // Keep only last 10 entries
      return newHistory.slice(-10)
    })
  }, [location])

  // Safe navigation function with error handling
  const safeNavigate = useCallback((to: string, options?: { replace?: boolean }) => {
    if (isNavigating) return // Prevent double navigation
    
    setIsNavigating(true)
    
    try {
      setLocation(to)
    } catch (error) {
      console.error('Navigation error:', error)
      // Fallback to home if navigation fails
      window.location.href = '/'
    } finally {
      setTimeout(() => setIsNavigating(false), 100)
    }
  }, [setLocation, isNavigating])

  // Safe back navigation
  const safeGoBack = useCallback(() => {
    if (isNavigating) return
    
    try {
      if (navigationHistory.length > 1) {
        // Use our tracked history
        const previousPath = navigationHistory[navigationHistory.length - 2]
        safeNavigate(previousPath, { replace: true })
      } else if (window.history.length > 1) {
        // Use browser history
        window.history.back()
      } else {
        // Fallback to home
        safeNavigate('/')
      }
    } catch (error) {
      console.error('Back navigation error:', error)
      safeNavigate('/')
    }
  }, [navigationHistory, safeNavigate, isNavigating])

  // Handle browser back button
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      try {
        // Let the browser handle it normally
        // This prevents conflicts with React Router
      } catch (error) {
        console.error('PopState error:', error)
        event.preventDefault()
        safeNavigate('/')
      }
    }

    window.addEventListener('popstate', handlePopState)
    return () => window.removeEventListener('popstate', handlePopState)
  }, [safeNavigate])

  // Provide safe navigation methods to children
  useEffect(() => {
    // Make safe navigation available globally
    (window as any).safeNavigate = safeNavigate;
    (window as any).safeGoBack = safeGoBack;
  }, [safeNavigate, safeGoBack])

  return (
    <RouteErrorBoundary>
      {children}
    </RouteErrorBoundary>
  )
}

// Hook for using safe navigation in components
export function useSafeNavigation() {
  const [, navigate] = useLocation()
  
  const safeNavigate = useCallback((to: string, options?: { replace?: boolean }) => {
    try {
      navigate(to, options)
    } catch (error) {
      console.error('Navigation error:', error)
      window.location.href = to
    }
  }, [navigate])

  const safeGoBack = useCallback(() => {
    try {
      if (window.history.length > 1) {
        window.history.back()
      } else {
        safeNavigate('/')
      }
    } catch (error) {
      console.error('Back navigation error:', error)
      safeNavigate('/')
    }
  }, [safeNavigate])

  return {
    safeNavigate,
    safeGoBack,
    currentPath: location.pathname
  }
}

// Safe Link component that won't crash
interface SafeLinkProps {
  to: string
  children: React.ReactNode
  className?: string
  replace?: boolean
}

export function SafeLink({ to, children, className, replace }: SafeLinkProps) {
  const { safeNavigate } = useSafeNavigation()
  
  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault()
    safeNavigate(to, { replace })
  }

  return (
    <a 
      href={to} 
      onClick={handleClick} 
      className={className}
      style={{ cursor: 'pointer' }}
    >
      {children}
    </a>
  )
} 