import React, { useEffect, useState, useCallback } from 'react'
import { useLocation } from 'wouter'
import { RouteErrorBoundary } from '../error-boundary/GlobalErrorBoundary'

interface SafeWouterRouterProps {
  children: React.ReactNode
}

export function SafeWouterRouter({ children }: SafeWouterRouterProps) {
  const [location, setLocation] = useLocation()
  const [navigationHistory, setNavigationHistory] = useState<string[]>([])
  const [isNavigating, setIsNavigating] = useState(false)

  // Track navigation history
  useEffect(() => {
    setNavigationHistory(prev => {
      const newHistory = [...prev, location]
      // Keep only last 10 entries
      return newHistory.slice(-10)
    })
  }, [location])

  // Safe navigation function with error handling
  const safeNavigate = useCallback((to: string, options?: { replace?: boolean }) => {
    if (isNavigating) return // Prevent double navigation
    
    setIsNavigating(true)
    
    try {
      setLocation(to, options)
    } catch (error) {
      console.error('Navigation error:', error)
      // Fallback to home if navigation fails
      window.location.href = '/'
    } finally {
      setTimeout(() => setIsNavigating(false), 100)
    }
  }, [setLocation, isNavigating])

  // Safe back navigation
  const safeGoBack = useCallback(() => {
    if (isNavigating) return
    
    try {
      if (navigationHistory.length > 1) {
        // Use our tracked history
        const previousPath = navigationHistory[navigationHistory.length - 2]
        safeNavigate(previousPath, { replace: true })
      } else if (window.history.length > 1) {
        // Use browser history
        window.history.back()
      } else {
        // Fallback to home
        safeNavigate('/')
      }
    } catch (error) {
      console.error('Back navigation error:', error)
      safeNavigate('/')
    }
  }, [navigationHistory, safeNavigate, isNavigating])

  // Handle browser back button
  useEffect(() => {
    const handlePopState = (event: PopStateEvent) => {
      try {
        // Let Wouter handle it normally
        // This prevents conflicts with Wouter
      } catch (error) {
        console.error('PopState error:', error)
        event.preventDefault()
        safeNavigate('/')
      }
    }

    window.addEventListener('popstate', handlePopState)
    return () => window.removeEventListener('popstate', handlePopState)
  }, [safeNavigate])

  // Provide safe navigation methods globally
  useEffect(() => {
    (window as any).safeNavigate = safeNavigate;
    (window as any).safeGoBack = safeGoBack;
  }, [safeNavigate, safeGoBack])

  return (
    <RouteErrorBoundary>
      {children}
    </RouteErrorBoundary>
  )
}

// Hook for using safe navigation in components
export function useSafeWouterNavigation() {
  const [location, setLocation] = useLocation()
  
  const safeNavigate = useCallback((to: string, options?: { replace?: boolean }) => {
    try {
      setLocation(to, options)
    } catch (error) {
      console.error('Navigation error:', error)
      window.location.href = to
    }
  }, [setLocation])

  const safeGoBack = useCallback(() => {
    try {
      if (window.history.length > 1) {
        window.history.back()
      } else {
        safeNavigate('/')
      }
    } catch (error) {
      console.error('Back navigation error:', error)
      safeNavigate('/')
    }
  }, [safeNavigate])

  return {
    safeNavigate,
    safeGoBack,
    currentPath: location
  }
}

// Safe Link component that won't crash
interface SafeWouterLinkProps {
  to: string
  children: React.ReactNode
  className?: string
  replace?: boolean
}

export function SafeWouterLink({ to, children, className, replace }: SafeWouterLinkProps) {
  const { safeNavigate } = useSafeWouterNavigation()
  
  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault()
    safeNavigate(to, { replace })
  }

  return (
    <a 
      href={to} 
      onClick={handleClick} 
      className={className}
      style={{ cursor: 'pointer' }}
    >
      {children}
    </a>
  )
}

// Safe back button component
interface SafeBackButtonProps {
  children?: React.ReactNode
  className?: string
  fallbackTo?: string
}

export function SafeBackButton({ children, className, fallbackTo = '/' }: SafeBackButtonProps) {
  const { safeGoBack } = useSafeWouterNavigation()
  
  const handleClick = (e: React.MouseEvent) => {
    e.preventDefault()
    safeGoBack()
  }

  return (
    <button 
      onClick={handleClick} 
      className={className}
      style={{ cursor: 'pointer' }}
    >
      {children || '← Back'}
    </button>
  )
} 