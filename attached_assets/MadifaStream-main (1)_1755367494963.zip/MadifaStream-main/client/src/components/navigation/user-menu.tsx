/**
 * User Menu Component
 * 
 * This component displays a dropdown menu in the navigation bar
 * that provides quick access to user profile, settings, and logout
 */

import { useAuth } from '@/hooks/use-auth';
import { useQueryClient } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';

import { 
    Avatar,
    AvatarFallback
 } from '@/components/ui/avatar';
import {  Button  } from '@/components/ui/button';
import {
    DropdownMenu,
    DropdownMenuContent,
    DropdownMenuGroup,
    DropdownMenuItem,
    DropdownMenuLabel,
    DropdownMenuSeparator,
    DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import { 
    ChevronDown,
    CreditCard,
    HelpCircle,
    LogOut,
    Settings,
    User
 } from 'lucide-react';

export function UserMenu() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { user, profile, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();

  // Handle logout
  const handleSignOut = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        queryClient.clear(); // Clear all react-query cache
        toast({
          title: 'Signed out',
          description: 'You have been successfully signed out',
        });
        setLocation('/auth');
      },
      onError: () => {
        toast({
          title: 'Error',
          description: 'There was a problem signing out',
          variant: 'destructive',
        });
      }
    });
  };

  // Generate avatar initials
  function getInitials(name: string) {
    if (!name) return 'U';
    return name.split(' ').map((n) => n[0]).join('').toUpperCase().substring(0, 2);
  }

  if (logoutMutation.isPending) {
    return (
      <Button variant="ghost" size="sm" disabled>
        <div className="h-8 w-8 rounded-full bg-muted animate-pulse" />
      </Button>
    );
  }

  if (!user) {
    return (
      <Button variant="outline" size="sm" asChild>
        <Link href="/auth">Sign In</Link>
      </Button>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" className="relative h-8 flex items-center gap-2 rounded-full" aria-label="User menu">
          <Avatar className="h-8 w-8" style={{ backgroundColor: '#4f46e5' }}>
            <AvatarFallback>
              {getInitials(profile?.display_name || user?.email || 'User')}
            </AvatarFallback>
          </Avatar>
          <span className="hidden md:inline-block text-sm font-medium">
            {profile?.display_name || user?.email?.split('@')[0] || 'User'}
          </span>
          <ChevronDown className="h-4 w-4 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <DropdownMenuLabel className="font-normal">
          <div className="flex flex-col space-y-1">
            <p className="text-sm font-medium leading-none">{profile?.display_name || 'My Account'}</p>
            <p className="text-xs leading-none text-muted-foreground">{user.email}</p>
          </div>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <DropdownMenuItem asChild>
            <Link href="/profile" className="cursor-pointer flex items-center">
              <User className="mr-2 h-4 w-4" />
              Profile
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/subscription" className="cursor-pointer flex items-center">
              <CreditCard className="mr-2 h-4 w-4" />
              Subscription
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/settings" className="cursor-pointer flex items-center">
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Link>
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem asChild>
          <a 
            href="https://madifahelp.zendesk.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="cursor-pointer flex items-center"
          >
            <HelpCircle className="mr-2 h-4 w-4" />
            Help Center
          </a>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem 
          onClick={handleSignOut} 
          className="cursor-pointer"
          disabled={logoutMutation.isPending}
        >
          <LogOut className="mr-2 h-4 w-4" />
          {logoutMutation.isPending ? 'Signing out...' : 'Log out'}
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}