import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  ExternalLink,
  RefreshCw,
  Trash2,
  Eye,
  Calendar,
  Clock,
  TrendingUp,
  Pencil,
} from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { UploadVideoButton } from "./admin/upload-video-button";
import { logger } from '@shared/logger';

interface BunnyStreamVideo {
  guid: string;
  title: string;
  dateUploaded: string;
  views: number;
  isPublic: boolean;
  length: number;
  status: number;
  thumbnailFileName: string;
  metaTags?: string[] | null;
  category?: string;
}

interface BunnyStreamCollection {
  guid: string;
  name: string;
  videoCount: number;
}

/**
 * A streamlined BunnyStream content manager that leverages BunnyStream's built-in features
 * This minimalist approach focuses on displaying and managing content while letting BunnyStream
 * handle the complex parts like views, comments, and storage.
 */
export function AdminContentManager() {
  const [activeTab, setActiveTab] = useState("videos");
  const [searchQuery, setSearchQuery] = useState("");
  const [page, setPage] = useState(1);
  const queryClient = useQueryClient();

  // Fetch videos from BunnyStream
  const { data: videos = [], isLoading: isLoadingVideos, refetch: refetchVideos } = useQuery<BunnyStreamVideo[]>({
    queryKey: ["/api/admin/videos", searchQuery, page],
    queryFn: async () => {
      try {
        const params = new URLSearchParams({
          page: page.toString(),
          ...(searchQuery && { search: searchQuery })
        });

        const res = await fetch(`/api/admin/videos?${params}`, {
          credentials: "include"
        });

        if (!res.ok) {
          throw new Error(`Failed to fetch videos: ${res.status} ${res.statusText}`);
        }

        return await res.json();
      } catch (error) {
        logger.api("Error fetching BunnyStream videos:", error);
        return [];
      }
    }
  });

  // Fetch collections from BunnyStream
  const { data: collections = [], isLoading: isLoadingCollections } = useQuery<BunnyStreamCollection[]>({
    queryKey: ["/api/admin/collections"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/admin/collections", {
          credentials: "include"
        });

        if (!res.ok) {
          throw new Error(`Failed to fetch collections: ${res.status} ${res.statusText}`);
        }

        return await res.json();
      } catch (error) {
        logger.api("Error fetching BunnyStream collections:", error);
        return [];
      }
    }
  });

  // Refresh content mutation
  const refreshContentMutation = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/admin/refresh-content", {
        method: "POST",
        credentials: "include"
      });
      if (!res.ok) throw new Error(`Failed to refresh content: ${res.status} ${res.statusText}`);
      return await res.json();
    },
    onSuccess: (data) => {
      refetchVideos();
      toast({
        title: "Content refreshed",
        description: `Successfully refreshed ${data.count} videos from BunnyStream.`,
      });
    },
    onError: (error: Error) => {
      // eslint-disable-next-line no-console
      logger.error("Error refreshing content:", { arg1: error });
      toast({
        title: "Failed to refresh content",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Delete video mutation
  const deleteVideoMutation = useMutation({
    mutationFn: async (guid: string) => {
      const res = await fetch(`/api/admin/videos/${guid}`, {
        method: "DELETE",
        credentials: "include"
      });
      if (!res.ok) throw new Error(`Failed to delete video: ${res.status} ${res.statusText}`);
    },
    onSuccess: () => {
      refetchVideos();
      toast({
        title: "Video deleted",
        description: "The video has been deleted from BunnyStream.",
      });
    },
    onError: (error: Error) => {
      // eslint-disable-next-line no-console
      logger.error("Error deleting video:", { arg1: error });
      toast({
        title: "Failed to delete video",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1); // Reset to first page when searching
    refetchVideos();
  };

  // Handle video deletion
  const handleDeleteVideo = (guid: string) => {
    if (confirm("Are you sure you want to delete this video? This action cannot be undone.")) {
      deleteVideoMutation.mutate(guid);
    }
  };

  // Format duration from seconds to readable format
  const formatDuration = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) {
      const remainingMinutes = minutes % 60;
      return `${hours}h ${remainingMinutes}m`;
    } else {
      return `${minutes}m`;
    }
  };

  // Format date 
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-ZA', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>BunnyStream Content Manager</CardTitle>
            <CardDescription>
              Manage videos directly from your BunnyStream library
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            <Button
              onClick={() => refreshContentMutation.mutate()}
              disabled={refreshContentMutation.isPending}
            >
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh Content
            </Button>
            {collections && collections.length > 0 && (
              <UploadVideoButton
                collectionId={collections[0].guid}
                onSuccess={() => {
                  refreshContentMutation.mutate();
                }}
              />
            )}
            <a
              href="https://panel.bunny.net/stream"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button variant="outline">
                <ExternalLink className="mr-2 h-4 w-4" />
                Open BunnyStream Panel
              </Button>
            </a>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="videos">Videos</TabsTrigger>
            <TabsTrigger value="collections">Collections</TabsTrigger>
            <TabsTrigger value="stats">Analytics</TabsTrigger>
          </TabsList>

          {/* Videos Tab */}
          <TabsContent value="videos">
            <div className="mb-6 flex items-center gap-4">
              <form onSubmit={handleSearch} className="flex-1 flex gap-2">
                <Input
                  placeholder="Search videos..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="flex-1"
                />
                <Button type="submit">Search</Button>
              </form>
            </div>

            {isLoadingVideos ? (
              <div className="flex justify-center py-10">
                <div className="animate-spin h-10 w-10 border-2 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : (
              <>
                <Table>
                  <TableCaption>Videos in your BunnyStream library</TableCaption>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Uploaded</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Views</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {videos.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-10">
                          No videos found in your BunnyStream library
                        </TableCell>
                      </TableRow>
                    ) : (
                      videos.map((video: BunnyStreamVideo) => (
                        <TableRow key={video.guid}>
                          <TableCell className="font-medium">{video.title}</TableCell>
                          <TableCell>{formatDate(video.dateUploaded)}</TableCell>
                          <TableCell>{formatDuration(video.length)}</TableCell>
                          <TableCell>{video.views.toLocaleString()}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-1 rounded-full text-xs ${video.status === 4 ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                              }`}>
                              {video.status === 4 ? "Ready" : "Processing"}
                            </span>
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => window.open(`https://panel.bunny.net/stream/library/videos/${video.guid}`, "_blank")}
                                title="Edit in BunnyStream Panel"
                              >
                                <Pencil className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="outline"
                                size="icon"
                                onClick={() => window.open(`https://iframe.mediadelivery.net/embed/${process.env.BUNNY_LIBRARY_ID || ""}/${video.guid}`, "_blank")}
                                title="Preview"
                              >
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="destructive"
                                size="icon"
                                onClick={() => handleDeleteVideo(video.guid)}
                                title="Delete"
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>

                {/* Pagination */}
                <div className="flex justify-center gap-2 mt-6">
                  <Button
                    variant="outline"
                    disabled={page <= 1}
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    disabled={videos.length < 10} // Assuming 10 items per page
                    onClick={() => setPage(p => p + 1)}
                  >
                    Next
                  </Button>
                </div>
              </>
            )}
          </TabsContent>

          {/* Collections Tab */}
          <TabsContent value="collections">
            {isLoadingCollections ? (
              <div className="flex justify-center py-10">
                <div className="animate-spin h-10 w-10 border-2 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : (
              <Table>
                <TableCaption>Collections in your BunnyStream library</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Videos</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {collections.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={3} className="text-center py-10">
                        No collections found in your BunnyStream library
                      </TableCell>
                    </TableRow>
                  ) : (
                    collections.map((collection: BunnyStreamCollection) => (
                      <TableRow key={collection.guid}>
                        <TableCell className="font-medium">{collection.name}</TableCell>
                        <TableCell>{collection.videoCount || 0}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => window.open(`https://panel.bunny.net/stream/library/collections/${collection.guid}`, "_blank")}
                            >
                              <ExternalLink className="h-4 w-4 mr-2" />
                              Manage
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="stats">
            <div className="text-center py-10">
              <p className="text-muted-foreground mb-4">
                Analytics are handled directly by BunnyStream and can be accessed through their dashboard.
              </p>
              <Button
                onClick={() => window.open("https://panel.bunny.net/stream/library/analytics", "_blank")}
              >
                <ExternalLink className="mr-2 h-4 w-4" />
                View Analytics in BunnyStream
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}