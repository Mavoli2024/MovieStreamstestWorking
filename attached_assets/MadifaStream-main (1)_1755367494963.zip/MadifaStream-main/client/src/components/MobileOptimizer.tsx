import React, { useEffect, useState } from 'react';

interface NetworkConnection {
  effectiveType?: string;
  addEventListener: (event: string, listener: () => void) => void;
  removeEventListener: (event: string, listener: () => void) => void;
}

interface NavigatorWithConnection extends Navigator {
  connection?: NetworkConnection;
}

interface MobileOptimizerProps {
  children: React.ReactNode;
}

/**
 * This component applies mobile-specific optimizations once on mount
 * It handles various optimizations like:
 * - Detecting connection speed
 * - Applying lower image quality on slow connections
 * - Optimizing touch targets
 * - Managing hardware acceleration
 */
export function MobileOptimizer({ children }: MobileOptimizerProps) {
  const [isOptimized, setIsOptimized] = useState(false);

  useEffect(() => {
    // Only run once
    if (isOptimized) return;

    // Detect network connection type if supported
    if ('connection' in navigator) {
      const conn = (navigator as NavigatorWithConnection).connection;
      if (conn) {
        // Listen for connection changes
        const updateConnectionStatus = () => {
          applyNetworkBasedOptimizations(conn.effectiveType || 'unknown');
        };
        
        conn.addEventListener('change', updateConnectionStatus);
        
        // Apply initial optimizations
        applyNetworkBasedOptimizations(conn.effectiveType || 'unknown');
        
        return () => {
          conn.removeEventListener('change', updateConnectionStatus);
        };
      }
    } else {
      // If connection API not available, apply default optimizations
      applyNetworkBasedOptimizations('unknown');
    }
    
    // Apply device-specific optimizations
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
      applyMobileOptimizations();
    }
    
    setIsOptimized(true);
  }, [isOptimized]);

  /**
   * Apply optimizations based on network connection type
   */
  const applyNetworkBasedOptimizations = (connectionType: string) => {
    const html = document.documentElement;
    
    // Remove existing data attributes
    html.removeAttribute('data-connection');
    
    // Set new connection type attribute
    html.setAttribute('data-connection', connectionType);
    
    // For slow connections, apply aggressive optimizations
    if (connectionType === 'slow-2g' || connectionType === '2g') {
      html.setAttribute('data-save-data', 'true');
      
      // Add styles for low data mode
      const styleEl = document.createElement('style');
      styleEl.textContent = `
        /* Lower image quality on slow connections */
        img:not([data-high-priority]) {
          filter: blur(0) !important;
          transition: filter 0.5s ease-in-out !important;
        }
        
        /* Disable animations on slow connections */
        .animate-pulse, .animate-spin, .animate-bounce {
          animation: none !important;
        }
        
        /* Lazy load everything except above the fold */
        img {
          loading: lazy !important;
        }
        
        /* Use lighter background colors */
        .bg-gradient-to-br, .bg-gradient-to-tr {
          background: none !important;
          background-color: #f5f5f5 !important;
        }
      `;
      document.head.appendChild(styleEl);
    }
  };

  /**
   * Apply mobile-specific optimizations
   */
  const applyMobileOptimizations = () => {
    // Add touch-specific class to body
    document.body.classList.add('touch-device');
    
    // Apply viewport height fix for mobile browsers
    const setVhProperty = () => {
      const vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
    };
    
    window.addEventListener('resize', setVhProperty);
    setVhProperty();
    
    // Optimize scrolling by preventing document level touch actions
    document.body.style.touchAction = 'pan-y';
    
    // Apply acceleration to elements
    setTimeout(() => {
      const scrollContainers = document.querySelectorAll('.scroll-container, [data-scroll]');
      scrollContainers.forEach(el => {
        (el as HTMLElement).classList.add('touch-scrollable');
      });
    }, 200);
  };

  return <>{children}</>;
}

/**
 * Adaptive Image component for mobile-first loading
 * Automatically adjusts quality based on connection speed
 */
export function AdaptiveImage({ 
  src, 
  alt,
  width,
  height,
  className = '',
  priority = false
}: { 
  src: string;
  alt: string;
  width?: number;
  height?: number;
  className?: string;
  priority?: boolean;
}) {
  const [loaded, setLoaded] = useState(false);
  const [connection, setConnection] = useState<string>('unknown');
  
  useEffect(() => {
    // Get connection information from HTML attribute
    const connectionType = document.documentElement.getAttribute('data-connection') || 'unknown';
    setConnection(connectionType);
  }, []);
  
  // Determine if we should use low quality images
  const lowQuality = ['slow-2g', '2g', '3g'].includes(connection) && !priority;
  
  return (
    <div 
      className={`relative overflow-hidden ${className}`} 
      style={{ width: width ? `${width}px` : '100%', height: height ? `${height}px` : 'auto' }}
    >
      {!loaded && (
        <div 
          className="absolute inset-0 bg-gray-200 animate-pulse"
          aria-hidden="true"
        />
      )}
      
      <img
        src={src}
        alt={alt}
        width={width}
        height={height}
        onLoad={() => setLoaded(true)}
        className={`w-full h-full object-cover transition-opacity duration-300 ${loaded ? 'opacity-100' : 'opacity-0'}`}
        loading={priority ? 'eager' : 'lazy'}
        data-high-priority={priority ? 'true' : undefined}
        // Apply blur filter based on connection for initial load, then remove on load
        style={{ 
          filter: lowQuality && !loaded ? 'blur(10px)' : 'none',
          transform: 'translateZ(0)'
        }}
      />
    </div>
  );
}