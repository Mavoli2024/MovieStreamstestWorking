import {  Button  } from "@/components/ui/button";
import {  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter  } from "@/components/ui/dialog";
import {  Link  } from "wouter";

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AuthModal({ isOpen, onClose }: AuthModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="text-2xl">Join Madifa to Continue</DialogTitle>
          <DialogDescription>
            Sign in or create an account to watch our full library of Mzansi stories.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter className="flex-col sm:flex-row sm:justify-center gap-2">
          <Link to="/auth?view=sign_in">
            <Button className="w-full sm:w-auto bg-primary hover:bg-primary/90">Sign In</Button>
          </Link>
          <Link to="/auth?view=sign_up">
            <Button variant="secondary" className="w-full sm:w-auto">Sign Up Free</Button>
          </Link>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
