import { useState } from "react";
import {  Link  } from "wouter";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {  Button  } from "@/components/ui/button";
import {  
  User as UserIcon, 
  LogOut, 
  Settings,
  Crown,
  Lock
 } from "lucide-react";
import type {  User  } from "@shared/schema";
import type {  UseMutationResult  } from "@tanstack/react-query";

type ProfileDropdownMenuProps = {
  user: User | null;
  logoutMutation: UseMutationResult<void, Error, void>;
  hasPremiumAccess: boolean;
};

/**
 * Controlled dropdown menu for user profile to avoid infinite update loops
 */
export function ProfileDropdownMenu({ user, logoutMutation, hasPremiumAccess }: ProfileDropdownMenuProps) {
  const [isOpen, setIsOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
    setIsOpen(false);
  };

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          className="relative h-8 w-8 rounded-full overflow-hidden"
        >
          <div className="bg-primary flex items-center justify-center w-full h-full rounded-full">
            <UserIcon size={16} className="text-white" />
          </div>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <div className="flex items-center justify-start p-2">
          <div className="flex flex-col space-y-1">
            {user?.username && (
              <p className="text-sm font-medium">{user.username}</p>
            )}
            <p className="text-xs text-muted-foreground">
              {hasPremiumAccess ? 'Premium Account' : 'Free Account'}
            </p>
          </div>
        </div>
        <DropdownMenuSeparator />
        
        <DropdownMenuItem asChild>
          <Link href="/profile" className="cursor-pointer flex items-center">
            <UserIcon className="mr-2 h-4 w-4" />
            <span>Profile</span>
          </Link>
        </DropdownMenuItem>

        <DropdownMenuItem asChild>
          <Link href="/subscription" className="cursor-pointer flex items-center">
            {hasPremiumAccess ? (
              <>
                <Crown className="mr-2 h-4 w-4" />
                <span>Premium Plan</span>
              </>
            ) : (
              <>
                <Lock className="mr-2 h-4 w-4" />
                <span>Upgrade to Premium</span>
              </>
            )}
          </Link>
        </DropdownMenuItem>

        <DropdownMenuItem asChild>
          <Link href="/settings" className="cursor-pointer flex items-center">
            <Settings className="mr-2 h-4 w-4" />
            <span>Settings</span>
          </Link>
        </DropdownMenuItem>

        <DropdownMenuSeparator />
        
        <DropdownMenuItem 
          onClick={handleLogout}
          disabled={logoutMutation.isPending}
          className="cursor-pointer flex items-center"
        >
          <LogOut className="mr-2 h-4 w-4" />
          <span>{logoutMutation.isPending ? "Logging out..." : "Log out"}</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}