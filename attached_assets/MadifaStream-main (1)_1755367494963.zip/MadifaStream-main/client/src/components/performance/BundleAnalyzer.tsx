import { logger } from '@shared/logger';
/**
 * Bundle Analyzer Component
 * 
 * Development-only component for analyzing bundle performance
 * Shows chunk sizes, load times, and optimization suggestions
 */

import React, { useState, useEffect } from 'react';
import {  Card, CardContent, CardHeader, CardTitle  } from '@/components/ui/card';
import {  Button  } from '@/components/ui/button';
import {  Badge  } from '@/components/ui/badge';

interface BundleChunk {
  name: string;
  size: number;
  gzipSize?: number;
  loadTime?: number;
  type: 'vendor' | 'app' | 'page' | 'asset';
}

interface BundleStats {
  totalSize: number;
  totalGzipSize: number;
  chunks: BundleChunk[];
  suggestions: string[];
}

export const BundleAnalyzer: React.FC = () => {
  const [stats, setStats] = useState<BundleStats | null>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Only show in development
    if (import.meta.env.DEV) {
      analyzeBundle();
    }
  }, []);

  const analyzeBundle = async () => {
    try {
      // Get performance entries for resources
      const resourceEntries = performance.getEntriesByType('resource') as PerformanceResourceTiming[];
      
      const chunks: BundleChunk[] = resourceEntries
        .filter(entry => entry.name.includes('.js') || entry.name.includes('.css'))
        .map(entry => {
          const name = entry.name.split('/').pop() || 'unknown';
          const loadTime = entry.responseEnd - entry.requestStart;
          
          let type: BundleChunk['type'] = 'app';
          if (name.includes('vendor')) type = 'vendor';
          else if (name.includes('page') || name.includes('-page-')) type = 'page';
          else if (name.includes('.css') || name.includes('.png') || name.includes('.svg')) type = 'asset';
          
          return {
            name,
            size: entry.transferSize || 0,
            loadTime,
            type,
          };
        });

      const totalSize = chunks.reduce((sum, chunk) => sum + chunk.size, 0);
      
      const suggestions = generateSuggestions(chunks, totalSize);

      setStats({
        totalSize,
        totalGzipSize: totalSize * 0.3, // Estimate
        chunks: chunks.sort((a, b) => b.size - a.size),
        suggestions,
      });
    } catch (error) {
      logger.error('Bundle analysis failed:', { arg1: error });
    }
  };

  const generateSuggestions = (chunks: BundleChunk[], totalSize: number): string[] => {
    const suggestions: string[] = [];
    
    // Check for large chunks
    const largeChunks = chunks.filter(chunk => chunk.size > 500000); // 500KB
    if (largeChunks.length > 0) {
      suggestions.push(`Consider splitting large chunks: ${largeChunks.map(c => c.name).join(', ')}`);
    }
    
    // Check for slow loading resources
    const slowChunks = chunks.filter(chunk => (chunk.loadTime || 0) > 1000); // 1s
    if (slowChunks.length > 0) {
      suggestions.push(`Optimize slow-loading resources: ${slowChunks.map(c => c.name).join(', ')}`);
    }
    
    // Check total bundle size
    if (totalSize > 2000000) { // 2MB
      suggestions.push('Total bundle size is large. Consider implementing more aggressive code splitting.');
    }
    
    // Check for redundant vendor chunks
    const vendorChunks = chunks.filter(chunk => chunk.type === 'vendor');
    if (vendorChunks.length > 5) {
      suggestions.push('Consider consolidating vendor chunks to reduce HTTP requests.');
    }
    
    return suggestions;
  };

  const formatSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getChunkColor = (type: BundleChunk['type']): string => {
    switch (type) {
      case 'vendor': return 'bg-blue-500';
      case 'app': return 'bg-green-500';
      case 'page': return 'bg-yellow-500';
      case 'asset': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  if (!import.meta.env.DEV) {
    return null;
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {!isVisible ? (
        <Button
          onClick={() => setIsVisible(true)}
          variant="outline"
          size="sm"
          className="bg-background/95 backdrop-blur-sm"
        >
          📊 Bundle Stats
        </Button>
      ) : (
        <Card className="w-96 max-h-96 overflow-auto bg-background/95 backdrop-blur-sm">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">Bundle Analysis</CardTitle>
              <Button
                onClick={() => setIsVisible(false)}
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0"
              >
                ×
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-2">
            {stats ? (
              <>
                <div className="text-xs text-muted-foreground">
                  Total: {formatSize(stats.totalSize)} • Estimated Gzip: {formatSize(stats.totalGzipSize)}
                </div>
                
                <div className="space-y-1">
                  <div className="text-xs font-medium">Top Chunks:</div>
                  {stats.chunks.slice(0, 5).map((chunk, index) => (
                    <div key={index} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1">
                        <div className={`w-2 h-2 rounded-full ${getChunkColor(chunk.type)}`} />
                        <span className="truncate max-w-32" title={chunk.name}>
                          {chunk.name.length > 20 ? `${chunk.name.slice(0, 20)}...` : chunk.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span>{formatSize(chunk.size)}</span>
                        {chunk.loadTime && (
                          <Badge variant="secondary" className="text-xs px-1">
                            {chunk.loadTime.toFixed(0)}ms
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                
                {stats.suggestions.length > 0 && (
                  <div className="space-y-1">
                    <div className="text-xs font-medium text-orange-500">Suggestions:</div>
                    {stats.suggestions.slice(0, 2).map((suggestion, index) => (
                      <div key={index} className="text-xs text-muted-foreground p-1 bg-orange-50 rounded">
                        {suggestion.length > 60 ? `${suggestion.slice(0, 60)}...` : suggestion}
                      </div>
                    ))}
                  </div>
                )}
                
                <Button
                  onClick={analyzeBundle}
                  variant="outline"
                  size="sm"
                  className="w-full text-xs h-6"
                >
                  Refresh
                </Button>
              </>
            ) : (
              <div className="text-xs text-muted-foreground">Loading analysis...</div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}; 