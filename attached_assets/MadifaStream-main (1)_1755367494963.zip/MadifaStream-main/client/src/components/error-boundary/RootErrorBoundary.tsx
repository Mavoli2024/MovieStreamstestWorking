import React from 'react';
import ErrorBoundary from './ErrorBoundary';
import {  AlertTriangle, Home, RefreshCw  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';
import {  Link  } from 'wouter';
import { logger } from '@shared/logger';

interface RootErrorBoundaryProps {
  children: React.ReactNode;
}

/**
 * Root-level error boundary that catches unhandled errors
 * across the entire application
 */
export function RootErrorBoundary({ children }: RootErrorBoundaryProps) {
  const handleReset = () => {
    // Force a complete refresh of the application
    window.location.href = '/';
  };
  
  const fallback = (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md bg-card p-8 rounded-lg shadow-lg space-y-6 text-center">
        <div className="w-16 h-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
          <AlertTriangle className="h-8 w-8 text-destructive" />
        </div>
        
        <div>
          <h1 className="text-2xl font-bold mb-2">Something went wrong</h1>
          <p className="text-muted-foreground mb-8">
            We've encountered an unexpected error. Please try refreshing the page or return to the homepage.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button variant="default" onClick={handleReset} className="flex items-center">
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh application
            </Button>
            
            <Button variant="outline" asChild>
              <Link href="/" onClick={() => window.location.href = '/'}>
                <Home className="mr-2 h-4 w-4" />
                Return to home
              </Link>
            </Button>
          </div>
        </div>
        
        <div className="text-xs text-muted-foreground pt-4 border-t border-border">
          If this issue persists, please contact support or try again later.
        </div>
      </div>
    </div>
  );

  return (
    <ErrorBoundary
      fallback={fallback}
      onError={(error, errorInfo) => {
        // Log to console in development
        logger.error('Application crash:', { arg1: error });
        logger.error('Component stack:', { arg1: errorInfo.componentStack });
        
        // In a production app, you would send this to an error tracking service
        // like Sentry, LogRocket, etc.
      }}
    >
      {children}
    </ErrorBoundary>
  );
}