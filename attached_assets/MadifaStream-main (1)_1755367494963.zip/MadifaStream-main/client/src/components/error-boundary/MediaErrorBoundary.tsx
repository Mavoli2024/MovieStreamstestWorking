import React from 'react';
import ErrorBoundary from './ErrorBoundary';
import {  FileVideo, RefreshCw  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';
import { logger } from '@shared/logger';

interface MediaErrorBoundaryProps {
  children: React.ReactNode;
  onReset?: () => void;
  mediaType?: 'video' | 'image' | 'audio';
  title?: string;
}

/**
 * Specialized error boundary for media components (video, images)
 * Provides a media-specific UI and helpful error messages
 */
export function MediaErrorBoundary({
  children,
  onReset,
  mediaType = 'video',
  title
}: MediaErrorBoundaryProps) {
  const mediaTitle = title || (mediaType === 'video' ? 'Video' : mediaType === 'image' ? 'Image' : 'Audio');
  
  const fallback = (
    <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-muted text-muted-foreground min-h-[200px] space-y-4">
      <FileVideo className="h-12 w-12 text-primary/60" />
      <div className="text-center">
        <h3 className="text-base font-medium mb-2">{mediaTitle} playback error</h3>
        <p className="text-sm mb-4">
          There was a problem playing this content. This could be due to network issues or content unavailability.
        </p>
        <Button 
          size="sm"
          variant="outline" 
          onClick={onReset}
          className="flex items-center"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Retry
        </Button>
      </div>
    </div>
  );

  return (
    <ErrorBoundary 
      fallback={fallback}
      onReset={onReset}
      onError={(error) => {
        logger.error(`Media error (${mediaType}):`, { arg1: error.message });
      }}
    >
      {children}
    </ErrorBoundary>
  );
}