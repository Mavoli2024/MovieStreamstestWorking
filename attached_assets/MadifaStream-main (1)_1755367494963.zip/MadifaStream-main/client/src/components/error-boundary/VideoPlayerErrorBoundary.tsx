import React from 'react';
import ErrorBoundary from './ErrorBoundary';
import {  AlertCircle, RefreshCw, Tv2  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';
import { logger } from '@shared/logger';

interface VideoPlayerErrorBoundaryProps {
  children: React.ReactNode;
  onReset?: () => void;
  videoTitle?: string;
  onBack?: () => void;
}

/**
 * Specialized error boundary for video player components
 * Provides a video-specific UI and retry mechanisms
 * 
 * CRITICAL COMPONENT: Video playback is core functionality and failures
 * here can frustrate users and lead to subscription cancellations
 */
export function VideoPlayerErrorBoundary({
  children,
  onReset,
  videoTitle = 'Video',
  onBack
}: VideoPlayerErrorBoundaryProps) {
  
  const handleReset = () => {
    if (onReset) {
      onReset();
    }
  };
  
  const handleBack = () => {
    if (onBack) {
      onBack();
    }
  };
  
  const fallback = (
    <div className="flex flex-col items-center justify-center p-8 bg-black text-white h-full w-full min-h-[300px]">
      <div className="max-w-md text-center">
        <Tv2 className="h-16 w-16 mb-4 mx-auto text-primary/70" />
        
        <h3 className="text-xl font-semibold mb-2">Video Playback Error</h3>
        <p className="text-white/70 mb-6">
          We're having trouble playing "{videoTitle}". This could be due to a temporary network issue, 
          insufficient bandwidth, or a problem with the video file.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button 
            variant="default" 
            onClick={handleReset}
            className="bg-primary hover:bg-primary/90"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Try again
          </Button>
          
          {onBack && (
            <Button 
              variant="outline" 
              onClick={handleBack}
              className="border-white/20 hover:bg-white/10"
            >
              Go back
            </Button>
          )}
        </div>
        
        <div className="mt-6 pt-4 border-t border-white/10 text-xs text-white/50 flex items-center justify-center">
          <AlertCircle className="h-3 w-3 mr-1" />
          If this issue persists, try using a different device or connection
        </div>
      </div>
    </div>
  );

  return (
    <ErrorBoundary
      fallback={fallback}
      onReset={handleReset}
      onError={(error) => {
        logger.error(`Video player error for "${videoTitle}":`, { arg1: error.message });
        // In production, you would log this error to an analytics service
        // with the video details to track content issues
      }}
    >
      {children}
    </ErrorBoundary>
  );
}