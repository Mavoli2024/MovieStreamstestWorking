import React, { Component, ErrorInfo, ReactNode } from 'react';
import {  AlertTriangle, RefreshCw, Home, ArrowLeft, Bug  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';
import {  Card, CardContent, CardHeader, CardTitle  } from '@/components/ui/card';
import {  Alert, AlertDescription  } from '@/components/ui/alert';
import { logger } from '@shared/logger';

// =============================================================================
// TYPES & INTERFACES
// =============================================================================

export interface ErrorBoundaryConfig {
  // Error categorization
  errorType?: 'payment' | 'video' | 'form' | 'data' | 'media' | 'network' | 'generic';
  
  // Display configuration
  showErrorDetails?: boolean;
  showReportButton?: boolean;
  allowRetry?: boolean;
  showFallbackContent?: boolean;
  
  // Custom content
  title?: string;
  description?: string;
  fallbackComponent?: ReactNode;
  
  // Actions
  onRetry?: () => void;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
  onReport?: (error: Error, errorInfo: ErrorInfo) => void;
  
  // Styling
  className?: string;
  variant?: 'minimal' | 'detailed' | 'card';
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
  retryCount: number;
  isReporting: boolean;
}

interface ErrorBoundaryProps extends ErrorBoundaryConfig {
  children: ReactNode;
  resetKeys?: Array<string | number>;
  resetOnPropsChange?: boolean;
}

// =============================================================================
// ERROR TYPE CONFIGURATIONS
// =============================================================================

const ERROR_TYPE_CONFIG: Record<string, Partial<ErrorBoundaryConfig>> = {
  payment: {
    title: 'Payment Error',
    description: 'There was an issue processing your payment. Please try again or contact support.',
    showReportButton: true,
    allowRetry: true,
  },
  video: {
    title: 'Video Playback Error',
    description: 'Unable to load or play the video content. This might be a temporary issue.',
    allowRetry: true,
    showFallbackContent: true,
  },
  form: {
    title: 'Form Error',
    description: 'There was an error submitting your form. Please check your input and try again.',
    allowRetry: true,
    showErrorDetails: false,
  },
  data: {
    title: 'Data Loading Error',
    description: 'Failed to load the requested data. Please refresh the page or try again later.',
    allowRetry: true,
  },
  media: {
    title: 'Media Error',
    description: 'Unable to load media content. Please check your connection and try again.',
    allowRetry: true,
  },
  network: {
    title: 'Network Error',
    description: 'Connection issue detected. Please check your internet connection and try again.',
    allowRetry: true,
  },
  generic: {
    title: 'Something went wrong',
    description: 'An unexpected error occurred. Please try again or contact support if the problem persists.',
    allowRetry: true,
    showReportButton: true,
  },
};

// =============================================================================
// UNIFIED ERROR BOUNDARY COMPONENT
// =============================================================================

export class UnifiedErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  private retryTimeoutId: NodeJS.Timeout | null = null;
  private resetTimeoutId: NodeJS.Timeout | null = null;

  constructor(props: ErrorBoundaryProps) {
    super(props);

    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      retryCount: 0,
      isReporting: false,
    };
  }

  static getDerivedStateFromError(error: Error): Partial<ErrorBoundaryState> {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log error details
    logger.error('Error Boundary caught an error:', {
      error: error.message,
      stack: error.stack,
      componentStack: errorInfo.componentStack,
      errorType: this.props.errorType || 'generic',
    });

    // Update state with error info
    this.setState({
      errorInfo,
    });

    // Call custom error handler
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Auto-report critical errors
    if (this.shouldAutoReport(error)) {
      this.reportError(error, errorInfo);
    }
  }

  componentDidUpdate(prevProps: ErrorBoundaryProps) {
    const { resetKeys, resetOnPropsChange } = this.props;
    const { hasError } = this.state;

    // Reset error state when reset keys change
    if (hasError && resetKeys && prevProps.resetKeys) {
      const hasResetKeyChanged = resetKeys.some(
        (key, index) => key !== prevProps.resetKeys![index]
      );

      if (hasResetKeyChanged) {
        this.resetErrorBoundary();
      }
    }

    // Reset on props change
    if (hasError && resetOnPropsChange && prevProps !== this.props) {
      this.resetErrorBoundary();
    }
  }

  componentWillUnmount() {
    if (this.retryTimeoutId) {
      clearTimeout(this.retryTimeoutId);
    }
    if (this.resetTimeoutId) {
      clearTimeout(this.resetTimeoutId);
    }
  }

  shouldAutoReport = (error: Error): boolean => {
    // Auto-report certain types of errors
    const autoReportErrors = [
      'ChunkLoadError',
      'TypeError',
      'ReferenceError',
      'RangeError',
    ];

    return autoReportErrors.some(errorType => 
      error.name === errorType || error.message.includes(errorType)
    );
  };

  resetErrorBoundary = () => {
    if (this.resetTimeoutId) {
      clearTimeout(this.resetTimeoutId);
    }

    this.resetTimeoutId = setTimeout(() => {
      this.setState({
        hasError: false,
        error: null,
        errorInfo: null,
        retryCount: 0,
        isReporting: false,
      });
    }, 100);
  };

  handleRetry = () => {
    const { onRetry } = this.props;
    const { retryCount } = this.state;

    // Limit retry attempts
    if (retryCount >= 3) {
      logger.warn('Maximum retry attempts reached');
      return;
    }

    // Update retry count
    this.setState(prevState => ({
      retryCount: prevState.retryCount + 1,
    }));

    // Call custom retry handler
    if (onRetry) {
      onRetry();
    }

    // Auto-retry after a delay
    if (this.retryTimeoutId) {
      clearTimeout(this.retryTimeoutId);
    }

    this.retryTimeoutId = setTimeout(() => {
      this.resetErrorBoundary();
    }, 1000);
  };

  reportError = async (error: Error, errorInfo: ErrorInfo) => {
    const { onReport } = this.props;

    this.setState({ isReporting: true });

    try {
      // Call custom report handler
      if (onReport) {
        await onReport(error, errorInfo);
      } else {
        // Default error reporting logic
        logger.error('Error reported to monitoring service:', {
          error: error.message,
          stack: error.stack,
          componentStack: errorInfo.componentStack,
          userAgent: navigator.userAgent,
          url: window.location.href,
          timestamp: new Date().toISOString(),
        });
      }
    } catch (reportError) {
      logger.error('Failed to report error:', reportError);
    } finally {
      this.setState({ isReporting: false });
    }
  };

  getConfig = (): ErrorBoundaryConfig => {
    const { errorType = 'generic', ...customConfig } = this.props;
    const typeConfig = ERROR_TYPE_CONFIG[errorType] || ERROR_TYPE_CONFIG.generic;
    
    return {
      ...typeConfig,
      ...customConfig,
      errorType,
    };
  };

  renderErrorContent = () => {
    const { hasError, error, errorInfo, retryCount, isReporting } = this.state;
    const config = this.getConfig();

    if (!hasError || !error) return null;

    const {
      title,
      description,
      showErrorDetails,
      showReportButton,
      allowRetry,
      variant = 'detailed',
      className,
    } = config;

    // Minimal variant
    if (variant === 'minimal') {
      return (
        <Alert className={className}>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {description || 'An error occurred. Please try again.'}
            {allowRetry && (
              <Button
                variant="link"
                size="sm"
                onClick={this.handleRetry}
                className="ml-2 p-0 h-auto"
                disabled={retryCount >= 3}
              >
                Try again
              </Button>
            )}
          </AlertDescription>
        </Alert>
      );
    }

    // Card variant
    if (variant === 'card') {
      return (
        <Card className={className}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              {title}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">{description}</p>
            
            {showErrorDetails && (
              <details className="text-sm">
                <summary className="cursor-pointer font-medium">
                  Technical Details
                </summary>
                <pre className="mt-2 p-3 bg-muted rounded text-xs overflow-auto">
                  {error.message}
                  {import.meta.env.DEV && error.stack}
                </pre>
              </details>
            )}
            
            <div className="flex gap-2">
              {allowRetry && (
                <Button
                  onClick={this.handleRetry}
                  disabled={retryCount >= 3}
                  variant="outline"
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  {retryCount > 0 ? `Retry (${retryCount}/3)` : 'Try Again'}
                </Button>
              )}
              
              {showReportButton && (
                <Button
                  onClick={() => this.reportError(error, errorInfo!)}
                  disabled={isReporting}
                  variant="outline"
                >
                  <Bug className="h-4 w-4 mr-2" />
                  {isReporting ? 'Reporting...' : 'Report Issue'}
                </Button>
              )}
              
              <Button
                onClick={() => window.location.reload()}
                variant="outline"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Reload Page
              </Button>
              
              <Button
                onClick={() => window.history.back()}
                variant="ghost"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Go Back
              </Button>
            </div>
          </CardContent>
        </Card>
      );
    }

    // Detailed variant (default)
    return (
      <div className={`min-h-[400px] flex items-center justify-center p-4 ${className}`}>
        <div className="text-center space-y-6 max-w-md">
          <div className="text-6xl">⚠️</div>
          
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-foreground">{title}</h2>
            <p className="text-muted-foreground">{description}</p>
          </div>
          
          {showErrorDetails && import.meta.env.DEV && (
            <details className="text-left">
              <summary className="cursor-pointer text-sm font-medium">
                Error Details (Development)
              </summary>
              <pre className="mt-2 p-3 bg-muted rounded text-xs overflow-auto text-left">
                {error.message}
                {error.stack}
                {errorInfo?.componentStack}
              </pre>
            </details>
          )}
          
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            {allowRetry && (
              <Button
                onClick={this.handleRetry}
                disabled={retryCount >= 3}
                className="min-w-[120px]"
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                {retryCount > 0 ? `Retry (${retryCount}/3)` : 'Try Again'}
              </Button>
            )}
            
            <Button
              onClick={() => window.location.href = '/'}
              variant="outline"
            >
              <Home className="h-4 w-4 mr-2" />
              Go Home
            </Button>
            
            {showReportButton && (
              <Button
                onClick={() => this.reportError(error, errorInfo!)}
                disabled={isReporting}
                variant="ghost"
                size="sm"
              >
                <Bug className="h-4 w-4 mr-2" />
                {isReporting ? 'Reporting...' : 'Report'}
              </Button>
            )}
          </div>
        </div>
      </div>
    );
  };

  render() {
    const { hasError } = this.state;
    const { children, fallbackComponent, showFallbackContent } = this.props;

    if (hasError) {
      // Show custom fallback component if provided
      if (fallbackComponent) {
        return fallbackComponent;
      }

      // Show fallback content for specific error types
      if (showFallbackContent) {
        return (
          <div className="space-y-4">
            {this.renderErrorContent()}
            <div className="opacity-50 pointer-events-none">
              {children}
            </div>
          </div>
        );
      }

      // Show error UI
      return this.renderErrorContent();
    }

    return children;
  }
}

// =============================================================================
// CONVENIENCE EXPORTS
// =============================================================================

// Pre-configured error boundaries for common use cases
export const PaymentErrorBoundary = (props: Omit<ErrorBoundaryProps, 'errorType'>) => (
  <UnifiedErrorBoundary {...props} errorType="payment" />
);

export const VideoErrorBoundary = (props: Omit<ErrorBoundaryProps, 'errorType'>) => (
  <UnifiedErrorBoundary {...props} errorType="video" />
);

export const FormErrorBoundary = (props: Omit<ErrorBoundaryProps, 'errorType'>) => (
  <UnifiedErrorBoundary {...props} errorType="form" variant="card" />
);

export const DataErrorBoundary = (props: Omit<ErrorBoundaryProps, 'errorType'>) => (
  <UnifiedErrorBoundary {...props} errorType="data" />
);

export const MediaErrorBoundary = (props: Omit<ErrorBoundaryProps, 'errorType'>) => (
  <UnifiedErrorBoundary {...props} errorType="media" />
);

export const NetworkErrorBoundary = (props: Omit<ErrorBoundaryProps, 'errorType'>) => (
  <UnifiedErrorBoundary {...props} errorType="network" />
);

// Hook for programmatic error boundary control
export const useErrorBoundary = () => {
  const [, setState] = React.useState();
  
  return React.useCallback((error: Error) => {
    setState(() => {
      throw error;
    });
  }, []);
}; 