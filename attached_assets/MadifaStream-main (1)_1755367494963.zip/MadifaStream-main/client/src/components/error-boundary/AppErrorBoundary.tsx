/**
 * App Error Boundary
 * 
 * Production-grade error boundary with:
 * - Smart error recovery strategies
 * - User-friendly error messages
 * - Error reporting to analytics
 * - Automatic retry mechanisms
 */

import React, { Component, ReactNode } from 'react';
import { AlertCircle, RefreshCw, Home, Bug } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { logger } from '@shared/logger';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: React.ErrorInfo | null;
  errorCount: number;
  lastErrorTime: number;
}

export class AppErrorBoundary extends Component<Props, State> {
  private retryTimeouts: NodeJS.Timeout[] = [];

  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null,
      errorCount: 0,
      lastErrorTime: 0,
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    const now = Date.now();
    const { errorCount, lastErrorTime } = this.state;
    
    // Track error frequency
    const isRepeatedError = now - lastErrorTime < 5000;
    const newErrorCount = isRepeatedError ? errorCount + 1 : 1;

    this.setState({
      errorInfo,
      errorCount: newErrorCount,
      lastErrorTime: now,
    });

    // Log error
    logger.error('App Error Boundary caught error:', {
      error: error.toString(),
      componentStack: errorInfo.componentStack,
      errorCount: newErrorCount,
    });

    // Call custom error handler
    this.props.onError?.(error, errorInfo);

    // Report to analytics in production
    if (import.meta.env.PROD) {
      this.reportError(error, errorInfo);
    }

    // Auto-retry for certain errors
    if (this.shouldAutoRetry(error) && newErrorCount < 3) {
      this.scheduleAutoRetry();
    }
  }

  componentWillUnmount() {
    // Clear any pending timeouts
    this.retryTimeouts.forEach(timeout => clearTimeout(timeout));
  }

  private reportError(error: Error, errorInfo: React.ErrorInfo) {
    // Send to error tracking service
    try {
      fetch('/api/errors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: error.message,
          stack: error.stack,
          componentStack: errorInfo.componentStack,
          userAgent: navigator.userAgent,
          timestamp: new Date().toISOString(),
          url: window.location.href,
        }),
      }).catch(() => {
        // Fail silently
      });
    } catch (e) {
      // Fail silently
    }
  }

  private shouldAutoRetry(error: Error): boolean {
    const retryablePatterns = [
      'ChunkLoadError',
      'Loading chunk',
      'Failed to fetch',
      'NetworkError',
      'Load failed',
    ];

    return retryablePatterns.some(pattern => 
      error.message.includes(pattern) || error.name.includes(pattern)
    );
  }

  private scheduleAutoRetry() {
    const timeout = setTimeout(() => {
      this.handleReset();
    }, 2000);

    this.retryTimeouts.push(timeout);
  }

  private handleReset = () => {
    this.setState({
      hasError: false,
      error: null,
      errorInfo: null,
    });
  };

  private handleReload = () => {
    window.location.reload();
  };

  private handleGoHome = () => {
    window.location.href = '/';
  };

  private getErrorType(error: Error): string {
    if (error.message.includes('ChunkLoadError') || error.message.includes('Loading chunk')) {
      return 'chunk';
    }
    if (error.message.includes('Network') || error.message.includes('fetch')) {
      return 'network';
    }
    if (error.message.includes('Permission') || error.message.includes('401')) {
      return 'auth';
    }
    return 'unknown';
  }

  private renderError() {
    const { error, errorInfo, errorCount } = this.state;
    const errorType = error ? this.getErrorType(error) : 'unknown';

    // Custom fallback
    if (this.props.fallback) {
      return this.props.fallback;
    }

    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="max-w-lg w-full">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 p-3 bg-destructive/10 rounded-full w-fit">
              <AlertCircle className="h-8 w-8 text-destructive" />
            </div>
            <CardTitle className="text-2xl">
              {errorType === 'chunk' && 'Update Required'}
              {errorType === 'network' && 'Connection Problem'}
              {errorType === 'auth' && 'Authentication Error'}
              {errorType === 'unknown' && 'Something went wrong'}
            </CardTitle>
            <CardDescription className="text-base mt-2">
              {errorType === 'chunk' && 'A new version is available. Please refresh to update.'}
              {errorType === 'network' && 'Please check your internet connection and try again.'}
              {errorType === 'auth' && 'Your session has expired. Please sign in again.'}
              {errorType === 'unknown' && 'An unexpected error occurred. Please try again.'}
            </CardDescription>
          </CardHeader>

          <CardContent className="space-y-4">
            {/* Error details in dev mode */}
            {import.meta.env.DEV && error && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm font-mono text-muted-foreground break-all">
                  {error.toString()}
                </p>
                {errorInfo && (
                  <details className="mt-2">
                    <summary className="cursor-pointer text-sm text-muted-foreground hover:text-foreground">
                      Component Stack
                    </summary>
                    <pre className="mt-2 text-xs overflow-auto max-h-40">
                      {errorInfo.componentStack}
                    </pre>
                  </details>
                )}
              </div>
            )}

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              {errorType === 'chunk' && (
                <Button 
                  onClick={this.handleReload} 
                  className="flex-1"
                  variant="default"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Refresh Page
                </Button>
              )}

              {errorType === 'network' && (
                <>
                  <Button 
                    onClick={this.handleReset} 
                    className="flex-1"
                    variant="default"
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Try Again
                  </Button>
                  <Button 
                    onClick={this.handleReload} 
                    variant="outline"
                    className="flex-1"
                  >
                    Reload Page
                  </Button>
                </>
              )}

              {errorType === 'auth' && (
                <Button 
                  onClick={() => window.location.href = '/auth'} 
                  className="flex-1"
                  variant="default"
                >
                  Sign In
                </Button>
              )}

              {errorType === 'unknown' && (
                <>
                  <Button 
                    onClick={this.handleReset} 
                    className="flex-1"
                    variant="default"
                    disabled={errorCount >= 3}
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Try Again {errorCount >= 3 && '(Max attempts reached)'}
                  </Button>
                  <Button 
                    onClick={this.handleGoHome} 
                    variant="outline"
                    className="flex-1"
                  >
                    <Home className="mr-2 h-4 w-4" />
                    Go Home
                  </Button>
                </>
              )}
            </div>

            {/* Error count warning */}
            {errorCount >= 2 && (
              <p className="text-sm text-muted-foreground text-center">
                This error has occurred {errorCount} times. 
                {errorCount >= 3 && ' Please contact support if the issue persists.'}
              </p>
            )}

            {/* Report bug link */}
            {import.meta.env.PROD && (
              <div className="text-center pt-2">
                <Button
                  variant="link"
                  size="sm"
                  className="text-muted-foreground"
                  onClick={() => {
                    // Open bug report form or email
                    window.open('mailto:support@madifa.co.za?subject=Bug Report', '_blank');
                  }}
                >
                  <Bug className="mr-1 h-3 w-3" />
                  Report this issue
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  render() {
    if (this.state.hasError) {
      return this.renderError();
    }

    return this.props.children;
  }
} 