import React from 'react';
import ErrorBoundary from './ErrorBoundary';
import {  ServerCrash, RefreshCw, AlertCircle  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';
import { logger } from '@shared/logger';

interface DataErrorBoundaryProps {
  children: React.ReactNode;
  onReset?: () => void;
  resourceName?: string;
  showDetails?: boolean;
}

/**
 * Specialized error boundary for data fetching components
 * Provides a friendlier UI for API/data errors
 */
export function DataErrorBoundary({
  children,
  onReset,
  resourceName = 'data',
  showDetails = true
}: DataErrorBoundaryProps) {
  
  const fallback = (error: Error, componentStack?: string) => (
    <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-muted/50 border border-muted min-h-[120px] space-y-3">
      <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
        <ServerCrash className="h-5 w-5 text-muted-foreground" />
      </div>
      <div className="text-center">
        <h3 className="text-base font-medium mb-1">Unable to load {resourceName}</h3>
        <p className="text-sm text-muted-foreground mb-3">
          There was a problem retrieving the requested information
        </p>
        
        {showDetails && error && (
          <div className="bg-muted/80 p-2 rounded mb-3 max-w-sm mx-auto">
            <div className="flex items-start text-xs text-left">
              <AlertCircle className="h-3 w-3 mr-1 mt-0.5 flex-shrink-0" />
              <span>{error.message || 'Unknown error'}</span>
            </div>
          </div>
        )}
        
        <Button
          size="sm"
          variant="outline"
          onClick={onReset}
          className="flex items-center text-xs"
        >
          <RefreshCw className="h-3 w-3 mr-1" />
          Try again
        </Button>
      </div>
    </div>
  );

  return (
    <ErrorBoundary
      onReset={onReset}
      onError={(error) => {
        logger.error(`Data error (${resourceName}):`, { arg1: error.message });
      }}
      fallback={(
        <>{fallback(new Error("An error occurred while fetching data"))}</>
      )}
    >
      {children}
    </ErrorBoundary>
  );
}