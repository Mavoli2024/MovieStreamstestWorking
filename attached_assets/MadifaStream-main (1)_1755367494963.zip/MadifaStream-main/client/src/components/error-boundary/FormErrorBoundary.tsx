import { logger } from '@shared/logger';
/**
 * Form Error Boundary Component
 * 
 * A specialized error boundary for handling form-related errors,
 * including validation errors, submission failures, and API issues.
 */

import React from 'react';
import ErrorBoundary from './ErrorBoundary';
import {  AlertTriangle, RefreshCw, XCircle  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';

interface FormErrorBoundaryProps {
  children: React.ReactNode;
  onReset?: () => void;
  formName?: string;
  showRetry?: boolean;
}

/**
 * Form Error Boundary component for handling errors in form components
 * 
 * @param children The form components to wrap
 * @param onReset Optional callback to execute when user resets the form
 * @param formName Optional name of the form for error messages
 * @param showRetry Whether to show the retry button
 */
export default function FormErrorBoundary({
  children,
  onReset,
  formName = 'form',
  showRetry = true
}: FormErrorBoundaryProps) {
  const formTitle = formName.charAt(0).toUpperCase() + formName.slice(1);
  
  const fallback = (
    <div className="flex flex-col items-center justify-center p-4 rounded-lg bg-destructive/10 text-destructive border border-destructive/20 space-y-4 my-4">
      <XCircle className="h-8 w-8" />
      <div className="text-center">
        <h3 className="text-base font-medium mb-2">{formTitle} submission error</h3>
        <p className="text-sm mb-4">
          There was a problem submitting this form. Please try again or contact support if the issue persists.
        </p>
        {showRetry && (
          <Button 
            size="sm"
            variant="outline" 
            onClick={onReset}
            className="border-destructive hover:bg-destructive/10 hover:text-destructive"
          >
            <RefreshCw className="h-4 w-4 mr-2" />
            Try again
          </Button>
        )}
      </div>
    </div>
  );

  return (
    <ErrorBoundary 
      fallback={fallback}
      onReset={onReset}
      onError={(error) => {
        // Log form errors for debugging
        logger.error(`Form error (${formName}):`, { arg1: error.message });
      }}
    >
      {children}
    </ErrorBoundary>
  );
}

/**
 * API Error component that can be shown when form submission fails due to API errors
 */
export function FormApiError({ 
  message, 
  onRetry,
  showRetry = true
}: { 
  message: string; 
  onRetry?: () => void;
  showRetry?: boolean;
}) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-md bg-destructive/10 text-destructive border border-destructive/20 my-2">
      <AlertTriangle className="h-5 w-5 flex-shrink-0 mt-0.5" />
      <div className="flex-1">
        <p className="text-sm font-medium">{message}</p>
        <p className="text-xs mt-1 text-destructive/80">
          There was an error communicating with the server. Please try again or check your connection.
        </p>
        {showRetry && onRetry && (
          <Button 
            size="sm" 
            variant="ghost" 
            onClick={onRetry} 
            className="mt-2 h-7 px-2 text-xs hover:bg-destructive/10"
          >
            <RefreshCw className="h-3 w-3 mr-1" />
            Retry
          </Button>
        )}
      </div>
    </div>
  );
}

/**
 * Validation Error component for displaying form validation errors
 */
export function FormValidationError({ 
  errors,
  title = "Please check your information"
}: { 
  errors: string[]; 
  title?: string;
}) {
  if (!errors.length) return null;
  
  return (
    <div className="p-3 rounded-md bg-destructive/10 text-destructive border border-destructive/20 my-2">
      <h4 className="text-sm font-medium flex items-center gap-2">
        <AlertTriangle className="h-4 w-4" />
        {title}
      </h4>
      <ul className="mt-2 text-xs space-y-1 list-disc list-inside">
        {errors.map((error, i) => (
          <li key={i}>{error}</li>
        ))}
      </ul>
    </div>
  );
}