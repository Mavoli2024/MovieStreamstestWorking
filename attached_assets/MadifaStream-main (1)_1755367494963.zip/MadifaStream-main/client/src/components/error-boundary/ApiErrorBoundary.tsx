import React, { Component, ReactNode } from 'react';
import * as Sentry from '@sentry/react';
import { Button } from '@/components/ui/button';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onRetry?: () => void;
}

interface State {
  hasError: boolean;
  error?: Error;
  retryCount: number;
}

export class ApiErrorBoundary extends Component<Props, State> {
  private maxRetries = 3;

  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, retryCount: 0 };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, retryCount: 0 };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    // Check if this is an API-related error
    const isApiError = error.message.includes('fetch') || 
                      error.message.includes('API') ||
                      error.message.includes('network') ||
                      error.message.includes('timeout');

    if (isApiError) {
      Sentry.withScope(scope => {
        scope.setTag('error.type', 'api');
        scope.setTag('error.boundary', 'api');
        scope.setLevel('error');
        scope.setContext('errorInfo', {
          componentStack: errorInfo.componentStack,
          retryCount: this.state.retryCount,
        });
        
        // Add API-specific context
        if (error.message.includes('fetch')) {
          scope.setTag('error.api.type', 'fetch');
        }
        if (error.message.includes('timeout')) {
          scope.setTag('error.api.type', 'timeout');
        }
        
        Sentry.captureException(error);
      });
    }
  }

  handleRetry = () => {
    if (this.state.retryCount < this.maxRetries) {
      this.setState(prevState => ({
        hasError: false,
        error: undefined,
        retryCount: prevState.retryCount + 1,
      }));
      
      // Call custom retry function if provided
      this.props.onRetry?.();
    }
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="flex flex-col items-center justify-center p-8 text-center">
          <AlertTriangle className="h-12 w-12 text-red-500 mb-4" />
          <h2 className="text-xl font-semibold mb-2">API Error</h2>
          <p className="text-muted-foreground mb-4 max-w-md">
            We're having trouble connecting to our servers. Please check your internet connection and try again.
          </p>
          
          {this.state.retryCount < this.maxRetries && (
            <Button
              onClick={this.handleRetry}
              className="mb-2"
              variant="outline"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Retry ({this.maxRetries - this.state.retryCount} attempts left)
            </Button>
          )}
          
          <Button
            onClick={() => window.location.reload()}
            variant="default"
          >
            Reload Page
          </Button>
          
          {import.meta.env.DEV && this.state.error && (
            <details className="mt-4 text-left">
              <summary className="cursor-pointer text-sm text-muted-foreground">
                Error Details (Development Only)
              </summary>
              <pre className="mt-2 text-xs bg-gray-100 p-2 rounded overflow-auto">
                {this.state.error.stack}
              </pre>
            </details>
          )}
        </div>
      );
    }

    return this.props.children;
  }
} 