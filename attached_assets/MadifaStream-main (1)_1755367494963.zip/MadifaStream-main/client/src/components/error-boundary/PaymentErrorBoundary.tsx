import React from 'react';
import ErrorBoundary from './ErrorBoundary';
import {  CreditCard, AlertCircle, RefreshCw, ArrowLeft  } from 'lucide-react';
import {  Button  } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { logger } from '@shared/logger';

interface PaymentErrorBoundaryProps {
  children: React.ReactNode;
  onReset?: () => void;
  planName?: string;
}

/**
 * Specialized error boundary for payment processing components
 * Provides user-friendly error recovery options for payment flows
 * 
 * CRITICAL COMPONENT: Payment processing directly impacts revenue and
 * errors here can cause abandoned purchases and customer service issues
 */
export function PaymentErrorBoundary({
  children,
  onReset,
  planName = 'subscription'
}: PaymentErrorBoundaryProps) {
  const [, navigate] = useLocation();
  
  const handleReset = () => {
    if (onReset) {
      onReset();
    }
  };
  
  const handleBackToPlans = () => {
    navigate('/subscription');
  };
  
  const fallback = (
    <div className="p-6 rounded-lg border border-destructive/20 bg-destructive/5 max-w-md mx-auto my-8">
      <div className="text-center">
        <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mx-auto mb-4">
          <CreditCard className="h-6 w-6 text-destructive" />
        </div>
        
        <h3 className="text-lg font-medium mb-2">Payment Processing Error</h3>
        <p className="text-muted-foreground mb-6">
          We encountered an issue while processing your payment for the {planName} plan. 
          Your payment has not been processed and you have not been charged.
        </p>
        
        <div className="space-y-3">
          <Button 
            variant="default" 
            onClick={handleReset}
            className="w-full"
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Try again
          </Button>
          
          <Button 
            variant="outline" 
            onClick={handleBackToPlans}
            className="w-full"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to subscription plans
          </Button>
        </div>
        
        <div className="mt-6 pt-4 border-t border-border text-xs text-muted-foreground flex items-start">
          <AlertCircle className="h-3 w-3 mr-1 mt-0.5 flex-shrink-0" />
          <span>
            If this issue persists, please try a different payment method or contact our support team.
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <ErrorBoundary
      fallback={fallback}
      onReset={handleReset}
      onError={(error) => {
        // Log payment errors with detailed context
        logger.payment(`Payment processing error for ${planName}:`, { arg1: error.message });
        
        // In production, you would track payment errors in a monitoring system
        // with the plan details and error type, but never include payment details
      }}
    >
      {children}
    </ErrorBoundary>
  );
}