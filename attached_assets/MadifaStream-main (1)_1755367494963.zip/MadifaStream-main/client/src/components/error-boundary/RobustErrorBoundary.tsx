import React from 'react';
import { ErrorBoundary } from 'react-error-boundary';
import { AlertCircle, RefreshCw, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

interface ErrorFallbackProps {
  error: Error;
  resetErrorBoundary: () => void;
  level?: 'page' | 'component' | 'video' | 'api';
}

function ErrorFallback({ error, resetErrorBoundary, level = 'component' }: ErrorFallbackProps) {
  const isProductionError = error.message.includes('ChunkLoadError') || 
                           error.message.includes('Loading chunk') ||
                           error.message.includes('Loading CSS chunk');

  const is405Error = error.message.includes('405') || error.message.includes('Method Not Allowed');
  const is500Error = error.message.includes('500') || error.message.includes('Internal Server Error');
  const isNetworkError = error.message.includes('NetworkError') || error.message.includes('fetch');
  const isVideoError = error.message.includes('video') || error.message.includes('format');

  let title = 'Something went wrong';
  let description = 'An unexpected error occurred. Please try again.';
  let actions: React.ReactNode = null;

  if (isProductionError) {
    title = 'App Update Available';
    description = 'A new version of MadifaStream is available. Please refresh to update.';
    actions = (
      <Button onClick={() => window.location.reload()} className="flex items-center gap-2">
        <RefreshCw className="w-4 h-4" />
        Refresh App
      </Button>
    );
  } else if (is405Error) {
    title = 'Service Temporarily Unavailable';
    description = 'This feature is temporarily unavailable. Our team is working on it.';
    actions = (
      <div className="flex gap-2">
        <Button variant="outline" onClick={resetErrorBoundary}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Try Again
        </Button>
        <Button onClick={() => window.location.href = '/'}>
          <Home className="w-4 h-4 mr-2" />
          Go Home
        </Button>
      </div>
    );
  } else if (is500Error) {
    title = 'Server Error';
    description = 'Our servers are experiencing issues. Please try again in a few moments.';
    actions = (
      <Button onClick={resetErrorBoundary} variant="outline">
        <RefreshCw className="w-4 h-4 mr-2" />
        Retry
      </Button>
    );
  } else if (isNetworkError) {
    title = 'Connection Problem';
    description = 'Please check your internet connection and try again.';
    actions = (
      <Button onClick={resetErrorBoundary}>
        <RefreshCw className="w-4 h-4 mr-2" />
        Retry
      </Button>
    );
  } else if (isVideoError) {
    title = 'Video Playback Error';
    description = 'Unable to play this video. The format may not be supported.';
    actions = (
      <div className="flex gap-2">
        <Button variant="outline" onClick={resetErrorBoundary} size="sm">
          Try Again
        </Button>
        <Button onClick={() => window.location.href = '/browse'} size="sm">
          Browse Other Videos
        </Button>
      </div>
    );
  } else {
    actions = (
      <div className="flex gap-2">
        <Button onClick={resetErrorBoundary} variant="outline">
          <RefreshCw className="w-4 h-4 mr-2" />
          Try Again
        </Button>
        {level === 'page' && (
          <Button onClick={() => window.location.href = '/'}>
            <Home className="w-4 h-4 mr-2" />
            Go Home
          </Button>
        )}
      </div>
    );
  }

  const cardSize = level === 'video' ? 'w-full max-w-md' : level === 'component' ? 'w-full' : 'w-full max-w-lg mx-auto';

  return (
    <Card className={`${cardSize} mt-8`}>
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
          <AlertCircle className="w-6 h-6 text-red-600" />
        </div>
        <CardTitle className="text-lg font-semibold text-gray-900">{title}</CardTitle>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <p className="text-gray-600">{description}</p>
        {process.env.NODE_ENV === 'development' && (
          <details className="text-left mt-4">
            <summary className="cursor-pointer text-sm text-gray-500 mb-2">Debug Info</summary>
            <pre className="text-xs bg-gray-100 p-2 rounded overflow-auto max-h-32">
              {error.stack || error.message}
            </pre>
          </details>
        )}
        <div className="flex justify-center">
          {actions}
        </div>
      </CardContent>
    </Card>
  );
}

interface RobustErrorBoundaryProps {
  children: React.ReactNode;
  level?: 'page' | 'component' | 'video' | 'api';
  fallback?: React.ComponentType<ErrorFallbackProps>;
  onError?: (error: Error, errorInfo: { componentStack: string }) => void;
}

export function RobustErrorBoundary({ 
  children, 
  level = 'component', 
  fallback: FallbackComponent,
  onError 
}: RobustErrorBoundaryProps) {
  const handleError = (error: Error, errorInfo: { componentStack: string }) => {
    // Log error to console in development
    if (process.env.NODE_ENV === 'development') {
      console.error('ErrorBoundary caught an error:', error, errorInfo);
    }
    
    // Custom error reporting
    if (onError) {
      onError(error, errorInfo);
    }
    
    // Report to external service in production
    if (process.env.NODE_ENV === 'production') {
      // Could integrate with Sentry here
      console.error('Production error:', error.message);
    }
  };

  const FinalFallbackComponent = FallbackComponent || ErrorFallback;

  return (
    <ErrorBoundary
      FallbackComponent={(props) => <FinalFallbackComponent {...props} level={level} />}
      onError={handleError}
      onReset={() => {
        // Clear any error states that might prevent recovery
        if (level === 'page') {
          window.location.reload();
        }
      }}
    >
      {children}
    </ErrorBoundary>
  );
}

export default RobustErrorBoundary;