import React, { Component, ErrorInfo, ReactNode } from 'react'
import { ErrorBoundary } from 'react-error-boundary'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { RefreshCw, Home, Bug } from 'lucide-react'

interface ErrorFallbackProps {
  error: Error
  resetErrorBoundary: () => void
  resetKeys?: Array<string | number>
}

function ErrorFallback({ error, resetErrorBoundary }: ErrorFallbackProps) {
  const handleReload = () => {
    window.location.reload()
  }

  const handleGoHome = () => {
    window.location.href = '/'
  }

  const handleReportError = () => {
    const errorReport = {
      message: error.message,
      stack: error.stack,
      url: window.location.href,
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString()
    }
    
    console.error('📋 Error Report:', errorReport)
    
    // Send to your error reporting service
    if (window.gtag) {
      window.gtag('event', 'exception', {
        description: error.message,
        fatal: false
      })
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-pink-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-xl p-6">
        <div className="text-center mb-6">
          <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <Bug className="w-8 h-8 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Something went wrong
          </h1>
          <p className="text-gray-600">
            We're sorry for the inconvenience. The app encountered an unexpected error.
          </p>
        </div>

        <Alert className="mb-6 border-red-200 bg-red-50">
          <AlertDescription className="text-red-800">
            <strong>Error:</strong> {error.message}
          </AlertDescription>
        </Alert>

        <div className="space-y-3">
          <Button 
            onClick={resetErrorBoundary}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
          
          <Button 
            onClick={handleGoHome}
            variant="outline"
            className="w-full"
          >
            <Home className="w-4 h-4 mr-2" />
            Go to Home
          </Button>
          
          <Button 
            onClick={handleReload}
            variant="outline"
            className="w-full"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Reload Page
          </Button>
          
          <Button 
            onClick={handleReportError}
            variant="ghost"
            className="w-full text-gray-600"
          >
            <Bug className="w-4 h-4 mr-2" />
            Report Issue
          </Button>
        </div>

        <div className="mt-6 text-center">
          <p className="text-sm text-gray-500">
            If this problem persists, please contact support.
          </p>
        </div>
      </div>
    </div>
  )
}

interface GlobalErrorBoundaryProps {
  children: ReactNode
}

export function GlobalErrorBoundary({ children }: GlobalErrorBoundaryProps) {
  return (
    <ErrorBoundary
      FallbackComponent={ErrorFallback}
      onError={(error, errorInfo) => {
        console.error('🚨 Global Error Boundary caught an error:', error, errorInfo)
        
        // Send to error reporting service
        if (window.gtag) {
          window.gtag('event', 'exception', {
            description: error.message,
            fatal: true
          })
        }
      }}
      onReset={() => {
        // Clear any error state
        window.location.reload()
      }}
    >
      {children}
    </ErrorBoundary>
  )
}

// Route-specific error boundary
export function RouteErrorBoundary({ children }: { children: ReactNode }) {
  return (
    <ErrorBoundary
      FallbackComponent={({ error, resetErrorBoundary }) => (
        <div className="min-h-[400px] flex items-center justify-center">
          <div className="text-center max-w-md mx-auto p-6">
            <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <Bug className="w-6 h-6 text-red-600" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900 mb-2">
              Page Error
            </h2>
            <p className="text-gray-600 mb-4">
              This section couldn't load properly.
            </p>
            <Button onClick={resetErrorBoundary} size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry
            </Button>
          </div>
        </div>
      )}
      onError={(error) => {
        console.error('🔧 Route Error:', error)
      }}
    >
      {children}
    </ErrorBoundary>
  )
}

// Video player specific error boundary
export function VideoErrorBoundary({ children }: { children: ReactNode }) {
  return (
    <ErrorBoundary
      FallbackComponent={({ error, resetErrorBoundary }) => (
        <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
          <div className="text-center p-4">
            <div className="mx-auto w-10 h-10 bg-red-100 rounded-full flex items-center justify-center mb-3">
              <Bug className="w-5 h-5 text-red-600" />
            </div>
            <h3 className="font-medium text-gray-900 mb-2">
              Video Player Error
            </h3>
            <p className="text-sm text-gray-600 mb-3">
              The video player encountered an error.
            </p>
            <Button onClick={resetErrorBoundary} size="sm" variant="outline">
              <RefreshCw className="w-4 h-4 mr-2" />
              Retry Video
            </Button>
          </div>
        </div>
      )}
      onError={(error) => {
        console.error('🎥 Video Error:', error)
      }}
    >
      {children}
    </ErrorBoundary>
  )
} 