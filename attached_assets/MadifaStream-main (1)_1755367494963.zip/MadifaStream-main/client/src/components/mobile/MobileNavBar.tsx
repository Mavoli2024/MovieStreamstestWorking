import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import {  Home, Search, BookmarkPlus, Download  } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useEffect, useState } from 'react';

/**
 * Mobile-specific bottom navigation bar
 * Provides quick access to main app features
 */
export function MobileNavBar() {
  const [location] = useLocation();
  const { user } = useAuth();
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  
  // Hide navigation bar when scrolling down with improved performance
  useEffect(() => {
    // Using requestAnimationFrame for smoother performance
    let ticking = false;
    
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      if (!ticking) {
        window.requestAnimationFrame(() => {
          // Only toggle visibility when scrolling more than 10px
          if (Math.abs(currentScrollY - lastScrollY) > 10) {
            // Determine scroll direction
            if (currentScrollY > lastScrollY && currentScrollY > 50) {
              // Scrolling down significantly - hide the nav bar
              setIsVisible(false);
            } else {
              // Scrolling up or at top of page - show the nav bar
              setIsVisible(true);
            }
            
            setLastScrollY(currentScrollY);
          }
          ticking = false;
        });
        
        ticking = true;
      }
    };
    
    window.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [lastScrollY]);
  
  // Don't show navigation bar if user is not authenticated
  if (!user) return null;
  
  // Don't show navigation on video page
  if (location.startsWith('/watch/')) return null;
  
  // Navigation items configuration
  const navItems = [
    { 
      icon: Home, 
      label: 'Home', 
      path: '/home', 
      active: location === '/home' || location === '/' 
    },
    { 
      icon: Search, 
      label: 'Explore', 
      path: '/browse', 
      active: location === '/browse' 
    },
    { 
      icon: BookmarkPlus, 
      label: 'My List', 
      path: '/my-list', 
      active: location === '/my-list' 
    },
    { 
      icon: Download, 
      label: 'Downloads', 
      path: '/downloads', 
      active: location === '/downloads' 
    }
  ];
  
  return (
    <nav 
      className={cn(
        "fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-background/95 backdrop-blur-md transition-transform duration-300 will-change-transform",
        isVisible ? "translate-y-0" : "translate-y-full"
      )}
      style={{
        WebkitBackfaceVisibility: "hidden", // Performance boost for Safari
        WebkitTransform: "translateZ(0)", // Hardware acceleration
      }}
    >
      <div className="flex items-center justify-around h-16 pb-1">
        {navItems.map((item) => (
          <NavItem 
            key={item.path}
            {...item}
          />
        ))}
      </div>
      
      {/* Safe area spacing for iOS devices with notches */}
      <div className="h-[env(safe-area-inset-bottom,0px)] bg-background" />
    </nav>
  );
}

interface NavItemProps {
  icon: React.FC<{ className?: string }>;
  label: string;
  path: string;
  active: boolean;
}

/**
 * Individual navigation item component
 */
function NavItem({ icon: Icon, label, path, active }: NavItemProps) {
  const [, navigate] = useLocation();
  
  return (
    <button
      className={cn(
        "flex flex-col items-center justify-center w-full h-full transition-colors",
        "active:opacity-70 touch-manipulation", // Improves touch response
        active ? "text-primary" : "text-muted-foreground"
      )}
      onClick={() => navigate(path)}
      aria-label={label}
    >
      <div className="relative">
        <Icon className={cn(
          "h-6 w-6 mb-1 transition-transform duration-200", 
          active ? "text-orange-500 scale-110" : "text-muted-foreground"
        )} />
        {active && (
          <span className="absolute -bottom-1 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-orange-500 rounded-full" />
        )}
      </div>
      <span className={cn(
        "text-[11px] font-medium transition-colors",
        active ? "text-foreground" : "text-muted-foreground"
      )}>
        {label}
      </span>
    </button>
  );
}