import React, { useRef, useState, useEffect } from 'react';
import { cn } from '@/lib/utils';

interface MobileScrollContainerProps {
  children: React.ReactNode;
  className?: string;
  direction?: 'horizontal' | 'vertical';
  snapType?: 'none' | 'proximity' | 'mandatory';
  snapAlign?: 'start' | 'center' | 'end';
  hideScrollbar?: boolean;
  smoothScroll?: boolean;
  scrollPadding?: boolean;
  onScroll?: (scrollPosition: number, maxScroll: number) => void;
}

/**
 * Mobile-optimized scrolling container component
 * Provides smooth scrolling with touch support and snap points
 */
export function MobileScrollContainer({
  children,
  className,
  direction = 'horizontal',
  snapType = 'none',
  snapAlign = 'start',
  hideScrollbar = true,
  smoothScroll = true,
  scrollPadding = true,
  onScroll
}: MobileScrollContainerProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isScrolling, setIsScrolling] = useState(false);
  const scrollTimer = useRef<NodeJS.Timeout | null>(null);
  
  // Set up scroll detection
  useEffect(() => {
    const scrollElement = scrollRef.current;
    if (!scrollElement || !onScroll) return;
    
    const handleScroll = () => {
      setIsScrolling(true);
      
      // Clear previous timeout
      if (scrollTimer.current) {
        clearTimeout(scrollTimer.current);
      }
      
      // Set new timeout to detect when scrolling stops
      scrollTimer.current = setTimeout(() => {
        setIsScrolling(false);
      }, 150);
      
      // Calculate scroll percentage
      const isHorizontal = direction === 'horizontal';
      const currentScroll = isHorizontal ? scrollElement.scrollLeft : scrollElement.scrollTop;
      const maxScroll = isHorizontal 
        ? scrollElement.scrollWidth - scrollElement.clientWidth
        : scrollElement.scrollHeight - scrollElement.clientHeight;
      
      onScroll(currentScroll, maxScroll);
    };
    
    scrollElement.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => {
      scrollElement.removeEventListener('scroll', handleScroll);
      if (scrollTimer.current) {
        clearTimeout(scrollTimer.current);
      }
    };
  }, [direction, onScroll]);
  
  // Get snap attributes
  const getSnapAttributes = () => {
    const attributes: Record<string, string> = {};
    
    if (snapType !== 'none') {
      attributes['data-snap-type'] = snapType;
      attributes['data-snap-align'] = snapAlign;
    }
    
    return attributes;
  };
  
  return (
    <div
      ref={scrollRef}
      className={cn(
        'overscroll-contain',
        direction === 'horizontal' ? 'overflow-x-auto' : 'overflow-y-auto',
        direction === 'horizontal' ? 'overflow-y-hidden' : 'overflow-x-hidden',
        hideScrollbar && 'scrollbar-hide',
        smoothScroll && 'scroll-smooth',
        scrollPadding && (
          direction === 'horizontal' 
            ? 'px-4 sm:px-6 md:px-8 -mx-4 sm:-mx-6 md:-mx-8' 
            : 'py-4 -my-4'
        ),
        direction === 'horizontal' && snapType !== 'none' && `snap-${snapType} snap-x`,
        direction === 'vertical' && snapType !== 'none' && `snap-${snapType} snap-y`,
        isScrolling && 'cursor-grabbing',
        className
      )}
      style={{
        WebkitOverflowScrolling: 'touch', // For momentum scrolling on iOS
      }}
      {...getSnapAttributes()}
    >
      {children}
    </div>
  );
}