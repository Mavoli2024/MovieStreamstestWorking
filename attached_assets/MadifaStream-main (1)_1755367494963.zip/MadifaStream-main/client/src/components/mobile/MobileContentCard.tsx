import React, { useState } from 'react';
import { useLocation } from 'wouter';
import {  PlayCircle, Plus, Check, Star, Clock  } from 'lucide-react';
import { cn } from '@/lib/utils';

// Types
interface MobileContentCardProps {
  id: number | string;
  title: string;
  thumbnailUrl: string;
  description?: string;
  duration?: number;
  rating?: number;
  isInWatchlist?: boolean;
  releaseYear?: number;
  className?: string;
  aspectRatio?: 'portrait' | 'landscape' | 'square';
  onClick?: () => void;
  onWatchlistToggle?: () => void;
}

/**
 * Mobile-optimized content card component for displaying movies and shows
 * Features touch-friendly controls and gestures
 */
export function MobileContentCard({
  id,
  title,
  thumbnailUrl,
  description,
  duration,
  rating,
  isInWatchlist = false,
  releaseYear,
  className,
  aspectRatio = 'portrait',
  onClick,
  onWatchlistToggle
}: MobileContentCardProps) {
  const [, navigate] = useLocation();
  const [isImageLoaded, setIsImageLoaded] = useState(false);
  const [isImageError, setIsImageError] = useState(false);
  const [isPressing, setIsPressing] = useState(false);
  
  // Format duration from minutes to HH:MM
  const formatDuration = (minutes: number): string => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  // Handle card click
  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      navigate(`/watch/${id}`);
    }
  };

  // Handle long press
  const handleTouchStart = () => {
    setIsPressing(true);
  };

  const handleTouchEnd = () => {
    setIsPressing(false);
  };

  // Determine card aspect ratio class
  const getAspectRatioClass = () => {
    switch (aspectRatio) {
      case 'landscape':
        return 'aspect-video';
      case 'square':
        return 'aspect-square';
      case 'portrait':
      default:
        return 'aspect-[2/3]';
    }
  };

  // Generate fallback thumbnail if image fails to load
  const generateFallbackThumbnail = () => {
    return (
      <div 
        className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-800 to-gray-900 p-4"
      >
        <div className="text-center">
          <span className="block text-sm sm:text-base font-medium text-white truncate">{title}</span>
          {releaseYear && <span className="text-xs text-gray-300">{releaseYear}</span>}
        </div>
      </div>
    );
  };

  return (
    <div 
      className={cn(
        "relative group overflow-hidden rounded-lg bg-card shadow-md transition-transform duration-300 cursor-pointer active:scale-95",
        isPressing && "scale-95 shadow-sm",
        className
      )}
      onClick={handleClick}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchEnd}
      style={{ touchAction: 'manipulation' }}
    >
      {/* Card Media */}
      <div className={cn("relative overflow-hidden", getAspectRatioClass())}>
        {/* Thumbnail */}
        {!isImageError ? (
          <img
            src={thumbnailUrl}
            alt={title}
            className={cn(
              "w-full h-full object-cover transition-opacity duration-300",
              isImageLoaded ? "opacity-100" : "opacity-0"
            )}
            onLoad={() => setIsImageLoaded(true)}
            onError={() => setIsImageError(true)}
            loading="lazy"
          />
        ) : generateFallbackThumbnail()}

        {/* Loading Skeleton */}
        {!isImageLoaded && !isImageError && (
          <div className="absolute inset-0 bg-gray-800 animate-pulse" />
        )}

        {/* Overlay with Gradient */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="rounded-full bg-primary/80 p-2">
            <PlayCircle className="w-9 h-9 text-white" />
          </div>
        </div>

        {/* Top Right Info */}
        {(rating || duration) && (
          <div className="absolute top-2 right-2 flex space-x-2">
            {rating && (
              <div className="flex items-center space-x-1 bg-black/60 text-white text-xs px-2 py-1 rounded-md">
                <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                <span>{rating.toFixed(1)}</span>
              </div>
            )}
            {duration && (
              <div className="flex items-center space-x-1 bg-black/60 text-white text-xs px-2 py-1 rounded-md">
                <Clock className="w-3 h-3" />
                <span>{formatDuration(duration)}</span>
              </div>
            )}
          </div>
        )}

        {/* Watchlist Button */}
        {onWatchlistToggle && (
          <div className="absolute bottom-2 right-2 z-10">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onWatchlistToggle();
              }}
              className={cn(
                "flex items-center justify-center w-8 h-8 rounded-full active:scale-90 transition-colors",
                isInWatchlist ? "bg-primary text-white" : "bg-black/60 text-white hover:bg-black/80"
              )}
              aria-label={isInWatchlist ? "Remove from watchlist" : "Add to watchlist"}
            >
              {isInWatchlist ? (
                <Check className="w-4 h-4" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
            </button>
          </div>
        )}
      </div>

      {/* Card Content */}
      <div className="p-2 pb-3">
        <h3 className="font-medium text-sm truncate">{title}</h3>
        {releaseYear && (
          <div className="text-xs text-muted-foreground mt-0.5">{releaseYear}</div>
        )}
        {description && (
          <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{description}</p>
        )}
      </div>
    </div>
  );
}