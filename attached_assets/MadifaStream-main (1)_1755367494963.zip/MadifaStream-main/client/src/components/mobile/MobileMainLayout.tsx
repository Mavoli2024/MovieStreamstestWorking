import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { useToast } from '@/hooks/use-toast';
import { useProfile } from '@/hooks/use-profile';
import { MobileNavBar } from './MobileNavBar';
import { User, Home, Search, BookmarkPlus, Download, LogOut } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { logger } from '../../shared/logger.js';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import MADIFA_LOGO_URL from '../../assets/madifa_logo.png';

interface MobileMainLayoutProps {
  children: React.ReactNode;
}

/**
 * Main layout component for mobile app
 * Includes navigation, profile drawer, and content area
 */
export function MobileMainLayout({ children }: MobileMainLayoutProps) {
  const [, navigate] = useLocation();
  const { user, logoutMutation, profile: userProfile } = useAuth();
  const { currentProfile } = useProfile();
  const activeProfile = userProfile || currentProfile;
  const [isScrolled, setIsScrolled] = useState(false);
  
  // Handle scroll event to update header appearance
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 0);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  // Handle logout
  const handleLogout = async () => {
    try {
      await logoutMutation.mutateAsync(undefined);
      navigate('/auth');
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Logout failed:', { arg1: error });
      }
    }
  };
  
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground overflow-hidden">
      {/* Mobile Header - Native-like with blur effect */}
      <header 
        className={cn(
          "sticky top-0 z-40 transition-all duration-300 pt-[env(safe-area-inset-top,0px)]",
          isScrolled 
            ? 'bg-background/85 backdrop-blur-lg shadow-sm border-b border-border/20' 
            : 'bg-gradient-to-b from-black/50 to-transparent'
        )}
      >
        <div className="flex items-center justify-between h-14 px-4">
          {/* Logo */}
          <div className="flex items-center">
            <img 
              src={MADIFA_LOGO_URL} 
              alt="Madifa" 
              className="h-7 active:opacity-70 transition-opacity rounded-full"
              onClick={() => navigate('/')}
              style={{touchAction: 'manipulation'}}
            />
          </div>
          
          {/* Right Side Actions */}
          <div className="flex items-center space-x-3">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate('/search')}
              className="text-primary-foreground relative w-9 h-9 rounded-full active:bg-accent/50"
            >
              <Search className="h-5 w-5" />
              <span className="sr-only">Search</span>
            </Button>
            
            {user && (
              <Sheet>
                <SheetTrigger asChild>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="rounded-full overflow-hidden active:opacity-80 transition-opacity"
                    style={{touchAction: 'manipulation'}}
                  >
                    <Avatar className="h-9 w-9 border-2 border-primary/80 shadow-sm">
                      <AvatarImage 
                        src={undefined} 
                        alt={activeProfile?.display_name || user?.email?.split('@')[0] || 'Profile'} 
                      />
                      <AvatarFallback 
                        className="bg-gradient-to-br from-orange-500 to-orange-600 text-white font-medium"
                        style={{
                          backgroundSize: '150% 150%',
                          backgroundPosition: '10% 10%',
                          backgroundColor: '#f97316',
                        }}
                      >
                        {(activeProfile?.display_name?.charAt(0) || user?.email?.charAt(0) || 'U').toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </SheetTrigger>
                
                <SheetContent 
                  side="right" 
                  className="w-[85%] sm:w-[385px] bg-background pt-[calc(env(safe-area-inset-top,0px)+1rem)] rounded-l-2xl border-l border-border"
                >
                  <SheetHeader className="pb-4">
                    <SheetTitle className="text-xl font-bold">My Account</SheetTitle>
                  </SheetHeader>
                  
                  <ScrollArea className="h-[calc(100vh-10rem)]">
                    {/* User Info */}
                    <div className="flex items-center mb-6 pb-6 border-b border-border">
                      <Avatar className="h-16 w-16 mr-4 border-2 border-primary/80 shadow-sm">
                        <AvatarImage 
                          src={undefined} 
                          alt={activeProfile?.display_name || user?.email?.split('@')[0] || 'Profile'}
                        />
                        <AvatarFallback 
                          className="text-white text-xl font-semibold"
                          style={{
                            background: '#f97316'
                          }}
                        >
                          {(activeProfile?.display_name?.charAt(0) || user?.email?.charAt(0) || 'U').toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold text-lg">
                          {activeProfile?.display_name || user?.email?.split('@')[0] || 'User'}
                        </h3>
                        <p className="text-sm text-muted-foreground">{user?.email}</p>
                      </div>
                    </div>
                    
                    {/* Menu Items */}
                    <div className="space-y-2 px-1">
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start h-12 text-base rounded-lg active:scale-[0.98] transition-transform" 
                        onClick={() => navigate('/home')}
                        style={{touchAction: 'manipulation'}}
                      >
                        <Home className="mr-3 h-5 w-5 text-orange-500" />
                        Home
                      </Button>
                      
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start h-12 text-base rounded-lg active:scale-[0.98] transition-transform" 
                        onClick={() => navigate('/my-list')}
                        style={{touchAction: 'manipulation'}}
                      >
                        <BookmarkPlus className="mr-3 h-5 w-5 text-orange-500" />
                        My List
                      </Button>
                      
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start h-12 text-base rounded-lg active:scale-[0.98] transition-transform" 
                        onClick={() => navigate('/downloads')}
                        style={{touchAction: 'manipulation'}}
                      >
                        <Download className="mr-3 h-5 w-5 text-orange-500" />
                        Downloads
                      </Button>
                      
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start h-12 text-base rounded-lg active:scale-[0.98] transition-transform" 
                        onClick={() => navigate('/profile')}
                        style={{touchAction: 'manipulation'}}
                      >
                        <User className="mr-3 h-5 w-5 text-orange-500" />
                        Account Settings
                      </Button>
                      
                      <div className="pt-2 mt-2 border-t border-border">
                        <Button 
                          variant="ghost" 
                          className="w-full justify-start h-12 text-base rounded-lg active:scale-[0.98] transition-transform text-red-500" 
                          onClick={handleLogout}
                          disabled={logoutMutation.isPending}
                          style={{touchAction: 'manipulation'}}
                        >
                          <LogOut className="mr-3 h-5 w-5 text-red-500" />
                          {logoutMutation.isPending ? 'Logging out...' : 'Log Out'}
                        </Button>
                      </div>
                    </div>
                    
                    {/* App Info */}
                    <div className="mt-8 pt-4 border-t border-border">
                      <p className="text-xs text-muted-foreground text-center">
                        Madifa v1.0.0 • © 2023 Madifa, Inc.
                      </p>
                    </div>
                  </ScrollArea>
                </SheetContent>
              </Sheet>
            )}
          </div>
        </div>
      </header>
      
      {/* Main Content - Enhanced for mobile viewing */}
      <main className="flex-1 overflow-auto pb-20 overscroll-none">
        <div className="min-h-[calc(100vh-4rem)]">
          {children}
        </div>
      </main>
      
      {/* Mobile Navigation Bar */}
      <MobileNavBar />
    </div>
  );
}
