import { useState, useEffect } from 'react';
import { 
  extractBunnyGuid, 
  generateSvgThumbnail, 
  getThumbnailApiUrl, 
  logThumbnailError 
} from '@/lib/thumbnail-utils';

interface MobileThumbnailImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackText?: string;
  width?: number;
  height?: number;
  videoId?: string;
  title?: string;
}

/**
 * Enhanced mobile-optimized thumbnail image with robust error handling
 * Includes multiple fallback strategies to ensure thumbnail display
 */
export function MobileThumbnailImage({
  src,
  alt,
  className = '',
  fallbackText,
  width,
  height,
  videoId: propVideoId,
  title
}: MobileThumbnailImageProps) {
  const [hasError, setHasError] = useState(false);
  const [fallbackAttempt, setFallbackAttempt] = useState(0);
  const [imgSrc, setImgSrc] = useState(src);
  
  // Extract video ID either from props or from the URL
  const videoId = propVideoId || extractBunnyGuid(src);
  const displayTitle = title || fallbackText || alt || 'Thumbnail';
  
  // Reset error state if source changes
  useEffect(() => {
    setHasError(false);
    setFallbackAttempt(0);
    setImgSrc(src);
  }, [src, videoId]);
  
  // Handle image load errors with progressive fallback strategies
  const handleError = () => {
    if (!hasError) {
      // For logging purposes
      const errorSource = fallbackAttempt === 0 ? 'direct-url' : `fallback-${fallbackAttempt}`;
      
      if (videoId && fallbackAttempt === 0) {
        // First fallback: Try the server API endpoint
        logThumbnailError(videoId, errorSource, new Error('Original thumbnail failed to load'));
        setFallbackAttempt(1);
        setImgSrc(getThumbnailApiUrl(videoId));
      } else if (videoId && fallbackAttempt === 1) {
        // Second fallback: Try with a different attempt parameter
        logThumbnailError(videoId, errorSource, new Error('First fallback failed to load'));
        setFallbackAttempt(2);
        setImgSrc(getThumbnailApiUrl(videoId, 2));
      } else {
        // Final fallback: Signal complete failure
        if (videoId) {
          logThumbnailError(videoId, errorSource, new Error('All image sources failed'));
        }
        setHasError(true);
      }
    }
  };
  
  // If all attempts failed, show text fallback with styling optimized for mobile
  if (hasError) {
    return (
      <div
        className={`flex items-center justify-center bg-gradient-to-br from-gray-800 to-gray-900 text-white rounded-md ${className}`}
        style={{ 
          width: width ? `${width}px` : '100%', 
          height: height ? `${height}px` : '100%',
          aspectRatio: '16/9'
        }}
      >
        <div className="p-2 text-center">
          <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-primary/20 flex items-center justify-center">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M12 18.5C15.5899 18.5 18.5 15.5899 18.5 12C18.5 8.41015 15.5899 5.5 12 5.5C8.41015 5.5 5.5 8.41015 5.5 12C5.5 15.5899 8.41015 18.5 12 18.5Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M12 13.5V10" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M12 16H12.01" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <span className="text-sm font-medium">{displayTitle}</span>
        </div>
      </div>
    );
  }
  
  // Show the image with error handler
  return (
    <img
      src={imgSrc}
      alt={alt}
      className={className}
      width={width}
      height={height}
      loading="lazy"
      onError={handleError}
    />
  );
}