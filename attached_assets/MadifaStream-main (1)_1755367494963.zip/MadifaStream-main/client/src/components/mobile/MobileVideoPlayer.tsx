import { useState, useEffect, useRef } from 'react';
import {  PlayCircle, PauseCircle, SkipForward, SkipBack, Volume2, VolumeX, Maximize, Minimize  } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MobileVideoPlayerProps {
  videoUrl: string;
  posterUrl?: string;
  title: string;
  autoPlay?: boolean;
  onTimeUpdate?: (currentTime: number, duration: number) => void;
  startTime?: number;
}

/**
 * Mobile-optimized video player component
 * Features touch-friendly controls and gestures
 */
export function MobileVideoPlayer({
  videoUrl,
  posterUrl,
  title,
  autoPlay = false,
  onTimeUpdate,
  startTime = 0,
}: MobileVideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [isSeeking, setIsSeeking] = useState(false);
  const [isBuffering, setIsBuffering] = useState(false);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastTouchX = useRef<number | null>(null);
  const seekStartValue = useRef<number | null>(null);

  // Initialize the video
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    // Set initial time if provided
    if (startTime > 0) {
      video.currentTime = startTime;
    }

    // Initialize listeners
    const handleLoadedMetadata = () => {
      setDuration(video.duration);
      // Enable autoplay if requested and user has interacted with the document
      if (autoPlay && document.documentElement.hasAttribute('data-user-interacted')) {
        video.play().catch(() => {
          // Auto-play failed, probably due to browser restrictions
          setIsPlaying(false);
        });
      }
    };

    const handleTimeUpdate = () => {
      if (!isSeeking) {
        setCurrentTime(video.currentTime);
        onTimeUpdate?.(video.currentTime, video.duration);
      }
    };

    const handleProgress = () => {
      if (video.buffered.length > 0) {
        const bufferedEnd = video.buffered.end(video.buffered.length - 1);
        const isBuffering = bufferedEnd < video.duration || 
                            (video.currentTime > bufferedEnd) || 
                            video.readyState < 3;
        setIsBuffering(isBuffering);
      }
    };

    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleVolumeChange = () => {
      setVolume(video.volume);
      setIsMuted(video.muted);
    };

    // Register event listeners
    video.addEventListener('loadedmetadata', handleLoadedMetadata);
    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('progress', handleProgress);
    video.addEventListener('play', handlePlay);
    video.addEventListener('pause', handlePause);
    video.addEventListener('volumechange', handleVolumeChange);
    video.addEventListener('waiting', () => setIsBuffering(true));
    video.addEventListener('canplay', () => setIsBuffering(false));

    return () => {
      // Clean up listeners
      video.removeEventListener('loadedmetadata', handleLoadedMetadata);
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('progress', handleProgress);
      video.removeEventListener('play', handlePlay);
      video.removeEventListener('pause', handlePause);
      video.removeEventListener('volumechange', handleVolumeChange);
      video.removeEventListener('waiting', () => setIsBuffering(true));
      video.removeEventListener('canplay', () => setIsBuffering(false));
    };
  }, [videoUrl, autoPlay, startTime, onTimeUpdate, isSeeking]);

  // Handle auto-hide controls
  useEffect(() => {
    const hideControls = () => setShowControls(false);
    
    // Reset the timeout whenever the controls are shown
    if (showControls && isPlaying && !isSeeking) {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
      controlsTimeoutRef.current = setTimeout(hideControls, 3000);
    }
    
    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    };
  }, [showControls, isPlaying, isSeeking]);

  // Monitor fullscreen changes
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Mark that user has interacted with the document (for autoplay)
  useEffect(() => {
    const markInteraction = () => {
      document.documentElement.setAttribute('data-user-interacted', 'true');
    };
    
    document.addEventListener('click', markInteraction, { once: true });
    document.addEventListener('touchstart', markInteraction, { once: true });
    
    return () => {
      document.removeEventListener('click', markInteraction);
      document.removeEventListener('touchstart', markInteraction);
    };
  }, []);

  // Play/pause toggle
  const togglePlayPause = () => {
    const video = videoRef.current;
    if (!video) return;
    
    if (isPlaying) {
      video.pause();
    } else {
      video.play().catch(error => {
        // console.error('Error playing video:', error);
      });
    }
    
    // Show controls when play state changes
    setShowControls(true);
  };

  // Seek to a specific time
  const seekTo = (time: number) => {
    const video = videoRef.current;
    if (!video) return;
    
    const clampedTime = Math.max(0, Math.min(time, duration));
    video.currentTime = clampedTime;
    setCurrentTime(clampedTime);
  };

  // Handle seeking with touch gesture
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length !== 1) return;
    
    // Record starting touch position
    lastTouchX.current = e.touches[0].clientX;
    seekStartValue.current = currentTime;
    setIsSeeking(true);
    
    // Show controls during seeking
    setShowControls(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!lastTouchX.current || !seekStartValue.current || e.touches.length !== 1) return;
    
    const touchX = e.touches[0].clientX;
    const deltaX = touchX - lastTouchX.current;
    
    // Calculate how much to seek (based on screen width)
    const seekDelta = (deltaX / window.innerWidth) * duration * 0.8;
    const newTime = Math.max(0, Math.min(seekStartValue.current + seekDelta, duration));
    
    // Update the UI without actually seeking yet (for smoother experience)
    setCurrentTime(newTime);
  };

  const handleTouchEnd = () => {
    if (seekStartValue.current !== null && lastTouchX.current !== null) {
      // Actually perform the seek operation
      seekTo(currentTime);
      
      // Reset the touch tracking
      lastTouchX.current = null;
      seekStartValue.current = null;
      
      // End seeking mode after a short delay to prevent accidental taps
      setTimeout(() => setIsSeeking(false), 100);
    }
  };

  // Format seconds to MM:SS
  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // Toggle fullscreen
  const toggleFullscreen = () => {
    const player = playerRef.current;
    if (!player) return;
    
    if (!document.fullscreenElement) {
      player.requestFullscreen().catch(err => {
        // console.error(`Error attempting to enable fullscreen: ${err.message}`);
      });
    } else {
      document.exitFullscreen();
    }
  };

  // Toggle mute
  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    
    video.muted = !video.muted;
    setIsMuted(video.muted);
  };

  // Skip forward/backward
  const skip = (seconds: number) => {
    const video = videoRef.current;
    if (!video) return;
    
    const newTime = Math.max(0, Math.min(currentTime + seconds, duration));
    seekTo(newTime);
    setShowControls(true);
  };

  return (
    <div 
      ref={playerRef}
      className={cn(
        "relative w-full aspect-video bg-black touch-none select-none overflow-hidden rounded-lg",
        isFullscreen && "fixed inset-0 z-50 rounded-none"
      )}
      onClick={() => setShowControls(!showControls)}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        src={videoUrl}
        poster={posterUrl}
        className="w-full h-full object-contain"
        playsInline
        preload="metadata"
        onDoubleClick={toggleFullscreen}
      />
      
      {/* Loading Indicator */}
      {isBuffering && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/20 z-10">
          <div className="loading-spinner w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}
      
      {/* Tap to Play Overlay (when paused) */}
      {!isPlaying && (
        <div 
          className="absolute inset-0 flex items-center justify-center bg-black/30 z-10 touch-manipulation"
          onClick={(e) => {
            e.stopPropagation();
            togglePlayPause();
          }}
        >
          <PlayCircle className="w-20 h-20 text-white/90 stroke-[1.5]" />
        </div>
      )}
      
      {/* Controls Container */}
      <div 
        className={cn(
          "absolute inset-0 flex flex-col justify-between p-3 bg-gradient-to-t from-black/70 to-transparent transition-opacity duration-300 z-20",
          showControls ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Controls */}
        <div className="flex items-center justify-between">
          <h2 className="text-white text-lg font-medium truncate max-w-[80%]">{title}</h2>
          
          <button 
            onClick={toggleFullscreen}
            className="p-2 touch-manipulation active:opacity-70"
          >
            {isFullscreen ? (
              <Minimize className="w-5 h-5 text-white" />
            ) : (
              <Maximize className="w-5 h-5 text-white" />
            )}
          </button>
        </div>
        
        {/* Bottom Controls */}
        <div className="space-y-2">
          {/* Progress Bar */}
          <div className="w-full h-1 bg-white/30 rounded-full relative">
            <div 
              className="absolute h-full bg-primary rounded-full" 
              style={{ width: `${(currentTime / (duration || 1)) * 100}%` }}
            />
            <input
              type="range"
              min={0}
              max={duration || 0}
              step="any"
              value={currentTime}
              onChange={(e) => {
                setIsSeeking(true);
                setCurrentTime(parseFloat(e.target.value));
              }}
              onMouseDown={() => setIsSeeking(true)}
              onMouseUp={() => {
                seekTo(currentTime);
                setIsSeeking(false);
              }}
              onTouchStart={() => setIsSeeking(true)}
              onTouchEnd={() => {
                seekTo(currentTime);
                setIsSeeking(false);
              }}
              className="absolute inset-0 w-full opacity-0 cursor-pointer touch-manipulation"
              style={{ margin: 0, padding: 0, height: '200%', top: '-50%' }}
            />
          </div>
          
          {/* Controls */}
          <div className="flex items-center justify-between">
            {/* Time Display */}
            <div className="text-white/90 text-xs">
              {formatTime(currentTime)} / {formatTime(duration)}
            </div>
            
            {/* Control Buttons */}
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => skip(-10)}
                className="p-1 touch-manipulation active:opacity-70"
              >
                <SkipBack className="w-5 h-5 text-white" />
              </button>
              
              <button 
                onClick={togglePlayPause}
                className="p-1 touch-manipulation active:opacity-70"
              >
                {isPlaying ? (
                  <PauseCircle className="w-8 h-8 text-white" />
                ) : (
                  <PlayCircle className="w-8 h-8 text-white" />
                )}
              </button>
              
              <button 
                onClick={() => skip(10)}
                className="p-1 touch-manipulation active:opacity-70"
              >
                <SkipForward className="w-5 h-5 text-white" />
              </button>
              
              <button 
                onClick={toggleMute}
                className="p-1 touch-manipulation active:opacity-70"
              >
                {isMuted ? (
                  <VolumeX className="w-5 h-5 text-white" />
                ) : (
                  <Volume2 className="w-5 h-5 text-white" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}