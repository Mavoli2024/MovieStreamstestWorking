/**
 * Mobile-specific adapter for Bunny Stream integration
 * Optimizes video and thumbnail handling for mobile devices
 */

// Get the CDN hostname from environment variables
const cdnHostname = import.meta.env.BUNNY_CDN_HOSTNAME || '';
const libraryId = import.meta.env.BUNNY_STREAM_LIBRARY_ID || '';

/**
 * Generate optimized thumbnail URL for mobile devices
 * Uses proper CDN paths based on Bunny.net best practices
 */
export function getMobileThumbnailUrl(videoId: string, _quality: 'low' | 'medium' | 'high' = 'medium'): string {
  if (!videoId) return '';
  
  // Basic error handling
  if (!cdnHostname) {
    // console.error('BUNNY_CDN_HOSTNAME environment variable not set');
    return '';
  }
  
  // First try the direct CDN thumbnail URL (most reliable)
  // Format: https://vz-{libraryId}.b-cdn.net/{videoGuid}/thumbnail.jpg
  return `https://${cdnHostname}/${videoId}/thumbnail.jpg`;
}

/**
 * Generate streaming URL for mobile-optimized playback
 * For mobile, we might want to use a different streaming format or quality
 */
export function getMobileStreamingUrl(videoId: string, format: 'hls' | 'mp4' = 'hls'): string {
  if (!videoId) return '';
  
  // Basic error handling
  if (!cdnHostname) {
    // console.error('BUNNY_CDN_HOSTNAME environment variable not set');
    return '';
  }
  
  if (format === 'hls') {
    // HLS adaptive streaming (recommended for mobile)
    // Format: https://vz-{libraryId}.b-cdn.net/{videoGuid}/playlist.m3u8
    return `https://${cdnHostname}/${videoId}/playlist.m3u8`;
  } else {
    // Direct MP4 link (fallback)
    // Format: https://vz-{libraryId}.b-cdn.net/{videoGuid}/{videoGuid}.mp4
    return `https://${cdnHostname}/${videoId}/${videoId}.mp4`;
  }
}

/**
 * Generate iframe embed URL for WebView embedding
 */
export function getMobileEmbedUrl(videoId: string): string {
  if (!videoId || !libraryId) return '';
  
  // Format: https://iframe.mediadelivery.net/embed/{libraryId}/{videoGuid}
  return `https://iframe.mediadelivery.net/embed/${libraryId}/${videoId}`;
}

/**
 * Check if device is capable of HLS playback
 * Most modern mobile browsers support HLS natively
 */
export function canPlayHls(): boolean {
  if (typeof document === 'undefined') return false;
  
  const video = document.createElement('video');
  return video.canPlayType('application/vnd.apple.mpegurl') !== '';
}

/**
 * Get appropriate video format based on device capabilities
 */
export function getBestVideoFormat(): 'hls' | 'mp4' {
  return canPlayHls() ? 'hls' : 'mp4';
}

/**
 * Preload thumbnail images for smoother UX on mobile
 * This helps with perceived performance
 */
export function preloadThumbnails(videoIds: string[]): void {
  if (typeof document === 'undefined') return;
  
  videoIds.forEach(id => {
    const img = new Image();
    img.src = getMobileThumbnailUrl(id);
  });
}

/**
 * Optimize video quality based on network connection
 * This helps with data usage on mobile
 */
export function getOptimizedQuality(): 'auto' | '720p' | '480p' | '360p' {
  if (typeof navigator === 'undefined') return 'auto';
  
  // Check if we have the Network Information API
  if ((navigator as any).connection && 'effectiveType' in (navigator as any).connection) {
    const effectiveType = ((navigator as any).connection as any).effectiveType;
    
    switch (effectiveType) {
      case '4g':
        return '720p';
      case '3g':
        return '480p';
      case '2g':
      case 'slow-2g':
        return '360p';
      default:
        return 'auto';
    }
  }
  
  return 'auto';
}

/**
 * Get appropriate video player parameters for mobile
 */
export function getMobilePlayerParams(): Record<string, string> {
  return {
    autoplay: 'false', // Don't autoplay on mobile to save data
    muted: 'false',
    loop: 'false',
    preload: 'metadata',
    playsinline: 'true', // Important for iOS
    quality: getOptimizedQuality()
  };
}

const handleBunnyEvent = (event: unknown) => {
  // console.log('MobileBunnyAdapter event', event);
}