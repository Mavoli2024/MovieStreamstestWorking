import { useState, useEffect, type ReactNode } from 'react';
import { isCapacitorEnvironment, getPlatform } from '@/capacitor-adapter';
import {  MobileMainLayout  } from './MobileMainLayout';
import { performanceMonitor } from '@/lib/performance-monitor';

interface CapacitorAppProps {
  children: ReactNode;
}

/**
 * Root component for Capacitor mobile app
 * Detects if we're in a Capacitor environment and applies mobile-specific layout
 * Applies performance optimizations for mobile devices
 */
export function CapacitorApp({ children }: CapacitorAppProps) {
  const [isMobile, setIsMobile] = useState(false);
  
  // Detect if we're in a Capacitor environment or on a mobile device
  useEffect(() => {
    // Check for Capacitor native environment
    const capacitorNative = isCapacitorEnvironment();
    
    // Check for mobile browser (fallback detection)
    const mobileUserAgent = typeof navigator !== 'undefined' && /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
    
    // Set mobile status based on either check
    setIsMobile(capacitorNative || mobileUserAgent);
    
    // Add platform-specific class to body
    if (typeof document !== 'undefined') {
      if (capacitorNative) {
        document.body.classList.add('capacitor-native');
        document.body.classList.add(`platform-${getPlatform()}`);
      }
      
      if (mobileUserAgent) {
        document.body.classList.add('mobile-browser');
      }
      
      // Apply global optimizations for mobile devices
      if (capacitorNative || mobileUserAgent) {
        // Apply performance optimizations
        performanceMonitor.init();
        
        // Fix for iOS and Safari scrolling
        (document.body.style as any).webkitOverflowScrolling = 'touch';
        
        // Optimize animations and transitions
        document.body.classList.add('hw-accelerated');
        document.body.classList.add('transform-high-performance');
        
        // Add mobile-specific meta tags
        const createMetaTag = (name: string, content: string) => {
          if (!document.querySelector(`meta[name="${name}"]`)) {
            const meta = document.createElement('meta');
            meta.name = name;
            meta.content = content;
            document.head.appendChild(meta);
          }
        };
        
        // Add mobile viewport and theme color meta tags
        createMetaTag('viewport', 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover');
        createMetaTag('apple-mobile-web-app-capable', 'yes');
        createMetaTag('mobile-web-app-capable', 'yes');
        createMetaTag('theme-color', '#121212');
        
        // Preload our font assets
        const fontPreload = document.createElement('link');
        fontPreload.rel = 'preload';
        fontPreload.href = '/fonts/inter-var.woff2';
        fontPreload.as = 'font';
        fontPreload.type = 'font/woff2';
        fontPreload.crossOrigin = 'anonymous';
        document.head.appendChild(fontPreload);
        
        // Fix mobile viewport height (iOS Safari issue)
        const resizeHandler = () => {
          const vh = window.innerHeight * 0.01;
          document.documentElement.style.setProperty('--vh', `${vh}px`);
        };
        
        window.addEventListener('resize', resizeHandler);
        resizeHandler(); // Initial call
      }
    }
  }, []);
  
  // Add global CSS variables for mobile
  useEffect(() => {
    if (typeof document === 'undefined' || !isMobile) return;
    
    const root = document.documentElement;
    
    // Set mobile-specific CSS variables
    root.style.setProperty('--mobile-bottom-nav-height', '4rem');
    
    // Add safe area variables for notched devices
    root.style.setProperty('--safe-area-top', 'env(safe-area-inset-top, 0px)');
    root.style.setProperty('--safe-area-bottom', 'env(safe-area-inset-bottom, 0px)');
    root.style.setProperty('--safe-area-left', 'env(safe-area-inset-left, 0px)');
    root.style.setProperty('--safe-area-right', 'env(safe-area-inset-right, 0px)');
    
    // Add these classes to body
    document.body.classList.add('safe-area-padding');
    
    // Improve page load performance
    if ('connection' in navigator) {
      const conn = (navigator as any).connection;
      if (conn) {
        // Add connection type to document for styling
        const connectionType = conn.effectiveType || 'unknown';
        root.setAttribute('data-connection', connectionType);
        
        // For slow connections, optimize further
        if (connectionType === 'slow-2g' || connectionType === '2g') {
          root.classList.add('slow-connection');
          
          // Reduce image quality on slow connections
          const styleEl = document.createElement('style');
          styleEl.textContent = `
            img:not([data-high-priority]) {
              filter: blur(0) !important;
              transition: filter 0.5s ease-in-out !important;
            }
            
            .animate-pulse, .animate-spin, .animate-bounce {
              animation: none !important;
            }
          `;
          document.head.appendChild(styleEl);
        }
      }
    }
  }, [isMobile]);
  
  // Always render children directly - let AdaptiveLayout handle layout detection
  return <>{children}</>;
}