import { useEffect, useState } from 'react';
import { logger } from '../../shared/logger.js';
import { initializeCapacitor } from '@/capacitor-adapter';

/**
 * Capacitor Initializer Component
 * Handles initialization of Capacitor for mobile platforms
 */
export default function CapacitorInitializer({ children }: { children: React.ReactNode }) {
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    const init = async () => {
      try {
        // Initialize Capacitor if available
        if (window.Capacitor) {
          await initializeCapacitor();
          setInitialized(true);
        } else {
          // Web environment - no Capacitor needed
          setInitialized(true);
        }
      } catch (error) {
        logger.error('Capacitor initialization error:', { arg1: error });
        setInitialized(true); // Continue anyway
      }
    };

    init();
  }, []);

  // Show loading or children based on initialization state
  if (!initialized) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}