import React from 'react';
import { cn } from '@/lib/utils';
import {  Label  } from '@/components/ui/label';
import {  Input  } from '@/components/ui/input';
import {  Textarea  } from '@/components/ui/textarea';
import {  Button  } from '@/components/ui/button';
import {  Switch  } from '@/components/ui/switch';
import { useFormField, FormField, FormItem, FormLabel, FormControl, FormDescription, FormMessage } from '@/components/ui/form';
import type {  Controller, ControllerProps, FieldPath, FieldValues  } from 'react-hook-form';
import {  
  Check, 
  ChevronDown, 
  X,
  Eye, 
  EyeOff, 
  Search, 
  Calendar,
  User,
  Mail,
  Phone,
  Lock,
  CreditCard
 } from 'lucide-react';

/**
 * Mobile-optimized form input with touch-friendly styling
 */
export function MobileInput({
  type = 'text',
  label,
  placeholder,
  icon,
  error,
  helperText,
  className,
  containerClassName,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & {
  label?: string;
  icon?: React.ReactNode;
  error?: string;
  helperText?: string;
  containerClassName?: string;
}) {
  const [passwordVisible, setPasswordVisible] = React.useState(false);
  const isPassword = type === 'password';
  const inputType = isPassword && passwordVisible ? 'text' : type;
  
  // Generate default icon based on input type if none is provided
  const getDefaultIcon = () => {
    if (icon) return icon;
    
    switch (type) {
      case 'email':
        return <Mail className="h-5 w-5 text-muted-foreground" />;
      case 'password':
        return <Lock className="h-5 w-5 text-muted-foreground" />;
      case 'tel':
        return <Phone className="h-5 w-5 text-muted-foreground" />;
      case 'search':
        return <Search className="h-5 w-5 text-muted-foreground" />;
      case 'date':
        return <Calendar className="h-5 w-5 text-muted-foreground" />;
      case 'number':
        return <CreditCard className="h-5 w-5 text-muted-foreground" />;
      default:
        return null;
    }
  };
  
  const displayIcon = getDefaultIcon();

  return (
    <div className={cn("space-y-2", containerClassName)}>
      {label && (
        <Label 
          htmlFor={props.id} 
          className="text-sm font-medium mb-1.5 block"
        >
          {label}
        </Label>
      )}
      
      <div className={cn(
        "relative flex items-center",
        error ? "text-destructive" : ""
      )}>
        {displayIcon && (
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2 pointer-events-none">
            {displayIcon}
          </div>
        )}
        
        <Input
          type={inputType}
          className={cn(
            "mobile-input h-12 text-base",
            displayIcon && "pl-10",
            isPassword && "pr-10",
            error ? "border-destructive" : "",
            className
          )}
          placeholder={placeholder}
          {...props}
        />
        
        {isPassword && (
          <button
            type="button"
            onClick={() => setPasswordVisible(!passwordVisible)}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
            tabIndex={-1}
          >
            {passwordVisible ? (
              <EyeOff className="h-5 w-5" />
            ) : (
              <Eye className="h-5 w-5" />
            )}
          </button>
        )}
        
        {props.value && props.onChange && !isPassword && (
          <button
            type="button"
            onClick={() => {
              const event = {
                target: { value: '' }
              } as React.ChangeEvent<HTMLInputElement>;
              props.onChange && props.onChange(event);
            }}
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"
            tabIndex={-1}
          >
            <X className="h-5 w-5" />
          </button>
        )}
      </div>
      
      {(error || helperText) && (
        <p className={cn(
          "text-xs mt-1",
          error ? "text-destructive" : "text-muted-foreground"
        )}>
          {error || helperText}
        </p>
      )}
    </div>
  );
}

/**
 * Mobile-optimized form textarea with touch-friendly styling
 */
export function MobileTextarea({
  label,
  error,
  helperText,
  className,
  containerClassName,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & {
  label?: string;
  error?: string;
  helperText?: string;
  containerClassName?: string;
}) {
  return (
    <div className={cn("space-y-2", containerClassName)}>
      {label && (
        <Label 
          htmlFor={props.id} 
          className="text-sm font-medium mb-1.5 block"
        >
          {label}
        </Label>
      )}
      
      <Textarea
        className={cn(
          "mobile-input min-h-24 text-base leading-relaxed",
          error ? "border-destructive" : "",
          className
        )}
        {...props}
      />
      
      {(error || helperText) && (
        <p className={cn(
          "text-xs mt-1",
          error ? "text-destructive" : "text-muted-foreground"
        )}>
          {error || helperText}
        </p>
      )}
    </div>
  );
}

/**
 * Mobile-optimized select input with custom styling
 */
export function MobileSelect({
  label,
  options,
  value,
  onChange,
  error,
  helperText,
  className,
  containerClassName,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & {
  label?: string;
  options: Array<{ value: string; label: string }>;
  error?: string;
  helperText?: string;
  containerClassName?: string;
}) {
  const placeholderText = (props as any).placeholder || "Select an option";
  return (
    <div className={cn("space-y-2", containerClassName)}>
      {label && (
        <Label 
          htmlFor={props.id} 
          className="text-sm font-medium mb-1.5 block"
        >
          {label}
        </Label>
      )}
      
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange?.(e as any)}
          className={cn(
            "mobile-input h-12 w-full rounded-md border border-input bg-background px-3 py-2 text-base ring-offset-background",
            "focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2",
            "disabled:cursor-not-allowed disabled:opacity-50",
            "appearance-none", // Remove default styling
            error ? "border-destructive" : "",
            className
          )}
          {...props}
        >
          <option value="" disabled>
            {placeholderText}
          </option>
          {options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
        
        {/* Custom dropdown arrow */}
        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-3">
          <ChevronDown className="h-5 w-5 text-muted-foreground" />
        </div>
      </div>
      
      {(error || helperText) && (
        <p className={cn(
          "text-xs mt-1",
          error ? "text-destructive" : "text-muted-foreground"
        )}>
          {error || helperText}
        </p>
      )}
    </div>
  );
}

/**
 * Mobile-optimized checkbox with touch-friendly area
 */
export function MobileCheckbox({
  label,
  checked,
  onChange,
  error,
  helperText,
  className,
  ...props
}: Omit<React.InputHTMLAttributes<HTMLInputElement>, 'type'> & {
  label: React.ReactNode;
  error?: string;
  helperText?: string;
}) {
  return (
    <div className={cn("space-y-2", className)}>
      <div className="flex items-center space-x-3">
        <div 
          className={cn(
            "h-6 w-6 rounded-md border border-primary overflow-hidden",
            "flex items-center justify-center",
            checked ? "bg-primary" : "bg-background"
          )}
          onClick={() => onChange?.({ target: { checked: !checked } } as React.ChangeEvent<HTMLInputElement>)}
        >
          {checked && <Check className="h-4 w-4 text-primary-foreground" />}
          <input
            type="checkbox"
            className="sr-only"
            checked={checked}
            onChange={onChange}
            {...props}
          />
        </div>
        
        <Label 
          htmlFor={props.id}
          className="text-sm cursor-pointer leading-tight flex-1"
          onClick={() => onChange?.({ target: { checked: !checked } } as React.ChangeEvent<HTMLInputElement>)}
        >
          {label}
        </Label>
      </div>
      
      {(error || helperText) && (
        <p className={cn(
          "text-xs ml-9",
          error ? "text-destructive" : "text-muted-foreground"
        )}>
          {error || helperText}
        </p>
      )}
    </div>
  );
}

/**
 * Mobile-optimized submit button
 */
export function MobileSubmitButton({
  children,
  isLoading,
  loadingText = "Submitting...",
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  isLoading?: boolean;
  loadingText?: string;
}) {
  return (
    <Button
      type="submit"
      className={cn(
        "w-full h-12 text-base font-medium",
        "active:scale-[0.97] transition-transform",
        className
      )}
      disabled={isLoading || props.disabled}
      {...props}
    >
      {isLoading ? loadingText : children}
    </Button>
  );
}

/**
 * Mobile-optimized form field that works with react-hook-form
 */
export function MobileFormField<
  TFieldValues extends FieldValues = FieldValues,
  TName extends FieldPath<TFieldValues> = FieldPath<TFieldValues>
>({
  control,
  name,
  ...props
}: ControllerProps<TFieldValues, TName>) {
  return (
    <FormField
      control={control}
      name={name}
      render={({ field, fieldState, formState }) => (
        <FormItem>
          {props.render({ field, fieldState, formState })}
        </FormItem>
      )}
    />
  );
}

/**
 * Complete mobile form layout
 */
export function MobileForm({
  children,
  onSubmit,
  className,
}: {
  children: React.ReactNode;
  onSubmit?: (e: React.FormEvent<HTMLFormElement>) => void;
  className?: string;
}) {
  return (
    <form 
      onSubmit={onSubmit}
      className={cn("space-y-6", className)}
      noValidate
    >
      {children}
    </form>
  );
}