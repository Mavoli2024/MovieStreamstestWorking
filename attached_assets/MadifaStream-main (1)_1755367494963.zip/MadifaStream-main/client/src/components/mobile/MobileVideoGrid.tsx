import {  Badge  } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import type {  Video  } from '@shared/schema';
import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { preloadThumbnails } from './MobileBunnyAdapter';
import {  MobileThumbnailImage  } from './MobileThumbnailImage';

interface MobileVideoGridProps {
  videos: Video[];
  title?: string;
  showCategory?: boolean;
  className?: string;
}

/**
 * Mobile-optimized video grid component
 * Displays thumbnails in a responsive grid with optimized loading
 */
export function MobileVideoGrid({
  videos,
  title,
  showCategory = false,
  className = ''
}: MobileVideoGridProps) {
  const [, navigate] = useLocation();
    // Preload thumbnails for better performance
  useEffect(() => {
    if (videos && videos.length > 0) {
      const videoIds = videos
        .map(video => video.video_url || video.trailer_url || '')
        .filter(Boolean);
      
      preloadThumbnails(videoIds);
    }
  }, [videos]);
  
  if (!videos || videos.length === 0) {
    return (
      <div className={cn("px-4 py-6", className)}>
        {title && <h2 className="text-xl font-semibold mb-4">{title}</h2>}
        <div className="flex items-center justify-center min-h-[200px] rounded-lg bg-gray-900 bg-opacity-40">
          <p className="text-gray-400">No videos available</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className={cn("px-4 py-6", className)}>
      {title && <h2 className="text-xl font-semibold mb-4">{title}</h2>}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {videos.map((video) => (
          <div 
            key={video.id} 
            className="relative cursor-pointer group"
            onClick={() => navigate(`/watch/${video.id}`)}
          >
            <div className="rounded-lg overflow-hidden relative aspect-video">
              <MobileThumbnailImage
                src={video.thumbnail_url || video.trailer_url || video.video_url || ''}
                alt={video.title || 'Video thumbnail'}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                fallbackText={video.title}
              />
              
              {/* Premium badge */}
              {video.is_premium && (
                <div className="absolute top-2 left-2">
                  <Badge 
                    variant="outline" 
                    className="bg-orange-500 text-white border-orange-400 text-xs"
                  >
                    Premium
                  </Badge>
                </div>
              )}
              
              {/* Play button overlay */}
              <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="w-12 h-12 rounded-full bg-orange-500 bg-opacity-80 flex items-center justify-center">
                  <svg 
                    className="w-6 h-6 text-white" 
                    fill="currentColor" 
                    viewBox="0 0 24 24"
                  >
                    <path d="M8 5v14l11-7z" />
                  </svg>
                </div>
              </div>
            </div>
            
            <div className="mt-2">
              <h3 className="font-medium text-sm line-clamp-1">{video.title}</h3>
              
              {showCategory && video.id && (
                <p className="text-xs text-gray-400 mt-1">
                  {video.id}
                </p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}