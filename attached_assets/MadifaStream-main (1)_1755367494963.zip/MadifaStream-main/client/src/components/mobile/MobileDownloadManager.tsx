import React, { useState, useEffect } from 'react';
import { logger } from '@shared/logger';
import { useLocation } from 'wouter';
import {  
  Download, 
  Trash2, 
  CheckCircle, 
  AlertCircle, 
  XCircle, 
  Pause, 
  Play,
  Settings,
  Info,
  Clock 
 } from 'lucide-react';
import { 
  getAllOfflineVideos, 
  deleteOfflineVideo, 
  OfflineVideo,
  cleanupOfflineStorage,
  getTotalOfflineStorageSize
} from '@/services/offlineStorage';
import { 
  cancelDownload, 
  getActiveDownloads 
} from '@/services/videoDownloader';
import { cn } from '@/lib/utils';
import {  
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle,
  SheetDescription,
  SheetFooter,
  SheetClose
 } from '@/components/ui/sheet';
import {  
  Card, 
  CardContent 
 } from '@/components/ui/card';
import {  Button  } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {  Progress  } from '@/components/ui/progress';
import {  Badge  } from '@/components/ui/badge';
import {  Tabs, TabsContent, TabsList, TabsTrigger  } from '@/components/ui/tabs';
import {  Checkbox  } from '@/components/ui/checkbox';
import {  Label  } from '@/components/ui/label';
import {  Switch  } from '@/components/ui/switch';

interface MobileDownloadManagerProps {
  className?: string;
}

/**
 * Mobile-optimized download manager component
 * Allows users to manage their downloaded videos for offline viewing
 */
export function MobileDownloadManager({ className }: MobileDownloadManagerProps) {
  const [, navigate] = useLocation();
  const [offlineVideos, setOfflineVideos] = useState<OfflineVideo[]>([]);
  const [loading, setLoading] = useState(true);
  const [totalStorageSize, setTotalStorageSize] = useState(0);
  const [activeTab, setActiveTab] = useState('all');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [videoToDelete, setVideoToDelete] = useState<OfflineVideo | null>(null);
  const [autoDeleteExpired, setAutoDeleteExpired] = useState(true);
  const [wifiOnlyDownloads, setWifiOnlyDownloads] = useState(true);
  const [showToastOnComplete, setShowToastOnComplete] = useState(true);
  const [deleteWarningOpen, setDeleteWarningOpen] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);

  // Load offline videos
  useEffect(() => {
    loadOfflineVideos();
  }, []);

  // Load all offline videos from storage
  async function loadOfflineVideos() {
    try {
      setLoading(true);
      
      // Get all videos
      const videos = await getAllOfflineVideos();
      setOfflineVideos(videos);
      
      // Get total storage size
      const size = await getTotalOfflineStorageSize();
      setTotalStorageSize(size);
      
      // Cleanup expired videos if auto-delete is enabled
      if (autoDeleteExpired) {
        const deletedCount = await cleanupOfflineStorage();
        if (deletedCount > 0) {
          // Reload data if videos were deleted
          const updatedVideos = await getAllOfflineVideos();
          setOfflineVideos(updatedVideos);
          
          const updatedSize = await getTotalOfflineStorageSize();
          setTotalStorageSize(updatedSize);
        }
      }
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Error loading offline videos:', error);
      }
    } finally {
      setLoading(false);
    }
  }

  // Handle video deletion
  async function handleDeleteVideo(video: OfflineVideo) {
    try {
      setIsUpdating(true);
      
      // If it's being downloaded, cancel the download first
      if (video.downloadState === 'downloading') {
        cancelDownload(video.id);
      }
      
      // Delete from storage
      await deleteOfflineVideo(video.id);
      
      // Update local state
      setOfflineVideos(videos => videos.filter(v => v.id !== video.id));
      
      // Update total storage size
      const newSize = totalStorageSize - (video.fileSize || 0);
      setTotalStorageSize(Math.max(0, newSize));
      
      setVideoToDelete(null);
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Error deleting video:', error);
      }
    } finally {
      setIsUpdating(false);
    }
  }

  // Handle playing a video
  function handlePlayVideo(video: OfflineVideo) {
    if (video.downloadState === 'completed') {
      // Navigate to video player with offline parameter
      navigate(`/watch/${video.id}?offline=true`);
    }
  }

  // Format file size in a human-readable format
  function formatFileSize(bytes?: number): string {
    if (!bytes) return '0 B';
    
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    
    return `${size.toFixed(1)} ${units[unitIndex]}`;
  }

  // Format the download date
  function formatDate(dateString?: string): string {
    if (!dateString) return 'Unknown';
    
    const date = new Date(dateString);
    return date.toLocaleDateString(undefined, { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  }

  // Get icon based on download state
  function getStatusIcon(state: OfflineVideo['downloadState']) {
    switch (state) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'downloading':
        return <Download className="h-5 w-5 text-primary animate-pulse" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Info className="h-5 w-5 text-muted-foreground" />;
    }
  }

  // Filter videos based on active tab
  const filteredVideos = offlineVideos.filter(video => {
    if (activeTab === 'all') return true;
    if (activeTab === 'downloaded') return video.downloadState === 'completed';
    if (activeTab === 'downloading') return video.downloadState === 'downloading';
    if (activeTab === 'failed') return video.downloadState === 'error';
    return true;
  });

  const handleDownload = (video: unknown) => {
    // console.log('MobileDownloadManager download', video);
  }

  return (
    <div className={cn("px-4 pb-24", className)}>
      {/* Header */}
      <div className="flex items-center justify-between py-4">
        <div>
          <h1 className="text-2xl font-bold">Downloads</h1>
          <p className="text-sm text-muted-foreground">
            {offlineVideos.length} videos · {formatFileSize(totalStorageSize)}
          </p>
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={() => setSettingsOpen(true)}
          className="rounded-full"
        >
          <Settings className="h-5 w-5" />
          <span className="sr-only">Download Settings</span>
        </Button>
      </div>
      
      {/* Tab navigation */}
      <Tabs
        defaultValue="all"
        value={activeTab}
        onValueChange={setActiveTab}
        className="w-full"
      >
        <div className="overflow-x-auto pb-2 -mx-4 px-4">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="all" className="rounded-full">All</TabsTrigger>
            <TabsTrigger value="downloaded" className="rounded-full">Downloaded</TabsTrigger>
            <TabsTrigger value="downloading" className="rounded-full">Downloading</TabsTrigger>
            <TabsTrigger value="failed" className="rounded-full">Failed</TabsTrigger>
          </TabsList>
        </div>
        
        {/* Empty state */}
        {filteredVideos.length === 0 && !loading && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <Download className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium">No downloads found</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Downloaded videos will appear here for offline viewing
            </p>
            <Button 
              variant="secondary" 
              className="mt-6"
              onClick={() => navigate('/browse')}
            >
              Browse videos
            </Button>
          </div>
        )}
        
        {/* Loading state */}
        {loading && (
          <div className="py-12 flex justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          </div>
        )}
        
        {/* Download list */}
        {!loading && filteredVideos.length > 0 && (
          <div className="space-y-4 mt-4">
            {filteredVideos.map(video => (
              <Card key={video.id} className="relative overflow-hidden">
                <CardContent className="p-0">
                  <div 
                    className="flex items-start p-3 gap-3 cursor-pointer touch-manipulation active:bg-accent/30 transition-colors"
                    onClick={() => handlePlayVideo(video)}
                  >
                    {/* Thumbnail */}
                    <div className="relative flex-shrink-0 w-24 h-16 rounded-md overflow-hidden">
                      <img
                        src={video.localThumbnailPath || video.thumbnailUrl}
                        alt={video.title}
                        className="w-full h-full object-cover bg-gray-800"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="2.18" ry="2.18"></rect><path d="M10 16l4-4"></path><path d="M14 16l-4-4"></path></svg>';
                        }}
                      />
                      
                      {/* Play indicator */}
                      {video.downloadState === 'completed' && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                          <Play className="h-8 w-8 text-white" />
                        </div>
                      )}
                      
                      {/* Download progress */}
                      {video.downloadState === 'downloading' && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60">
                          <span className="text-white text-xs font-bold">{video.downloadProgress}%</span>
                          <Progress 
                            value={video.downloadProgress} 
                            className="w-3/4 h-1 mt-1"
                          />
                        </div>
                      )}
                      
                      {/* Error indicator */}
                      {video.downloadState === 'error' && (
                        <div className="absolute inset-0 flex items-center justify-center bg-black/50">
                          <XCircle className="h-8 w-8 text-red-500" />
                        </div>
                      )}
                    </div>
                    
                    {/* Content */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-medium line-clamp-2 text-sm">{video.title}</h3>
                          
                          {/* Video details */}
                          <div className="flex items-center mt-1 space-x-3">
                            {/* Status */}
                            <div className="flex items-center">
                              {getStatusIcon(video.downloadState)}
                              <span className="text-xs ml-1 text-muted-foreground">
                                {video.downloadState === 'completed' ? 'Downloaded' : 
                                 video.downloadState === 'downloading' ? 'Downloading' : 
                                 video.downloadState === 'error' ? 'Failed' : 'Pending'}
                              </span>
                            </div>
                            
                            {/* File size */}
                            {video.fileSize && (
                              <span className="text-xs text-muted-foreground">
                                {formatFileSize(video.fileSize)}
                              </span>
                            )}
                            
                            {/* Quality */}
                            {video.videoQuality && (
                              <Badge variant="outline" className="text-[10px] py-0 h-4">
                                {video.videoQuality}
                              </Badge>
                            )}
                          </div>
                          
                          {/* Download date for completed downloads */}
                          {video.downloadDate && (
                            <div className="flex items-center mt-1 text-xs text-muted-foreground">
                              <Clock className="h-3 w-3 mr-1" />
                              <span>Downloaded {formatDate(video.downloadDate)}</span>
                            </div>
                          )}
                          
                          {/* Error message */}
                          {video.downloadState === 'error' && video.downloadError && (
                            <p className="text-xs text-red-500 mt-1 line-clamp-1">
                              {video.downloadError}
                            </p>
                          )}
                        </div>
                        
                        {/* Action Button */}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="flex-shrink-0 h-8 w-8 rounded-full"
                          onClick={(e) => {
                            e.stopPropagation();
                            setVideoToDelete(video);
                            setDeleteWarningOpen(true);
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Delete</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </Tabs>
      
      {/* Settings Sheet */}
      <Sheet open={settingsOpen} onOpenChange={setSettingsOpen}>
        <SheetContent side="bottom" className="rounded-t-[20px]">
          <SheetHeader className="mb-6">
            <SheetTitle>Download Settings</SheetTitle>
            <SheetDescription>
              Configure how videos are downloaded and stored on your device
            </SheetDescription>
          </SheetHeader>
          
          <div className="space-y-6">
            {/* Download quality */}
            <div>
              <h3 className="text-sm font-medium mb-2">Video Quality</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className={cn(
                  "relative border rounded-lg p-3 cursor-pointer transition-colors",
                  "data-[selected=true]:border-primary data-[selected=true]:bg-primary/10"
                )}
                data-selected="true"
                onClick={() => {}}
                >
                  <div className="font-medium text-sm">Standard (SD)</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Lower quality, less storage
                  </div>
                </div>
                
                <div className={cn(
                  "relative border rounded-lg p-3 cursor-pointer transition-colors"
                )}
                onClick={() => {}}
                >
                  <div className="font-medium text-sm">High (HD)</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Better quality, more storage
                  </div>
                </div>
              </div>
            </div>
            
            {/* Storage settings */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Storage</h3>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-delete" className="text-sm">
                    Auto-delete expired videos
                  </Label>
                  <p className="text-[11px] text-muted-foreground">
                    Remove videos that have reached their expiry date
                  </p>
                </div>
                <Switch
                  id="auto-delete"
                  checked={autoDeleteExpired}
                  onCheckedChange={setAutoDeleteExpired}
                />
              </div>
              
              <div className="py-2">
                <Label className="text-sm mb-1 block">Storage Used</Label>
                <div className="space-y-2">
                  <Progress value={(totalStorageSize / (5 * 1024 * 1024 * 1024)) * 100} className="h-2" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{formatFileSize(totalStorageSize)}</span>
                    <span>5 GB Total</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Network settings */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Network</h3>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="wifi-only" className="text-sm">
                    Download on Wi-Fi only
                  </Label>
                  <p className="text-[11px] text-muted-foreground">
                    Prevent downloads using mobile data
                  </p>
                </div>
                <Switch
                  id="wifi-only"
                  checked={wifiOnlyDownloads}
                  onCheckedChange={setWifiOnlyDownloads}
                />
              </div>
            </div>
            
            {/* Notification settings */}
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Notifications</h3>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="show-toast" className="text-sm">
                    Show download notifications
                  </Label>
                  <p className="text-[11px] text-muted-foreground">
                    Get notified when downloads complete
                  </p>
                </div>
                <Switch
                  id="show-toast"
                  checked={showToastOnComplete}
                  onCheckedChange={setShowToastOnComplete}
                />
              </div>
            </div>
          </div>
          
          <SheetFooter className="mt-6">
            <Button 
              variant="ghost" 
              className="w-full"
              onClick={() => {
                // Reset to defaults
                setAutoDeleteExpired(true);
                setWifiOnlyDownloads(true);
                setShowToastOnComplete(true);
              }}
            >
              Reset to defaults
            </Button>
            <SheetClose asChild>
              <Button className="w-full">Save Settings</Button>
            </SheetClose>
          </SheetFooter>
        </SheetContent>
      </Sheet>
      
      {/* Delete confirmation dialog */}
      <AlertDialog 
        open={deleteWarningOpen} 
        onOpenChange={setDeleteWarningOpen}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Downloaded Video?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove "{videoToDelete?.title}" from your device.
              You will need to download it again to watch offline.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              disabled={isUpdating}
              onClick={() => {
                if (videoToDelete) {
                  handleDeleteVideo(videoToDelete);
                  setDeleteWarningOpen(false);
                }
              }}
            >
              {isUpdating ? 'Deleting...' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}