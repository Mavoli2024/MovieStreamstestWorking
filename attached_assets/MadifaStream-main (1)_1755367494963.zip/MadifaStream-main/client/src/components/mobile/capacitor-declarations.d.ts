/**
 * TypeScript interface declarations for Capacitor
 * This helps with type checking when using Capacitor APIs
 */

interface CapacitorGlobal {
  isNativePlatform?: () => boolean;
  getPlatform?: () => string;
  convertFileSrc?: (filePath: string) => string;
  Plugins?: {
    App?: {
      addListener: (eventName: string, callback: (data: unknown) => void) => { remove: () => void };
    };
    StatusBar?: {
      getInfo: () => Promise<{ height: number }>;
    };
    Network?: {
      addListener: (eventName: string, callback: (data: unknown) => void) => { remove: () => void };
    };
    Filesystem?: {
      readFile: (options: { path: string; directory?: string }) => Promise<{ data: string }>;
      writeFile: (options: { path: string; data: string; directory?: string }) => Promise<void>;
    };
    Device?: {
      getInfo: () => Promise<Record<string, unknown>>;
    };
    SplashScreen?: {
      hide: () => Promise<void>;
    };
  };
}

declare global {
  interface Window {
    Capacitor?: CapacitorGlobal;
  }
}