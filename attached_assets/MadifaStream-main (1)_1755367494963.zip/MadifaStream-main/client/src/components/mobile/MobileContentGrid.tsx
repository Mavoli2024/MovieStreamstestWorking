import React, { useRef, useState, useEffect } from 'react';
import {  ChevronRight, ChevronLeft  } from 'lucide-react';
import { cn } from '@/lib/utils';
import {  MobileContentCard  } from './MobileContentCard';

// Types
interface ContentItem {
  id: number | string;
  title: string;
  thumbnailUrl: string;
  description?: string;
  duration?: number;
  rating?: number;
  isInWatchlist?: boolean;
  releaseYear?: number;
}

interface MobileContentGridProps {
  title?: string;
  items: ContentItem[];
  viewAllLink?: string;
  layout?: 'grid' | 'row' | 'featured';
  aspectRatio?: 'portrait' | 'landscape' | 'square';
  className?: string;
  onItemClick?: (item: ContentItem) => void;
  onWatchlistToggle?: (item: ContentItem) => void;
  isLoading?: boolean;
  loadingItemCount?: number;
}

/**
 * Mobile-optimized content grid for displaying movie/show cards
 * Supports horizontal scrolling rows and grid layouts
 */
export function MobileContentGrid({
  title,
  items,
  viewAllLink,
  layout = 'row',
  aspectRatio = 'portrait',
  className,
  onItemClick,
  onWatchlistToggle,
  isLoading = false,
  loadingItemCount = 6
}: MobileContentGridProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [showLeftScroll, setShowLeftScroll] = useState(false);
  const [showRightScroll, setShowRightScroll] = useState(true);
  const [isTouchScrolling, setIsTouchScrolling] = useState(false);
  
  // Check if scroll buttons should be visible
  const checkScrollButtons = () => {
    const container = scrollContainerRef.current;
    if (!container) return;
    
    const { scrollLeft, scrollWidth, clientWidth } = container;
    const isScrollable = scrollWidth > clientWidth;
    
    setShowLeftScroll(scrollLeft > 10);
    setShowRightScroll(isScrollable && scrollLeft < scrollWidth - clientWidth - 10);
  };
  
  // Update scroll button visibility on resize and content change
  useEffect(() => {
    checkScrollButtons();
    
    // Add scroll event listener
    const container = scrollContainerRef.current;
    if (container) {
      container.addEventListener('scroll', checkScrollButtons);
    }
    
    // Add resize observer
    const resizeObserver = new ResizeObserver(() => {
      checkScrollButtons();
    });
    
    if (container) {
      resizeObserver.observe(container);
    }
    
    return () => {
      container?.removeEventListener('scroll', checkScrollButtons);
      resizeObserver.disconnect();
    };
  }, [items, isLoading]);
  
  // Scroll left/right
  const scrollLeft = () => {
    const container = scrollContainerRef.current;
    if (!container) return;
    
    const scrollAmount = container.clientWidth * 0.75;
    container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
  };
  
  const scrollRight = () => {
    const container = scrollContainerRef.current;
    if (!container) return;
    
    const scrollAmount = container.clientWidth * 0.75;
    container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
  };
  
  // Handle touch start/end for scroll buttons visibility
  const handleTouchStart = () => {
    setIsTouchScrolling(true);
  };
  
  const handleTouchEnd = () => {
    setTimeout(() => setIsTouchScrolling(false), 200);
  };
  
  // Generate skeleton items for loading state
  const renderSkeletonItems = () => {
    return Array(loadingItemCount)
      .fill(0)
      .map((_, index) => (
        <div 
          key={`skeleton-${index}`}
          className={cn(
            "bg-gray-800 animate-pulse rounded-lg overflow-hidden",
            layout === 'grid' ? 'w-full' : aspectRatio === 'landscape' ? 'min-w-[250px]' : 'min-w-[140px]',
            aspectRatio === 'landscape' ? 'aspect-video' : aspectRatio === 'square' ? 'aspect-square' : 'aspect-[2/3]'
          )}
        />
      ));
  };
  
  // Determine the content layout class
  const getContentLayoutClass = () => {
    switch (layout) {
      case 'grid':
        return 'grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3';
      case 'row':
        return 'flex gap-3 overflow-x-auto scrollbar-hide snap-x snap-mandatory';
      case 'featured':
        return 'flex flex-col gap-4';
      default:
        return 'flex gap-3 overflow-x-auto scrollbar-hide';
    }
  };
  
  // Determine card size based on layout and aspect ratio
  const getCardSizeClass = () => {
    if (layout === 'grid') return 'w-full';
    
    switch (aspectRatio) {
      case 'landscape':
        return 'min-w-[250px] sm:min-w-[280px] md:min-w-[320px] flex-shrink-0 snap-start';
      case 'square':
        return 'min-w-[160px] sm:min-w-[180px] md:min-w-[200px] flex-shrink-0 snap-start';
      case 'portrait':
      default:
        return 'min-w-[140px] sm:min-w-[160px] md:min-w-[180px] flex-shrink-0 snap-start';
    }
  };
  
  return (
    <div className={cn("space-y-3", className)}>
      {/* Section Header */}
      {title && (
        <div className="flex items-center justify-between px-4 sm:px-6">
          <h2 className="text-lg font-semibold">{title}</h2>
          {viewAllLink && (
            <a 
              href={viewAllLink} 
              className="text-sm text-primary hover:underline flex items-center"
            >
              View all
              <ChevronRight className="w-4 h-4 ml-1" />
            </a>
          )}
        </div>
      )}
      
      {/* Content Row */}
      <div className="relative">
        {/* Left Scroll Button */}
        {layout === 'row' && showLeftScroll && !isTouchScrolling && (
          <button
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-background/80 hover:bg-background/90 backdrop-blur rounded-full p-1 shadow-md transform transition-transform active:scale-90"
            onClick={scrollLeft}
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        )}
        
        {/* Content Container */}
        <div
          ref={scrollContainerRef}
          className={cn(
            getContentLayoutClass(),
            layout === 'row' ? 'px-4 sm:px-6 py-1 -mx-4 sm:-mx-6' : 'px-4 sm:px-6',
            "touch-pan-x"
          )}
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
        >
          {/* Render content or skeleton based on loading state */}
          {isLoading
            ? renderSkeletonItems()
            : items.map((item) => (
                <div key={item.id} className={getCardSizeClass()}>
                  <MobileContentCard
                    {...item}
                    aspectRatio={aspectRatio}
                    onClick={() => onItemClick?.(item)}
                    onWatchlistToggle={
                      onWatchlistToggle ? () => onWatchlistToggle(item) : undefined
                    }
                  />
                </div>
              ))}
        </div>
        
        {/* Right Scroll Button */}
        {layout === 'row' && showRightScroll && !isTouchScrolling && (
          <button
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-background/80 hover:bg-background/90 backdrop-blur rounded-full p-1 shadow-md transform transition-transform active:scale-90"
            onClick={scrollRight}
            aria-label="Scroll right"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        )}
      </div>
    </div>
  );
}