import {  Button  } from "@/components/ui/button";
import {  ThumbnailImage  } from "@/components/ui/thumbnail-image";
import {  Check, Play, Plus, X  } from "lucide-react";
import { useEffect, useState, useRef } from "react";
import {  Link  } from "wouter";
import type { Database } from "@/types/database-generated.types";
import { adaptVideoForUI } from "@/lib/type-adapters";
import { UIVideo } from "@/lib/type-adapters";

// Use the UI-friendly video type
type Video = Database['public']['Tables']['videos']['Row'];

interface VideoDetailModalProps {
  video: Video;
  isInWatchlist?: boolean;
  onAddToWatchlist?: (videoId: string) => void;
  onRemoveFromWatchlist?: (videoId: string) => void;
  onClose: () => void;
  relatedVideos?: Video[];
}

export function VideoDetailModal({
  video: rawVideo,
  isInWatchlist = false,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  onClose,
  relatedVideos = []
}: VideoDetailModalProps) {
  // Ensure video has all required fields with proper types
  const video = adaptVideoForUI(rawVideo);
  const [similarVideos, setSimilarVideos] = useState<UIVideo[]>([]);
  const modalRef = useRef<HTMLDivElement>(null);

  // Handle watchlist toggle
  const handleWatchlistToggle = () => {
    if (isInWatchlist && onRemoveFromWatchlist) {
      onRemoveFromWatchlist(video.id);
    } else if (onAddToWatchlist) {
      onAddToWatchlist(video.id);
    }
  };

  // Close on escape key
  useEffect(() => {
    modalRef.current?.focus();
    const handleEscKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    
    document.addEventListener('keydown', handleEscKey);
    
    return () => {
      document.removeEventListener('keydown', handleEscKey);
    };
  }, [onClose]);

  // Set similar videos, default to provided or empty array
  useEffect(() => {
    // Adapt all related videos to ensure they have proper types
    const adaptedRelatedVideos = relatedVideos.map(video => adaptVideoForUI(video));
    setSimilarVideos(adaptedRelatedVideos.slice(0, 6));
  }, [relatedVideos]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50 overflow-y-auto" onClick={onClose}>
      <div
        ref={modalRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="video-detail-modal-title"
        tabIndex={-1}
        className="bg-card rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto my-8 outline-none"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative">
          <ThumbnailImage
            src={video.thumbnail_url || ''}
            alt={video.title}
            title={video.title}
            className="w-full h-64 md:h-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent"></div>
          
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-4 right-4 text-white hover:text-primary text-2xl"
            onClick={onClose}
          >
            <X />
          </Button>
          
          <div className="absolute bottom-4 left-4">
            <h2 id="video-detail-modal-title" className="text-3xl font-bold mb-2">{video.title}</h2>
            <div className="flex flex-wrap gap-4 mb-4">
              <Link href={`/watch/${video.id}`}>
                <a>
                  <Button className="bg-primary hover:bg-red-700 text-white py-2 px-6 rounded flex items-center gap-2 font-medium">
                    <Play className="h-4 w-4" />
                    Play
                  </Button>
                </a>
              </Link>
              <Button 
                variant="secondary"
                className="bg-gray-700 bg-opacity-70 hover:bg-opacity-90 text-white py-2 px-6 rounded flex items-center gap-2 font-medium"
                onClick={handleWatchlistToggle}
              >
                {isInWatchlist ? <Check className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                {isInWatchlist ? "In My List" : "My List"}
              </Button>
            </div>
          </div>
        </div>
        
        <div className="p-6">
          <div className="flex items-center text-sm mb-4">
            <span className="text-green-500 mr-3">95% Match</span>
            <span className="mr-3">{video.release_year}</span>
            <span className="border border-gray-600 px-1 mr-3">{video.age_rating}</span>
            <span className="mr-3">
              {Math.floor((video.duration_minutes || 0))}h {Math.round((((video.duration_minutes || 0) % 1) * 60))}m
            </span>
            <span>HD</span>
          </div>
          
          <p className="text-gray-300 mb-6">{video.description}</p>
          
          {/* Use type assertion to handle cast property */}
          {video.cast && Array.isArray(video.cast) && video.cast.length > 0 && (
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-2">Cast</h3>
              <p className="text-gray-400">{video.cast.join(', ')}</p>
            </div>
          )}
          
          {video.director && (
            <div className="mb-6">
              <h3 className="text-lg font-medium mb-2">Director</h3>
              <p className="text-gray-400">{video.director}</p>
            </div>
          )}
          
          {video.genres && Array.isArray(video.genres) && video.genres.length > 0 && (
            <div>
              <h3 className="text-lg font-medium mb-2">Genres</h3>
              <div className="flex flex-wrap gap-2">
                {video.genres.map((genre, index) => (
                  <span key={index} className="bg-gray-800 text-gray-300 px-3 py-1 rounded-full text-sm">
                    {genre}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {similarVideos.length > 0 && (
            <div className="mt-8">
              <h3 className="text-lg font-medium mb-4">More Like This</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                {similarVideos.map(similar => (
                  <div key={similar.id} className="content-card">
                    <ThumbnailImage
                      src={similar.thumbnail_url || ''}
                      alt={similar.title}
                      title={similar.title}
                      className="w-full h-28 rounded"
                    />
                    <div className="flex justify-between items-center mt-1">
                      <div className="flex items-center">
                        <span className="text-xs text-green-500 mr-1">91%</span>
                        <span className="text-xs border border-gray-600 px-0.5">{similar.age_rating}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-6 w-6 text-xs text-gray-400 hover:text-white"
                        onClick={(e) => {
                          e.stopPropagation();
                          onAddToWatchlist && onAddToWatchlist(similar.id);
                        }}
                      >
                        <Plus className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
