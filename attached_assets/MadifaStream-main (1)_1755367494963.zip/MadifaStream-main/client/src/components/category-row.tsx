import {  Button  } from "@/components/ui/button";
import {  ChevronLeft, ChevronRight  } from "lucide-react";
import { useRef } from "react";
import {  VideoGridCard  } from "./video/VideoGridCard";
import {  VideoFeaturedCard  } from "./video/VideoFeaturedCard";
import type { Database } from "@/types/database-generated.types";

// Use Supabase types instead of schema types
type Video = Database['public']['Tables']['videos']['Row'];
type Watchlist = Database['public']['Tables']['watchlist']['Row'];

interface CategoryRowProps {
  title: string;
  videos: Video[];
  isContinueWatching?: boolean;
  watchProgress?: Record<string, number>;
  watchlist?: Watchlist[];
  onAddToWatchlist?: (videoId: string) => void;
  onRemoveFromWatchlist?: (videoId: string) => void;
  variant?: 'grid' | 'featured';
}

export function CategoryRow({
  title,
  videos,
  isContinueWatching = false,
  watchProgress = {},
  watchlist = [],
  onAddToWatchlist,
  onRemoveFromWatchlist,
  variant = 'grid',
}: CategoryRowProps) {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({
        left: -600,
        behavior: "smooth",
      });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({
        left: 600,
        behavior: "smooth",
      });
    }
  };

  if (videos.length === 0) {
    return null; // Don't render empty categories
  }

  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        <h2 className="text-xl font-medium mb-4">{title}</h2>

        <div className="relative">
          <div
            ref={scrollContainerRef}
            className="category-scroll flex space-x-4 overflow-x-auto py-2 -mx-4 px-4"
          >
            {videos.map((video, idx) => (
              variant === 'featured' ? (
                <div key={video.id} className="hidden md:block min-w-[400px] max-w-[700px] mr-6">
                  <VideoFeaturedCard video={video} />
                </div>
              ) : (
                <VideoGridCard
                  key={video.id}
                  video={video}
                  progress={isContinueWatching ? watchProgress[video.id] : undefined}
                  isContinueWatching={isContinueWatching}
                />
              )
            ))}
          </div>

          { videos.length > 4 && (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white rounded-full h-10 w-10 hidden md:flex items-center justify-center"
                onClick={scrollLeft}
              >
                <ChevronLeft className="h-6 w-6" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black bg-opacity-50 text-white rounded-full h-10 w-10 hidden md:flex items-center justify-center"
                onClick={scrollRight}
              >
                <ChevronRight className="h-6 w-6" />
              </Button>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
