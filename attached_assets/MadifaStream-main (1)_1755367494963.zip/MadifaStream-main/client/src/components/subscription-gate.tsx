import {  Button  } from "@/components/ui/button";
import { useSubscription } from "@/hooks/use-subscription";
import {  LockIcon, Sparkles  } from "lucide-react";
import type {  JSXElementConstructor, Key, ReactElement, ReactNode, ReactPortal  } from "react";
import {  Link  } from "wouter";
import MADIFA_LOGO_URL from '../assets/madifa_logo.png';

interface SubscriptionGateProps {
  children: ReactNode;
  isTrailer?: boolean;
}

/**
 * Enhanced component that restricts content based on subscription tier with improved verification.
 * If the user is on the free tier, they can only see trailers,
 * otherwise they need to upgrade to premium.
 */
export function SubscriptionGate({ children, isTrailer = false }: SubscriptionGateProps) {
  const { canWatchFullContent, premiumPlan } = useSubscription();
  
  // Allow access to trailers for everyone
  if (isTrailer) {
    return <>{children}</>;
  }
  
  // For non-trailers, verify premium access
  // This calls our enhanced verification function that double-checks login and premium status
  if (canWatchFullContent()) {
    return <>{children}</>;
  }
  
  // Show upgrade message with improved marketing for Madifa premium
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center bg-gradient-to-b from-black/80 via-primary/10 to-black/80 rounded-lg border border-secondary/30 shadow-lg min-h-[300px]">
      <div className="absolute top-0 left-0 w-full h-full bg-center opacity-5 rounded-lg" style={{backgroundImage: `url(${MADIFA_LOGO_URL})`}}></div>
      
      <div className="relative z-10">
        <div className="flex justify-center mb-4">
          <img 
            src={MADIFA_LOGO_URL} 
            alt="Madifa" 
            className="h-20 w-20 rounded-full shadow-lg ring-2 ring-secondary" 
          />
        </div>
        
        <LockIcon className="w-12 h-12 text-secondary mx-auto mb-4" />
        <h2 className="text-2xl font-bold mb-2 text-white">Premium Content</h2>
        <p className="text-gray-300 mb-6 max-w-md">
          Experience the best of South African cinema with Madifa Premium!
          Unlock our full library of exclusive movies and shows for only R59/month.
        </p>
        
        <div className="flex flex-col gap-4 items-center">
          <div className="bg-gradient-to-r from-primary/20 to-primary/30 p-5 rounded-lg mb-4 backdrop-blur-sm border border-secondary/20">
            <h3 className="text-lg font-semibold flex items-center gap-2 text-white">
              <Sparkles className="h-5 w-5 text-secondary" />
              Madifa Premium ({premiumPlan ? `R${Number(premiumPlan.price) / 100}/month` : 'R59/month'})
            </h3>
            <ul className="mt-3 text-sm text-gray-200 text-left">
              {premiumPlan?.features.map((feature: string | number | boolean | ReactElement<any, string | JSXElementConstructor<any>> | Iterable<ReactNode> | ReactPortal | null | undefined, i: Key | null | undefined) => (
                <li key={i} className="flex items-start gap-2 mb-2 bg-primary/20 p-2 rounded">
                  <span className="text-secondary">✓</span>
                  <span>{feature}</span>
                </li>
              ))}
              {!premiumPlan && (
                <>
                  <li className="flex items-start gap-2 mb-2 bg-primary/20 p-2 rounded">
                    <span className="text-secondary">✓</span>
                    <span>Access to all exclusive Madifa content</span>
                  </li>
                  <li className="flex items-start gap-2 mb-2 bg-primary/20 p-2 rounded">
                    <span className="text-secondary">✓</span>
                    <span>No advertisements</span>
                  </li>
                  <li className="flex items-start gap-2 mb-2 bg-primary/20 p-2 rounded">
                    <span className="text-secondary">✓</span>
                    <span>HD video quality on all devices</span>
                  </li>
                  <li className="flex items-start gap-2 mb-2 bg-primary/20 p-2 rounded">
                    <span className="text-secondary">✓</span>
                    <span>Support South African filmmakers</span>
                  </li>
                </>
              )}
            </ul>
          </div>
          
          <Link href="/subscription">
            <Button className="bg-secondary hover:bg-secondary/90 text-white font-semibold px-8 py-2 shadow-lg">
              Upgrade to Premium
            </Button>
          </Link>
          
          <p className="text-xs text-gray-400 mt-2">
            Secured by PayFast - No long-term contracts, cancel anytime
          </p>
        </div>
      </div>
    </div>
  );
}