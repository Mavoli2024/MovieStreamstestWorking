/**
 * Form Textarea Component
 * 
 * A specialized textarea component that integrates with our form system
 * and provides consistent styling, error handling, and accessibility features.
 */

import React, { forwardRef } from 'react';
import {  
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
 } from '@/components/ui/form';
import {  Textarea  } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import {  UseFormReturn  } from 'react-hook-form';
import {  FormError  } from './enhanced-form';

interface FormTextareaProps extends Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, 'form'> {
  form: UseFormReturn<Record<string, unknown>>;
  name: string;
  label?: string;
  helperText?: string;
  showErrorMessage?: boolean;
  containerClassName?: string;
  isLoading?: boolean;
  requiredIndicator?: boolean;
  characterCount?: boolean;
  maxLength?: number;
}

/**
 * Enhanced form textarea with consistent styling and error handling
 */
export const FormTextarea = forwardRef<HTMLTextAreaElement, FormTextareaProps>(
  ({
    form,
    name,
    label,
    helperText,
    showErrorMessage = true,
    containerClassName,
    isLoading,
    requiredIndicator = false,
    characterCount = false,
    maxLength,
    className,
    disabled,
    ...props
  }, ref) => {
    return (
      <FormField
        control={form.control}
        name={name}
        render={({ field, fieldState }) => {
          // Get current character count for the field
          const currentLength = String(field.value || '').length;
          
          return (
            <FormItem className={cn(containerClassName)}>
              {label && (
                <FormLabel className="flex items-center space-x-1">
                  <span>{label}</span>
                  {requiredIndicator && (
                    <span className="text-destructive">*</span>
                  )}
                </FormLabel>
              )}
              
              <FormControl>
                <Textarea
                  {...props}
                  ref={ref}
                  value={field.value as string}
                  name={field.name}
                  onBlur={field.onBlur}
                  onChange={field.onChange}
                  className={cn(
                    fieldState.error && "border-destructive focus-visible:ring-destructive/30",
                    isLoading && "opacity-70",
                    className
                  )}
                  disabled={disabled || isLoading}
                  maxLength={maxLength}
                />
              </FormControl>
              
              {/* Character count */}
              {characterCount && (
                <div className="flex justify-end">
                  <p className={cn(
                    "text-xs text-muted-foreground mt-1",
                    maxLength && currentLength >= maxLength * 0.9 && "text-amber-500",
                    maxLength && currentLength >= maxLength && "text-destructive"
                  )}>
                    {currentLength}{maxLength ? `/${maxLength}` : ""}
                  </p>
                </div>
              )}
              
              {/* Helper text */}
              {helperText && !fieldState.error && (
                <p className="text-muted-foreground text-xs mt-1">
                  {helperText}
                </p>
              )}
              
              {/* Error message */}
              {showErrorMessage && fieldState.error?.message && (
                <FormMessage />
              )}
            </FormItem>
          );
        }}
      />
    );
  }
);

FormTextarea.displayName = 'FormTextarea';

/**
 * Standalone textarea component with error handling but without form integration
 */
interface StandaloneTextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string;
  error?: string;
  helperText?: string;
  containerClassName?: string;
  isLoading?: boolean;
  requiredIndicator?: boolean;
  characterCount?: boolean;
  maxLength?: number;
}

export const StandaloneTextarea = forwardRef<HTMLTextAreaElement, StandaloneTextareaProps>(
  ({
    label,
    error,
    helperText,
    containerClassName,
    isLoading,
    requiredIndicator = false,
    characterCount = false,
    maxLength,
    className,
    disabled,
    value = '',
    ...props
  }, ref) => {
    // Get current character count
    const currentLength = String(value).length;
    
    return (
      <div className={cn("space-y-1.5", containerClassName)}>
        {label && (
          <div className="flex items-center space-x-1 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
            <span>{label}</span>
            {requiredIndicator && (
              <span className="text-destructive">*</span>
            )}
          </div>
        )}
        
        <Textarea
          {...props}
          ref={ref}
          className={cn(
            error && "border-destructive focus-visible:ring-destructive/30",
            isLoading && "opacity-70",
            className
          )}
          disabled={disabled || isLoading}
          value={value}
          maxLength={maxLength}
        />
        
        {/* Character count */}
        {characterCount && (
          <div className="flex justify-end">
            <p className={cn(
              "text-xs text-muted-foreground",
              maxLength && currentLength >= maxLength * 0.9 && "text-amber-500",
              maxLength && currentLength >= maxLength && "text-destructive"
            )}>
              {currentLength}{maxLength ? `/${maxLength}` : ""}
            </p>
          </div>
        )}
        
        {/* Helper text */}
        {helperText && !error && (
          <p className="text-muted-foreground text-xs">
            {helperText}
          </p>
        )}
        
        {/* Error message */}
        {error && <FormError message={error} />}
      </div>
    );
  }
);

StandaloneTextarea.displayName = 'StandaloneTextarea';