/**
 * Form Wrapper Component
 * 
 * A unified wrapper component that provides consistent styling, layout,
 * and functionality for all forms across the application.
 * Follows SSOT and DRY principles for form design.
 */

import React from 'react';
import { cn } from '@/lib/utils';
import {  Button  } from '@/components/ui/button';
import {  Loader2  } from 'lucide-react';

interface FormWrapperProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  className?: string;
  onSubmit?: (e: React.FormEvent) => void;
  isLoading?: boolean;
  submitText?: string;
  showSubmitButton?: boolean;
  submitButtonProps?: React.ComponentProps<typeof Button>;
  header?: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

const sizeClasses = {
  sm: 'max-w-sm',
  md: 'max-w-md',
  lg: 'max-w-lg',
  xl: 'max-w-xl'
};

export function FormWrapper({
  children,
  title,
  subtitle,
  className,
  onSubmit,
  isLoading = false,
  submitText = 'Submit',
  showSubmitButton = true,
  submitButtonProps,
  header,
  footer,
  size = 'md',
  ...props
}: FormWrapperProps) {
  return (
    <div className={cn("w-full mx-auto", sizeClasses[size])}>
      <form 
        onSubmit={onSubmit}
        className={cn("form-container", className)}
        {...props}
      >
        {/* Custom Header */}
        {header}
        
        {/* Default Header */}
        {(title || subtitle) && !header && (
          <div className="form-header">
            {title && (
              <h1 className="form-title">
                {title}
              </h1>
            )}
            {subtitle && (
              <p className="form-subtitle">
                {subtitle}
              </p>
            )}
          </div>
        )}

        {/* Form Content */}
        <div className="space-y-6">
          {children}
        </div>

        {/* Submit Button */}
        {showSubmitButton && (
          <div className="mt-8">
            <Button
              type="submit"
              disabled={isLoading}
              className="form-button"
              {...submitButtonProps}
            >
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                submitText
              )}
            </Button>
          </div>
        )}

        {/* Custom Footer */}
        {footer}
      </form>
    </div>
  );
}

/**
 * Form Section Component
 * 
 * Used to group related form fields within a form
 */
interface FormSectionProps {
  children: React.ReactNode;
  title?: string;
  subtitle?: string;
  className?: string;
}

export function FormSection({
  children,
  title,
  subtitle,
  className
}: FormSectionProps) {
  return (
    <div className={cn("profile-section", className)}>
      {(title || subtitle) && (
        <div className="mb-4">
          {title && (
            <h3 className="profile-section-header">
              {title}
            </h3>
          )}
          {subtitle && (
            <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
              {subtitle}
            </p>
          )}
        </div>
      )}
      <div className="space-y-4">
        {children}
      </div>
    </div>
  );
}

/**
 * Form Divider Component
 * 
 * Provides visual separation between form sections
 */
interface FormDividerProps {
  text?: string;
  className?: string;
}

export function FormDivider({ text, className }: FormDividerProps) {
  return (
    <div className={cn("form-divider", className)}>
      {text && (
        <span className="form-divider-text">
          {text}
        </span>
      )}
    </div>
  );
}

/**
 * Form Actions Component
 * 
 * Wrapper for form action buttons with consistent spacing
 */
interface FormActionsProps {
  children: React.ReactNode;
  className?: string;
  orientation?: 'horizontal' | 'vertical';
}

export function FormActions({ 
  children, 
  className, 
  orientation = 'horizontal' 
}: FormActionsProps) {
  return (
    <div className={cn(
      "mt-8",
      orientation === 'horizontal' ? "flex gap-4" : "space-y-4",
      className
    )}>
      {children}
    </div>
  );
}
