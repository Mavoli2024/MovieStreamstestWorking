/**
 * Enhanced Form Component
 * 
 * A wrapper around react-hook-form that provides:
 * - Built-in error handling
 * - Loading states
 * - Form-level error messages
 * - Consistent styling
 */

import React, { useState } from 'react';
import { useForm, UseFormReturn, FieldValues, SubmitHandler, UseFormProps } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import type {  ZodSchema  } from 'zod';
import {  AlertCircle, Loader2  } from 'lucide-react';
import {  Form  } from '@/components/ui/form';
import {  Alert, AlertDescription  } from '@/components/ui/alert';
import { handleValidationError } from '@/lib/form-validation';

interface EnhancedFormProps<TFormValues extends FieldValues> {
  children: (form: UseFormReturn<TFormValues>) => React.ReactNode;
  onSubmit: SubmitHandler<TFormValues>;
  schema?: ZodSchema<any>;
  defaultValues?: UseFormProps<TFormValues>['defaultValues'];
  id?: string;
  className?: string;
  resetOnSuccess?: boolean;
  submitOnEnter?: boolean;
}

/**
 * EnhancedForm component with improved error handling and loading state
 */
export function EnhancedForm<TFormValues extends FieldValues>({
  children,
  onSubmit,
  schema,
  defaultValues,
  id,
  className = '',
  resetOnSuccess = false,
  submitOnEnter = true,
}: EnhancedFormProps<TFormValues>) {
  const [formError, setFormError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize form with optional schema validation
  const form = useForm<TFormValues>({
    defaultValues,
    resolver: schema ? zodResolver(schema as any) : undefined,
  });

  const handleSubmit = async (values: TFormValues) => {
    setFormError(null);
    setIsSubmitting(true);

    try {
      await onSubmit(values);
      
      // Reset form if requested
      if (resetOnSuccess) {
        form.reset();
      }
    } catch (error) {
      // Handle errors and map them to form fields
      const errors = handleValidationError(error);
      
      // If there's a general form error, display it
      if (errors._form) {
        setFormError(errors._form);
      }
      
      // Set field-specific errors
      Object.entries(errors).forEach(([field, message]) => {
        if (field !== '_form') {
          form.setError(field as any, { 
            type: 'manual', 
            message 
          });
        }
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Enter key press if enabled
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (submitOnEnter && e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      form.handleSubmit(handleSubmit)();
    }
  };

  return (
    <Form {...form}>
      <form
        id={id}
        className={className}
        onSubmit={form.handleSubmit(handleSubmit)}
        onKeyDown={handleKeyDown}
      >
        {/* Form error message */}
        {formError && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{formError}</AlertDescription>
          </Alert>
        )}

        {/* Loading overlay */}
        {isSubmitting && (
          <div className="absolute inset-0 bg-background/50 flex items-center justify-center rounded-md z-10">
            <div className="bg-background p-4 rounded-lg shadow-lg flex items-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <span>Processing...</span>
            </div>
          </div>
        )}

        {/* Form content */}
        <div className={isSubmitting ? 'opacity-50 pointer-events-none' : ''}>
          {children(form)}
        </div>
      </form>
    </Form>
  );
}

/**
 * Simple form error component for displaying individual field errors
 */
export function FormError({ message }: { message?: string }) {
  if (!message) return null;
  
  return (
    <div className="text-destructive text-sm flex items-center gap-1.5 mt-1.5">
      <AlertCircle className="h-3.5 w-3.5" />
      <span>{message}</span>
    </div>
  );
}

/**
 * Form success message component
 */
export function FormSuccess({ message }: { message: string }) {
  if (!message) return null;
  
  return (
    <div className="bg-success/10 text-success text-sm py-2.5 px-3 rounded-md flex items-center mb-4">
      <span>{message}</span>
    </div>
  );
}