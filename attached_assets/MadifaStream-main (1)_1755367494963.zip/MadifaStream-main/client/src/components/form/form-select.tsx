/**
 * Form Select Component
 * 
 * A specialized select component that integrates with our form system
 * and provides consistent styling, error handling, and accessibility features.
 */

import React from 'react';
import {  
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
 } from '@/components/ui/form';
import {  
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue
 } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import {  UseFormReturn  } from 'react-hook-form';
import {  FormError  } from './enhanced-form';

export interface SelectOption {
  label: string;
  value: string;
  disabled?: boolean;
}

export interface SelectGroup {
  label: string;
  options: SelectOption[];
}

interface FormSelectProps {
  form: UseFormReturn<any>;
  name: string;
  label?: string;
  placeholder?: string;
  helperText?: string;
  options: SelectOption[] | SelectGroup[];
  showErrorMessage?: boolean;
  containerClassName?: string;
  selectClassName?: string;
  isLoading?: boolean;
  requiredIndicator?: boolean;
  disabled?: boolean;
  isGrouped?: boolean;
}

/**
 * Enhanced form select with consistent styling and error handling
 */
export const FormSelect: React.FC<FormSelectProps> = ({
  form,
  name,
  label,
  placeholder = "Select an option",
  helperText,
  options,
  showErrorMessage = true,
  containerClassName,
  selectClassName,
  isLoading,
  requiredIndicator = false,
  disabled,
  isGrouped = false,
}) => {
  // Check if options are grouped
  const optionsAreGrouped = isGrouped || 'options' in options[0];
  
  return (
    <FormField
      control={form.control}
      name={name}
      render={({ field, fieldState }) => (
        <FormItem className={cn(containerClassName)}>
          {label && (
            <FormLabel className="flex items-center space-x-1">
              <span>{label}</span>
              {requiredIndicator && (
                <span className="text-destructive">*</span>
              )}
            </FormLabel>
          )}
          
          <FormControl>
            <Select
              disabled={disabled || isLoading}
              onValueChange={(val) => field.onChange(val)}
              defaultValue={field.value}
              value={field.value}
            >
              <SelectTrigger className={cn(
                fieldState.error && "border-destructive focus:ring-destructive/30",
                isLoading && "opacity-70",
                selectClassName
              )}>
                <SelectValue placeholder={placeholder} />
              </SelectTrigger>
              
              <SelectContent>
                {optionsAreGrouped ? (
                  // Render grouped options
                  (options as SelectGroup[]).map((group, groupIndex) => (
                    <SelectGroup key={groupIndex}>
                      <div className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
                        {group.label}
                      </div>
                      {group.options.map((option, optionIndex) => (
                        <SelectItem
                          key={`${groupIndex}-${optionIndex}`}
                          value={option.value}
                          disabled={option.disabled}
                        >
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  ))
                ) : (
                  // Render flat options
                  (options as SelectOption[]).map((option, index) => (
                    <SelectItem
                      key={index}
                      value={option.value}
                      disabled={option.disabled}
                    >
                      {option.label}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </FormControl>
          
          {/* Helper text */}
          {helperText && !fieldState.error && (
            <p className="text-muted-foreground text-xs mt-1">
              {helperText}
            </p>
          )}
          
          {/* Error message */}
          {showErrorMessage && fieldState.error?.message && (
            <FormMessage />
          )}
        </FormItem>
      )}
    />
  );
};

/**
 * Standalone select component with error handling but without form integration
 */
interface StandaloneSelectProps {
  label?: string;
  placeholder?: string;
  error?: string;
  helperText?: string;
  options: SelectOption[] | SelectGroup[];
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  containerClassName?: string;
  selectClassName?: string;
  isLoading?: boolean;
  requiredIndicator?: boolean;
  disabled?: boolean;
  isGrouped?: boolean;
}

export const StandaloneSelect: React.FC<StandaloneSelectProps> = ({
  label,
  placeholder = "Select an option",
  error,
  helperText,
  options,
  value,
  onChange,
  containerClassName,
  selectClassName,
  isLoading,
  requiredIndicator = false,
  disabled,
  isGrouped = false,
}) => {
  // Check if options are grouped
  const optionsAreGrouped = isGrouped || 'options' in options[0];
  
  return (
    <div className={cn("space-y-1.5", containerClassName)}>
      {label && (
        <div className="flex items-center space-x-1 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
          <span>{label}</span>
          {requiredIndicator && (
            <span className="text-destructive">*</span>
          )}
        </div>
      )}
      
      <Select
        disabled={disabled || isLoading}
        onValueChange={(val) => onChange?.(val as any)}
        value={value}
      >
        <SelectTrigger className={cn(
          error && "border-destructive focus:ring-destructive/30",
          isLoading && "opacity-70",
          selectClassName
        )}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        
        <SelectContent>
          {optionsAreGrouped ? (
            // Render grouped options
            (options as SelectGroup[]).map((group, groupIndex) => (
              <SelectGroup key={groupIndex}>
                <div className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
                  {group.label}
                </div>
                {group.options.map((option, optionIndex) => (
                  <SelectItem
                    key={`${groupIndex}-${optionIndex}`}
                    value={option.value}
                    disabled={option.disabled}
                  >
                    {option.label}
                  </SelectItem>
                ))}
              </SelectGroup>
            ))
          ) : (
            // Render flat options
            (options as SelectOption[]).map((option, index) => (
              <SelectItem
                key={index}
                value={option.value}
                disabled={option.disabled}
              >
                {option.label}
              </SelectItem>
            ))
          )}
        </SelectContent>
      </Select>
      
      {/* Helper text */}
      {helperText && !error && (
        <p className="text-muted-foreground text-xs mt-1">
          {helperText}
        </p>
      )}
      
      {/* Error message */}
      {error && <FormError message={error} />}
    </div>
  );
};