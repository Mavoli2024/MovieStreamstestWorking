/**
 * Form Input Component
 * 
 * A specialized input component that integrates with our form system
 * and provides consistent styling, error handling, and accessibility features.
 */

import React, { forwardRef } from 'react';
import {  
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
 } from '@/components/ui/form';
import {  Input  } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import {  UseFormReturn  } from 'react-hook-form';
import { InputHTMLAttributes } from 'react';

export interface FormInputProps<TFieldValues = any> extends Omit<InputHTMLAttributes<HTMLInputElement>, 'form'> {
  form: UseFormReturn<TFieldValues>;
  name: string;
  label: string;
  description?: string;
  helperText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  showErrorMessage?: boolean;
  containerClassName?: string;
  isLoading?: boolean;
  requiredIndicator?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

// Create local interface instead of importing non-exported one
interface LocalInputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string;
}

/**
 * Enhanced form input with consistent styling and error handling
 */
export const FormInput = forwardRef<HTMLInputElement, FormInputProps>(
  ({
    form,
    name,
    label,
    description,
    helperText,
    leftIcon,
    rightIcon,
    showErrorMessage = true,
    containerClassName,
    isLoading,
    requiredIndicator = false,
    className,
    disabled,
    onChange,
    ...props
  }, ref) => {
    return (
      <FormField
        control={form.control}
        name={name}
        render={({ field, fieldState }) => {
          const handleInput = (e: React.ChangeEvent<HTMLInputElement>) => {
            field.onChange(e);
            onChange?.(e);
          };

          return (
          <FormItem className={cn("form-group", containerClassName)}>
            {label && (
              <FormLabel className="form-label flex items-center space-x-1">
                <span>{label}</span>
                {requiredIndicator && (
                  <span className="text-red-500 ml-1">*</span>
                )}
              </FormLabel>
            )}
            
            <FormControl>
              <div className="form-input-group">
                {leftIcon && (
                  <div className="form-input-icon">
                    {leftIcon}
                  </div>
                )}
                
                <Input
                  {...props}
                  ref={ref}
                  value={String(field.value ?? "")}
                  name={field.name}
                  onBlur={field.onBlur}
                  className={cn(
                    "form-input",
                    leftIcon && "form-input-with-icon",
                    rightIcon && "pr-10",
                    fieldState.error && "error",
                    isLoading && "opacity-70",
                    className
                  )}
                  disabled={disabled || isLoading}
                  onChange={handleInput}
                />
                
                {rightIcon && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 transition-colors duration-300">
                    {rightIcon}
                  </div>
                )}
                
                {isLoading && (
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full"></div>
                  </div>
                )}
              </div>
            </FormControl>
            
            {/* Helper text */}
            {helperText && !fieldState.error && (
              <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
                {helperText}
              </p>
            )}
            
            {/* Error message */}
            {showErrorMessage && fieldState.error?.message && (
              <div className="form-error">
                {fieldState.error.message}
              </div>
            )}
            
            {description && <p className="text-xs text-gray-400 mt-1">{description}</p>}
          </FormItem>
          );
        }}
      />
    );
  }
);

FormInput.displayName = 'FormInput';

/**
 * Standalone input component with error handling but without form integration
 */
interface StandaloneInputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  error?: string;
  helperText?: string;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  containerClassName?: string;
  isLoading?: boolean;
  requiredIndicator?: boolean;
}

export const StandaloneInput = forwardRef<HTMLInputElement, StandaloneInputProps>(
  ({
    label,
    error,
    helperText,
    leftIcon,
    rightIcon,
    containerClassName,
    isLoading,
    requiredIndicator = false,
    className,
    disabled,
    ...props
  }, ref) => {
    return (
      <div className={cn("form-group", containerClassName)}>
        {label && (
          <label className="form-label flex items-center space-x-1">
            <span>{label}</span>
            {requiredIndicator && (
              <span className="text-red-500 ml-1">*</span>
            )}
          </label>
        )}
        
        <div className="form-input-group">
          {leftIcon && (
            <div className="form-input-icon">
              {leftIcon}
            </div>
          )}
          
          <Input
            {...props}
            ref={ref}
            className={cn(
              "form-input",
              leftIcon && "form-input-with-icon",
              rightIcon && "pr-10",
              error && "error",
              isLoading && "opacity-70",
              className
            )}
            disabled={disabled || isLoading}
          />
          
          {rightIcon && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 transition-colors duration-300">
              {rightIcon}
            </div>
          )}
          
          {isLoading && (
            <div className="absolute right-3 top-1/2 -translate-y-1/2">
              <div className="animate-spin h-4 w-4 border-2 border-primary border-t-transparent rounded-full"></div>
            </div>
          )}
        </div>
        
        {/* Helper text */}
        {helperText && !error && (
          <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">
            {helperText}
          </p>
        )}
        
        {/* Error message */}
        {error && (
          <div className="form-error">
            {error}
          </div>
        )}
      </div>
    );
  }
);

StandaloneInput.displayName = 'StandaloneInput';