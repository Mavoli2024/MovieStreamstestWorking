import React from 'react';
import { cn } from '../../utils/cn';

interface OfflineIndicatorProps {
  show: boolean;
  className?: string;
}

export const OfflineIndicator: React.FC<OfflineIndicatorProps> = ({
  show,
  className,
}) => {
  if (!show) return null;

  return (
    <div
      className={cn(
        'fixed top-0 left-0 right-0 z-40',
        'bg-red-500 text-white px-4 py-2',
        'animate-in slide-in-from-top duration-300',
        className
      )}
    >
      <div className="flex items-center justify-center gap-2 text-sm font-medium">
        <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
        <span>You are currently offline. Some features may not work.</span>
      </div>
    </div>
  );
};
