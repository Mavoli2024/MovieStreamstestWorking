import {  TabsList, TabsTrigger  } from '@/components/ui/tabs';
import type {  ReactNode  } from 'react';

interface TabItem {
  /**
   * The value that identifies this tab within a <Tabs> component
   */
  value: string;
  /**
   * Text displayed next to the (optional) icon
   */
  label: string;
  /**
   * Optional icon rendered before the label
   */
  icon?: ReactNode;
}

interface SettingsTabsProps {
  /**
   * Array of tab definitions to render
   */
  tabs: TabItem[];
  /**
   * Extra Tailwind classes for the TabsList wrapper.
   * Useful if a parent component wants to tweak spacing.
   */
  className?: string;
}

/**
 * Enhanced SettingsTabs
 *
 * A modern, responsive tab list with excellent mobile support.
 * Features horizontal scrolling on small screens and proper grid layout on larger screens.
 * Optimized touch targets and smooth transitions for better user experience.
 */
export function SettingsTabs({ tabs, className = '' }: SettingsTabsProps) {
  return (
    <div className="w-full">
      {/* Mobile: Horizontal scrolling tabs */}
      <div className="sm:hidden">
        <div className="flex overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4">
          <TabsList className={`flex-shrink-0 inline-flex h-12 items-center justify-start rounded-lg bg-gray-100 dark:bg-gray-800 p-1 text-gray-500 dark:text-gray-400 min-w-max ${className}`.trim()}>
            {tabs.map(({ value, label, icon }) => (
              <TabsTrigger 
                key={value} 
                value={value} 
                className="inline-flex items-center justify-center whitespace-nowrap rounded-md px-4 py-2 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-white data-[state=active]:text-gray-900 data-[state=active]:shadow-sm dark:data-[state=active]:bg-gray-950 dark:data-[state=active]:text-gray-50 min-w-max touch-manipulation"
              >
                {icon}
                <span className="text-xs sm:text-sm font-medium">{label}</span>
              </TabsTrigger>
            ))}
          </TabsList>
        </div>
      </div>

      {/* Tablet and Desktop: Grid layout */}
      <div className="hidden sm:block">
        <TabsList className={`grid h-12 w-full grid-cols-2 lg:grid-cols-4 items-center justify-center rounded-lg bg-gray-100 dark:bg-gray-800 p-1 text-gray-500 dark:text-gray-400 ${className}`.trim()}>
          {tabs.map(({ value, label, icon }) => (
            <TabsTrigger 
              key={value} 
              value={value} 
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-2 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 data-[state=active]:bg-white data-[state=active]:text-gray-900 data-[state=active]:shadow-sm dark:data-[state=active]:bg-gray-950 dark:data-[state=active]:text-gray-50 h-10"
            >
              {icon}
              <span className="text-sm font-medium">{label}</span>
            </TabsTrigger>
          ))}
        </TabsList>
      </div>
    </div>
  );
}
