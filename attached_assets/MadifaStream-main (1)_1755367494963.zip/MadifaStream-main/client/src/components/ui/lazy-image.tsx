import React, { useState, useRef, useEffect, useCallback } from 'react';
import { cn } from '@/lib/utils';
import { usePerformanceMonitor } from '@/hooks/use-performance-monitor';

interface LazyImageProps extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'onLoad' | 'onError'> {
  src: string;
  alt: string;
  className?: string;
  placeholderSrc?: string;
  errorSrc?: string;
  threshold?: number;
  rootMargin?: string;
  enablePreload?: boolean;
  quality?: 'low' | 'medium' | 'high';
  onLoad?: (event: React.SyntheticEvent<HTMLImageElement>) => void;
  onError?: (event: React.SyntheticEvent<HTMLImageElement>) => void;
  priority?: boolean; // For above-the-fold images
}

interface ImageState {
  loading: boolean;
  loaded: boolean;
  error: boolean;
  inView: boolean;
}

export const LazyImage: React.FC<LazyImageProps> = ({
  src,
  alt,
  className,
  placeholderSrc,
  errorSrc,
  threshold = 0.1,
  rootMargin = '50px',
  enablePreload = true,
  quality = 'medium',
  onLoad,
  onError,
  priority = false,
  ...props
}) => {
  const imgRef = useRef<HTMLImageElement>(null);
  const [state, setState] = useState<ImageState>({
    loading: false,
    loaded: false,
    error: false,
    inView: priority, // If priority, start in view
  });

  const { observeElement, unobserveElement } = usePerformanceMonitor();

  // Generate quality-optimized URL
  const getOptimizedSrc = useCallback((originalSrc: string, imageQuality: string) => {
    // If using Bunny CDN or similar, add quality parameters
    if (originalSrc.includes('b-cdn.net')) {
      const url = new URL(originalSrc);
      switch (imageQuality) {
        case 'low':
          url.searchParams.set('width', '400');
          url.searchParams.set('quality', '60');
          break;
        case 'medium':
          url.searchParams.set('width', '800');
          url.searchParams.set('quality', '80');
          break;
        case 'high':
          url.searchParams.set('width', '1200');
          url.searchParams.set('quality', '95');
          break;
      }
      return url.toString();
    }
    return originalSrc;
  }, []);

  const optimizedSrc = getOptimizedSrc(src, quality);

  // Intersection Observer setup
  useEffect(() => {
    const imageElement = imgRef.current;
    if (!imageElement || priority) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setState(prev => ({ ...prev, inView: true }));
            observeElement(entry.target);
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold,
        rootMargin,
      }
    );

    observer.observe(imageElement);

    return () => {
      observer.unobserve(imageElement);
      if (imageElement) {
        unobserveElement(imageElement);
      }
    };
  }, [threshold, rootMargin, priority, observeElement, unobserveElement]);

  // Preload image when in view
  useEffect(() => {
    if (!state.inView || state.loaded || state.error || !enablePreload) return;

    setState(prev => ({ ...prev, loading: true }));

    const img = new Image();
    
    img.onload = () => {
      setState(prev => ({ ...prev, loading: false, loaded: true }));
    };
    
    img.onerror = () => {
      setState(prev => ({ ...prev, loading: false, error: true }));
    };

    img.src = optimizedSrc;
  }, [state.inView, state.loaded, state.error, enablePreload, optimizedSrc]);

  const handleLoad = useCallback((event: React.SyntheticEvent<HTMLImageElement>) => {
    setState(prev => ({ ...prev, loading: false, loaded: true }));
    onLoad?.(event);
  }, [onLoad]);

  const handleError = useCallback((event: React.SyntheticEvent<HTMLImageElement>) => {
    setState(prev => ({ ...prev, loading: false, error: true }));
    onError?.(event);
  }, [onError]);

  const getSrcToDisplay = () => {
    if (state.error && errorSrc) return errorSrc;
    if (!state.inView || state.loading) return placeholderSrc || 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="225"><rect width="100%" height="100%" fill="%23374151"/></svg>';
    return optimizedSrc;
  };

  return (
    <div className={cn("relative overflow-hidden", className)}>
      {/* Placeholder/Loading state */}
      {(!state.loaded || state.loading) && (
        <div className="absolute inset-0 bg-gray-700 animate-pulse flex items-center justify-center">
          {state.loading && (
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          )}
        </div>
      )}

      {/* Error state */}
      {state.error && !errorSrc && (
        <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
          <div className="text-center text-gray-400">
            <svg className="w-12 h-12 mx-auto mb-2" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
            </svg>
            <p className="text-xs">Failed to load</p>
          </div>
        </div>
      )}

      {/* Main image */}
      <img
        ref={imgRef}
        src={getSrcToDisplay()}
        alt={alt}
        onLoad={handleLoad}
        onError={handleError}
        className={cn(
          "w-full h-full object-cover transition-opacity duration-300",
          {
            "opacity-0": !state.loaded && !state.error,
            "opacity-100": state.loaded || state.error,
          }
        )}
        loading={priority ? "eager" : "lazy"}
        decoding="async"
        {...props}
      />

      {/* Progressive enhancement: WebP support detection */}
      {state.loaded && !state.error && (
        <picture className="absolute inset-0">
          <source 
            srcSet={optimizedSrc.replace(/\.(jpg|jpeg|png)$/i, '.webp')} 
            type="image/webp" 
          />
          <img
            src={optimizedSrc}
            alt={alt}
            className="w-full h-full object-cover"
            loading={priority ? "eager" : "lazy"}
            decoding="async"
          />
        </picture>
      )}
    </div>
  );
};

// Higher-order component for automatic quality selection
export const AdaptiveLazyImage: React.FC<LazyImageProps> = (props) => {
  const { isPerformanceMode } = usePerformanceMonitor();
  
  // Automatically adjust quality based on performance
  const adaptiveQuality = isPerformanceMode ? 'low' : (props.quality || 'medium');
  
  return <LazyImage {...props} quality={adaptiveQuality} />;
};

// Specific variant for video thumbnails
export const LazyVideoThumbnail: React.FC<Omit<LazyImageProps, 'errorSrc'>> = (props) => {
  const defaultErrorSrc = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" width="400" height="225" viewBox="0 0 400 225"><rect width="100%" height="100%" fill="%23374151"/><circle cx="200" cy="112.5" r="30" fill="%23ffffff" opacity="0.5"/><polygon points="190,97.5 190,127.5 215,112.5" fill="%23374151"/></svg>';
  
  return (
    <LazyImage
      {...props}
      errorSrc={defaultErrorSrc}
      quality={props.quality || 'medium'}
      className={cn("aspect-video", props.className)}
    />
  );
}; 