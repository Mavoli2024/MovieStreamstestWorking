import { useRef, useState, useEffect } from "react";
import {  Play, Pause, Volume2, VolumeX, SkipBack, SkipForward, Maximize, Minimize, X, Subtitles  } from "lucide-react";
import Hls from "hls.js";
import {  Button  } from "@/components/ui/button";
import {  Slider  } from "@/components/ui/slider";
import { cn } from "@/lib/utils";
import { logger } from '@shared/logger';

interface VideoPlayerProps {
  src: string;
  posterUrl?: string;
  onClose?: () => void;
  onProgress?: (progressSeconds: number) => void;
  initialProgress?: number;
}

export function VideoPlayer({ 
  src, 
  posterUrl, 
  onClose, 
  onProgress,
  initialProgress = 0
}: VideoPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(1);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(initialProgress);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [controlsTimeout, setControlsTimeout] = useState<NodeJS.Timeout | null>(null);

  // Format time in HH:MM:SS
  const formatTime = (timeInSeconds: number): string => {
    const hours = Math.floor(timeInSeconds / 3600);
    const minutes = Math.floor((timeInSeconds % 3600) / 60);
    const seconds = Math.floor(timeInSeconds % 60);
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };
  
  const remainingTime = Math.max(0, duration - currentTime);

  // Toggle play/pause
  const togglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
    }
  };

  // Toggle mute
  const toggleMute = () => {
    if (videoRef.current) {
      videoRef.current.muted = !isMuted;
      setIsMuted(!isMuted);
    }
  };

  // Handle volume change
  const handleVolumeChange = (value: number[]) => {
    const newVolume = value[0];
    setVolume(newVolume);
    if (videoRef.current) {
      videoRef.current.volume = newVolume;
      if (newVolume === 0) {
        setIsMuted(true);
        videoRef.current.muted = true;
      } else if (isMuted) {
        setIsMuted(false);
        videoRef.current.muted = false;
      }
    }
  };

  // Seek video
  const handleSeek = (value: number[]) => {
    const seekTime = value[0];
    setCurrentTime(seekTime);
    if (videoRef.current) {
      videoRef.current.currentTime = seekTime;
    }
  };

  // Skip backward/forward
  const skip = (seconds: number) => {
    if (videoRef.current) {
      videoRef.current.currentTime += seconds;
    }
  };

  // Toggle fullscreen
  const toggleFullscreen = () => {
    if (!containerRef.current) return;

    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => {
        setIsFullscreen(true);
      }).catch(err => {
        if (import.meta.env.DEV) {
          logger.error(`Error attempting to enable fullscreen: ${err.message}`);
        }
      });
    } else {
      document.exitFullscreen().then(() => {
        setIsFullscreen(false);
      }).catch(err => {
        if (import.meta.env.DEV) {
          logger.error(`Error attempting to exit fullscreen: ${err.message}`);
        }
      });
    }
  };

  // Hide controls after inactivity
  const resetControlsTimeout = () => {
    setShowControls(true);
    
    if (controlsTimeout) {
      clearTimeout(controlsTimeout);
    }
    
    const timeout = setTimeout(() => {
      if (isPlaying) {
        setShowControls(false);
      }
    }, 3000);
    
    setControlsTimeout(timeout);
  };

  // Effect to setup video event listeners
  useEffect(() => {
    const videoElement = videoRef.current;
    
    if (!videoElement) return;
    
    let hls: Hls | null = null;
    
    const handlePlay = () => setIsPlaying(true);
    const handlePause = () => setIsPlaying(false);
    const handleDurationChange = () => setDuration(videoElement.duration);
    const handleTimeUpdate = () => {
      setCurrentTime(videoElement.currentTime);
      if (onProgress) {
        onProgress(videoElement.currentTime);
      }
    };
    const handleVolumeChange = () => {
      setVolume(videoElement.volume);
      setIsMuted(videoElement.muted);
    };
    
    // Set initial position if provided
    if (initialProgress > 0) {
      videoElement.currentTime = initialProgress;
    }
    
    // Setup HLS if needed
    if (src.includes('.m3u8') && Hls.isSupported()) {
      hls = new Hls();
      hls.loadSource(src);
      hls.attachMedia(videoElement);
      
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        // Auto-play video when HLS is ready
        videoElement.play().catch(error => {
          if (import.meta.env.DEV) {
            logger.error("Auto-play failed after HLS manifest parsed:", { arg1: error });
          }
        });
      });
      
      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          switch(data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              if (import.meta.env.DEV) {
                logger.error("HLS network error, trying to recover...");
              }
              hls?.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              if (import.meta.env.DEV) {
                logger.error("HLS media error, trying to recover...");
              }
              hls?.recoverMediaError();
              break;
            default:
              if (import.meta.env.DEV) {
                logger.error("Fatal HLS error, cannot recover:", { arg1: data });
              }
              break;
          }
        }
      });
    } else {
      // For MP4 and other formats, just set the src directly
      // Auto-play after a small delay
      setTimeout(() => {
        videoElement.play().catch(error => {
          if (import.meta.env.DEV) {
            logger.error("Auto-play failed for MP4:", { arg1: error });
          }
        });
      }, 100);
    }
    
    // Add event listeners
    videoElement.addEventListener('play', handlePlay);
    videoElement.addEventListener('pause', handlePause);
    videoElement.addEventListener('durationchange', handleDurationChange);
    videoElement.addEventListener('timeupdate', handleTimeUpdate);
    videoElement.addEventListener('volumechange', handleVolumeChange);
    
    // Cleanup
    return () => {
      videoElement.removeEventListener('play', handlePlay);
      videoElement.removeEventListener('pause', handlePause);
      videoElement.removeEventListener('durationchange', handleDurationChange);
      videoElement.removeEventListener('timeupdate', handleTimeUpdate);
      videoElement.removeEventListener('volumechange', handleVolumeChange);
      
      // Destroy HLS instance if it exists
      if (hls) {
        hls.destroy();
      }
      
      if (controlsTimeout) {
        clearTimeout(controlsTimeout);
      }
    };
  }, [src, initialProgress, onProgress]);

  // Effect to handle document fullscreen events
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  return (
    <div 
      ref={containerRef}
      className="video-container relative flex-grow bg-black w-full h-full"
      onMouseMove={resetControlsTimeout}
    >
      <video
        ref={videoRef}
        className="w-full h-full"
        poster={posterUrl}
        onClick={togglePlay}
      >
        {/* The source element is not needed as we'll handle both HLS and MP4 in JavaScript */}
        Your browser does not support the video tag.
      </video>
      
      {onClose && (
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 right-4 text-white bg-black bg-opacity-50 hover:bg-opacity-70 z-10"
          onClick={onClose}
        >
          <X />
        </Button>
      )}
      
      <div className={cn(
        "video-controls absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black to-transparent transition-opacity",
        !showControls && "opacity-0"
      )}>
        <div className="mb-2 flex items-center justify-between text-sm text-gray-300">
          <div>{formatTime(currentTime)}</div>
          <div>-{formatTime(remainingTime)}</div>
        </div>
        
        <div className="mb-4">
          <Slider
            value={[currentTime]}
            min={0}
            max={duration || 100}
            step={1}
            onValueChange={handleSeek}
            className="video-progress"
          />
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:text-primary"
              onClick={togglePlay}
            >
              {isPlaying ? <Pause /> : <Play />}
            </Button>
            
            <div className="flex items-center space-x-2">
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:text-primary"
                onClick={toggleMute}
              >
                {isMuted ? <VolumeX /> : <Volume2 />}
              </Button>
              
              <div className="w-24 hidden sm:block">
                <Slider
                  value={[isMuted ? 0 : volume]}
                  min={0}
                  max={1}
                  step={0.1}
                  onValueChange={handleVolumeChange}
                  className="h-1"
                />
              </div>
            </div>
            
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:text-primary"
              onClick={() => skip(-10)}
            >
              <SkipBack />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:text-primary"
              onClick={() => skip(10)}
            >
              <SkipForward />
            </Button>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:text-primary"
            >
              <Subtitles />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:text-primary"
              onClick={toggleFullscreen}
            >
              {isFullscreen ? <Minimize /> : <Maximize />}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
