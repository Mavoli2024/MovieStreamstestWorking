import React from 'react';
import { useToasts } from '../../stores/uiStore';
import { cn } from '../../utils/cn';

export const ToastProvider: React.FC = () => {
  const { toasts, removeToast } = useToasts();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-50 flex flex-col gap-2 max-w-md">
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          toast={toast}
          onRemove={() => removeToast(toast.id)}
        />
      ))}
    </div>
  );
};

interface ToastProps {
  toast: {
    id: string;
    type: 'success' | 'error' | 'warning' | 'info';
    title: string;
    message?: string;
    duration?: number;
    dismissible?: boolean;
    actions?: Array<{
      label: string;
      onClick: () => void;
      variant?: 'default' | 'ghost';
    }>;
  };
  onRemove: () => void;
}

const Toast: React.FC<ToastProps> = ({ toast, onRemove }) => {
  const { type, title, message, dismissible = true, actions } = toast;

  const typeStyles = {
    success: 'bg-green-50 border-green-200 text-green-800',
    error: 'bg-red-50 border-red-200 text-red-800',
    warning: 'bg-yellow-50 border-yellow-200 text-yellow-800',
    info: 'bg-blue-50 border-blue-200 text-blue-800',
  };

  const iconStyles = {
    success: '✓',
    error: '✕',
    warning: '⚠',
    info: 'ℹ',
  };

  return (
    <div className={cn(
      'relative rounded-lg border p-4 shadow-lg transition-all duration-300',
      'animate-in slide-in-from-right-full',
      typeStyles[type]
    )}>
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 text-lg">
          {iconStyles[type]}
        </div>
        
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-sm">{title}</h4>
          {message && (
            <p className="mt-1 text-sm opacity-90">{message}</p>
          )}
          
          {actions && actions.length > 0 && (
            <div className="mt-3 flex gap-2">
              {actions.map((action, index) => (
                <button
                  key={index}
                  onClick={action.onClick}
                  className={cn(
                    'px-3 py-1 text-xs font-medium rounded transition-colors',
                    action.variant === 'ghost'
                      ? 'hover:bg-black/10'
                      : 'bg-black/10 hover:bg-black/20'
                  )}
                >
                  {action.label}
                </button>
              ))}
            </div>
          )}
        </div>
        
        {dismissible && (
          <button
            onClick={onRemove}
            className="flex-shrink-0 text-lg hover:opacity-70 transition-opacity"
            aria-label="Close toast"
          >
            ×
          </button>
        )}
      </div>
    </div>
  );
};
