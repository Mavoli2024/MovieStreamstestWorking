import { cn } from "@/lib/utils"

const skeletonStyle = {
  background: 'var(--color-skeleton)',
  borderRadius: 'var(--radius-md)',
  width: '100%',
  minHeight: '1.5em',
  margin: 'var(--space-xs) 0',
};

export function Skeleton({ style, ...props }: React.HTMLAttributes<HTMLDivElement>) {
  return <div style={{ ...skeletonStyle, ...style }} {...props} />;
}
