import React from 'react';
import { Search, Film, Wifi, AlertCircle, Users, Play } from 'lucide-react';

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon,
  title,
  description,
  action,
  className = ''
}) => {
  return (
    <div className={`flex flex-col items-center justify-center text-center py-12 px-4 ${className}`}>
      {icon && (
        <div className="mb-6 text-muted-foreground">
          {icon}
        </div>
      )}
      
      <h3 className="text-xl font-semibold mb-2 text-foreground">
        {title}
      </h3>
      
      <p className="text-muted-foreground mb-6 max-w-md">
        {description}
      </p>
      
      {action && (
        <button
          onClick={action.onClick}
          className="bg-primary text-primary-foreground px-6 py-2 rounded-md hover:bg-primary/90 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
        >
          {action.label}
        </button>
      )}
    </div>
  );
};

// Pre-built empty states for common scenarios
export const NoSearchResults: React.FC<{ query: string; onClear: () => void }> = ({ query, onClear }) => (
  <EmptyState
    icon={<Search className="w-16 h-16" />}
    title="No results found"
    description={`We couldn't find any videos matching "${query}". Try adjusting your search terms or browse our categories.`}
    action={{
      label: "Clear Search",
      onClick: onClear
    }}
  />
);

export const NoVideos: React.FC<{ onBrowse: () => void }> = ({ onBrowse }) => (
  <EmptyState
    icon={<Film className="w-16 h-16" />}
    title="No videos available"
    description="There are no videos in this category yet. Check back later or explore other categories."
    action={{
      label: "Browse Categories",
      onClick: onBrowse
    }}
  />
);

export const OfflineState: React.FC<{ onRetry: () => void }> = ({ onRetry }) => (
  <EmptyState
    icon={<Wifi className="w-16 h-16" />}
    title="You're offline"
    description="Check your internet connection and try again."
    action={{
      label: "Retry",
      onClick: onRetry
    }}
  />
);

export const ErrorState: React.FC<{ onRetry: () => void }> = ({ onRetry }) => (
  <EmptyState
    icon={<AlertCircle className="w-16 h-16" />}
    title="Something went wrong"
    description="We're having trouble loading this content. Please try again."
    action={{
      label: "Try Again",
      onClick: onRetry
    }}
  />
);

export const EmptyWatchlist: React.FC<{ onExplore: () => void }> = ({ onExplore }) => (
  <EmptyState
    icon={<Play className="w-16 h-16" />}
    title="Your watchlist is empty"
    description="Save videos to your watchlist to watch them later."
    action={{
      label: "Explore Videos",
      onClick: onExplore
    }}
  />
);

export const EmptyProfile: React.FC<{ onUpload: () => void }> = ({ onUpload }) => (
  <EmptyState
    icon={<Users className="w-16 h-16" />}
    title="No videos uploaded"
    description="You haven't uploaded any videos yet. Start sharing your content with the community."
    action={{
      label: "Upload Video",
      onClick: onUpload
    }}
  />
);

// Loading state with skeleton pattern
export const LoadingState: React.FC<{ message?: string }> = ({ message = "Loading..." }) => (
  <div className="flex flex-col items-center justify-center text-center py-12 px-4">
    <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary mb-4"></div>
    <p className="text-muted-foreground">{message}</p>
  </div>
);

// Maintenance state
export const MaintenanceState: React.FC = () => (
  <EmptyState
    icon={<AlertCircle className="w-16 h-16" />}
    title="Under Maintenance"
    description="We're performing scheduled maintenance. Please check back in a few minutes."
  />
);

// Coming soon state
export const ComingSoonState: React.FC = () => (
  <EmptyState
    icon={<Film className="w-16 h-16" />}
    title="Coming Soon"
    description="This feature is coming soon. Stay tuned for updates!"
  />
);
