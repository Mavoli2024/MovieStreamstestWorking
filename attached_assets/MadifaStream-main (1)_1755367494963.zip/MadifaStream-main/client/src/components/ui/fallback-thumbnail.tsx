
interface FallbackThumbnailProps {
  title: string;
  className?: string;
  width?: number;
  height?: number;
}

/**
 * Generates a fallback thumbnail with the movie's title initials
 * when the actual thumbnail fails to load
 */
export function FallbackThumbnail({
  title,
  className = '',
  width = 300,
  height = 169
}: FallbackThumbnailProps) {
  // Get first two letters of the title, or just the first letter if it's one character
  const initials = title.substring(0, 2).toUpperCase();

  // Generate a deterministic color based on the movie title
  const hue = Array.from(title).reduce((sum, char) => sum + char.charCodeAt(0), 0) % 360;
  const saturation = 70;
  const lightness = 25;

  const style = {
    width: width,
    height: height,
    backgroundColor: `hsl(${hue}, ${saturation}%, ${lightness}%)`,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'white',
    fontSize: Math.min(width, height) * 0.3,
    fontWeight: 'bold' as const,
    borderRadius: '4px',
    overflow: 'hidden',
  };

  return (
    <div style={style} className={className}>
      {initials}
    </div>
  );
}

/**
 * Generates a fallback image URL for a thumbnail with a gradient background
 * and the movie's initials.
 */
export function generateFallbackImageUrl(title: string): string {
  // Get first two letters of the title
  const initials = title.substring(0, 2).toUpperCase();

  // Generate a deterministic color based on the movie title
  const hue = Array.from(title).reduce((sum, char) => sum + char.charCodeAt(0), 0) % 360;

  // Create a data URL with an SVG
  const svgContent = `
    <svg xmlns="http://www.w3.org/2000/svg" width="300" height="169" viewBox="0 0 300 169">
      <defs>
        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:hsl(${hue}, 70%, 20%);stop-opacity:1" />
          <stop offset="100%" style="stop-color:hsl(${hue}, 70%, 30%);stop-opacity:1" />
        </linearGradient>
      </defs>
      <rect width="300" height="169" fill="url(#grad)" />
      <text x="150" y="95" font-family="Arial, sans-serif" font-size="60" 
        font-weight="bold" fill="white" text-anchor="middle" dominant-baseline="middle">
        ${initials}
      </text>
    </svg>
  `;

  // Convert to data URL
  return `data:image/svg+xml;base64,${btoa(svgContent)}`;
}