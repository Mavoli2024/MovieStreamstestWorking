import React from 'react';

interface SkeletonProps {
  className?: string;
}

export const Skeleton: React.FC<SkeletonProps> = ({ className = '' }) => {
  return (
    <div 
      className={`animate-pulse bg-muted rounded ${className}`}
      role="status"
      aria-label="Loading..."
    />
  );
};

export const VideoCardSkeleton: React.FC = () => {
  return (
    <div className="space-y-3">
      {/* Thumbnail skeleton */}
      <div className="aspect-video w-full">
        <Skeleton className="w-full h-full rounded-lg" />
      </div>
      
      {/* Title skeleton */}
      <div className="space-y-2">
        <Skeleton className="h-4 w-3/4" />
        <Skeleton className="h-4 w-1/2" />
      </div>
      
      {/* Metadata skeleton */}
      <div className="flex items-center space-x-2">
        <Skeleton className="h-3 w-16" />
        <Skeleton className="h-3 w-12" />
      </div>
    </div>
  );
};

export const VideoGridSkeleton: React.FC<{ count?: number }> = ({ count = 8 }) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {Array.from({ length: count }).map((_, index) => (
        <VideoCardSkeleton key={index} />
      ))}
    </div>
  );
};

export const VideoRowSkeleton: React.FC<{ count?: number }> = ({ count = 6 }) => {
  return (
    <div className="space-y-4">
      {/* Category title skeleton */}
      <Skeleton className="h-6 w-48" />
      
      {/* Horizontal scrolling video cards */}
      <div className="flex space-x-4 overflow-x-auto pb-4">
        {Array.from({ length: count }).map((_, index) => (
          <div key={index} className="flex-shrink-0 w-64">
            <VideoCardSkeleton />
          </div>
        ))}
      </div>
    </div>
  );
};

export const HeroSkeleton: React.FC = () => {
  return (
    <div className="relative w-full h-96 md:h-[500px] lg:h-[600px]">
      <Skeleton className="w-full h-full rounded-lg" />
      
      {/* Hero content overlay skeleton */}
      <div className="absolute bottom-0 left-0 right-0 p-6 md:p-8 lg:p-12 space-y-4">
        <Skeleton className="h-8 w-2/3 md:h-10 md:w-1/2" />
        <Skeleton className="h-4 w-full md:w-3/4" />
        <Skeleton className="h-4 w-4/5 md:w-2/3" />
        
        {/* Action buttons skeleton */}
        <div className="flex space-x-4 mt-6">
          <Skeleton className="h-12 w-32" />
          <Skeleton className="h-12 w-40" />
        </div>
      </div>
    </div>
  );
};

// Shimmer effect for enhanced loading animation
export const ShimmerSkeleton: React.FC<SkeletonProps> = ({ className = '' }) => {
  return (
    <div 
      className={`relative overflow-hidden bg-muted rounded ${className}`}
      role="status"
      aria-label="Loading..."
    >
      <div className="absolute inset-0 -translate-x-full animate-[shimmer_2s_infinite] bg-gradient-to-r from-transparent via-white/10 to-transparent" />
    </div>
  );
};

// Add shimmer animation to CSS
const shimmerAnimation = `
@keyframes shimmer {
  100% {
    transform: translateX(100%);
  }
}
`;

// Export animation styles to be added to CSS
export const skeletonStyles = shimmerAnimation;
