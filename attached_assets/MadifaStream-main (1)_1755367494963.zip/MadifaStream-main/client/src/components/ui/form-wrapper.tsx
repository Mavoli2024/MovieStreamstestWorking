import React from 'react';
import {  FormItem, FormControl, FormMessage  } from '@/components/ui/form';

interface SimpleFormItemProps {
  label: string;
  htmlFor?: string;
  children: React.ReactNode;
  error?: string;
}

export function SimpleFormItem({ label, htmlFor, children, error }: SimpleFormItemProps) {
  const id = htmlFor || Math.random().toString(36).substring(2, 9);
  
  return (
    <div className="space-y-2">
      <label 
        htmlFor={id} 
        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
      >
        {label}
      </label>
      {children}
      {error && <p className="text-sm font-medium text-destructive">{error}</p>}
    </div>
  );
}

interface FormFieldWrapperProps {
  label: string;
  children: React.ReactNode;
  className?: string;
}

export function FormFieldWrapper({ label, children, className }: FormFieldWrapperProps) {
  return (
    <FormItem className={className}>
      <div className="space-y-2">
        <div className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
          {label}
        </div>
        <FormControl>
          {children}
        </FormControl>
        <FormMessage />
      </div>
    </FormItem>
  );
}