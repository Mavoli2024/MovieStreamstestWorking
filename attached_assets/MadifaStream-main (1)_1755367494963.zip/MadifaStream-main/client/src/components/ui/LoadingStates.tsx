/**
 * Loading States and Skeleton Components
 * 
 * Provides comprehensive loading indicators, skeleton screens, and loading states
 * for better user experience during data fetching and processing.
 */

import React from 'react';
import { cn } from '../../utils/cn';

// Loading spinner component
export const LoadingSpinner: React.FC<{
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}> = ({ size = 'md', className = '' }) => {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
  };

  return (
    <div
      className={cn(
        'animate-spin rounded-full border-2 border-gray-300 border-t-blue-600',
        sizeClasses[size],
        className
      )}
      role="status"
      aria-label="Loading"
    >
      <span className="sr-only">Loading...</span>
    </div>
  );
};

// Skeleton base component
export const Skeleton: React.FC<{
  className?: string;
  width?: string | number;
  height?: string | number;
  rounded?: boolean;
  animate?: boolean;
}> = ({
  className = '',
  width,
  height,
  rounded = true,
  animate = true,
}) => {
  const style: React.CSSProperties = {};
  if (width) style.width = typeof width === 'number' ? `${width}px` : width;
  if (height) style.height = typeof height === 'number' ? `${height}px` : height;

  return (
    <div
      className={cn(
        'bg-gray-200 dark:bg-gray-700',
        rounded && 'rounded',
        animate && 'animate-pulse',
        className
      )}
      style={style}
      role="status"
      aria-label="Loading content"
    />
  );
};

// Video card skeleton
export const VideoCardSkeleton: React.FC<{
  className?: string;
}> = ({ className = '' }) => (
  <div className={cn('space-y-3', className)}>
    <Skeleton className="aspect-video w-full" />
    <div className="space-y-2">
      <Skeleton height={20} width="75%" />
      <Skeleton height={16} width="60%" />
      <Skeleton height={16} width="40%" />
    </div>
  </div>
);

// Video grid skeleton
export const VideoGridSkeleton: React.FC<{
  count?: number;
  className?: string;
}> = ({ count = 12, className = '' }) => (
  <div className={cn('grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6', className)}>
    {Array.from({ length: count }).map((_, index) => (
      <VideoCardSkeleton key={index} />
    ))}
  </div>
);

// Profile skeleton
export const ProfileSkeleton: React.FC<{
  className?: string;
}> = ({ className = '' }) => (
  <div className={cn('flex items-center space-x-4', className)}>
    <Skeleton className="w-12 h-12 rounded-full" />
    <div className="space-y-2">
      <Skeleton height={16} width={120} />
      <Skeleton height={14} width={80} />
    </div>
  </div>
);

// Text skeleton
export const TextSkeleton: React.FC<{
  lines?: number;
  className?: string;
}> = ({ lines = 3, className = '' }) => (
  <div className={cn('space-y-2', className)}>
    {Array.from({ length: lines }).map((_, index) => (
      <Skeleton
        key={index}
        height={16}
        width={index === lines - 1 ? '60%' : '100%'}
      />
    ))}
  </div>
);

// Button skeleton
export const ButtonSkeleton: React.FC<{
  className?: string;
}> = ({ className = '' }) => (
  <Skeleton className={cn('h-10 w-24', className)} />
);

// Navigation skeleton
export const NavigationSkeleton: React.FC<{
  className?: string;
}> = ({ className = '' }) => (
  <div className={cn('flex items-center space-x-6', className)}>
    <Skeleton width={120} height={32} />
    <div className="flex space-x-4">
      {Array.from({ length: 4 }).map((_, index) => (
        <Skeleton key={index} width={80} height={24} />
      ))}
    </div>
  </div>
);

// Page skeleton
export const PageSkeleton: React.FC<{
  showNavigation?: boolean;
  showSidebar?: boolean;
  className?: string;
}> = ({
  showNavigation = true,
  showSidebar = false,
  className = '',
}) => (
  <div className={cn('min-h-screen', className)}>
    {showNavigation && (
      <div className="border-b border-gray-200 dark:border-gray-700 p-4">
        <NavigationSkeleton />
      </div>
    )}
    
    <div className="flex">
      {showSidebar && (
        <div className="w-64 p-4 border-r border-gray-200 dark:border-gray-700">
          <div className="space-y-4">
            {Array.from({ length: 6 }).map((_, index) => (
              <Skeleton key={index} height={20} width="100%" />
            ))}
          </div>
        </div>
      )}
      
      <div className="flex-1 p-6">
        <div className="space-y-6">
          <Skeleton height={32} width="40%" />
          <TextSkeleton lines={2} />
          <VideoGridSkeleton count={8} />
        </div>
      </div>
    </div>
  </div>
);

// Loading overlay
export const LoadingOverlay: React.FC<{
  show: boolean;
  message?: string;
  className?: string;
}> = ({ show, message = 'Loading...', className = '' }) => {
  if (!show) return null;

  return (
    <div
      className={cn(
        'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50',
        className
      )}
    >
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 flex items-center space-x-4">
        <LoadingSpinner size="md" />
        <span className="text-gray-900 dark:text-gray-100">{message}</span>
      </div>
    </div>
  );
};

// Loading button
export const LoadingButton: React.FC<{
  loading?: boolean;
  disabled?: boolean;
  children: React.ReactNode;
  className?: string;
  loadingText?: string;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
}> = ({
  loading = false,
  disabled = false,
  children,
  className = '',
  loadingText = 'Loading...',
  onClick,
  type = 'button',
}) => (
  <button
    type={type}
    onClick={onClick}
    disabled={disabled || loading}
    className={cn(
      'inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md',
      'bg-blue-600 text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500',
      'disabled:opacity-50 disabled:cursor-not-allowed',
      className
    )}
  >
    {loading && (
      <LoadingSpinner size="sm" className="mr-2" />
    )}
    {loading ? loadingText : children}
  </button>
);

// Empty state component
export const EmptyState: React.FC<{
  title: string;
  description?: string;
  action?: React.ReactNode;
  icon?: React.ReactNode;
  className?: string;
}> = ({
  title,
  description,
  action,
  icon,
  className = '',
}) => (
  <div className={cn('text-center py-12', className)}>
    {icon && (
      <div className="mx-auto mb-4 text-gray-400 dark:text-gray-500">
        {icon}
      </div>
    )}
    <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-2">
      {title}
    </h3>
    {description && (
      <p className="text-gray-500 dark:text-gray-400 mb-4">
        {description}
      </p>
    )}
    {action && action}
  </div>
);

// Loading state hook
export const useLoadingState = (initialState: boolean = false) => {
  const [loading, setLoading] = React.useState(initialState);
  const [error, setError] = React.useState<string | null>(null);

  const startLoading = React.useCallback(() => {
    setLoading(true);
    setError(null);
  }, []);

  const stopLoading = React.useCallback(() => {
    setLoading(false);
  }, []);

  const setLoadingError = React.useCallback((errorMessage: string) => {
    setLoading(false);
    setError(errorMessage);
  }, []);

  const resetState = React.useCallback(() => {
    setLoading(false);
    setError(null);
  }, []);

  return {
    loading,
    error,
    startLoading,
    stopLoading,
    setLoadingError,
    resetState,
  };
};

// Suspense fallback
export const SuspenseFallback: React.FC<{
  className?: string;
}> = ({ className = '' }) => (
  <div className={cn('flex items-center justify-center p-8', className)}>
    <LoadingSpinner size="lg" />
  </div>
);

// Loading states for different scenarios
export const LoadingStates = {
  // Video player loading
  VideoPlayer: () => (
    <div className="aspect-video bg-gray-900 flex items-center justify-center">
      <LoadingSpinner size="lg" className="text-white" />
    </div>
  ),

  // Search results loading
  SearchResults: () => (
    <div className="space-y-4">
      <Skeleton height={24} width="30%" />
      <VideoGridSkeleton count={8} />
    </div>
  ),

  // Profile page loading
  ProfilePage: () => (
    <div className="space-y-6">
      <div className="flex items-center space-x-4">
        <Skeleton className="w-24 h-24 rounded-full" />
        <div className="space-y-2">
          <Skeleton height={24} width={200} />
          <Skeleton height={16} width={150} />
          <Skeleton height={16} width={100} />
        </div>
      </div>
      <div className="space-y-4">
        <Skeleton height={20} width="25%" />
        <VideoGridSkeleton count={6} />
      </div>
    </div>
  ),

  // Comments loading
  Comments: () => (
    <div className="space-y-4">
      {Array.from({ length: 5 }).map((_, index) => (
        <div key={index} className="flex space-x-3">
          <Skeleton className="w-8 h-8 rounded-full" />
          <div className="flex-1 space-y-2">
            <Skeleton height={16} width="20%" />
            <Skeleton height={14} width="80%" />
          </div>
        </div>
      ))}
    </div>
  ),

  // Sidebar loading
  Sidebar: () => (
    <div className="space-y-4">
      <Skeleton height={20} width="60%" />
      <div className="space-y-2">
        {Array.from({ length: 8 }).map((_, index) => (
          <Skeleton key={index} height={16} width="100%" />
        ))}
      </div>
    </div>
  ),
};
