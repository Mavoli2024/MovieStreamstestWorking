import { getOptimizedDimensions, preloadImage } from '@/lib/imageLoader';
import {
    BUNNY_CDN_HOST,
    generateSvgThumbnail,
    getBestThumbnailUrl,
    getThumbnailApiUrl,
    logThumbnailError
} from '@/lib/thumbnail-utils';
import { memo, useCallback, useEffect, useRef, useState } from 'react';
import type { Database } from '@/types/database-generated.types';

type Video = Database['public']['Tables']['videos']['Row'];

interface ThumbnailImageProps {
  src?: string;
  alt: string;
  title: string;
  width?: number;
  height?: number;
  className?: string;
  aspectRatio?: string;
  video?: Partial<Video>;
  priority?: boolean;
  srcSet?: string;
  sizes?: string;
  style?: React.CSSProperties;
}

/**
 * Enhanced thumbnail component with robust error handling and fallbacks
 * This component attempts multiple strategies to display thumbnails with progressive loading
 */
export const ThumbnailImage = memo(function ThumbnailImage({
  src,
  alt,
  title,
  width = 320,
  height = 180,
  className = '',
  aspectRatio = '16/9',
  video,
  priority = false,
  srcSet,
  sizes,
  style,
}: ThumbnailImageProps) {
  const [hasError, setHasError] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [fallbackAttempt, setFallbackAttempt] = useState(0);
  const [imgSrc, setImgSrc] = useState<string>('');
  const [shouldLoad, setShouldLoad] = useState(priority);
  const imgRef = useRef<HTMLImageElement>(null);
  const intersectionObserverRef = useRef<IntersectionObserver | null>(null);

  const videoId = video?.id;
  
  const optimizedDimensions = getOptimizedDimensions(width, height);
  
  const handleError = useCallback(() => {
    if (fallbackAttempt >= 2) {
      setHasError(true);
      setIsLoading(false);
      return;
    }

    const nextAttempt = fallbackAttempt + 1;
    setFallbackAttempt(nextAttempt);

    let fallbackSrc = '';

    if (videoId) {
      if (nextAttempt === 1) {
        fallbackSrc = getThumbnailApiUrl(videoId);
      } else if (nextAttempt === 2) {
        fallbackSrc = generateSvgThumbnail(title);
      }
    } else {
      fallbackSrc = generateSvgThumbnail(title);
    }

    if (fallbackSrc) {
      setImgSrc(fallbackSrc);
    } else {
      setHasError(true);
    }

    logThumbnailError(videoId || src || 'unknown', `Fallback attempt ${nextAttempt}`, 'Client-side fallback triggered');
  }, [fallbackAttempt, videoId, src, title]);

  const loadImage = useCallback(() => {
    if (!shouldLoad) return;
    
    setIsLoading(true);
    setHasError(false);
    setFallbackAttempt(0);
    
    let initialSrc = src;
    
    // Use getBestThumbnailUrl for consistent thumbnail handling
    if (!initialSrc && video) {
      initialSrc = getBestThumbnailUrl(video);
    }
    
    if (!initialSrc) {
      setHasError(true);
      setIsLoading(false);
      handleError();
      return;
    }
    
    setImgSrc(initialSrc);
    
    if (priority) {
      preloadImage(initialSrc)
        .then(() => setIsLoading(false))
        .catch(() => handleError());
    }
  }, [shouldLoad, video, src, priority, handleError]);

  useEffect(() => {
    if (priority) return;
    
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && !shouldLoad) {
          setShouldLoad(true);
          if (imgRef.current && intersectionObserverRef.current) {
            intersectionObserverRef.current.unobserve(imgRef.current);
          }
        }
      },
      { rootMargin: '200px' }
    );

    if (imgRef.current) {
      intersectionObserverRef.current = observer;
      observer.observe(imgRef.current);
    }

    return () => {
      if (intersectionObserverRef.current && imgRef.current) {
        intersectionObserverRef.current.unobserve(imgRef.current);
      }
    };
  }, [priority, shouldLoad]);

  useEffect(() => {
    if (shouldLoad) {
      loadImage();
    }
  }, [shouldLoad, loadImage]);

  const imageStyle = {
    aspectRatio: aspectRatio,
    width: optimizedDimensions.width,
    height: optimizedDimensions.height,
    ...hasError && {
      backgroundImage: imgSrc,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
    },
  };

  if (!shouldLoad && !priority) {
    return (
      <div
        ref={imgRef}
        className={`bg-card/50 animate-pulse ${className}`}
        style={{ aspectRatio, width, height }}
        aria-label={alt}
      />
    );
  }

  return (
    <img
      ref={imgRef}
      src={hasError ? 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7' : (isLoading ? generateSvgThumbnail(title, '#111') : imgSrc)}
      alt={alt || 'Video thumbnail'}
      title={title}
      width={optimizedDimensions.width}
      height={optimizedDimensions.height}
      className={className}
      style={{ minWidth: 44, minHeight: 44, ...imageStyle, ...style }}
      onLoad={() => setIsLoading(false)}
      onError={handleError}
      loading={priority ? 'eager' : 'lazy'}
      srcSet={srcSet}
      sizes={sizes || '(max-width: 600px) 100vw, 300px'}
    />
  );
});