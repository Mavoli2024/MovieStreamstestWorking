import React from 'react';
import { Loader2, AlertCircle, RefreshCw, Wifi, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function LoadingSpinner({ size = 'md', className = '' }: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6',
    lg: 'w-8 h-8',
  };

  return (
    <Loader2 className={`animate-spin ${sizeClasses[size]} ${className}`} />
  );
}

interface LoadingStateProps {
  loading: boolean;
  error: string | null;
  onRetry?: () => void;
  isEmpty?: boolean;
  emptyMessage?: string;
  children: React.ReactNode;
  loadingMessage?: string;
  retryCount?: number;
  maxRetries?: number;
  className?: string;
}

export function RobustLoadingState({
  loading,
  error,
  onRetry,
  isEmpty = false,
  emptyMessage = 'No data available',
  children,
  loadingMessage = 'Loading...',
  retryCount = 0,
  maxRetries = 3,
  className = '',
}: LoadingStateProps) {
  // Error state
  if (error) {
    const isNetworkError = error.includes('network') || error.includes('connection') || error.includes('fetch');
    const isServerError = error.includes('500') || error.includes('server error');
    const isNotFound = error.includes('404') || error.includes('not found');
    const isAuth = error.includes('401') || error.includes('unauthorized') || error.includes('log in');

    return (
      <Card className={`${className} border-red-200 bg-red-50`}>
        <CardContent className="flex flex-col items-center justify-center p-8 text-center space-y-4">
          <div className="flex items-center justify-center w-12 h-12 bg-red-100 rounded-full">
            {isNetworkError ? (
              <WifiOff className="w-6 h-6 text-red-600" />
            ) : (
              <AlertCircle className="w-6 h-6 text-red-600" />
            )}
          </div>
          
          <div className="space-y-2">
            <h3 className="font-semibold text-red-900">
              {isNetworkError ? 'Connection Problem' :
               isServerError ? 'Server Error' :
               isNotFound ? 'Not Found' :
               isAuth ? 'Authentication Required' :
               'Something went wrong'}
            </h3>
            <p className="text-red-700 text-sm max-w-md">{error}</p>
            {retryCount > 0 && (
              <p className="text-red-600 text-xs">
                Retry attempt {retryCount}/{maxRetries}
              </p>
            )}
          </div>

          {onRetry && (
            <div className="flex gap-2">
              <Button
                onClick={onRetry}
                variant="outline"
                size="sm"
                className="flex items-center gap-2 border-red-300 text-red-700 hover:bg-red-100"
              >
                <RefreshCw className="w-4 h-4" />
                Try Again
              </Button>
              
              {isAuth && (
                <Button
                  onClick={() => window.location.href = '/auth'}
                  size="sm"
                  className="bg-red-600 hover:bg-red-700"
                >
                  Sign In
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  // Loading state
  if (loading) {
    return (
      <Card className={`${className} border-blue-200 bg-blue-50`}>
        <CardContent className="flex flex-col items-center justify-center p-8 text-center space-y-4">
          <LoadingSpinner size="lg" className="text-blue-600" />
          <div className="space-y-1">
            <p className="text-blue-900 font-medium">{loadingMessage}</p>
            {retryCount > 0 && (
              <p className="text-blue-600 text-sm">
                Retrying... ({retryCount}/{maxRetries})
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Empty state
  if (isEmpty) {
    return (
      <Card className={`${className} border-gray-200 bg-gray-50`}>
        <CardContent className="flex flex-col items-center justify-center p-8 text-center space-y-4">
          <div className="flex items-center justify-center w-12 h-12 bg-gray-100 rounded-full">
            <AlertCircle className="w-6 h-6 text-gray-400" />
          </div>
          <div className="space-y-2">
            <h3 className="font-semibold text-gray-900">No Content</h3>
            <p className="text-gray-600 text-sm">{emptyMessage}</p>
          </div>
          {onRetry && (
            <Button
              onClick={onRetry}
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Refresh
            </Button>
          )}
        </CardContent>
      </Card>
    );
  }

  // Success state - render children
  return <>{children}</>;
}

interface NetworkStatusProps {
  isOnline: boolean;
  className?: string;
}

export function NetworkStatus({ isOnline, className = '' }: NetworkStatusProps) {
  if (isOnline) return null;

  return (
    <div className={`fixed top-0 left-0 right-0 z-50 bg-red-600 text-white py-2 px-4 text-center text-sm ${className}`}>
      <div className="flex items-center justify-center gap-2">
        <WifiOff className="w-4 h-4" />
        <span>No internet connection. Some features may not work.</span>
      </div>
    </div>
  );
}

interface ProgressBarProps {
  progress: number;
  className?: string;
  showPercentage?: boolean;
}

export function ProgressBar({ progress, className = '', showPercentage = false }: ProgressBarProps) {
  const clampedProgress = Math.max(0, Math.min(100, progress));

  return (
    <div className={`w-full ${className}`}>
      <div className="bg-gray-200 rounded-full h-2 overflow-hidden">
        <div
          className="bg-blue-600 h-full transition-all duration-300 ease-out"
          style={{ width: `${clampedProgress}%` }}
        />
      </div>
      {showPercentage && (
        <div className="text-center mt-1 text-sm text-gray-600">
          {Math.round(clampedProgress)}%
        </div>
      )}
    </div>
  );
}

interface InlineLoadingProps {
  loading: boolean;
  error?: string | null;
  size?: 'sm' | 'md';
  className?: string;
}

export function InlineLoading({ loading, error, size = 'sm', className = '' }: InlineLoadingProps) {
  if (error) {
    return (
      <span className={`inline-flex items-center gap-1 text-red-600 text-sm ${className}`}>
        <AlertCircle className="w-3 h-3" />
        <span>Error</span>
      </span>
    );
  }

  if (loading) {
    return (
      <span className={`inline-flex items-center gap-2 text-gray-600 text-sm ${className}`}>
        <LoadingSpinner size={size} />
        <span>Loading...</span>
      </span>
    );
  }

  return null;
}

export default RobustLoadingState;