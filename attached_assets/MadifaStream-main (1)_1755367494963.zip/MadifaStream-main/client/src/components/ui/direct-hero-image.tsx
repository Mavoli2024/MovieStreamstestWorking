import { useEffect, useState } from 'react';

interface DirectHeroImageProps {
  videoId: string | null;
  title: string;
  className?: string;
}

/**
 * Enhanced hero image component that uses multiple fallback strategies
 * to ensure images load properly from Bunny CDN
 */
export function DirectHeroImage({
  videoId,
  title,
  className = ""
}: DirectHeroImageProps) {
  const [hasError, setHasError] = useState(false);
  const [imgSrc, setImgSrc] = useState<string | null>(null);

  // Create an SVG fallback image with the video title
  const generateSvgFallback = (title: string) => {
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" width="1920" height="1080" viewBox="0 0 1920 1080">
        <defs>
          <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#2D1B4E;stop-opacity:1" />
            <stop offset="100%" style="stop-color:#180D29;stop-opacity:1" />
          </linearGradient>
        </defs>
        <rect width="1920" height="1080" fill="url(#grad)" />
        <text x="960" y="540" font-family="Arial, sans-serif" font-size="72" fill="#FF8400" text-anchor="middle" dominant-baseline="middle">${title}</text>
      </svg>
    `)}`;
  };

  useEffect(() => {
    if (!videoId) {
      setImgSrc(null);
      return;
    }

    // Use backend proxy for hero image
    setImgSrc(`/api/videos/${videoId}/thumbnail`);

    // We'll handle errors in the onError handler by using the fallback
  }, [videoId]);

  // Handle image load errors
  const handleError = () => {
    setHasError(true);
  };

  // When no image or error, use the SVG fallback
  if (!imgSrc || hasError) {
    return (
      <div
        className={className}
        style={{
          backgroundImage: `url(${generateSvgFallback(title)})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat',
          backgroundColor: '#180D29'
        }}
      />
    );
  }

  return (
    <img
      src={imgSrc}
      alt={title}
      className={`${className} hero-image`}
      onError={handleError}
      loading="eager" // Load hero image eagerly since it's visible immediately
    />
  );
}