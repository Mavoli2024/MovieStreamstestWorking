import { useEffect, useRef, useState } from 'react';

interface BunnyPlayerProps {
  videoId: string;
  title: string;
  onProgress?: (seconds: number) => void;
  onEnded?: () => void;
  initialProgress?: number;
  onClose?: () => void;
}

/**
 * A minimal wrapper for the BunnyStream player iframe
 * This leverages BunnyStream's built-in player instead of creating our own
 */
export function BunnyPlayer({
  videoId,
  title,
  onProgress,
  onEnded,
  initialProgress = 0,
  onClose,
}: BunnyPlayerProps) {
  // ALL HOOKS MUST BE AT THE TOP LEVEL
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  
  // Handle messages from the iframe for tracking progress
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // Make sure the message is from the BunnyStream player
      if (event.origin !== 'https://iframe.mediadelivery.net') return;
      
      try {
        const data = JSON.parse(event.data);
        
        // Handle different message types from the player
        if (data.event === 'timeupdate') {
          // Convert milliseconds to seconds
          const seconds = Math.floor(data.currentTime / 1000);
          
          // Set loaded state to true once playback has started
          if (!isLoaded && seconds > 0) {
            setIsLoaded(true);
          }
          
          // Pass progress to parent if callback provided
          if (onProgress) {
            onProgress(seconds);
          }
        } else if (data.event === 'ended' && onEnded) {
          onEnded();
        } else if (data.event === 'play') {
          // Also set loaded when playback starts
          setIsLoaded(true);
        } else if (data.event === 'playerready') {
          // We'll keep the loading indicator until playback actually starts
          // to avoid flickering between loading states
          
          // If we have a starting position, seek to it
          if (initialProgress > 0 && iframeRef.current) {
            // Seek using postMessage
            iframeRef.current.contentWindow?.postMessage(
              JSON.stringify({
                event: 'seek',
                time: initialProgress * 1000 // milliseconds
              }),
              '*'
            );
          }
        }
      } catch (error) {
        // Error parsing player message - silently ignore
      }
    };
    
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [onProgress, onEnded, initialProgress, isLoaded]);
  
  // Validate required props AFTER all hooks
  if (!videoId) {
    return (
      <div className="relative w-full h-full bg-black flex items-center justify-center">
        <p className="text-white">Error: Video ID is required</p>
      </div>
    );
  }
  
  // Create the BunnyStream embed URL
  const libraryId = import.meta.env.BUNNY_STREAM_LIBRARY_ID || '425043'; // Fallback to known library ID
  const embedUrl = `https://iframe.mediadelivery.net/embed/${libraryId}/${videoId}`;
  
  // Add parameters for autoplay, starting time, etc.
  const urlWithParams = new URL(embedUrl);
  urlWithParams.searchParams.append('autoplay', 'true');
  urlWithParams.searchParams.append('preload', 'true');
  
  // Add starting position if provided (convert seconds to milliseconds)
  if (initialProgress > 0) {
    urlWithParams.searchParams.append('startTime', (initialProgress * 1000).toString());
  }
  
  // Optional: customize player appearance
  urlWithParams.searchParams.append('hideControls', 'false');
  urlWithParams.searchParams.append('hideTitle', 'true');

  return (
    <div className="relative w-full h-full bg-black">
      {!isLoaded && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-primary"></div>
        </div>
      )}
      
      <iframe
        ref={iframeRef}
        src={urlWithParams.toString()}
        className="w-full h-full border-0"
        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
        title={title}
        loading="eager"
      />
      
      {onClose && (
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 bg-black/50 hover:bg-black/70 text-white rounded-full p-2 z-20"
          aria-label="Close video"
        >
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      )}
    </div>
  );
}