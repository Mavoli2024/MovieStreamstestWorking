import React from 'react';
import { cn } from '@/lib/utils';

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  message?: string;
  className?: string;
  primaryColor?: boolean;
}

export function LoadingSpinner({
  size = 'md',
  message,
  className,
  primaryColor = true
}: LoadingSpinnerProps) {
  // Different sizes in pixels
  const sizeMap = {
    sm: 'h-4 w-4',
    md: 'h-8 w-8',
    lg: 'h-12 w-12',
    xl: 'h-16 w-16'
  };

  // Determine the border color
  const borderColor = primaryColor ? 'border-primary' : 'border-white';

  return (
    <div className={cn('flex flex-col items-center justify-center', className)}>
      <div
        className={cn(
          'animate-spin rounded-full border-t-2 border-b-2',
          sizeMap[size],
          borderColor
        )}
      />
      {message && (
        <p className="mt-2 text-sm text-center text-muted-foreground">{message}</p>
      )}
    </div>
  );
}