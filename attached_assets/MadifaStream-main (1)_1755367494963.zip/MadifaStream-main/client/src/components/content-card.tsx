import type {  Video  } from "@shared/schema";
import {  StandardizedContentCard  } from "./standardized-content-card";

interface ContentCardProps {
  video: Video;
  progress?: number; // as percentage 0-100
  isContinueWatching?: boolean;
  isInWatchlist?: boolean;
  onAddToWatchlist?: (videoId: string) => void;
  onRemoveFromWatchlist?: (videoId: string) => void;
  className?: string;
}

/**
 * ContentCard is now a wrapper around StandardizedContentCard for backward compatibility
 * This ensures we maintain a single source of truth for our content card UI
 */
export function ContentCard({
  video,
  progress,
  isContinueWatching = false,
  isInWatchlist = false,
  onAddToWatchlist,
  onRemoveFromWatchlist,
  className = ""
}: ContentCardProps) {
  return (
    <StandardizedContentCard
      video={video}
      progress={progress}
      isContinueWatching={isContinueWatching}
      isInWatchlist={isInWatchlist}
      onAddToWatchlist={onAddToWatchlist}
      onRemoveFromWatchlist={onRemoveFromWatchlist}
      showControls={true}
      showMetadata={true}
      className={className}
    />
  );
}