import { useAuth } from "@/hooks/use-auth";
import type {  Profile  } from '@/types/database';
import { createContext, ReactNode, useContext  } from 'react';

// Define the shape of the context value
interface ProfileContextType {
  // The currently active user profile.
  // This is the full profile object from the 'profiles' table.
  activeProfile: Profile | null;

  // The loading state, derived directly from useAuth.
  // True if the initial user session and profile are being fetched.
  isLoading: boolean;

  profiles: Profile[];
  isLoadingProfiles: boolean;
}

// Create the context
const ProfileContext = createContext<ProfileContextType | undefined>(undefined);

// Define the props for the provider component
interface ProfileProviderProps {
  children: ReactNode;
}

/**
 * Provides the active user profile to the component tree.
 * This provider is a lightweight wrapper around the `useAuth` hook,
 * designed to isolate profile-specific data and make it available
 * where needed. It no longer contains any data-fetching logic itself.
 */
export const ProfileProvider = ({ children }: ProfileProviderProps) => {
  // Get the profile and loading state from the single source of truth.
  const { profile, isLoading } = useAuth();

  const profiles = profile ? [profile] : [];
  const isLoadingProfiles = isLoading;

  const value = {
    activeProfile: profile,
    profiles,
    isLoading,
    isLoadingProfiles,
  };

  return (
    <ProfileContext.Provider value={value}>
      {children}
    </ProfileContext.Provider>
  );
};

/**
 * Custom hook to consume the ProfileContext.
 * This is the standard way for components to access the active profile.
 */
export const useProfileContext = (): ProfileContextType => {
  const context = useContext(ProfileContext);
  if (context === undefined) {
    throw new Error('useProfileContext must be used within a ProfileProvider');
  }
  return context;
};