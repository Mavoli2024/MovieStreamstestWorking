import {  Button  } from "@/components/ui/button";
import {  Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle  } from "@/components/ui/card";
import {  Label  } from "@/components/ui/label";
import {  LoadingSpinner  } from "@/components/ui/loading-spinner";
import {  RadioGroup, RadioGroupItem  } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from '@tanstack/react-query';
import {  AlertCircle, CheckCircle2  } from 'lucide-react';
import { useEffect, useState } from 'react';

// PayFast environment type
type PayFastEnvironment = 'production' | 'sandbox';

// Admin settings panel component
export function AdminSettings() {
  const { toast } = useToast();
  const [selectedEnvironment, setSelectedEnvironment] = useState<PayFastEnvironment>('sandbox');

  // Fetch current environment on component mount
  const { data: environmentData, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/payment/environment'],
    queryFn: () => fetchEnvironment(),
  });

  // Update state when data is fetched
  useEffect(() => {
    if (environmentData?.environment) {
      setSelectedEnvironment(environmentData.environment);
    }
  }, [environmentData]);

  // Mutation for switching environments
  const switchEnvironmentMutation = useMutation({
    mutationFn: async (environment: PayFastEnvironment) => {
      const res = await updateEnvironment(environment);
      return res;
    },
    onSuccess: (data) => {
      toast({
        title: "Environment Switched",
        description: `Payment environment changed to ${data.environment}`,
        variant: "default",
      });
      refetch();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to switch environment",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle environment change
  const handleEnvironmentChange = (value: PayFastEnvironment) => {
    setSelectedEnvironment(value);
  };

  // Handle save button click
  const handleSave = () => {
    if (selectedEnvironment !== environmentData?.environment) {
      switchEnvironmentMutation.mutate(selectedEnvironment);
    }
  };

  const fetchEnvironment = async () => {
    const res = await fetch('/api/payment/environment', {
      method: 'GET',
      credentials: 'include',
    });
    if (!res.ok) throw new Error(`Failed to fetch environment: ${res.status} ${res.statusText}`);
    return await res.json();
  };

  const updateEnvironment = async (environment: string) => {
    const res = await fetch('/api/payment/environment', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ environment }),
    });
    if (!res.ok) throw new Error(`Failed to update environment: ${res.status} ${res.statusText}`);
    return await res.json();
  };

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardHeader>
          <CardTitle>Payment Environment</CardTitle>
          <CardDescription>Loading settings...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center py-6">
          <LoadingSpinner size="md" />
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full border-red-200">
        <CardHeader>
          <CardTitle className="flex items-center">
            <AlertCircle className="mr-2 h-5 w-5 text-red-500" />
            Error Loading Settings
          </CardTitle>
          <CardDescription>
            Could not load payment environment settings.
            You might not have admin permissions.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-red-500">
            {error instanceof Error ? error.message : "Unknown error"}
          </p>
        </CardContent>
        <CardFooter>
          <Button variant="outline" onClick={() => refetch()}>
            Try Again
          </Button>
        </CardFooter>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Payment Environment</CardTitle>
        <CardDescription>
          Configure which PayFast environment to use for payment processing
        </CardDescription>
      </CardHeader>
      <CardContent>
        <RadioGroup
          value={selectedEnvironment}
          onValueChange={(value) => handleEnvironmentChange(value as PayFastEnvironment)}
          className="space-y-4"
        >
          <div className="flex items-start space-x-3 space-y-0 rounded-md border p-4">
            <RadioGroupItem value="sandbox" id="sandbox" />
            <div className="space-y-1">
              <Label className="font-medium" htmlFor="sandbox">
                Sandbox Environment
              </Label>
              <p className="text-sm text-muted-foreground">
                Use sandbox mode for testing payments. No real transactions will occur.
                <span className="block mt-1 text-xs text-green-500">
                  Merchant ID: {process.env.PAYFAST_SANDBOX_MERCHANT_ID?.slice(0, 4)}****
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-start space-x-3 space-y-0 rounded-md border p-4">
            <RadioGroupItem value="production" id="production" />
            <div className="space-y-1">
              <Label className="font-medium" htmlFor="production">
                Production Environment
              </Label>
              <p className="text-sm text-muted-foreground">
                Use production mode for real payments. Actual charges will be processed.
                <span className="block mt-1 text-xs text-green-500">
                  Merchant ID: {process.env.PAYFAST_MERCHANT_ID?.slice(0, 4)}****
                </span>
              </p>
            </div>
          </div>
        </RadioGroup>

        {environmentData?.environment && (
          <div className="mt-4 flex items-center text-sm text-muted-foreground">
            <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
            Currently using: <span className="font-medium capitalize ml-1">{environmentData.environment}</span>
          </div>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={() => refetch()}>
          Refresh
        </Button>
        <Button
          onClick={handleSave}
          disabled={switchEnvironmentMutation.isPending || selectedEnvironment === environmentData?.environment}
        >
          {switchEnvironmentMutation.isPending ? (
            <div className="flex items-center">
              <LoadingSpinner size="sm" primaryColor={false} />
              <span className="ml-2">Saving...</span>
            </div>
          ) : (
            "Save Changes"
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}