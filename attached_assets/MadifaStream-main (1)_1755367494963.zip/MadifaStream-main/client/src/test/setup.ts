import '@testing-library/jest-dom'
import { expect, afterEach, beforeAll, afterAll, vi } from 'vitest'
import { cleanup } from '@testing-library/react'
import axe from 'axe-core'

// Cleanup after each test
afterEach(() => {
  cleanup()
})

// Mock window.matchMedia
Object.defineProperty(window, 'matchMedia', {
  writable: true,
  value: (query: string) => ({
    matches: false,
    media: query,
    onchange: null,
    addListener: () => {},
    removeListener: () => {},
    addEventListener: () => {},
    removeEventListener: () => {},
    dispatchEvent: () => {},
  }),
})

// Mock IntersectionObserver
global.IntersectionObserver = class IntersectionObserver {
  constructor() {}
  disconnect() {}
  observe() {}
  unobserve() {}
} as any

// Mock ResizeObserver
global.ResizeObserver = class ResizeObserver {
  constructor() {}
  disconnect() {}
  observe() {}
  unobserve() {}
} as any

// Mock PerformanceObserver
global.PerformanceObserver = class PerformanceObserver {
  constructor() {}
  disconnect() {}
  observe() {}
  unobserve() {}
  static supportedEntryTypes: string[] = []
} as any

// Mock requestAnimationFrame
global.requestAnimationFrame = (cb: FrameRequestCallback) => {
  return setTimeout(cb, 0)
}

global.cancelAnimationFrame = (id: number) => {
  clearTimeout(id)
}

// Mock fetch
global.fetch = vi.fn()

// Mock console methods to reduce noise in tests
const originalError = console.error
const originalWarn = console.warn

beforeAll(() => {
  console.error = (...args: any[]) => {
    if (
      typeof args[0] === 'string' &&
      args[0].includes('Warning: ReactDOM.render is no longer supported')
    ) {
      return
    }
    originalError.call(console, ...args)
  }

  console.warn = (...args: any[]) => {
    if (
      typeof args[0] === 'string' &&
      (args[0].includes('componentWillReceiveProps') ||
        args[0].includes('componentWillMount'))
    ) {
      return
    }
    originalWarn.call(console, ...args)
  }
})

afterAll(() => {
  console.error = originalError
  console.warn = originalWarn
})

// Accessibility testing utilities
export const testAccessibility = async (container: HTMLElement) => {
  const results = await axe.run(container)
  // Basic accessibility check without toHaveNoViolations
  if (results.violations.length > 0) {
    console.warn('Accessibility violations found:', results.violations)
  }
}

// Performance testing utilities
export const measureRenderTime = (renderFn: () => void) => {
  const start = performance.now()
  renderFn()
  const end = performance.now()
  return end - start
}

// Component testing utilities
export const createMockProps = (overrides = {}) => ({
  // Default props that most components might need
  className: '',
  children: null,
  ...overrides
})

// Mock environment variables
vi.mock('../../env.d.ts', () => ({
  VITE_API_URL: 'http://localhost:5001',
  VITE_SUPABASE_URL: 'https://test.supabase.co',
  VITE_SUPABASE_ANON_KEY: 'test-key',
  VITE_BUNNY_CDN_URL: 'https://test.bunnycdn.com',
  VITE_BUNNY_STREAM_URL: 'https://test.stream.bunnycdn.com',
  NODE_ENV: 'test'
}))

// Mock React Router
vi.mock('wouter', () => ({
  useLocation: () => ['/', () => {}],
  useRoute: () => [false, {}],
  Router: ({ children }: { children: React.ReactNode }) => children,
  Route: ({ children }: { children: React.ReactNode }) => children,
  Switch: ({ children }: { children: React.ReactNode }) => children,
  Redirect: () => null
}))

// Mock Capacitor
vi.mock('@capacitor/core', () => ({
  Capacitor: {
    isNativePlatform: () => false,
    getPlatform: () => 'web'
  }
}))

// Mock Sentry
vi.mock('@sentry/react', () => ({
  init: vi.fn(),
  captureException: vi.fn(),
  captureMessage: vi.fn(),
  withScope: vi.fn((callback) => callback({})),
  setUser: vi.fn(),
  setTag: vi.fn(),
  setContext: vi.fn()
}))

// Global test configuration
export const testConfig = {
  renderTimeout: 1000,
  accessibilityTimeout: 5000,
  performanceThreshold: 100, // ms
  asyncTimeout: 10000
}

// Test data factories
export const createTestUser = (overrides = {}) => ({
  id: 'test-user-id',
  email: 'test@example.com',
  name: 'Test User',
  avatar: 'https://example.com/avatar.jpg',
  subscription: 'premium',
  ...overrides
})

export const createTestVideo = (overrides = {}) => ({
  id: 'test-video-id',
  title: 'Test Video',
  description: 'Test video description',
  thumbnail: 'https://example.com/thumbnail.jpg',
  duration: 120,
  views: 1000,
  likes: 50,
  category: 'entertainment',
  ...overrides
})

// Async testing utilities
export const waitForElement = async (selector: string, timeout = testConfig.asyncTimeout) => {
  return new Promise((resolve, reject) => {
    const startTime = Date.now()
    
    const checkElement = () => {
      const element = document.querySelector(selector)
      if (element) {
        resolve(element)
      } else if (Date.now() - startTime > timeout) {
        reject(new Error(`Element ${selector} not found within ${timeout}ms`))
      } else {
        setTimeout(checkElement, 50)
      }
    }
    
    checkElement()
  })
}

// Error boundary testing
export const triggerErrorBoundary = (component: any) => {
  const error = new Error('Test error for error boundary')
  const errorInfo = { componentStack: 'Test component stack' }
  
  // Simulate error in component
  if (component.componentDidCatch) {
    component.componentDidCatch(error, errorInfo)
  }
  
  return { error, errorInfo }
} 