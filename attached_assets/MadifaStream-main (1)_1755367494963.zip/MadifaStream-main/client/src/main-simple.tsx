import { createRoot } from "react-dom/client";
import React from "react";
import { logger } from '@shared/logger';

// Minimal test component
function SimpleApp() {
  return (
    <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
      <h1>Simple Test App</h1>
      <p>If you can see this text, React is working correctly!</p>
      <p>Current time: {new Date().toLocaleTimeString()}</p>
    </div>
  );
}

// Render the minimal app
const rootElement = document.getElementById('root');
if (rootElement) {
  createRoot(rootElement).render(<SimpleApp />);
} else {
  logger.error('Root element not found');
} 