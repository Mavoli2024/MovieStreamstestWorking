/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_SUPABASE_URL: string;
  readonly VITE_SUPABASE_ANON_KEY: string;
  readonly VITE_BACKEND_API_URL: string;
  readonly VITE_SITE_URL: string;
  readonly VITE_BUNNY_STREAM_LIBRARY_ID: string;
  readonly VITE_BUNNY_CDN_HOSTNAME: string;
  readonly VITE_BUNNY_STREAM_HOSTNAME: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}