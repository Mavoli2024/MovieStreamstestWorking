import { create } from 'zustand';

export interface Toast {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message?: string;
  duration?: number;
  dismissible?: boolean;
  actions?: Array<{
    label: string;
    onClick: () => void;
    variant?: 'default' | 'ghost';
  }>;
}

// Extended UI State including nested helper objects for convenient composability
export interface UIState {
  // Navigation
  sidebarOpen: boolean;
  mobileMenuOpen: boolean;
  
  // Search
  searchQuery: string;
  searchFocused: boolean;
  searchResults: any[];
  searchLoading: boolean;
  
  // Modals and overlays
  currentModal: string | null;
  modalData: any;
  
  // Toasts and notifications
  toasts: Toast[];
  
  // Theming
  theme: 'dark' | 'light';
  setTheme: (theme: 'dark' | 'light') => void;
  toggleTheme: () => void;

  // Loading states
  globalLoading: boolean;
  loadingMessage: string;
  // granular operation loading map
  loadingOperations: Record<string, boolean>;
  
  // Network status
  networkStatus: 'online' | 'offline';
  
  // Player state
  playerFullscreen: boolean;
  playerMinimized: boolean;
  currentVideoId: string | null;
  
  // UI preferences
  compactMode: boolean;
  showBreadcrumbs: boolean;
  
  // Actions
  setSidebarOpen: (open: boolean) => void;
  setMobileMenuOpen: (open: boolean) => void;
  toggleSidebar: () => void;
  toggleMobileMenu: () => void;
  
  setSearchQuery: (query: string) => void;
  setSearchFocused: (focused: boolean) => void;
  setSearchResults: (results: any[]) => void;
  setSearchLoading: (loading: boolean) => void;
  clearSearch: () => void;
  
  openModal: (modalType: string, data?: any) => void;
  closeModal: () => void;
  
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
  clearToasts: () => void;
  
  setGlobalLoading: (loading: boolean, message?: string) => void;
  setLoadingOperation: (operation: string, loading: boolean) => void;
  setNetworkStatus: (status: 'online' | 'offline') => void;
  
  setPlayerFullscreen: (fullscreen: boolean) => void;
  setPlayerMinimized: (minimized: boolean) => void;
  setCurrentVideoId: (videoId: string | null) => void;
  
  setCompactMode: (compact: boolean) => void;
  setShowBreadcrumbs: (show: boolean) => void;
  // convenience nested helpers (populated below via merge)
  sidebar: any;
  modal: any;
  toast: any;
  loading: any;
  reset?: () => void;
}

let toastCounter = 0;

export const initialState = {
  theme: 'dark' as 'dark',
  sidebarOpen: false,
  mobileMenuOpen: false,
  searchQuery: '',
  searchFocused: false,
  searchResults: [],
  searchLoading: false,
  currentModal: null,
  modalData: null,
  toasts: [],
  globalLoading: false,
  loadingMessage: '',
  networkStatus: 'online' as 'online',
  playerFullscreen: false,
  playerMinimized: false,
  currentVideoId: null,
  compactMode: false,
  showBreadcrumbs: true,
  loadingOperations: {},
};

export const useUIStore = create<UIState>((set, get) => ({
  ...initialState,
  
  // Navigation actions
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setMobileMenuOpen: (open) => set({ mobileMenuOpen: open }),
  toggleSidebar: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
  toggleMobileMenu: () => set((state) => ({ mobileMenuOpen: !state.mobileMenuOpen })),
  
  // Search actions
  setSearchQuery: (query) => set({ searchQuery: query }),
  setSearchFocused: (focused) => set({ searchFocused: focused }),
  setSearchResults: (results) => set({ searchResults: results }),
  setSearchLoading: (loading) => set({ searchLoading: loading }),
  clearSearch: () => set({ 
    searchQuery: '', 
    searchResults: [], 
    searchLoading: false 
  }),
  
  // Modal actions
  openModal: (modalType, data) => set({ 
    currentModal: modalType, 
    modalData: data 
  }),
  closeModal: () => set({ 
    currentModal: null, 
    modalData: null 
  }),
  
  // Toast actions
  addToast: (toast) => {
    const incoming: any = toast; // allow tests that include id field
    if (incoming.id) {
      set((state) => ({ toasts: [...state.toasts, incoming as Toast] }));
      return;
    }
    const id = `toast-${++toastCounter}`;
    const newToast: Toast = {
      id,
      duration: 5000,
      dismissible: true,
      ...toast,
    };
    
    set((state) => ({
      toasts: [...state.toasts, newToast]
    }));
    
    // Auto-remove toast after duration
    if (newToast.duration && newToast.duration > 0) {
      setTimeout(() => {
        get().removeToast(id);
      }, newToast.duration);
    }
  },
  
  removeToast: (id) => set((state) => ({
    toasts: state.toasts.filter(toast => toast.id !== id)
  })),
  
  clearToasts: () => set({ toasts: [] }),
  
  // Loading actions
  // Loading actions
  setGlobalLoading: (loading, message = '') => set({ 
    globalLoading: loading, 
    loadingMessage: message 
  }),
  setLoadingOperation: (operation, loading) => set((state) => ({
    loadingOperations: { ...state.loadingOperations, [operation]: loading },
  })),
  
  setNetworkStatus: (status) => set({ networkStatus: status }),
  
  // Player actions
  setPlayerFullscreen: (fullscreen) => set({ playerFullscreen: fullscreen }),
  setPlayerMinimized: (minimized) => set({ playerMinimized: minimized }),
  setCurrentVideoId: (videoId) => set({ currentVideoId: videoId }),
  
  // Theme actions
  setTheme: (theme) => set({ theme }),
  toggleTheme: () => set((state) => ({ theme: state.theme === 'dark' ? 'light' : 'dark' })),

  // UI preference actions
  setCompactMode: (compact) => set({ compactMode: compact }),
  setShowBreadcrumbs: (show) => set({ showBreadcrumbs: show }),

  // reset for tests
  reset: () => set({ ...initialState }),

  // ----- Nested helper wrappers for compatibility with legacy tests -----
  sidebar: {
    open: () => set({ sidebarOpen: true }),
    close: () => set({ sidebarOpen: false }),
    toggle: () => set((state) => ({ sidebarOpen: !state.sidebarOpen })),
    get isOpen() {
      return get().sidebarOpen;
    },
  },
  modal: {
    open: (data?: any) => set({ currentModal: 'custom', modalData: data }),
    close: () => set({ currentModal: null, modalData: null }),
    get isOpen() {
      return get().currentModal !== null;
    },
    get data() {
      return get().modalData;
    },
  },
  toast: {
    add: (t: Omit<Toast, 'id'>) => get().addToast(t),
    remove: (id: string) => get().removeToast(id),
    get items() {
      return get().toasts;
    },
  },
  loading: {
    setGlobal: (loading: boolean) => get().setGlobalLoading(loading),
    get global() {
      return get().globalLoading;
    },
    setOperation: (op: string, loading: boolean) => get().setLoadingOperation(op, loading),
    get operations() {
      return get().loadingOperations;
    },
  },
}));

// Selectors for commonly used combinations
export const useNavigation = () => useUIStore((state) => ({
  sidebarOpen: state.sidebarOpen,
  mobileMenuOpen: state.mobileMenuOpen,
  setSidebarOpen: state.setSidebarOpen,
  setMobileMenuOpen: state.setMobileMenuOpen,
  toggleSidebar: state.toggleSidebar,
  toggleMobileMenu: state.toggleMobileMenu,
}));

export const useSearch = () => useUIStore((state) => ({
  searchQuery: state.searchQuery,
  searchFocused: state.searchFocused,
  searchResults: state.searchResults,
  searchLoading: state.searchLoading,
  setSearchQuery: state.setSearchQuery,
  setSearchFocused: state.setSearchFocused,
  setSearchResults: state.setSearchResults,
  setSearchLoading: state.setSearchLoading,
  clearSearch: state.clearSearch,
}));

export const useModals = () => useUIStore((state) => ({
  currentModal: state.currentModal,
  modalData: state.modalData,
  openModal: state.openModal,
  closeModal: state.closeModal,
}));

export const useToasts = () => useUIStore((state) => ({
  toasts: state.toasts,
  addToast: state.addToast,
  removeToast: state.removeToast,
  clearToasts: state.clearToasts,
}));

export const usePlayer = () => useUIStore((state) => ({
  playerFullscreen: state.playerFullscreen,
  playerMinimized: state.playerMinimized,
  currentVideoId: state.currentVideoId,
  setPlayerFullscreen: state.setPlayerFullscreen,
  setPlayerMinimized: state.setPlayerMinimized,
  setCurrentVideoId: state.setCurrentVideoId,
}));

export const useGlobalLoading = () => useUIStore((state) => ({
  globalLoading: state.globalLoading,
  loadingMessage: state.loadingMessage,
  setGlobalLoading: state.setGlobalLoading,
}));

// Network status detection
if (typeof window !== 'undefined') {
  const updateNetworkStatus = () => {
    useUIStore.getState().setNetworkStatus(navigator.onLine ? 'online' : 'offline');
  };
  
  window.addEventListener('online', updateNetworkStatus);
  window.addEventListener('offline', updateNetworkStatus);
  
  // Initial check
  updateNetworkStatus();
}

// Toast helper functions
export const toast = {
  success: (title: string, message?: string, options?: Partial<Toast>) => {
    useUIStore.getState().addToast({
      type: 'success',
      title,
      message,
      ...options,
    });
  },
  
  error: (title: string, message?: string, options?: Partial<Toast>) => {
    useUIStore.getState().addToast({
      type: 'error',
      title,
      message,
      duration: 0, // Error toasts don't auto-dismiss by default
      ...options,
    });
  },
  
  warning: (title: string, message?: string, options?: Partial<Toast>) => {
    useUIStore.getState().addToast({
      type: 'warning',
      title,
      message,
      ...options,
    });
  },
  
  info: (title: string, message?: string, options?: Partial<Toast>) => {
    useUIStore.getState().addToast({
      type: 'info',
      title,
      message,
      ...options,
    });
  },
};

// Modal helper functions
export const modal = {
  open: (modalType: string, data?: any) => {
    useUIStore.getState().openModal(modalType, data);
  },
  
  close: () => {
    useUIStore.getState().closeModal();
  },
};
