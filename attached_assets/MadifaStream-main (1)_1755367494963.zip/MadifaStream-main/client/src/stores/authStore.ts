import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Session } from '@supabase/supabase-js';

export interface AuthState {
  // Auth state
  user: User | null;
  session: Session | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  error: any | null;
  
  // User metadata
  profile: UserProfile | null;
  roles: string[];
  subscription: UserSubscription | null;
  
  // Actions
  setUser: (user: User | null) => void;
  setSession: (session: Session | null) => void;
  setProfile: (profile: UserProfile | null) => void;
  setLoading: (loading: boolean) => void;
  setRoles: (roles: string[]) => void;
  setSubscription: (subscription: UserSubscription | null) => void;
  setError: (error: any | null) => void;
  
  // Auth methods
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, username?: string) => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshSession: () => Promise<void>;
  
  // Utility methods
  hasRole: (role: string) => boolean;
  hasAnyRole: (roles: string[]) => boolean;
  hasPermission: (permission: string) => boolean;
  isSubscribed: () => boolean;
  getDisplayName: () => string;
}

export interface UserProfile {
  id: string;
  username: string;
  email: string;
  avatar_url?: string;
  bio?: string;
  website?: string;
  location?: string;
  created_at: string;
  updated_at: string;
}

export interface UserSubscription {
  id: string;
  user_id: string;
  plan_id: string;
  status: 'active' | 'inactive' | 'canceled' | 'past_due';
  current_period_start: string;
  current_period_end: string;
  created_at: string;
  updated_at: string;
  plan: {
    id: string;
    name: string;
    features: string[];
    price: number;
    billing_interval: 'monthly' | 'yearly';
  };
}

const defaultState = {
  user: null,
  session: null,
  isLoading: false,
  isAuthenticated: false,
  profile: null,
  roles: [],
  subscription: null,
  error: null,
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      ...defaultState,
      
      // Setters
      setUser: (user) => {
        set({ 
          user, 
          isAuthenticated: !!user 
        });
        // Sync with auth token storage
        if (!user) {
          localStorage.removeItem('auth_token');
        }
      },
      
      setSession: (session) => {
        set({ 
          session,
          isAuthenticated: !!session,
          user: session?.user || null
        });
        // Store auth token for API calls
        if (session?.access_token) {
          localStorage.setItem('auth_token', session.access_token);
        } else {
          localStorage.removeItem('auth_token');
        }
      },
      
      setProfile: (profile) => set({ profile }),
      setLoading: (isLoading) => set({ isLoading }),
      setRoles: (roles) => set({ roles }),
      setSubscription: (subscription) => set({ subscription }),
      setError: (error) => set({ error }),
      
      // Auth methods implemented for tests
      login: async (email: string, password: string) => {
        const supabase = (await import('../lib/supabase')).supabase;
        set({ isLoading: true, error: null });
        try {
          // Use Supabase client – will be mocked in tests
          // @ts-ignore
          const { data, error } = await supabase.auth.signInWithPassword({ email, password });
          if (error) {
            set({ error, user: null, session: null, isAuthenticated: false });
            throw error;
          }
          set({ user: data.user, session: data.session, isAuthenticated: true });
        } finally {
          set({ isLoading: false });
        }
      },
      
      register: async (email: string, password: string, username?: string) => {
        const supabase = (await import('../lib/supabase')).supabase;
        set({ isLoading: true, error: null });
        try {
          const { data, error } = await supabase.auth.signUp({ 
            email, 
            password,
            options: {
              data: {
                username: username || email.split('@')[0]
              }
            }
          });
          if (error) {
            set({ error });
            throw error;
          }
          set({ user: data.user, session: data.session, isAuthenticated: !!data.user });
        } finally {
          set({ isLoading: false });
        }
      },
      
      resetPassword: async (email: string) => {
        const supabase = (await import('../lib/supabase')).supabase;
        set({ isLoading: true, error: null });
        try {
          const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: `${window.location.origin}/auth?reset=true`
          });
          if (error) {
            set({ error });
            throw error;
          }
        } finally {
          set({ isLoading: false });
        }
      },
      
      logout: async () => {
        const supabase = (await import('../lib/supabase')).supabase;
        set({ isLoading: true, error: null });
        try {
          // @ts-ignore
          const { error } = await supabase.auth.signOut();
          if (error) {
            set({ error });
            throw error;
          }
          set(defaultState);
          // Broadcast logout
          if (typeof window !== 'undefined') {
            const bc = new BroadcastChannel('madifa-auth');
            bc.postMessage({ type: 'LOGOUT' });
          }
        } finally {
          set({ isLoading: false });
        }
      },
      
      refreshSession: async () => {
        try {
          // TODO: Implement session refresh
          // const { data, error } = await supabase.auth.getSession();
          // if (error) throw error;
          // set({ session: data.session, isAuthenticated: !!data.session });
        } catch (error) {
          console.error('Session refresh failed:', error);
          set({ session: null, isAuthenticated: false });
        }
      },
      
      // Utility methods
      hasRole: (role: string) => {
        const { roles } = get();
        return roles.includes(role);
      },
      
      hasAnyRole: (rolesToCheck: string[]) => {
        const { roles } = get();
        return rolesToCheck.some(role => roles.includes(role));
      },
      
      hasPermission: (permission: string) => {
        const { roles, subscription } = get();
        
        // Admin has all permissions
        if (roles.includes('admin')) return true;
        
        // Check subscription-based permissions
        if (permission === 'watch_premium' && subscription?.status === 'active') {
          return true;
        }
        
        // Check role-based permissions
        const rolePermissions: Record<string, string[]> = {
          moderator: ['moderate_content', 'manage_users'],
          creator: ['upload_content', 'manage_own_content'],
          user: ['watch_free', 'create_watchlist', 'rate_content'],
        };
        
        return roles.some(role => rolePermissions[role]?.includes(permission));
      },
      
      isSubscribed: () => {
        const { subscription } = get();
        return subscription?.status === 'active';
      },
      
      getDisplayName: () => {
        const { user, profile } = get();
        return profile?.username || user?.email?.split('@')[0] || 'User';
      },
    }),
    {
      name: 'madifa-auth',
      // Only persist non-sensitive data
      partialize: (state) => ({
        user: state.user,
        session: state.session,
        isAuthenticated: state.isAuthenticated,
        profile: state.profile,
        roles: state.roles,
        subscription: state.subscription,
      }),
    }
  )
);

// Selectors for commonly used combinations
export const useAuthUser = () => useAuthStore((state) => ({
  user: state.user,
  profile: state.profile,
  isAuthenticated: state.isAuthenticated,
  isLoading: state.isLoading,
  getDisplayName: state.getDisplayName,
}));

export const useAuthActions = () => useAuthStore((state) => ({
  login: state.login,
  register: state.register,
  logout: state.logout,
  refreshSession: state.refreshSession,
}));

export const useAuthPermissions = () => useAuthStore((state) => ({
  roles: state.roles,
  subscription: state.subscription,
  hasRole: state.hasRole,
  hasAnyRole: state.hasAnyRole,
  hasPermission: state.hasPermission,
  isSubscribed: state.isSubscribed,
}));

// Cross-tab synchronization for auth events
if (typeof window !== 'undefined') {
  const bc = new BroadcastChannel('madifa-auth');
  
  bc.onmessage = (event) => {
    if (event.data.type === 'LOGOUT') {
      useAuthStore.setState(defaultState);
    }
  };
  
  // Listen for auth state changes
  useAuthStore.subscribe((state) => {
    if (!state.isAuthenticated) {
      bc.postMessage({ type: 'AUTH_CHANGED', payload: { isAuthenticated: false } });
    }
  });
}
