import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface SettingsState {
  // Theme settings
  theme: 'light' | 'dark' | 'system';
  
  // Playback settings
  autoplay: boolean;
  quality: 'auto' | '720p' | '1080p' | '4k';
  volume: number;
  muted: boolean;
  
  // Language and accessibility
  language: string;
  subtitles: boolean;
  subtitleLanguage: string;
  
  // Notifications
  notifications: boolean;
  emailNotifications: boolean;
  pushNotifications: boolean;
  
  // Content preferences
  adultContent: boolean;
  dataUsage: 'high' | 'medium' | 'low';
  
  // UI preferences
  sidebarCollapsed: boolean;
  gridView: boolean;
  
  // Actions
  setTheme: (theme: SettingsState['theme']) => void;
  setAutoplay: (autoplay: boolean) => void;
  setQuality: (quality: SettingsState['quality']) => void;
  setVolume: (volume: number) => void;
  setMuted: (muted: boolean) => void;
  setLanguage: (language: string) => void;
  setSubtitles: (subtitles: boolean) => void;
  setSubtitleLanguage: (language: string) => void;
  setNotifications: (notifications: boolean) => void;
  setEmailNotifications: (emailNotifications: boolean) => void;
  setPushNotifications: (pushNotifications: boolean) => void;
  setAdultContent: (adultContent: boolean) => void;
  setDataUsage: (dataUsage: SettingsState['dataUsage']) => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
  setGridView: (gridView: boolean) => void;
  
  // Bulk actions
  updateSettings: (settings: Partial<SettingsState>) => void;
  resetSettings: () => void;
}

const defaultSettings: Omit<SettingsState, keyof SettingsActions> = {
  theme: 'system',
  autoplay: true,
  quality: 'auto',
  volume: 1,
  muted: false,
  language: 'en',
  subtitles: false,
  subtitleLanguage: 'en',
  notifications: true,
  emailNotifications: true,
  pushNotifications: true,
  adultContent: false,
  dataUsage: 'high',
  sidebarCollapsed: false,
  gridView: true,
};

type SettingsActions = {
  setTheme: (theme: SettingsState['theme']) => void;
  setAutoplay: (autoplay: boolean) => void;
  setQuality: (quality: SettingsState['quality']) => void;
  setVolume: (volume: number) => void;
  setMuted: (muted: boolean) => void;
  setLanguage: (language: string) => void;
  setSubtitles: (subtitles: boolean) => void;
  setSubtitleLanguage: (language: string) => void;
  setNotifications: (notifications: boolean) => void;
  setEmailNotifications: (emailNotifications: boolean) => void;
  setPushNotifications: (pushNotifications: boolean) => void;
  setAdultContent: (adultContent: boolean) => void;
  setDataUsage: (dataUsage: SettingsState['dataUsage']) => void;
  setSidebarCollapsed: (collapsed: boolean) => void;
  setGridView: (gridView: boolean) => void;
  updateSettings: (settings: Partial<SettingsState>) => void;
  resetSettings: () => void;
};

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set, get) => ({
      ...defaultSettings,
      
      // Individual setters
      setTheme: (theme) => set({ theme }),
      setAutoplay: (autoplay) => set({ autoplay }),
      setQuality: (quality) => set({ quality }),
      setVolume: (volume) => set({ volume: Math.max(0, Math.min(1, volume)) }),
      setMuted: (muted) => set({ muted }),
      setLanguage: (language) => set({ language }),
      setSubtitles: (subtitles) => set({ subtitles }),
      setSubtitleLanguage: (language) => set({ subtitleLanguage: language }),
      setNotifications: (notifications) => set({ notifications }),
      setEmailNotifications: (emailNotifications) => set({ emailNotifications }),
      setPushNotifications: (pushNotifications) => set({ pushNotifications }),
      setAdultContent: (adultContent) => set({ adultContent }),
      setDataUsage: (dataUsage) => set({ dataUsage }),
      setSidebarCollapsed: (collapsed) => set({ sidebarCollapsed: collapsed }),
      setGridView: (gridView) => set({ gridView }),
      
      // Bulk actions
      updateSettings: (settings) => set((state) => ({ ...state, ...settings })),
      resetSettings: () => set(defaultSettings),
    }),
    {
      name: 'madifa-settings',
      // Only persist non-function values
      partialize: (state) => Object.fromEntries(
        Object.entries(state).filter(([key]) => typeof state[key as keyof SettingsState] !== 'function')
      ),
    }
  )
);

// Selectors for commonly used combinations
export const useThemeSettings = () => useSettingsStore((state) => ({
  theme: state.theme,
  setTheme: state.setTheme,
}));

export const usePlaybackSettings = () => useSettingsStore((state) => ({
  autoplay: state.autoplay,
  quality: state.quality,
  volume: state.volume,
  muted: state.muted,
  setAutoplay: state.setAutoplay,
  setQuality: state.setQuality,
  setVolume: state.setVolume,
  setMuted: state.setMuted,
}));

export const useNotificationSettings = () => useSettingsStore((state) => ({
  notifications: state.notifications,
  emailNotifications: state.emailNotifications,
  pushNotifications: state.pushNotifications,
  setNotifications: state.setNotifications,
  setEmailNotifications: state.setEmailNotifications,
  setPushNotifications: state.setPushNotifications,
}));

export const useUISettings = () => useSettingsStore((state) => ({
  sidebarCollapsed: state.sidebarCollapsed,
  gridView: state.gridView,
  setSidebarCollapsed: state.setSidebarCollapsed,
  setGridView: state.setGridView,
}));

// Cross-tab synchronization
if (typeof window !== 'undefined') {
  const bc = new BroadcastChannel('madifa-settings');
  
  useSettingsStore.subscribe((state) => {
    bc.postMessage({ type: 'SETTINGS_CHANGED', payload: state });
  });
  
  bc.onmessage = (event) => {
    if (event.data.type === 'SETTINGS_CHANGED') {
      useSettingsStore.setState(event.data.payload);
    }
  };
}
