/**
 * WebSocket Client Service
 * 
 * Manages WebSocket connections for real-time features like:
 * - Watch party chat and video synchronization
 * - User presence tracking
 * - Real-time system notifications
 */

// import { io, Socket } from 'socket.io-client'; // Optional dependency
type Socket = any;
import { logger } from '../../../shared/logger.js';

export interface ChatMessage {
  id: string;
  userId: string;
  username: string;
  message: string;
  timestamp: Date;
  roomId: string;
  messageType: 'text' | 'system' | 'emoji';
}

export interface VideoSyncEvent {
  videoId: string;
  action: 'play' | 'pause' | 'seek';
  timestamp: number;
  userId: string;
  username: string;
}

export interface UserPresence {
  userId: string;
  username: string;
  status: 'online' | 'watching' | 'idle' | 'offline';
  currentVideo?: string;
  joinedAt: Date;
}

export interface RoomParticipant {
  id: string;
  displayName: string;
  avatar?: string;
}

export interface ConnectionStatus {
  connected: boolean;
  error?: string;
  reconnectAttempts: number;
  lastConnected?: Date;
}

type EventHandler = (...args: any[]) => void;

class WebSocketService {
  private socket: Socket | null = null;
  private connectionStatus: ConnectionStatus = {
    connected: false,
    reconnectAttempts: 0,
  };
  private eventHandlers = new Map<string, Set<EventHandler>>();
  private currentRoom: string | null = null;
  private maxReconnectAttempts = 5;
  private reconnectDelay = 1000;
  private heartbeatInterval?: NodeJS.Timeout;

  constructor() {
    // Auto-connect when browser comes online
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => {
        if (!this.isConnected()) {
          this.connect();
        }
      });

      window.addEventListener('offline', () => {
        this.disconnect();
      });
    }
  }

  /**
   * Connect to WebSocket server
   */
  async connect(token?: string): Promise<boolean> {
    if (this.socket?.connected) {
      return true;
    }

    if (!token) {
      logger.error('WebSocket connection requires authentication token');
      return false;
    }

    try {
      // Socket.IO disabled - missing dependency
      console.warn('WebSocket service disabled - socket.io-client not available');
      return false;
      
      // const serverUrl = process.env.NODE_ENV === 'production' 
      //   ? process.env.NEXT_PUBLIC_API_URL || window.location.origin
      //   : 'http://localhost:3000';

      // this.socket = io(serverUrl, {
      //   auth: { token },
      //   transports: ['websocket', 'polling'],
      //   upgrade: true,
      //   rememberUpgrade: true,
      //   timeout: 10000,
      // });

      this.setupEventListeners();
      
      return new Promise((resolve) => {
        const timeout = setTimeout(() => {
          logger.error('WebSocket connection timeout');
          resolve(false);
        }, 10000);

        this.socket!.on('connect', () => {
          clearTimeout(timeout);
          this.connectionStatus.connected = true;
          this.connectionStatus.lastConnected = new Date();
          this.connectionStatus.reconnectAttempts = 0;
          delete this.connectionStatus.error;
          
          logger.info('WebSocket connected successfully');
          this.startHeartbeat();
          resolve(true);
        });

        this.socket!.on('connect_error', (error) => {
          clearTimeout(timeout);
          this.connectionStatus.connected = false;
          this.connectionStatus.error = error.message;
          
          logger.error('WebSocket connection failed', { error });
          resolve(false);
        });
      });
    } catch (error) {
      logger.error('WebSocket connection error', {
        error: error instanceof Error ? error : new Error(String(error)),
      });
      return false;
    }
  }

  /**
   * Disconnect from WebSocket server
   */
  disconnect(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }

    if (this.socket) {
      this.socket.disconnect();
      this.socket = null;
    }

    this.connectionStatus.connected = false;
    this.currentRoom = null;
    
    logger.info('WebSocket disconnected');
  }

  /**
   * Check if connected
   */
  isConnected(): boolean {
    return this.socket?.connected ?? false;
  }

  /**
   * Get connection status
   */
  getConnectionStatus(): ConnectionStatus {
    return { ...this.connectionStatus };
  }

  /**
   * Join a chat room
   */
  async joinRoom(roomId: string, videoId?: string): Promise<boolean> {
    if (!this.isConnected()) {
      logger.warn('Cannot join room: WebSocket not connected');
      return false;
    }

    return new Promise((resolve) => {
      const timeout = setTimeout(() => resolve(false), 5000);

      this.socket!.emit('room:join', { roomId, videoId });
      
      this.socket!.once('room:joined', (data) => {
        clearTimeout(timeout);
        this.currentRoom = roomId;
        logger.info('Joined room successfully', { roomId, participants: data.participants?.length });
        resolve(true);
      });

      this.socket!.once('error', (error) => {
        clearTimeout(timeout);
        logger.error('Failed to join room', { roomId, error });
        resolve(false);
      });
    });
  }

  /**
   * Leave current room
   */
  async leaveRoom(): Promise<boolean> {
    if (!this.currentRoom || !this.isConnected()) {
      return true;
    }

    return new Promise((resolve) => {
      const timeout = setTimeout(() => resolve(true), 2000); // Always resolve after timeout

      this.socket!.emit('room:leave', { roomId: this.currentRoom });
      
      this.socket!.once('room:left', () => {
        clearTimeout(timeout);
        logger.info('Left room successfully', { roomId: this.currentRoom });
        this.currentRoom = null;
        resolve(true);
      });
    });
  }

  /**
   * Send chat message
   */
  sendChatMessage(message: string): boolean {
    if (!this.isConnected() || !this.currentRoom) {
      logger.warn('Cannot send message: not connected or not in a room');
      return false;
    }

    if (!message.trim() || message.length > 500) {
      logger.warn('Invalid message: empty or too long');
      return false;
    }

    this.socket!.emit('chat:send', {
      message: message.trim(),
      roomId: this.currentRoom,
    });

    return true;
  }

  /**
   * Send video sync event
   */
  sendVideoSync(videoId: string, action: 'play' | 'pause' | 'seek', timestamp: number): boolean {
    if (!this.isConnected() || !this.currentRoom) {
      logger.warn('Cannot sync video: not connected or not in a room');
      return false;
    }

    const syncEvent: Omit<VideoSyncEvent, 'userId' | 'username'> = {
      videoId,
      action,
      timestamp,
    };

    this.socket!.emit('video:sync', syncEvent);
    logger.debug('Video sync event sent', syncEvent);
    
    return true;
  }

  /**
   * Update user presence
   */
  updatePresence(status: 'online' | 'watching' | 'idle', videoId?: string): void {
    if (!this.isConnected()) return;

    this.socket!.emit('presence:update', {
      status,
      videoId,
    });
  }

  /**
   * Add event listener
   */
  on(event: string, handler: EventHandler): void {
    if (!this.eventHandlers.has(event)) {
      this.eventHandlers.set(event, new Set());
    }
    this.eventHandlers.get(event)!.add(handler);
  }

  /**
   * Remove event listener
   */
  off(event: string, handler?: EventHandler): void {
    if (!this.eventHandlers.has(event)) return;

    if (handler) {
      this.eventHandlers.get(event)!.delete(handler);
    } else {
      this.eventHandlers.delete(event);
    }
  }

  /**
   * Get current room ID
   */
  getCurrentRoom(): string | null {
    return this.currentRoom;
  }

  /**
   * Setup socket event listeners
   */
  private setupEventListeners(): void {
    if (!this.socket) return;

    // Connection events
    this.socket.on('connect', () => {
      this.connectionStatus.connected = true;
      this.emit('connected');
    });

    this.socket.on('disconnect', (reason) => {
      this.connectionStatus.connected = false;
      this.emit('disconnected', reason);
      
      // Attempt reconnection if not intentional
      if (reason !== 'io client disconnect') {
        this.attemptReconnection();
      }
    });

    this.socket.on('connect_error', (error) => {
      this.connectionStatus.error = error.message;
      this.emit('connection_error', error);
    });

    // Chat events
    this.socket.on('chat:message', (message: ChatMessage) => {
      this.emit('chat:message', message);
    });

    // Room events
    this.socket.on('room:joined', (data) => {
      this.emit('room:joined', data);
    });

    this.socket.on('room:left', (data) => {
      this.emit('room:left', data);
    });

    this.socket.on('room:user_joined', (data) => {
      this.emit('room:user_joined', data);
    });

    this.socket.on('room:user_left', (data) => {
      this.emit('room:user_left', data);
    });

    // Video sync events
    this.socket.on('video:sync', (event: VideoSyncEvent) => {
      this.emit('video:sync', event);
    });

    // Presence events
    this.socket.on('presence:update', (presence: UserPresence) => {
      this.emit('presence:update', presence);
    });

    // System events
    this.socket.on('system:message', (message) => {
      this.emit('system:message', message);
    });

    // Error handling
    this.socket.on('error', (error) => {
      logger.error('WebSocket error', { error });
      this.emit('error', error);
    });
  }

  /**
   * Emit event to registered handlers
   */
  private emit(event: string, ...args: any[]): void {
    const handlers = this.eventHandlers.get(event);
    if (handlers) {
      handlers.forEach(handler => {
        try {
          handler(...args);
        } catch (error) {
          logger.error('Event handler error', { event, error });
        }
      });
    }
  }

  /**
   * Attempt reconnection with exponential backoff
   */
  private attemptReconnection(): void {
    if (this.connectionStatus.reconnectAttempts >= this.maxReconnectAttempts) {
      logger.error('Max reconnection attempts reached');
      this.emit('reconnection_failed');
      return;
    }

    this.connectionStatus.reconnectAttempts++;
    const delay = this.reconnectDelay * Math.pow(2, this.connectionStatus.reconnectAttempts - 1);

    logger.info('Attempting WebSocket reconnection', {
      attempt: this.connectionStatus.reconnectAttempts,
      delay,
    });

    setTimeout(() => {
      if (!this.isConnected() && this.socket) {
        this.socket.connect();
      }
    }, delay);
  }

  /**
   * Start heartbeat to maintain connection
   */
  private startHeartbeat(): void {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }

    this.heartbeatInterval = setInterval(() => {
      if (this.isConnected()) {
        this.socket!.emit('ping', (response: string) => {
          if (response === 'pong') {
            logger.debug('WebSocket heartbeat successful');
          }
        });
      }
    }, 30000); // Every 30 seconds
  }

  /**
   * Get service statistics
   */
  getStatistics(): {
    connected: boolean;
    currentRoom: string | null;
    reconnectAttempts: number;
    lastConnected?: string;
  } {
    return {
      connected: this.isConnected(),
      currentRoom: this.currentRoom,
      reconnectAttempts: this.connectionStatus.reconnectAttempts,
      lastConnected: this.connectionStatus.lastConnected?.toISOString(),
    };
  }

  /**
   * Cleanup resources
   */
  cleanup(): void {
    this.disconnect();
    this.eventHandlers.clear();
    logger.info('WebSocket service cleaned up');
  }
}

// Export singleton instance
export const webSocketService = new WebSocketService();

// Cleanup on page unload
if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', () => {
    webSocketService.cleanup();
  });
}

export default WebSocketService;