import { logger } from '@shared/logger';
/**
 * Client-side BunnyStream API interface
 * This is a client-side wrapper for BunnyStream functionality
 */

export interface BunnyVideoMetadata {
  guid: string;
  title: string;
  dateUploaded: string;
  views: number;
  length: number;
  status: number;
  thumbnailFileName?: string;
  category?: string;
  totalWatchTime?: number;
  averageWatchTime?: number;
}

export interface BunnyStreamingOptions {
  quality?: 'auto' | '240p' | '360p' | '480p' | '720p' | '1080p';
  autoplay?: boolean;
  muted?: boolean;
  controls?: boolean;
}

/**
 * Get video metadata from the server
 */
export async function getVideoMetadata(videoId: string): Promise<BunnyVideoMetadata | null> {
  try {
    const response = await fetch(`/api/videos/${videoId}/metadata`);
    if (!response.ok) {
      throw new Error(`Failed to fetch video metadata: ${response.statusText}`);
    }
    return await response.json();
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error fetching video metadata:', { arg1: error });
    }
    return null;
  }
}

/**
 * Get video streaming URL
 */
export async function getVideoStreamUrl(videoId: string, options?: BunnyStreamingOptions): Promise<string | null> {
  try {
    const queryParams = new URLSearchParams();
    if (options?.quality) queryParams.append('quality', options.quality);
    
    const response = await fetch(`/api/videos/${videoId}/stream?${queryParams}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch video stream URL: ${response.statusText}`);
    }
    
    const data = await response.json();
    return data.streamUrl;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.api('Error fetching video stream URL:', { arg1: error });
    }
    return null;
  }
}

/**
 * Get video thumbnail URL
 */
export function getVideoThumbnailUrl(videoId: string, width= 320, height= 180): string {
  // CRITICAL FIX: Use VITE_ prefix for client environment variables
  const cdnHostname = import.meta.env.VITE_BUNNY_CDN_HOSTNAME || 'cdn.example.com';
  return `https://${cdnHostname}/${videoId}/thumbnail_${width}x${height}.jpg`;
}

/**
 * Get video HLS manifest URL
 */
export function getVideoHlsUrl(videoId: string): string {
  // CRITICAL FIX: Use VITE_ prefix for client environment variables
  const cdnHostname = import.meta.env.VITE_BUNNY_CDN_HOSTNAME || 'cdn.example.com';
  return `https://${cdnHostname}/${videoId}/playlist.m3u8`;
}
