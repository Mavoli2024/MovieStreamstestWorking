/* eslint-disable @typescript-eslint/no-explicit-any */
/**
 * EnhancedVideoService (temporary stub)
 * Provides helper to enhance video metadata.
 */
export interface EnhancedVideoMetadata {
  id: string;
  title: string;
  description?: string | null;
  thumbnail_url?: string | null;
  video_url?: string | null;
  trailer_url?: string | null;
  release_year?: number | null;
  duration_minutes?: number | null;
  age_rating?: string | null;
  genres?: string[];
  cast?: string[] | string | null;
  director?: string | null;
  collection_id?: string | null;
  collection_name?: string | null;
  is_premium?: boolean;
  is_trailer?: boolean;
  status?: string | null;
  // Additional enhanced fields
  content_type?: 'video' | 'trailer' | 'movie' | 'series';
  content_category?: string;
  access_level?: 'premium' | 'free';
  [key: string]: unknown;
}

export function getThumbnailUrl(video: EnhancedVideoMetadata, fileName= 'thumbnail.jpg'): string {
  // Prefer explicit thumbnail URL from DB, otherwise build a fallback using Bunny CDN conventions
  if (video.thumbnail_url) return video.thumbnail_url;
  if (video.video_url) {
    // Bunny thumbnails are typically `${video_url}/thumbnails/${fileName}`
    return `${video.video_url.replace(/\/*$/, '')}/thumbnails/${fileName}`;
  }
  return '/public/fallback-thumbnail.svg';
}

export async function enhanceVideoMetadata(video: unknown): Promise<EnhancedVideoMetadata> {
  // TODO: Replace with real backend call when available
  const videoWithAccess: EnhancedVideoMetadata = {
    ...(video as EnhancedVideoMetadata),
    access_level: (video as any)?.is_premium ? 'premium' : 'free',
  };
  return videoWithAccess;
}

const EnhancedVideoService = {
  enhanceVideoMetadata,
  getThumbnailUrl,
};

export default EnhancedVideoService; 