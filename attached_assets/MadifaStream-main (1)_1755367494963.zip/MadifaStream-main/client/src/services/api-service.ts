/**
 * Robust API Service
 * 
 * Production-grade API client with:
 * - Automatic retry with exponential backoff
 * - Request/response interceptors
 * - Offline detection and queueing
 * - Error normalization
 * - Request cancellation
 * - Response caching
 */

import axios, { AxiosInstance, AxiosError, AxiosRequestConfig } from 'axios';
import axiosRetry from 'axios-retry';
import { toast } from 'react-hot-toast';
import { logger } from '@shared/logger';

export interface ApiError {
  code: string;
  message: string;
  status?: number;
  details?: unknown;
}

export interface ApiResponse<T = any> {
  data: T;
  error?: ApiError;
  meta?: {
    timestamp: number;
    cached?: boolean;
  };
}

class ApiService {
  private static instance: ApiService;
  private client: AxiosInstance;
  private cache = new Map<string, { data: unknown; timestamp: number }>();
  private offlineQueue: Array<() => Promise<any>> = [];
  private isOnline = navigator.onLine;

  private constructor() {
    // Create axios instance
    this.client = axios.create({
      baseURL: '/api',
      timeout: 30000,
      headers: {
        'Content-Type': 'application/json',
      },
      withCredentials: true,
    });

    // Configure retry logic
    axiosRetry(this.client, {
      retries: 2, // Reduce retries since React Query also retries
      retryDelay: axiosRetry.exponentialDelay,
      retryCondition: (error) => {
        // Only retry on network errors or specific 5xx errors (not 404 or other client errors)
        if (axiosRetry.isNetworkOrIdempotentRequestError(error)) {
          return true;
        }
        
        const status = error.response?.status;
        // Only retry on actual server errors, not missing endpoints (404, 405) 
        return status === 502 || status === 503 || status === 504;
      },
      onRetry: (retryCount, error) => {
        logger.warn(`API retry attempt ${retryCount}:`, error.message);
      },
    });

    // Setup interceptors
    this.setupInterceptors();

    // Monitor online status
    this.setupOnlineMonitoring();
  }

  static getInstance(): ApiService {
    if (!ApiService.instance) {
      ApiService.instance = new ApiService();
    }
    return ApiService.instance;
  }

  /**
   * Setup request/response interceptors
   */
  private setupInterceptors(): void {
    // Request interceptor
    this.client.interceptors.request.use(
      (config) => {
        // Add auth token if available
        const token = this.getAuthToken();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }

        // Add request ID for tracking
        config.headers['X-Request-ID'] = this.generateRequestId();

        // Check if offline
        if (!this.isOnline) {
          throw new Error('No internet connection');
        }

        return config;
      },
      (error) => {
        return Promise.reject(error);
      }
    );

    // Response interceptor
    this.client.interceptors.response.use(
      (response) => {
        // Log successful responses in dev
        if (import.meta.env.DEV) {
          logger.debug('API Response:', {
            url: response.config.url,
            status: response.status,
            data: response.data,
          });
        }

        return response;
      },
      async (error: AxiosError) => {
        const apiError = this.normalizeError(error);

        // Handle specific error cases
        if (error.response?.status === 401) {
          // Unauthorized - clear auth and redirect
          this.handleUnauthorized();
        } else if (error.response?.status === 402) {
          // Payment required
          toast.error('Subscription required for this content');
        } else if (error.response?.status === 429) {
          // Rate limited
          toast.error('Too many requests. Please try again later.');
        } else if (!this.isOnline) {
          // Offline
          toast.error('No internet connection');
        } else if (error.code === 'ECONNABORTED') {
          // Timeout
          toast.error('Request timed out. Please try again.');
        } else {
          // Generic error
          toast.error(apiError.message);
        }

        return Promise.reject(apiError);
      }
    );
  }

  /**
   * Setup online/offline monitoring
   */
  private setupOnlineMonitoring(): void {
    window.addEventListener('online', () => {
      this.isOnline = true;
      toast.success('Back online');
      this.processOfflineQueue();
    });

    window.addEventListener('offline', () => {
      this.isOnline = false;
      toast.error('No internet connection');
    });
  }

  /**
   * Process queued offline requests
   */
  private async processOfflineQueue(): Promise<void> {
    const queue = [...this.offlineQueue];
    this.offlineQueue = [];

    for (const request of queue) {
      try {
        await request();
      } catch (error) {
        logger.error('Failed to process offline request:', error);
      }
    }
  }

  /**
   * Get auth token from storage with Supabase fallback
   */
  private getAuthToken(): string | null {
    // Try multiple sources
    const sources = [
      () => localStorage.getItem('auth_token'),
      () => sessionStorage.getItem('auth_token'),
      () => document.cookie.match(/auth_token=([^;]+)/)?.[1],
      () => document.cookie.match(/supabase_auth_token=([^;]+)/)?.[1], // Fallback to Supabase cookie
    ];

    for (const source of sources) {
      const token = source();
      if (token) return token;
    }

    // CRITICAL FIX: Fallback to Supabase session if no token in storage
    // This is async but we can't await in this sync method, so we'll trigger a session check
    // The next request will have the token after the onAuthStateChange handler runs
    if (typeof window !== 'undefined' && !localStorage.getItem('auth_token')) {
      // Import supabase dynamically to avoid circular dependencies
      import('@/lib/supabase').then(({ supabase }) => {
        supabase.auth.getSession().then(({ data: { session } }) => {
          if (session?.access_token) {
            localStorage.setItem('auth_token', session.access_token);
            if (import.meta.env.DEV) {
              logger.info('Retrieved missing auth token from Supabase session');
            }
          }
        });
      }).catch(error => {
        if (import.meta.env.DEV) {
          logger.warn('Failed to get Supabase session for token fallback:', error);
        }
      });
    }

    return null;
  }

  /**
   * Generate unique request ID
   */
  private generateRequestId(): string {
    return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Normalize error response
   */
  private normalizeError(error: AxiosError): ApiError {
    if (error.response?.data) {
      const data = error.response.data as any;
      return {
        code: data.code || 'UNKNOWN_ERROR',
        message: data.message || data.error || 'An error occurred',
        status: error.response.status,
        details: data.details || data,
      };
    }

    if (error.code === 'ECONNABORTED') {
      return {
        code: 'TIMEOUT',
        message: 'Request timed out',
      };
    }

    if (!this.isOnline) {
      return {
        code: 'OFFLINE',
        message: 'No internet connection',
      };
    }

    return {
      code: 'NETWORK_ERROR',
      message: error.message || 'Network error occurred',
    };
  }

  /**
   * Handle unauthorized responses
   */
  private handleUnauthorized(): void {
    // Clear auth data
    localStorage.removeItem('auth_token');
    sessionStorage.removeItem('auth_token');
    
    // Redirect to login
    if (window.location.pathname !== '/auth') {
      window.location.href = '/auth?redirect=' + encodeURIComponent(window.location.pathname);
    }
  }

  /**
   * Check if response is cached and valid
   */
  private getCachedResponse<T>(key: string, maxAge= 60000): T | null {
    const cached = this.cache.get(key);
    
    if (cached && Date.now() - cached.timestamp < maxAge) {
      return cached.data as T;
    }
    
    return null;
  }

  /**
   * Cache response
   */
  private cacheResponse(key: string, data: unknown): void {
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
    });

    // Limit cache size
    if (this.cache.size > 100) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }
  }

  /**
   * Make GET request
   */
  async get<T = any>(
    url: string,
    config?: AxiosRequestConfig & { cache?: boolean; cacheTime?: number }
  ): Promise<ApiResponse<T>> {
    const cacheKey = `GET:${url}:${JSON.stringify(config?.params || {})}`;
    
    // Check cache
    if (config?.cache !== false) {
      const cached = this.getCachedResponse<T>(cacheKey, config?.cacheTime);
      if (cached) {
        return {
          data: cached,
          meta: { timestamp: Date.now(), cached: true },
        };
      }
    }

    try {
      const response = await this.client.get<T>(url, config);
      
      // Cache successful response
      if (config?.cache !== false) {
        this.cacheResponse(cacheKey, response.data);
      }
      
      return {
        data: response.data,
        meta: { timestamp: Date.now() },
      };
    } catch (error) {
      throw error;
    }
  }

  /**
   * Make POST request
   */
  async post<T = any>(
    url: string,
    data?: unknown,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    // Queue if offline
    if (!this.isOnline && config?.headers?.['X-Offline-Queue'] !== 'false') {
      return new Promise((resolve, reject) => {
        this.offlineQueue.push(async () => {
          try {
            const result = await this.post<T>(url, data, {
              ...config,
              headers: { ...config?.headers, 'X-Offline-Queue': 'false' },
            });
            resolve(result);
          } catch (error) {
            reject(error);
          }
        });
        
        toast.success('Request queued. Will send when online.');
      });
    }

    const response = await this.client.post<T>(url, data, config);
    return {
      data: response.data,
      meta: { timestamp: Date.now() },
    };
  }

  /**
   * Make PUT request
   */
  async put<T = any>(
    url: string,
    data?: unknown,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    const response = await this.client.put<T>(url, data, config);
    return {
      data: response.data,
      meta: { timestamp: Date.now() },
    };
  }

  /**
   * Make PATCH request
   */
  async patch<T = any>(
    url: string,
    data?: unknown,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    const response = await this.client.patch<T>(url, data, config);
    return {
      data: response.data,
      meta: { timestamp: Date.now() },
    };
  }

  /**
   * Make DELETE request
   */
  async delete<T = any>(
    url: string,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    const response = await this.client.delete<T>(url, config);
    
    // Clear related cache entries
    this.cache.forEach((_, key) => {
      if (key.includes(url)) {
        this.cache.delete(key);
      }
    });
    
    return {
      data: response.data,
      meta: { timestamp: Date.now() },
    };
  }

  /**
   * Upload file with progress
   */
  async upload<T = any>(
    url: string,
    file: File,
    onProgress?: (progress: number) => void,
    config?: AxiosRequestConfig
  ): Promise<ApiResponse<T>> {
    const formData = new FormData();
    formData.append('file', file);

    const response = await this.client.post<T>(url, formData, {
      ...config,
      headers: {
        ...config?.headers,
        'Content-Type': 'multipart/form-data',
      },
      onUploadProgress: (progressEvent) => {
        if (progressEvent.total) {
          const progress = Math.round((progressEvent.loaded * 100) / progressEvent.total);
          onProgress?.(progress);
        }
      },
    });

    return {
      data: response.data,
      meta: { timestamp: Date.now() },
    };
  }

  /**
   * Create cancelable request
   */
  createCancelableRequest<T = any>(
    request: () => Promise<ApiResponse<T>>
  ): {
    promise: Promise<ApiResponse<T>>;
    cancel: () => void;
  } {
    const source = axios.CancelToken.source();
    
    const promise = request().catch((error) => {
      if (axios.isCancel(error)) {
        throw new Error('Request cancelled');
      }
      throw error;
    });

    return {
      promise,
      cancel: () => source.cancel('Request cancelled by user'),
    };
  }

  /**
   * Clear cache
   */
  clearCache(pattern?: string): void {
    if (pattern) {
      this.cache.forEach((_, key) => {
        if (key.includes(pattern)) {
          this.cache.delete(key);
        }
      });
    } else {
      this.cache.clear();
    }
  }

  /**
   * Get cache stats
   */
  getCacheStats(): { size: number; entries: string[] } {
    return {
      size: this.cache.size,
      entries: Array.from(this.cache.keys()),
    };
  }
}

export const apiService = ApiService.getInstance();

// Convenience exports
export const api = {
  get: apiService.get.bind(apiService),
  post: apiService.post.bind(apiService),
  put: apiService.put.bind(apiService),
  patch: apiService.patch.bind(apiService),
  delete: apiService.delete.bind(apiService),
  upload: apiService.upload.bind(apiService),
}; 