import { createClient } from '@supabase/supabase-js';

export interface NotificationData {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  url?: string;
  type: 'content' | 'subscription' | 'download' | 'recommendation' | 'system';
  userId?: string;
}

export class NotificationService {
  private supabase;
  private vapidKey = process.env.NEXT_PUBLIC_VAPID_KEY;
  private maxRetries = 3;
  private retryDelay = 1000; // 1 second
  private connectionStatus: 'connected' | 'disconnected' | 'unknown' = 'unknown';
  private lastHeartbeat: number = 0;

  constructor() {
    this.supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    );
  }

  // Register service worker and request notification permission
  async initializeNotifications(): Promise<boolean> {
    if (!('serviceWorker' in navigator) || !('Notification' in window)) {
      return false;
    }

    try {
      // Register service worker
      const registration = await navigator.serviceWorker.register('/sw.js');

      // Request notification permission
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        return false;
      }

      // Get push subscription
      const subscription = await this.subscribeToPushNotifications(registration);
      if (subscription) {
        await this.saveSubscription(subscription);
        return true;
      }

      return false;
    } catch {
      return false;
    }
  }

  // Subscribe to push notifications
  private async subscribeToPushNotifications(registration: ServiceWorkerRegistration) {
    try {
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: this.urlBase64ToUint8Array(this.vapidKey!) as BufferSource
      });

      return subscription;
    } catch {
      return null;
    }
  }

  // Save subscription to database
  private async saveSubscription(subscription: PushSubscription) {
    try {
      const { data: { user } } = await this.supabase.auth.getUser();
      if (!user) return;

      const { error } = await this.supabase
        .from('push_subscriptions')
        .upsert({
          user_id: user.id,
          subscription: subscription.toJSON(),
          endpoint: subscription.endpoint,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
    } catch {
      // Silently fail
    }
  }

  // Send notification to user with retry logic
  async sendNotification(userId: string, notification: NotificationData): Promise<boolean> {
    let lastError: Error | null = null;
    
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        const { data, error } = await this.supabase.functions.invoke('send-push-notification', {
          body: {
            userId,
            notification
          }
        });

        if (error) throw new Error(error.message || 'Push notification failed');
        
        // Success
        return true;
        
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        
        if (attempt < this.maxRetries) {
          // Wait before retry with exponential backoff
          await new Promise(resolve => setTimeout(resolve, this.retryDelay * attempt));
        }
      }
    }
    
    // All attempts failed
    console.error(`Failed to send push notification after ${this.maxRetries} attempts:`, lastError);
    return false;
  }

  // Update notification preferences
  async updateNotificationPreferences(preferences: {
    newContent: boolean;
    subscriptionReminders: boolean;
    downloadComplete: boolean;
    recommendations: boolean;
  }) {
    try {
      const { data: { user } } = await this.supabase.auth.getUser();
      if (!user) return;

      const { error } = await this.supabase
        .from('notification_preferences')
        .upsert({
          user_id: user.id,
          ...preferences,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
    } catch {
      // Silently fail
    }
  }

  // Get notification preferences
  async getNotificationPreferences() {
    try {
      const { data: { user } } = await this.supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await this.supabase
        .from('notification_preferences')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      
      return data || {
        newContent: true,
        subscriptionReminders: true,
        downloadComplete: true,
        recommendations: true
      };
    } catch {
      return null;
    }
  }

  // Unsubscribe from push notifications
  async unsubscribeFromNotifications() {
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      if (!registration) return;

      const subscription = await registration.pushManager.getSubscription();
      if (subscription) {
        await subscription.unsubscribe();
        
        // Remove from database
        const { data: { user } } = await this.supabase.auth.getUser();
        if (user) {
          await this.supabase
            .from('push_subscriptions')
            .delete()
            .eq('user_id', user.id);
        }
      }
    } catch {
      // Silently fail
    }
  }

  // Helper function to convert VAPID key
  private urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(new ArrayBuffer(rawData.length));

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  // Check notification permission status
  getPermissionStatus(): NotificationPermission | null {
    if (!('Notification' in window)) {
      return null;
    }
    return Notification.permission;
  }

  // Check if notifications are supported
  isSupported(): boolean {
    return 'serviceWorker' in navigator && 'Notification' in window && 'PushManager' in window;
  }

  // Get connection status
  getConnectionStatus(): 'connected' | 'disconnected' | 'unknown' {
    return this.connectionStatus;
  }

  // Test connectivity to push service
  async testConnection(): Promise<boolean> {
    try {
      const startTime = Date.now();
      
      // Test connection to Supabase
      const { data } = await this.supabase.auth.getSession();
      
      this.connectionStatus = 'connected';
      this.lastHeartbeat = Date.now();
      
      return true;
    } catch (error) {
      this.connectionStatus = 'disconnected';
      console.error('Push service connection test failed:', error);
      return false;
    }
  }

  // Get service status
  async getServiceStatus(): Promise<{
    isSupported: boolean;
    permission: NotificationPermission | null;
    connectionStatus: string;
    lastHeartbeat: number;
    serviceWorkerActive: boolean;
  }> {
    const serviceWorkerActive = await this.isServiceWorkerActive();
    
    return {
      isSupported: this.isSupported(),
      permission: this.getPermissionStatus(),
      connectionStatus: this.connectionStatus,
      lastHeartbeat: this.lastHeartbeat,
      serviceWorkerActive
    };
  }

  // Check if service worker is active
  private async isServiceWorkerActive(): Promise<boolean> {
    if (!('serviceWorker' in navigator)) {
      return false;
    }
    
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      return !!(registration?.active);
    } catch {
      return false;
    }
  }

  // Schedule periodic connectivity checks
  startHeartbeat(intervalMs: number = 30000): void {
    setInterval(async () => {
      await this.testConnection();
    }, intervalMs);
    
    // Initial test
    this.testConnection();
  }
}

// Export singleton instance
export const notificationService = new NotificationService();
