import { createClient } from '@supabase/supabase-js';
import { logger } from '@shared/logger';

export interface NotificationData {
  title: string;
  body: string;
  icon?: string;
  badge?: string;
  url?: string;
  type: 'content' | 'subscription' | 'download' | 'recommendation' | 'system';
  userId?: string;
}

export class NotificationService {
  private supabase;
  private vapidKey = process.env.NEXT_PUBLIC_VAPID_KEY;

  constructor() {
    this.supabase = createClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
    );
  }

  // Register service worker and request notification permission
  async initializeNotifications(): Promise<boolean> {
    if (!('serviceWorker' in navigator) || !('Notification' in window)) {      return false;
    }

    try {
      // Register service worker
      const registration = await navigator.serviceWorker.register('/sw.js');

      // Request notification permission
      const permission = await Notification.requestPermission();
      if (permission !== 'granted') {
        return false;
      }

      // Get push subscription
      const subscription = await this.subscribeToPushNotifications(registration);
      if (subscription) {
        await this.saveSubscription(subscription);
        return true;
      }

      return false;
    } catch (error) {
      return false;
    }
  }

  // Subscribe to push notifications
  private async subscribeToPushNotifications(registration: ServiceWorkerRegistration) {
    try {
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: this.urlBase64ToUint8Array(this.vapidKey!) as BufferSource
      });

      return subscription;
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Failed to subscribe to push notifications:', { arg1: error });
      }
      return null;
    }
  }

  // Save subscription to database
  private async saveSubscription(subscription: PushSubscription) {
    try {
      const { data: { user } } = await this.supabase.auth.getUser();
      if (!user) return;

      const { error } = await this.supabase
        .from('push_subscriptions')
        .upsert({
          user_id: user.id,
          subscription: subscription.toJSON(),
          endpoint: subscription.endpoint,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      if (import.meta.env.DEV) {
        logger.info('Push subscription saved');
      }
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Failed to save push subscription:', { arg1: error });
      }
    }
  }

  // Send notification to user
  async sendNotification(userId: string, notification: NotificationData) {
    try {
      const { error } = await this.supabase.functions.invoke('send-push-notification', {
        body: {
          userId,
          notification
        }
      });

      if (error) throw error;
      if (import.meta.env.DEV) {
        logger.info('Notification sent successfully');
      }
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Failed to send notification:', { arg1: error });
      }
    }
  }

  // Update notification preferences
  async updateNotificationPreferences(preferences: {
    newContent: boolean;
    subscriptionReminders: boolean;
    downloadComplete: boolean;
    recommendations: boolean;
  }) {
    try {
      const { data: { user } } = await this.supabase.auth.getUser();
      if (!user) return;

      const { error } = await this.supabase
        .from('notification_preferences')
        .upsert({
          user_id: user.id,
          ...preferences,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Failed to update notification preferences:', { arg1: error });
      }
    }
  }

  // Get notification preferences
  async getNotificationPreferences() {
    try {
      const { data: { user } } = await this.supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await this.supabase
        .from('notification_preferences')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      
      return data || {
        newContent: true,
        subscriptionReminders: true,
        downloadComplete: true,
        recommendations: true
      };
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Failed to get notification preferences:', { arg1: error });
      }
      return null;
    }
  }

  // Unsubscribe from push notifications
  async unsubscribeFromNotifications() {
    try {
      const registration = await navigator.serviceWorker.getRegistration();
      if (!registration) return;

      const subscription = await registration.pushManager.getSubscription();
      if (subscription) {
        await subscription.unsubscribe();
        
        // Remove from database
        const { data: { user } } = await this.supabase.auth.getUser();
        if (user) {
          await this.supabase
            .from('push_subscriptions')
            .delete()
            .eq('user_id', user.id);
        }
      }
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Failed to unsubscribe from notifications:', { arg1: error });
      }
    }
  }

  // Helper function to convert VAPID key
  private urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(new ArrayBuffer(rawData.length));

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }
}

// Export singleton instance
export const notificationService = new NotificationService();
