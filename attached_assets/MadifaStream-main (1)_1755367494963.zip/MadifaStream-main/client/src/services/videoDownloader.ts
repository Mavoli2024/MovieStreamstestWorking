/**
 * Video Downloader Service
 * Handles downloading videos for offline viewing on mobile devices
 */

import { getPlatform } from '../capacitor-adapter';
import { 
  saveOfflineVideo, 
  updateDownloadProgress, 
  OfflineVideo
} from './offlineStorage';
import { logger } from '@shared/logger';

// Interfaces for download options
interface DownloadOptions {
  quality?: 'SD' | 'HD';
  expiryDays?: number; // Number of days until download expires
  showNotification?: boolean;
  allowMeteredConnection?: boolean;
  downloadThumbnail?: boolean;
}

// Interface for a download job
interface DownloadJob {
  videoId: string | number;
  videoUrl: string;
  thumbnailUrl: string;
  title: string;
  options: DownloadOptions;
  abortController: AbortController;
}

// Active downloads map
const activeDownloads = new Map<string | number, DownloadJob>();

/**
 * Start downloading a video for offline viewing
 */
export async function startVideoDownload(
  videoId: string | number,
  videoUrl: string,
  thumbnailUrl: string,
  title: string,
  description?: string,
  duration?: number,
  options: DownloadOptions = {}
): Promise<boolean> {
  try {
    // Check if this video is already being downloaded
    if (activeDownloads.has(videoId)) {
      logger.info('Download already in progress for video:', videoId);
      return false;
    }
    
    // Initialize video in the offline database
    const defaultOptions: DownloadOptions = {
      quality: 'SD',
      expiryDays: 30, // Default: videos expire after 30 days
      showNotification: true,
      allowMeteredConnection: false,
      downloadThumbnail: true
    };
    
    const mergedOptions = { ...defaultOptions, ...options };
    
    // Calculate expiry date if expiryDays is set
    let expiryDate: string | undefined;
    if (mergedOptions.expiryDays) {
      const date = new Date();
      date.setDate(date.getDate() + mergedOptions.expiryDays);
      expiryDate = date.toISOString();
    }
    
    // Create initial record in the database
    const offlineVideo: OfflineVideo = {
      id: videoId,
      title,
      description,
      thumbnailUrl,
      downloadProgress: 0,
      downloadState: 'downloading',
      duration,
      videoQuality: mergedOptions.quality,
      expiryDate
    };
    
    await saveOfflineVideo(offlineVideo);
    
    // Create abort controller for cancelling the download
    const abortController = new AbortController();
    
    // Create download job
    const downloadJob: DownloadJob = {
      videoId,
      videoUrl,
      thumbnailUrl,
      title,
      options: mergedOptions,
      abortController
    };
    
    // Add to active downloads
    activeDownloads.set(videoId, downloadJob);
    
    // Start the actual download process
    if (getPlatform() === 'web') {
      // In web mode, we simulate the download process
      await simulateDownload(videoId, abortController.signal);
    } else {
      // In native mode, we would use Capacitor's plugins
      // This is where we'd implement the actual download logic with Capacitor
      await nativeDownload(downloadJob, abortController.signal);
    }
    
    return true;
  } catch (error) {
    logger.error('Error starting video download:', error);
    
    // Update status to error
    await updateDownloadProgress(
      videoId, 
      0, 
      'error', 
      error instanceof Error ? error.message : 'Unknown error'
    );
    
    // Remove from active downloads
    activeDownloads.delete(videoId);
    
    return false;
  }
}

/**
 * Implement actual download process for web platform
 */
async function simulateDownload(videoId: string | number, signal: AbortSignal): Promise<void> {
  const job = activeDownloads.get(videoId);
  if (!job) throw new Error('Download job not found');

  try {
    // Get video blob from URL
    const response = await fetch(job.videoUrl, { signal });
    if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);

    const contentLength = response.headers.get('content-length');
    const totalSize = contentLength ? parseInt(contentLength, 10) : 0;
    
    let downloadedSize = 0;
    const chunks: Uint8Array[] = [];
    
    const reader = response.body?.getReader();
    if (!reader) throw new Error('Response body is not readable');

    while (true) {
      const { done, value } = await reader.read();
      
      if (signal.aborted) {
        throw new Error('Download cancelled');
      }
      
      if (done) break;
      
      chunks.push(value);
      downloadedSize += value.length;
      
      // Calculate progress
      const progress = totalSize > 0 ? Math.round((downloadedSize / totalSize) * 100) : 0;
      
      // Update progress in database
      await updateDownloadProgress(videoId, progress, 'downloading');
    }

    // Combine chunks into single array
    const videoData = new Uint8Array(new ArrayBuffer(downloadedSize));
    let offset = 0;
    for (const chunk of chunks) {
      videoData.set(chunk, offset);
      offset += chunk.length;
    }

    // Encrypt the video data
    const encryptedData = await encryptVideoData(videoData, videoId.toString());
    
    // Store in IndexedDB for web
    await storeVideoData(videoId, encryptedData, job.thumbnailUrl);
    
    // Mark as completed
    await updateDownloadProgress(videoId, 100, 'completed');
    
    // Remove from active downloads
    activeDownloads.delete(videoId);
    
    logger.info(`Successfully downloaded video ${videoId}`);
    
  } catch (error) {
    logger.error(`Download failed for video ${videoId}:`, error);
    await updateDownloadProgress(videoId, 0, 'error', error instanceof Error ? error.message : 'Unknown error');
    activeDownloads.delete(videoId);
    throw error;
  }
}

/**
 * Perform native download using Capacitor plugins
 */
async function nativeDownload(job: DownloadJob, signal: AbortSignal): Promise<void> {
  try {
    // For mobile platforms, we'll use a simplified approach until Capacitor plugins are properly installed
    if (getPlatform() === 'ios' || getPlatform() === 'android') {
      // In a production environment, you would install @capacitor/filesystem and @capacitor/network
      // For now, we'll use the web implementation with additional mobile optimizations
      logger.info('Using web implementation for mobile download');
      await simulateDownload(job.videoId, signal);
      return;
    }
    
    // If running on web, use the web implementation
    await simulateDownload(job.videoId, signal);
    
  } catch (error) {
    logger.error('Error in native download:', error);
    await updateDownloadProgress(job.videoId, 0, 'error', error instanceof Error ? error.message : 'Unknown error');
    activeDownloads.delete(job.videoId);
    throw error;
  }
}

/**
 * Cancel an active download
 */
export function cancelDownload(videoId: string | number): boolean {
  const downloadJob = activeDownloads.get(videoId);
  if (!downloadJob) {
    logger.info('No active download found for video:', videoId);
    return false;
  }
  
  try {
    // Abort the download
    downloadJob.abortController.abort();
    
    // Remove from active downloads
    activeDownloads.delete(videoId);
    
    return true;
  } catch (error) {
    logger.error('Error cancelling download:', error);
    return false;
  }
}

/**
 * Get all active downloads
 */
export function getActiveDownloads(): Array<{ videoId: string | number; progress: number; title: string }> {
  const downloads: Array<{ videoId: string | number; progress: number; title: string }> = [];
  
  for (const [videoId, job] of activeDownloads.entries()) {
    downloads.push({
      videoId,
      progress: 0, // This would be updated with actual progress in a real implementation
      title: job.title
    });
  }
  
  return downloads;
}

/* Removed duplicate isConnectedToWifi stub implementation */



// Encryption key derivation
async function deriveEncryptionKey(videoId: string): Promise<CryptoKey> {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    encoder.encode(`madifa_video_${videoId}_encryption_key`),
    'PBKDF2',
    false,
    ['deriveKey']
  );
  
  return crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: encoder.encode('madifa_salt'),
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

// Encrypt video data for secure storage
async function encryptVideoData(videoData: Uint8Array, videoId: string): Promise<Uint8Array> {
  try {
    const key = await deriveEncryptionKey(videoId);
    const iv = crypto.getRandomValues(new Uint8Array(12)); // AES-GCM uses 12-byte IV
    
    const encryptedData = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      videoData.buffer as BufferSource
    );
    
    // Combine IV and encrypted data
    const result = new Uint8Array(iv.length + encryptedData.byteLength);
    result.set(iv, 0);
    result.set(new Uint8Array(encryptedData), iv.length);
    
    return result;
  } catch (error) {
    logger.error('Error encrypting video data:', error);
    throw new Error('Failed to encrypt video data');
  }
}

// Decrypt video data for playback
export async function decryptVideoData(encryptedData: Uint8Array, videoId: string): Promise<Uint8Array> {
  try {
    const key = await deriveEncryptionKey(videoId);
    const iv = encryptedData.slice(0, 12);
    const data = encryptedData.slice(12);
    
    const decryptedData = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      data
    );
    
    return new Uint8Array(decryptedData);
  } catch (error) {
    logger.error('Error decrypting video data:', error);
    throw new Error('Failed to decrypt video data');
  }
}

// Store video data in IndexedDB (for web platform)
async function storeVideoData(videoId: string | number, encryptedData: Uint8Array, thumbnailUrl: string): Promise<void> {
  const dbName = 'madifa_video_storage';
  const dbVersion = 1;
  
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(dbName, dbVersion);
    
    request.onerror = () => reject(new Error('Failed to open video storage database'));
    
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains('videos')) {
        db.createObjectStore('videos', { keyPath: 'id' });
      }
    };
    
    request.onsuccess = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      const transaction = db.transaction(['videos'], 'readwrite');
      const store = transaction.objectStore('videos');
      
      const videoRecord = {
        id: videoId,
        data: encryptedData,
        thumbnailUrl,
        storedAt: new Date().toISOString()
      };
      
      const putRequest = store.put(videoRecord);
      putRequest.onsuccess = () => resolve();
      putRequest.onerror = () => reject(new Error('Failed to store video data'));
    };
  });
}

// Get stored video data from IndexedDB
export async function getStoredVideoData(videoId: string | number): Promise<Uint8Array | null> {
  const dbName = 'madifa_video_storage';
  
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(dbName);
    
    request.onerror = () => reject(new Error('Failed to open video storage database'));
    
    request.onsuccess = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      const transaction = db.transaction(['videos'], 'readonly');
      const store = transaction.objectStore('videos');
      
      const getRequest = store.get(videoId);
      getRequest.onsuccess = () => {
        if (getRequest.result) {
          resolve(getRequest.result.data);
        } else {
          resolve(null);
        }
      };
      getRequest.onerror = () => reject(new Error('Failed to get video data'));
    };
  });
}

/**
 * Check if device is connected to Wi-Fi
 */
export function isConnectedToWifi(): boolean {
  // Check if navigator.connection is available (Network Information API)
  const connection = (navigator as unknown as { connection?: unknown; mozConnection?: unknown; webkitConnection?: unknown }).connection || (navigator as unknown as { connection?: unknown; mozConnection?: unknown; webkitConnection?: unknown }).mozConnection || (navigator as unknown as { connection?: unknown; mozConnection?: unknown; webkitConnection?: unknown }).webkitConnection;
  
  if (connection) {
    // Check if connection type indicates Wi-Fi
    return (connection as any).type === 'wifi' || (connection as any).effectiveType === '4g';
  }
  
  // Fallback: assume Wi-Fi if we can't determine
  return true;
}

/**
 * Check available storage space
 */
export async function getAvailableStorageSpace(): Promise<number> {
  try {
    // Use Storage API if available
    if ('storage' in navigator && 'estimate' in navigator.storage) {
      const estimate = await navigator.storage.estimate();
      return estimate.quota ? estimate.quota - (estimate.usage || 0) : 1024 * 1024 * 1024;
    }
  } catch (error) {
    logger.warn('Unable to estimate storage space:', error);
  }
  
  // Fallback: Return 1GB as a conservative estimate
  return 1024 * 1024 * 1024;
}