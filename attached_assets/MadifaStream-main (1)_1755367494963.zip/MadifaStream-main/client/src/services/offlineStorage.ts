/**
 * Offline Storage Service
 * Manages local storage of videos and metadata for offline viewing
 */

import { getPlatform } from '../capacitor-adapter';
import { logger } from '@shared/logger';

// Types
export interface OfflineVideo {
  id: string | number;
  title: string;
  description?: string;
  thumbnailUrl: string;
  localVideoPath?: string;
  localThumbnailPath?: string;
  downloadProgress: number; // 0-100
  downloadState: 'idle' | 'downloading' | 'completed' | 'error';
  downloadError?: string;
  fileSize?: number; // In bytes
  duration?: number; // In seconds
  downloadDate?: string;
  expiryDate?: string; // Optional expiry date
  videoQuality?: 'SD' | 'HD';
  isHdr?: boolean;
}

// Database name and version
const DB_NAME = 'madifa_offline_db';
const DB_VERSION = 1;

// IndexedDB instance
let db: IDBDatabase | null = null;

/**
 * Initialize the offline storage database
 */
export async function initOfflineStorage(): Promise<boolean> {
  return new Promise((resolve, reject) => {
    try {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = (event) => {
        if (import.meta.env.DEV) {
          logger.db('Failed to open offline database:', { arg1: event });
        }
        reject(new Error('Failed to open offline database'));
      };

      request.onsuccess = (event) => {
        db = (event.target as IDBOpenDBRequest).result;
        logger.info('Offline database opened successfully');
        resolve(true);
      };

      request.onupgradeneeded = (event) => {
        const database = (event.target as IDBOpenDBRequest).result;
        
        // Create videos object store if it doesn't exist
        if (!database.objectStoreNames.contains('videos')) {
          const videoStore = database.createObjectStore('videos', { keyPath: 'id' });
          videoStore.createIndex('downloadState', 'downloadState', { unique: false });
          videoStore.createIndex('downloadDate', 'downloadDate', { unique: false });
        }
        
        // Create metadata store if it doesn't exist
        if (!database.objectStoreNames.contains('metadata')) {
          database.createObjectStore('metadata', { keyPath: 'key' });
        }
      };
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Error initializing offline storage:', { arg1: error });
      }
      reject(error);
    }
  });
}

/**
 * Save video metadata for offline viewing
 */
export async function saveOfflineVideo(video: OfflineVideo): Promise<boolean> {
  return new Promise((resolve, reject) => {
    if (!db) {
      reject(new Error('Database not initialized'));
      return;
    }

    try {
      const transaction = db.transaction(['videos'], 'readwrite');
      const store = transaction.objectStore('videos');
      
      const request = store.put(video);
      
      request.onsuccess = () => {
        resolve(true);
      };
      
      request.onerror = (event) => {
        if (import.meta.env.DEV) {
          logger.error('Error saving offline video:', { arg1: event });
        }
        reject(new Error('Failed to save offline video'));
      };
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Error in saveOfflineVideo:', { arg1: error });
      }
      reject(error);
    }
  });
}

/**
 * Get all offline videos
 */
export async function getAllOfflineVideos(): Promise<OfflineVideo[]> {
  return new Promise((resolve, reject) => {
    if (!db) {
      reject(new Error('Database not initialized'));
      return;
    }

    try {
      const transaction = db.transaction(['videos'], 'readonly');
      const store = transaction.objectStore('videos');
      const request = store.getAll();
      
      request.onsuccess = () => {
        resolve(request.result);
      };
      
      request.onerror = (event) => {
        if (import.meta.env.DEV) {
          logger.error('Error getting offline videos:', { arg1: event });
        }
        reject(new Error('Failed to get offline videos'));
      };
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Error in getAllOfflineVideos:', { arg1: error });
      }
      reject(error);
    }
  });
}

/**
 * Get a specific offline video by ID
 */
export async function getOfflineVideo(id: string | number): Promise<OfflineVideo | null> {
  return new Promise((resolve, reject) => {
    if (!db) {
      reject(new Error('Database not initialized'));
      return;
    }

    try {
      const transaction = db.transaction(['videos'], 'readonly');
      const store = transaction.objectStore('videos');
      const request = store.get(id);
      
      request.onsuccess = () => {
        resolve(request.result || null);
      };
      
      request.onerror = (event) => {
        if (import.meta.env.DEV) {
          logger.error('Error getting offline video:', { arg1: event });
        }
        reject(new Error('Failed to get offline video'));
      };
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Error in getOfflineVideo:', { arg1: error });
      }
      reject(error);
    }
  });
}

/**
 * Update download progress for a video
 */
export async function updateDownloadProgress(
  id: string | number, 
  progress: number, 
  state: OfflineVideo['downloadState'],
  error?: string
): Promise<boolean> {
  return new Promise((resolve, reject) => {
    if (!db) {
      reject(new Error('Database not initialized'));
      return;
    }

    try {
      const transaction = db.transaction(['videos'], 'readwrite');
      const store = transaction.objectStore('videos');
      const request = store.get(id);
      
      request.onsuccess = () => {
        const video = request.result;
        if (!video) {
          reject(new Error('Video not found'));
          return;
        }
        
        video.downloadProgress = progress;
        video.downloadState = state;
        if (error) video.downloadError = error;
        
        // If download is completed, set the download date
        if (state === 'completed') {
          video.downloadDate = new Date().toISOString();
        }
        
        const updateRequest = store.put(video);
        
        updateRequest.onsuccess = () => {
          resolve(true);
        };
        
        updateRequest.onerror = (event) => {
          if (import.meta.env.DEV) {
            logger.error('Error updating download progress:', { arg1: event });
          }
          reject(new Error('Failed to update download progress'));
        };
      };
      
      request.onerror = (event) => {
        if (import.meta.env.DEV) {
          logger.error('Error getting video for progress update:', { arg1: event });
        }
        reject(new Error('Failed to get video for progress update'));
      };
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Error in updateDownloadProgress:', { arg1: error });
      }
      reject(error);
    }
  });
}

/**
 * Delete an offline video
 */
export async function deleteOfflineVideo(id: string | number): Promise<boolean> {
  return new Promise((resolve, reject) => {
    if (!db) {
      reject(new Error('Database not initialized'));
      return;
    }

    try {
      // First get the video to get file paths
      const transaction = db.transaction(['videos'], 'readwrite');
      const store = transaction.objectStore('videos');
      const getRequest = store.get(id);
      
      getRequest.onsuccess = async () => {
        const video = getRequest.result;
        if (!video) {
          resolve(true); // Already deleted or doesn't exist
          return;
        }
        
        // Delete actual files if we're in a Capacitor environment
        if (getPlatform() !== 'web') {
          // Delete files (implementation depends on Capacitor setup)
          try {
            if (video.localVideoPath) {
              logger.debug('Would delete video file at:', video.localVideoPath);
            }
            
            if (video.localThumbnailPath) {
              logger.debug('Would delete thumbnail file at:', video.localThumbnailPath);
            }
          } catch (fileError) {
            if (import.meta.env.DEV) {
              logger.error('Error deleting offline files:', { arg1: fileError });
            }
            // Continue with database deletion even if file deletion fails
          }
        }
        
        // Delete from database
        const deleteRequest = store.delete(id);
        
        deleteRequest.onsuccess = () => {
          resolve(true);
        };
        
        deleteRequest.onerror = (event) => {
          if (import.meta.env.DEV) {
            logger.db('Error deleting offline video from database:', { arg1: event });
          }
          reject(new Error('Failed to delete offline video from database'));
        };
      };
      
      getRequest.onerror = (event) => {
        if (import.meta.env.DEV) {
          logger.error('Error getting video for deletion:', { arg1: event });
        }
        reject(new Error('Failed to get video for deletion'));
      };
    } catch (error) {
      if (import.meta.env.DEV) {
        logger.error('Error in deleteOfflineVideo:', { arg1: error });
      }
      reject(error);
    }
  });
}

/**
 * Get the total size of all offline videos
 */
export async function getTotalOfflineStorageSize(): Promise<number> {
  try {
    const videos = await getAllOfflineVideos();
    return videos.reduce((total, video) => total + (video.fileSize || 0), 0);
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.error('Error calculating total storage size:', { arg1: error });
    }
    return 0;
  }
}

/**
 * Check if a video is available offline
 */
export async function isVideoAvailableOffline(id: string | number): Promise<boolean> {
  try {
    const video = await getOfflineVideo(id);
    return !!video && video.downloadState === 'completed';
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.error('Error checking if video is available offline:', { arg1: error });
    }
    return false;
  }
}

/**
 * Storage cleanup - remove expired videos or videos with errors
 */
export async function cleanupOfflineStorage(): Promise<number> {
  try {
    const videos = await getAllOfflineVideos();
    let cleanupCount = 0;
    
    for (const video of videos) {
      const shouldDelete = (
        // Delete videos with errors
        video.downloadState === 'error' ||
        // Delete videos with expiry dates that have passed
        (video.expiryDate && new Date(video.expiryDate) < new Date())
      );
      
      if (shouldDelete) {
        await deleteOfflineVideo(video.id);
        cleanupCount++;
      }
    }
    
    return cleanupCount;
  } catch (error) {
    if (import.meta.env.DEV) {
      logger.error('Error during storage cleanup:', { arg1: error });
    }
    return 0;
  }
}