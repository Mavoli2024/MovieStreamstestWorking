import pRetry from 'p-retry';
import { logger } from '@shared/logger';

interface ApiConfig {
  baseUrl?: string;
  timeout?: number;
  retries?: number;
  retryDelay?: number;
  headers?: Record<string, string>;
}

interface ApiResponse<T = any> {
  data: T;
  status: number;
  statusText: string;
}

interface ApiError extends Error {
  status?: number;
  code?: string;
  retryable?: boolean;
}

class RobustApiService {
  private config: Required<ApiConfig>;
  private authToken: string | null = null;

  constructor(config: ApiConfig = {}) {
    this.config = {
      baseUrl: config.baseUrl || '',
      timeout: config.timeout || 30000,
      retries: config.retries || 3,
      retryDelay: config.retryDelay || 1000,
      headers: {
        'Content-Type': 'application/json',
        ...config.headers,
      },
    };

    // Initialize auth token from localStorage
    this.authToken = localStorage.getItem('auth_token');
  }

  setAuthToken(token: string | null) {
    this.authToken = token;
    if (token) {
      localStorage.setItem('auth_token', token);
    } else {
      localStorage.removeItem('auth_token');
    }
  }

  private getHeaders(): Record<string, string> {
    const headers = { ...this.config.headers };
    
    if (this.authToken) {
      headers.Authorization = `Bearer ${this.authToken}`;
    }
    
    return headers;
  }

  private async makeRequest<T>(
    url: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.config.timeout);

    try {
      const fullUrl = url.startsWith('http') ? url : `${this.config.baseUrl}${url}`;
      
      const response = await fetch(fullUrl, {
        ...options,
        headers: {
          ...this.getHeaders(),
          ...options.headers,
        },
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      // Handle different response types
      let data: T;
      const contentType = response.headers.get('content-type');
      
      if (contentType?.includes('application/json')) {
        data = await response.json();
      } else if (contentType?.includes('text/')) {
        data = (await response.text()) as any;
      } else {
        data = (await response.blob()) as any;
      }

      if (!response.ok) {
        const error: ApiError = new Error(
          typeof data === 'object' && data && 'message' in data 
            ? (data as any).message 
            : `HTTP ${response.status}: ${response.statusText}`
        );
        error.status = response.status;
        error.code = typeof data === 'object' && data && 'code' in data ? (data as any).code : undefined;
        
        // Determine if error is retryable
        error.retryable = response.status >= 500 || 
                         response.status === 429 || 
                         response.status === 408 ||
                         response.status === 0; // Network error
        
        throw error;
      }

      return {
        data,
        status: response.status,
        statusText: response.statusText,
      };
    } catch (error) {
      clearTimeout(timeoutId);
      
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          const timeoutError: ApiError = new Error('Request timeout');
          timeoutError.status = 408;
          timeoutError.retryable = true;
          throw timeoutError;
        }
        
        // Network errors
        if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
          const networkError: ApiError = new Error('Network connection failed');
          networkError.status = 0;
          networkError.retryable = true;
          throw networkError;
        }
      }
      
      throw error;
    }
  }

  private async requestWithRetry<T>(
    url: string,
    options: RequestInit = {}
  ): Promise<ApiResponse<T>> {
    return pRetry(
      async () => {
        try {
          return await this.makeRequest<T>(url, options);
        } catch (error) {
          const apiError = error as ApiError;
          
          // Don't retry client errors (4xx) except 408, 429
          if (apiError.status && apiError.status >= 400 && apiError.status < 500) {
            if (apiError.status !== 408 && apiError.status !== 429) {
              apiError.retryable = false;
            }
          }
          
          if (!apiError.retryable) {
            // Mark as non-retryable to stop pRetry
            throw new pRetry.AbortError(apiError.message);
          }
          
          throw error;
        }
      },
      {
        retries: this.config.retries,
        minTimeout: this.config.retryDelay,
        maxTimeout: this.config.retryDelay * 4,
        factor: 2,
        onFailedAttempt: (error) => {
          logger.warn(`API request failed (attempt ${error.attemptNumber}/${this.config.retries + 1}):`, {
            url,
            error: error.message,
            status: (error as ApiError).status,
          });
        },
      }
    );
  }

  async get<T = any>(url: string, params?: Record<string, any>): Promise<T> {
    const urlWithParams = params 
      ? `${url}?${new URLSearchParams(params).toString()}`
      : url;
    
    const response = await this.requestWithRetry<T>(urlWithParams, {
      method: 'GET',
    });
    
    return response.data;
  }

  async post<T = any>(url: string, data?: any): Promise<T> {
    const response = await this.requestWithRetry<T>(url, {
      method: 'POST',
      body: data ? JSON.stringify(data) : undefined,
    });
    
    return response.data;
  }

  async put<T = any>(url: string, data?: any): Promise<T> {
    const response = await this.requestWithRetry<T>(url, {
      method: 'PUT',
      body: data ? JSON.stringify(data) : undefined,
    });
    
    return response.data;
  }

  async delete<T = any>(url: string): Promise<T> {
    const response = await this.requestWithRetry<T>(url, {
      method: 'DELETE',
    });
    
    return response.data;
  }

  // Specialized method for video URL signing with enhanced error handling
  async getSignedVideoUrl(videoId: string, expiresIn: number = 3600): Promise<{
    signedUrl: string;
    expires: number;
    video: { id: string; title: string; duration?: number };
  }> {
    try {
      return await this.post('/api/signed-video-url', {
        videoId,
        expiresIn,
      });
    } catch (error) {
      const apiError = error as ApiError;
      
      // Enhanced error handling for video URLs
      if (apiError.status === 405) {
        throw new Error('Video service temporarily unavailable. Please try again in a moment.');
      } else if (apiError.status === 403) {
        throw new Error('Premium subscription required to watch this video.');
      } else if (apiError.status === 404) {
        throw new Error('Video not found or no longer available.');
      } else if (apiError.status === 401) {
        throw new Error('Please log in to watch videos.');
      }
      
      throw new Error('Unable to load video. Please try again.');
    }
  }

  // Health check with circuit breaker pattern
  private isHealthy = true;
  private lastHealthCheck = 0;
  private healthCheckInterval = 60000; // 1 minute

  async healthCheck(): Promise<boolean> {
    const now = Date.now();
    
    // Skip if recently checked and healthy
    if (this.isHealthy && (now - this.lastHealthCheck) < this.healthCheckInterval) {
      return true;
    }

    try {
      await this.get('/api/health');
      this.isHealthy = true;
      this.lastHealthCheck = now;
      return true;
    } catch (error) {
      this.isHealthy = false;
      this.lastHealthCheck = now;
      logger.error('API health check failed:', error);
      return false;
    }
  }

  // Get service status
  getStatus(): {
    healthy: boolean;
    lastCheck: number;
    hasAuth: boolean;
  } {
    return {
      healthy: this.isHealthy,
      lastCheck: this.lastHealthCheck,
      hasAuth: !!this.authToken,
    };
  }
}

// Export singleton instance
export const robustApi = new RobustApiService({
  timeout: 30000,
  retries: 3,
  retryDelay: 1000,
});

export default robustApi;