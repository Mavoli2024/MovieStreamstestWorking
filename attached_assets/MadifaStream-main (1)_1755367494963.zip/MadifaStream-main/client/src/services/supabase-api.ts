/* eslint-disable @typescript-eslint/no-explicit-any */
import { logger } from '@shared/logger';
import { supabase } from '@/lib/supabase';
import { generatePlaceholderThumbnail } from '@/lib/placeholder-utils';

// Temporary broad type until full typing is completed
type EnhancedVideo = unknown;

// Get videos with pagination and access checking
export async function getVideos(
  page= 0,
  limit= 20,
  category?: string
): Promise<{ data: EnhancedVideo[]; hasMore: boolean; totalCount?: number }> {
  try {
    logger.debug(`Fetching videos from Supabase - page: ${page}, limit: ${limit}, category: ${category}`);

    let query = supabase
      .from('videos')
      .select('*')
      .order('created_at', { ascending: false })
      .range(page * limit, (page + 1) * limit - 1);

    if (category) {
      query = query.eq('category', category);
    }

    const { data, error } = await query;

    if (error) {
      logger.error('Error fetching videos from Supabase:', error);
      
      // Handle specific RLS permission error by returning empty results instead of throwing
      if ((error as any)?.code === '42501') {
        logger.warn('Permission denied for videos table - returning empty results');
        return { data: [], hasMore: false, totalCount: 0 };
      }
      
      logger.error('Error fetching videos:', error);
      throw error;
    }

    logger.info(`Successfully fetched ${data?.length || 0} videos from Supabase`);

    const enhancedVideos = data?.map(video => ({
      ...video,
      thumbnail_url: video.thumbnail_url || generatePlaceholderThumbnail(video.title),
      created_at: new Date(video.created_at).toISOString(),
      updated_at: new Date(video.updated_at).toISOString()
    })) || [];

    return {
      data: enhancedVideos,
      hasMore: data?.length === limit,
      totalCount: data?.length || 0
    };
  } catch (error: unknown) {
    logger.error('Error in getVideos:', error);
    
    // Return empty results for permission errors instead of throwing
    if ((error as any)?.code === '42501') {
      return { data: [], hasMore: false, totalCount: 0 };
    }
    
    throw error;
  }
} 