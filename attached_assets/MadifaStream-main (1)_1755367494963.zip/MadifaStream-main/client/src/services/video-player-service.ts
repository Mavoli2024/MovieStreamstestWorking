/**
 * Video Player Service
 * 
 * Robust video streaming service with:
 * - Automatic retry logic for failed streams
 * - Quality adaptation based on network conditions
 * - Error recovery and fallback mechanisms
 * - Progress tracking and analytics
 * - Offline detection and handling
 */

import pRetry from 'p-retry';
import { logger } from '@shared/logger';
import { supabase } from '@/lib/supabase';

export interface VideoStreamConfig {
  videoId: string;
  videoUrl?: string;
  quality?: 'auto' | '1080p' | '720p' | '480p' | '360p';
  startTime?: number;
  headers?: Record<string, string>;
}

export interface StreamHealth {
  bitrate: number;
  bufferedSeconds: number;
  droppedFrames: number;
  networkSpeed: number;
  recommendedQuality: string;
}

export interface VideoErrorDetails {
  code: 'NETWORK_ERROR' | 'DECODE_ERROR' | 'SOURCE_ERROR' | 'PERMISSION_ERROR' | 'UNKNOWN_ERROR';
  message: string;
  details?: unknown;
  recoverable: boolean;
}

class VideoPlayerService {
  private static instance: VideoPlayerService;
  private activeStreams = new Map<string, AbortController>();
  private streamHealth = new Map<string, StreamHealth>();
  private retryAttempts = new Map<string, number>();

  private constructor() {}

  static getInstance(): VideoPlayerService {
    if (!VideoPlayerService.instance) {
      VideoPlayerService.instance = new VideoPlayerService();
    }
    return VideoPlayerService.instance;
  }

  /**
   * Get video stream URL with retry logic and fallback
   */
  async getStreamUrl(config: VideoStreamConfig): Promise<string> {
    const { videoId, videoUrl, quality = 'auto' } = config;

    // If direct URL provided, validate and return
    if (videoUrl) {
      return this.validateStreamUrl(videoUrl);
    }

    // Retry logic for fetching stream URL
    return pRetry(
      async () => {
        const url = await this.fetchStreamUrl(videoId, quality);
        return this.validateStreamUrl(url);
      },
      {
        retries: 3,
        minTimeout: 1000,
        maxTimeout: 5000,
        onFailedAttempt: (error) => {
          logger.warn(`Stream URL fetch attempt ${error.attemptNumber} failed:`, error);
          this.retryAttempts.set(videoId, error.attemptNumber);
        },
      }
    );
  }

  /**
   * Fetch stream URL from backend
   */
  private async fetchStreamUrl(videoId: string, quality: string): Promise<string> {
    const controller = new AbortController();
    this.activeStreams.set(videoId, controller);

    try {
      // Call server route that returns a signed Bunny URL
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData.session?.access_token;

      const response = await fetch(`/api/signed-video-url`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({ videoId, expiresIn: 3600 }),
        signal: controller.signal,
        credentials: 'include',
      });

      if (!response.ok) {
        if (response.status === 402 || response.status === 403) {
          throw this.createError('PERMISSION_ERROR', 'Subscription required', false);
        }
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const data = await response.json();
      const streamUrl = data?.signedUrl;
      if (!streamUrl) {
        throw new Error('No signedUrl in response');
      }

      return streamUrl;
    } catch (error) {
      // If primary fails, try fallback
      if (error instanceof Error && error.name !== 'AbortError') {
        return this.fetchFallbackStream(videoId);
      }
      throw error;
    } finally {
      this.activeStreams.delete(videoId);
    }
  }

  /**
   * Fallback stream fetching mechanism
   */
  private async fetchFallbackStream(videoId: string): Promise<string> {
    try {
      // Try public videos endpoint (matches server payload shape)
      const response = await fetch('/api/videos/public');
      if (response.ok) {
        const payload = await response.json();
        const videos = payload?.items ?? [];
        const video = videos.find((v: any) => v.id === videoId);
        if (video?.video_url) {
          return video.video_url;
        }
      }
    } catch (error) {
      logger.error('Fallback stream fetch failed:', error);
    }

    throw this.createError('SOURCE_ERROR', 'Unable to locate video stream', true);
  }

  /**
   * Validate stream URL
   */
  private async validateStreamUrl(url: string): Promise<string> {
    if (!url || typeof url !== 'string') {
      throw this.createError('SOURCE_ERROR', 'Invalid stream URL', false);
    }

    // Validate URL format
    try {
      const urlObj = new URL(url, window.location.origin);
      
      // Check if it's a supported video URL
      const supportedHosts = ['bunnycdn.com', 'b-cdn.net', 'cloudfront.net'];
      const isSupported = supportedHosts.some(host => urlObj.hostname.includes(host));
      
      if (!isSupported && !urlObj.hostname.includes(window.location.hostname)) {
        logger.warn('Stream URL from unsupported host:', urlObj.hostname);
      }

      return urlObj.toString();
    } catch (error) {
      throw this.createError('SOURCE_ERROR', 'Malformed stream URL', false);
    }
  }

  /**
   * Monitor stream health and adapt quality
   */
  monitorStreamHealth(
    videoId: string,
    video: HTMLVideoElement,
    onQualityChange?: (quality: string) => void
  ): () => void {
    let lastTime = 0;
    let lastDroppedFrames = 0;
    
    const interval = setInterval(() => {
      if (video.paused || video.ended) return;

      const currentTime = video.currentTime;
      const buffered = video.buffered.length > 0 
        ? video.buffered.end(video.buffered.length - 1) - currentTime
        : 0;

      // Calculate effective bitrate
      const timeDelta = currentTime - lastTime;
      const bitrate = timeDelta > 0 ? (video.videoWidth * video.videoHeight * 30 * timeDelta) / 1000000 : 0;

      // Check for dropped frames (if supported)
      const videoQuality = (video as any).getVideoPlaybackQuality?.();
      const droppedFrames = videoQuality?.droppedVideoFrames || 0;
      const droppedDelta = droppedFrames - lastDroppedFrames;

      // Estimate network speed
      const networkSpeed = this.estimateNetworkSpeed();

      // Determine recommended quality
      const recommendedQuality = this.calculateRecommendedQuality(
        bitrate,
        buffered,
        droppedDelta,
        networkSpeed
      );

      const health: StreamHealth = {
        bitrate,
        bufferedSeconds: buffered,
        droppedFrames: droppedDelta,
        networkSpeed,
        recommendedQuality,
      };

      this.streamHealth.set(videoId, health);

      // Notify if quality should change
      if (onQualityChange && health.recommendedQuality !== this.getCurrentQuality(video)) {
        onQualityChange(health.recommendedQuality);
      }

      lastTime = currentTime;
      lastDroppedFrames = droppedFrames;
    }, 2000);

    // Return cleanup function
    return () => {
      clearInterval(interval);
      this.streamHealth.delete(videoId);
    };
  }

  /**
   * Estimate network speed using Navigation Timing API
   */
  private estimateNetworkSpeed(): number {
    if ('connection' in navigator) {
      const connection = (navigator as any).connection;
      if (connection?.downlink) {
        return connection.downlink; // Mbps
      }
    }

    // Fallback estimation based on resource timing
    const perfEntries = performance.getEntriesByType('resource')
      .filter(entry => entry.name.includes('video') || entry.name.includes('stream'))
      .slice(-5); // Last 5 video resources

    if (perfEntries.length > 0) {
      const speeds = perfEntries.map(entry => {
        const bytes = (entry as any).transferSize || 0;
        const duration = entry.duration / 1000; // Convert to seconds
        return bytes > 0 && duration > 0 ? (bytes * 8) / (duration * 1000000) : 0; // Mbps
      }).filter(speed => speed > 0);

      if (speeds.length > 0) {
        return speeds.reduce((a, b) => a + b) / speeds.length;
      }
    }

    return 10; // Default assumption: 10 Mbps
  }

  /**
   * Calculate recommended quality based on metrics
   */
  private calculateRecommendedQuality(
    bitrate: number,
    buffered: number,
    droppedFrames: number,
    networkSpeed: number
  ): string {
    // Quality thresholds (Mbps)
    const qualityBitrates = {
      '1080p': 8,
      '720p': 5,
      '480p': 2.5,
      '360p': 1,
    };

    // Start with network-based recommendation
    let recommended = '360p';
    for (const [quality, requiredBitrate] of Object.entries(qualityBitrates)) {
      if (networkSpeed >= requiredBitrate * 1.5) { // 50% headroom
        recommended = quality;
      } else {
        break;
      }
    }

    // Downgrade if buffering issues
    if (buffered < 5) { // Less than 5 seconds buffered
      const qualities = Object.keys(qualityBitrates);
      const currentIndex = qualities.indexOf(recommended);
      if (currentIndex > 0) {
        recommended = qualities[currentIndex - 1];
      }
    }

    // Downgrade if dropping frames
    if (droppedFrames > 5) { // More than 5 frames dropped in interval
      const qualities = Object.keys(qualityBitrates);
      const currentIndex = qualities.indexOf(recommended);
      if (currentIndex > 0) {
        recommended = qualities[currentIndex - 1];
      }
    }

    return recommended;
  }

  /**
   * Get current quality from video element
   */
  private getCurrentQuality(video: HTMLVideoElement): string {
    const height = video.videoHeight;
    if (height >= 1080) return '1080p';
    if (height >= 720) return '720p';
    if (height >= 480) return '480p';
    return '360p';
  }

  /**
   * Handle video errors with recovery strategies
   */
  async handleVideoError(
    error: Error | Event,
    video: HTMLVideoElement,
    config: VideoStreamConfig
  ): Promise<boolean> {
    const videoError = this.parseVideoError(error, video);
    
    logger.error('Video playback error:', videoError);

    if (!videoError.recoverable) {
      return false;
    }

    // Try recovery strategies
    const strategies = [
      () => this.reloadVideo(video),
      () => this.switchToLowerQuality(video, config),
      () => this.tryAlternateSource(video, config),
    ];

    for (const strategy of strategies) {
      try {
        const recovered = await strategy();
        if (recovered) {
          logger.info('Video error recovered');
          return true;
        }
      } catch (strategyError) {
        logger.warn('Recovery strategy failed:', strategyError);
      }
    }

    return false;
  }

  /**
   * Parse video error into structured format
   */
  private parseVideoError(error: Error | Event, video: HTMLVideoElement): VideoErrorDetails {
    if (error instanceof Event && error.type === 'error') {
      const videoError = video.error;
      
      if (videoError) {
        switch (videoError.code) {
          case videoError.MEDIA_ERR_NETWORK:
            return this.createError('NETWORK_ERROR', 'Network error while loading video', true);
          case videoError.MEDIA_ERR_DECODE:
            return this.createError('DECODE_ERROR', 'Video format not supported', false);
          case videoError.MEDIA_ERR_SRC_NOT_SUPPORTED:
            return this.createError('SOURCE_ERROR', 'Video source not supported', true);
          default:
            return this.createError('UNKNOWN_ERROR', videoError.message || 'Unknown video error', true);
        }
      }
    }

    if (error instanceof Error) {
      if (error.name === 'NotAllowedError') {
        return this.createError('PERMISSION_ERROR', 'Playback not allowed', false);
      }
      
      if (error.message.includes('network') || error.message.includes('fetch')) {
        return this.createError('NETWORK_ERROR', error.message, true);
      }
    }

    return this.createError('UNKNOWN_ERROR', 'An unexpected error occurred', true);
  }

  /**
   * Create structured error
   */
  private createError(
    code: VideoErrorDetails['code'],
    message: string,
    recoverable: boolean,
    details?: unknown
  ): VideoErrorDetails {
    const err = new Error(message) as Error & VideoErrorDetails;
    err.name = code;
    err.message = message;
    (err as any).code = code;
    (err as any).recoverable = recoverable;
    if (details !== undefined) (err as any).details = details;
    return err as unknown as VideoErrorDetails;
  }

  /**
   * Recovery strategy: Reload video
   */
  private async reloadVideo(video: HTMLVideoElement): Promise<boolean> {
    const currentTime = video.currentTime;
    const src = video.src;
    
    video.src = '';
    video.load();
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    video.src = src;
    video.currentTime = currentTime;
    
    return new Promise((resolve) => {
      const handleCanPlay = () => {
        video.removeEventListener('canplay', handleCanPlay);
        resolve(true);
      };
      
      const handleError = () => {
        video.removeEventListener('error', handleError);
        resolve(false);
      };
      
      video.addEventListener('canplay', handleCanPlay);
      video.addEventListener('error', handleError);
      
      video.load();
    });
  }

  /**
   * Recovery strategy: Switch to lower quality
   */
  private async switchToLowerQuality(
    video: HTMLVideoElement,
    config: VideoStreamConfig
  ): Promise<boolean> {
    const qualities = ['720p', '480p', '360p'];
    const currentQuality = this.getCurrentQuality(video);
    const currentIndex = qualities.indexOf(currentQuality);
    
    if (currentIndex === -1 || currentIndex === qualities.length - 1) {
      return false;
    }
    
    const lowerQuality = qualities[currentIndex + 1];
    const newUrl = await this.getStreamUrl({ ...config, quality: lowerQuality as any });
    
    if (newUrl && newUrl !== video.src) {
      const currentTime = video.currentTime;
      video.src = newUrl;
      video.currentTime = currentTime;
      
      return new Promise((resolve) => {
        const handleCanPlay = () => {
          video.removeEventListener('canplay', handleCanPlay);
          resolve(true);
        };
        
        video.addEventListener('canplay', handleCanPlay);
        video.load();
      });
    }
    
    return false;
  }

  /**
   * Recovery strategy: Try alternate source
   */
  private async tryAlternateSource(
    video: HTMLVideoElement,
    config: VideoStreamConfig
  ): Promise<boolean> {
    try {
      const fallbackUrl = await this.fetchFallbackStream(config.videoId);
      if (fallbackUrl && fallbackUrl !== video.src) {
        const currentTime = video.currentTime;
        video.src = fallbackUrl;
        video.currentTime = currentTime;
        
        return new Promise((resolve) => {
          const handleCanPlay = () => {
            video.removeEventListener('canplay', handleCanPlay);
            resolve(true);
          };
          
          video.addEventListener('canplay', handleCanPlay);
          video.load();
        });
      }
    } catch (error) {
      logger.error('Failed to get alternate source:', error);
    }
    
    return false;
  }

  /**
   * Clean up resources
   */
  cleanup(videoId: string): void {
    const controller = this.activeStreams.get(videoId);
    if (controller) {
      controller.abort();
      this.activeStreams.delete(videoId);
    }
    
    this.streamHealth.delete(videoId);
    this.retryAttempts.delete(videoId);
  }
}

export const videoPlayerService = VideoPlayerService.getInstance(); 