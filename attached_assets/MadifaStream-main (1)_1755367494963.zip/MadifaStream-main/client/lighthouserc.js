module.exports = {
  ci: {
    collect: {
      url: [
        'http://localhost:5173/', // Home page
        'http://localhost:5173/browse', // Browse page
        'http://localhost:5173/categories', // Categories
        'http://localhost:5173/profile', // Profile page
        'http://localhost:5173/admin', // Admin dashboard
        'http://localhost:5173/watch/1', // Video player page
      ],
      numberOfRuns: 3,
      settings: {
        chromeFlags: '--no-sandbox --disable-dev-shm-usage',
        preset: 'desktop',
        throttling: {
          rttMs: 40,
          throughputKbps: 10240,
          cpuSlowdownMultiplier: 1,
          requestLatencyMs: 0,
          downloadThroughputKbps: 0,
          uploadThroughputKbps: 0
        }
      }
    },
    assert: {
      assertions: {
        'categories:performance': ['error', {minScore: 0.8}],
        'categories:accessibility': ['error', {minScore: 0.9}],
        'categories:best-practices': ['error', {minScore: 0.9}],
        'categories:seo': ['error', {minScore: 0.8}],
        'categories:pwa': ['warn', {minScore: 0.6}],
        
        // Core Web Vitals
        'first-contentful-paint': ['error', {maxNumericValue: 2000}],
        'largest-contentful-paint': ['error', {maxNumericValue: 2500}],
        'cumulative-layout-shift': ['error', {maxNumericValue: 0.1}],
        'total-blocking-time': ['error', {maxNumericValue: 300}],
        
        // Performance metrics
        'speed-index': ['error', {maxNumericValue: 3000}],
        'interactive': ['error', {maxNumericValue: 3500}],
        
        // Resource optimization
        'unused-javascript': ['warn', {maxNumericValue: 20000}],
        'unused-css-rules': ['warn', {maxNumericValue: 20000}],
        'modern-image-formats': ['warn', {}],
        'uses-webp-images': ['warn', {}],
        'efficient-animated-content': ['warn', {}],
        
        // Best practices
        'uses-http2': ['error', {}],
        'uses-text-compression': ['error', {}],
        'render-blocking-resources': ['warn', {}],
        
        // Security
        'is-on-https': ['error', {}],
        'uses-https': ['error', {}],
        
        // Accessibility
        'color-contrast': ['error', {}],
        'image-alt': ['error', {}],
        'label': ['error', {}],
        'link-name': ['error', {}],
      }
    },
    upload: {
      target: 'temporary-public-storage',
    },
  },
  
  // Mobile configuration
  mobile: {
    collect: {
      url: [
        'http://localhost:5173/',
        'http://localhost:5173/browse',
        'http://localhost:5173/categories',
        'http://localhost:5173/profile',
        'http://localhost:5173/watch/1',
      ],
      numberOfRuns: 3,
      settings: {
        chromeFlags: '--no-sandbox --disable-dev-shm-usage',
        preset: 'mobile',
        throttling: {
          rttMs: 150,
          throughputKbps: 1638.4,
          cpuSlowdownMultiplier: 4,
          requestLatencyMs: 0,
          downloadThroughputKbps: 0,
          uploadThroughputKbps: 0
        }
      }
    },
    assert: {
      assertions: {
        'categories:performance': ['error', {minScore: 0.7}], // Lower for mobile
        'categories:accessibility': ['error', {minScore: 0.9}],
        'categories:best-practices': ['error', {minScore: 0.9}],
        'categories:seo': ['error', {minScore: 0.8}],
        
        // Mobile-specific Core Web Vitals (more lenient)
        'first-contentful-paint': ['error', {maxNumericValue: 3000}],
        'largest-contentful-paint': ['error', {maxNumericValue: 4000}],
        'cumulative-layout-shift': ['error', {maxNumericValue: 0.1}],
        'total-blocking-time': ['error', {maxNumericValue: 600}],
        
        // Mobile performance
        'speed-index': ['error', {maxNumericValue: 4500}],
        'interactive': ['error', {maxNumericValue: 5000}],
        
        // Mobile-specific checks
        'viewport': ['error', {}],
        'tap-targets': ['error', {}],
        'font-size': ['error', {}],
      }
    }
  }
}; 