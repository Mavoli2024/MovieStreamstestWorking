#!/bin/bash
# Clean build script to ensure consistent output

echo "Cleaning previous build..."
rm -rf dist
rm -rf node_modules/.vite

echo "Running fresh build..."
npm run build

echo "Build complete!"