// client/vite.config.ts
import react from "file:///home/runner/workspace/node_modules/@vitejs/plugin-react/dist/index.mjs";
import path from "path";
import { defineConfig } from "file:///home/runner/workspace/node_modules/vite/dist/node/index.js";
import { sentryVitePlugin } from "file:///home/runner/workspace/node_modules/@sentry/vite-plugin/dist/esm/index.mjs";
import viteImagemin from "file:///home/runner/workspace/node_modules/vite-plugin-imagemin/dist/index.mjs";
import PurgeCSS from "file:///home/runner/workspace/node_modules/vite-plugin-purgecss/dist/index.mjs";
import { visualizer } from "file:///home/runner/workspace/node_modules/rollup-plugin-visualizer/dist/plugin/index.js";
var __vite_injected_original_dirname = "/home/runner/workspace/client";
var vite_config_default = defineConfig({
  root: __vite_injected_original_dirname,
  appType: "spa",
  base: "/",
  // Enhanced dependency optimization
  optimizeDeps: {
    include: [
      "react",
      "react-dom",
      "react/jsx-runtime",
      "react-dom/client",
      "@supabase/supabase-js",
      "@tanstack/react-query",
      "react-hook-form",
      "wouter",
      "framer-motion",
      "hls.js"
    ],
    exclude: [
      "@capacitor/core",
      "@capacitor/app",
      "lucide-react"
      // Let our icon system handle this
    ]
  },
  plugins: [
    react({
      // Force include React in development mode
      include: "**/*.{jsx,tsx}"
    }),
    // Sentry plugin for source maps and error tracking
    sentryVitePlugin({
      org: process.env.SENTRY_ORG,
      project: process.env.SENTRY_PROJECT,
      authToken: process.env.SENTRY_AUTH_TOKEN,
      sourcemaps: {
        assets: "./dist/**",
        ignore: ["node_modules/**"]
      }
    }),
    // Image optimization
    viteImagemin({
      gifsicle: { optimizationLevel: 7 },
      mozjpeg: { quality: 80 },
      pngquant: { quality: [0.8, 0.9] },
      webp: { quality: 75 }
    }),
    // CSS purging for production
    PurgeCSS({
      content: ["./src/**/*.{js,jsx,ts,tsx,vue,html}"],
      safelist: [
        /^hljs-/,
        /^toast-/,
        /^Toastify/,
        /^lucide-/,
        "dark",
        "light",
        "data-theme"
      ]
    }),
    // Bundle analyzer (only in analyze mode)
    ...process.env.ANALYZE === "true" ? [
      visualizer({
        filename: "dist/stats.html",
        open: true,
        gzipSize: true,
        brotliSize: true
      })
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(__vite_injected_original_dirname, "./src"),
      "@shared": path.resolve(__vite_injected_original_dirname, "../shared")
    }
  },
  // Production build configuration to prevent React import issues
  build: {
    outDir: "../dist/public",
    emptyOutDir: true,
    target: "es2015",
    // Optimize chunk size
    chunkSizeWarningLimit: 1e3,
    // Enable minification
    minify: "terser",
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true
      }
    },
    // Disable tree-shaking for React to prevent import chain issues
    rollupOptions: {
      external: [],
      output: {
        manualChunks: {
          "vendor-react": ["react", "react-dom", "react-dom/client"],
          "vendor-ui": ["@radix-ui/react-dropdown-menu", "@radix-ui/react-dialog", "@radix-ui/react-toast"],
          "vendor-state": ["@tanstack/react-query", "wouter"],
          "vendor-supabase": ["@supabase/supabase-js"],
          "vendor-forms": ["react-hook-form", "@hookform/resolvers"],
          "vendor-media": ["hls.js", "framer-motion"],
          "vendor-icons": ["lucide-react"],
          "vendor-misc": ["clsx", "class-variance-authority", "tailwind-merge"],
          "vendor-monitoring": ["@sentry/react"]
        },
        // Ensure React is always available globally
        globals: {
          "react": "React",
          "react-dom": "ReactDOM"
        }
      }
    },
    // Prevent aggressive minification that could break React
    sourcemap: false,
    // Ensure all imports are properly resolved
    commonjsOptions: {
      include: [/node_modules/],
      transformMixedEsModules: true
    }
  },
  server: {
    port: 5173,
    strictPort: true,
    // Fail fast if port is busy instead of trying others
    host: true,
    hmr: {
      port: 5174
    },
    proxy: {
      "/api": {
        target: "http://localhost:5001",
        changeOrigin: true,
        secure: false
      }
    }
  },
  preview: {
    port: 4173,
    host: true
  }
});
export {
  vite_config_default as default
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiY2xpZW50L3ZpdGUuY29uZmlnLnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJjb25zdCBfX3ZpdGVfaW5qZWN0ZWRfb3JpZ2luYWxfZGlybmFtZSA9IFwiL2hvbWUvcnVubmVyL3dvcmtzcGFjZS9jbGllbnRcIjtjb25zdCBfX3ZpdGVfaW5qZWN0ZWRfb3JpZ2luYWxfZmlsZW5hbWUgPSBcIi9ob21lL3J1bm5lci93b3Jrc3BhY2UvY2xpZW50L3ZpdGUuY29uZmlnLnRzXCI7Y29uc3QgX192aXRlX2luamVjdGVkX29yaWdpbmFsX2ltcG9ydF9tZXRhX3VybCA9IFwiZmlsZTovLy9ob21lL3J1bm5lci93b3Jrc3BhY2UvY2xpZW50L3ZpdGUuY29uZmlnLnRzXCI7aW1wb3J0IHJlYWN0IGZyb20gJ0B2aXRlanMvcGx1Z2luLXJlYWN0J1xuaW1wb3J0IHBhdGggZnJvbSBcInBhdGhcIlxuaW1wb3J0IHsgZGVmaW5lQ29uZmlnIH0gZnJvbSAndml0ZSdcbmltcG9ydCB7IHNlbnRyeVZpdGVQbHVnaW4gfSBmcm9tICdAc2VudHJ5L3ZpdGUtcGx1Z2luJ1xuaW1wb3J0IHZpdGVJbWFnZW1pbiBmcm9tICd2aXRlLXBsdWdpbi1pbWFnZW1pbidcbmltcG9ydCBQdXJnZUNTUyBmcm9tICd2aXRlLXBsdWdpbi1wdXJnZWNzcydcbmltcG9ydCB7IHZpc3VhbGl6ZXIgfSBmcm9tICdyb2xsdXAtcGx1Z2luLXZpc3VhbGl6ZXInXG4vLyBpbXBvcnQgeyBWaXRlUFdBIH0gZnJvbSAndml0ZS1wbHVnaW4tcHdhJyAvLyBUT0RPOiBSZS1lbmFibGUgd2hlbiBQV0EgaXMgbmVlZGVkXG5cbi8vIGh0dHBzOi8vdml0ZWpzLmRldi9jb25maWcvXG5leHBvcnQgZGVmYXVsdCBkZWZpbmVDb25maWcoe1xuICByb290OiBfX2Rpcm5hbWUsXG4gIGFwcFR5cGU6ICdzcGEnLFxuICBiYXNlOiAnLycsXG4gIFxuXG4gIFxuICAvLyBFbmhhbmNlZCBkZXBlbmRlbmN5IG9wdGltaXphdGlvblxuICBvcHRpbWl6ZURlcHM6IHtcbiAgICBpbmNsdWRlOiBbXG4gICAgICAncmVhY3QnLFxuICAgICAgJ3JlYWN0LWRvbScsXG4gICAgICAncmVhY3QvanN4LXJ1bnRpbWUnLFxuICAgICAgJ3JlYWN0LWRvbS9jbGllbnQnLFxuICAgICAgJ0BzdXBhYmFzZS9zdXBhYmFzZS1qcycsXG4gICAgICAnQHRhbnN0YWNrL3JlYWN0LXF1ZXJ5JyxcbiAgICAgICdyZWFjdC1ob29rLWZvcm0nLFxuICAgICAgJ3dvdXRlcicsXG4gICAgICAnZnJhbWVyLW1vdGlvbicsXG4gICAgICAnaGxzLmpzJ1xuICAgIF0sXG4gICAgZXhjbHVkZTogW1xuICAgICAgJ0BjYXBhY2l0b3IvY29yZScsIFxuICAgICAgJ0BjYXBhY2l0b3IvYXBwJyxcbiAgICAgICdsdWNpZGUtcmVhY3QnIC8vIExldCBvdXIgaWNvbiBzeXN0ZW0gaGFuZGxlIHRoaXNcbiAgICBdXG4gIH0sXG4gIFxuICBwbHVnaW5zOiBbXG4gICAgcmVhY3Qoe1xuICAgICAgLy8gRm9yY2UgaW5jbHVkZSBSZWFjdCBpbiBkZXZlbG9wbWVudCBtb2RlXG4gICAgICBpbmNsdWRlOiBcIioqLyoue2pzeCx0c3h9XCIsXG4gICAgfSksXG4gICAgLy8gU2VudHJ5IHBsdWdpbiBmb3Igc291cmNlIG1hcHMgYW5kIGVycm9yIHRyYWNraW5nXG4gICAgc2VudHJ5Vml0ZVBsdWdpbih7XG4gICAgICBvcmc6IHByb2Nlc3MuZW52LlNFTlRSWV9PUkcsXG4gICAgICBwcm9qZWN0OiBwcm9jZXNzLmVudi5TRU5UUllfUFJPSkVDVCxcbiAgICAgIGF1dGhUb2tlbjogcHJvY2Vzcy5lbnYuU0VOVFJZX0FVVEhfVE9LRU4sXG4gICAgICBzb3VyY2VtYXBzOiB7XG4gICAgICAgIGFzc2V0czogXCIuL2Rpc3QvKipcIixcbiAgICAgICAgaWdub3JlOiBbXCJub2RlX21vZHVsZXMvKipcIl0sXG4gICAgICB9LFxuICAgIH0pLFxuICAgIC8vIEltYWdlIG9wdGltaXphdGlvblxuICAgIHZpdGVJbWFnZW1pbih7XG4gICAgICBnaWZzaWNsZTogeyBvcHRpbWl6YXRpb25MZXZlbDogNyB9LFxuICAgICAgbW96anBlZzogeyBxdWFsaXR5OiA4MCB9LFxuICAgICAgcG5ncXVhbnQ6IHsgcXVhbGl0eTogWzAuOCwgMC45XSB9LFxuICAgICAgd2VicDogeyBxdWFsaXR5OiA3NSB9LFxuICAgIH0pLFxuICAgIC8vIENTUyBwdXJnaW5nIGZvciBwcm9kdWN0aW9uXG4gICAgUHVyZ2VDU1Moe1xuICAgICAgY29udGVudDogWycuL3NyYy8qKi8qLntqcyxqc3gsdHMsdHN4LHZ1ZSxodG1sfSddLFxuICAgICAgc2FmZWxpc3Q6IFtcbiAgICAgICAgL15obGpzLS8sXG4gICAgICAgIC9edG9hc3QtLyxcbiAgICAgICAgL15Ub2FzdGlmeS8sXG4gICAgICAgIC9ebHVjaWRlLS8sXG4gICAgICAgICdkYXJrJyxcbiAgICAgICAgJ2xpZ2h0JyxcbiAgICAgICAgJ2RhdGEtdGhlbWUnLFxuICAgICAgXSxcbiAgICB9KSxcbiAgICAvLyBCdW5kbGUgYW5hbHl6ZXIgKG9ubHkgaW4gYW5hbHl6ZSBtb2RlKVxuICAgIC4uLihwcm9jZXNzLmVudi5BTkFMWVpFID09PSAndHJ1ZScgPyBbXG4gICAgICB2aXN1YWxpemVyKHtcbiAgICAgICAgZmlsZW5hbWU6ICdkaXN0L3N0YXRzLmh0bWwnLFxuICAgICAgICBvcGVuOiB0cnVlLFxuICAgICAgICBnemlwU2l6ZTogdHJ1ZSxcbiAgICAgICAgYnJvdGxpU2l6ZTogdHJ1ZSxcbiAgICAgIH0pXG4gICAgXSA6IFtdKSxcbiAgXSxcbiAgXG4gIHJlc29sdmU6IHtcbiAgICBhbGlhczoge1xuICAgICAgXCJAXCI6IHBhdGgucmVzb2x2ZShfX2Rpcm5hbWUsIFwiLi9zcmNcIiksXG4gICAgICBcIkBzaGFyZWRcIjogcGF0aC5yZXNvbHZlKF9fZGlybmFtZSwgXCIuLi9zaGFyZWRcIiksXG4gICAgfSxcbiAgfSxcbiAgXG4gIC8vIFByb2R1Y3Rpb24gYnVpbGQgY29uZmlndXJhdGlvbiB0byBwcmV2ZW50IFJlYWN0IGltcG9ydCBpc3N1ZXNcbiAgYnVpbGQ6IHtcbiAgICBvdXREaXI6ICcuLi9kaXN0L3B1YmxpYycsXG4gICAgZW1wdHlPdXREaXI6IHRydWUsXG4gICAgdGFyZ2V0OiAnZXMyMDE1JyxcbiAgICBcbiAgICAvLyBPcHRpbWl6ZSBjaHVuayBzaXplXG4gICAgY2h1bmtTaXplV2FybmluZ0xpbWl0OiAxMDAwLFxuICAgIFxuICAgIC8vIEVuYWJsZSBtaW5pZmljYXRpb25cbiAgICBtaW5pZnk6ICd0ZXJzZXInLFxuICAgIHRlcnNlck9wdGlvbnM6IHtcbiAgICAgIGNvbXByZXNzOiB7XG4gICAgICAgIGRyb3BfY29uc29sZTogdHJ1ZSxcbiAgICAgICAgZHJvcF9kZWJ1Z2dlcjogdHJ1ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBcbiAgICAvLyBEaXNhYmxlIHRyZWUtc2hha2luZyBmb3IgUmVhY3QgdG8gcHJldmVudCBpbXBvcnQgY2hhaW4gaXNzdWVzXG4gICAgcm9sbHVwT3B0aW9uczoge1xuICAgICAgZXh0ZXJuYWw6IFtdLFxuICAgICAgb3V0cHV0OiB7XG4gICAgICAgIG1hbnVhbENodW5rczoge1xuICAgICAgICAgICd2ZW5kb3ItcmVhY3QnOiBbJ3JlYWN0JywgJ3JlYWN0LWRvbScsICdyZWFjdC1kb20vY2xpZW50J10sXG4gICAgICAgICAgJ3ZlbmRvci11aSc6IFsnQHJhZGl4LXVpL3JlYWN0LWRyb3Bkb3duLW1lbnUnLCAnQHJhZGl4LXVpL3JlYWN0LWRpYWxvZycsICdAcmFkaXgtdWkvcmVhY3QtdG9hc3QnXSxcbiAgICAgICAgICAndmVuZG9yLXN0YXRlJzogWydAdGFuc3RhY2svcmVhY3QtcXVlcnknLCAnd291dGVyJ10sXG4gICAgICAgICAgJ3ZlbmRvci1zdXBhYmFzZSc6IFsnQHN1cGFiYXNlL3N1cGFiYXNlLWpzJ10sXG4gICAgICAgICAgJ3ZlbmRvci1mb3Jtcyc6IFsncmVhY3QtaG9vay1mb3JtJywgJ0Bob29rZm9ybS9yZXNvbHZlcnMnXSxcbiAgICAgICAgICAndmVuZG9yLW1lZGlhJzogWydobHMuanMnLCAnZnJhbWVyLW1vdGlvbiddLFxuICAgICAgICAgICd2ZW5kb3ItaWNvbnMnOiBbJ2x1Y2lkZS1yZWFjdCddLFxuICAgICAgICAgICd2ZW5kb3ItbWlzYyc6IFsnY2xzeCcsICdjbGFzcy12YXJpYW5jZS1hdXRob3JpdHknLCAndGFpbHdpbmQtbWVyZ2UnXSxcbiAgICAgICAgICAndmVuZG9yLW1vbml0b3JpbmcnOiBbJ0BzZW50cnkvcmVhY3QnXVxuICAgICAgICB9LFxuICAgICAgICAvLyBFbnN1cmUgUmVhY3QgaXMgYWx3YXlzIGF2YWlsYWJsZSBnbG9iYWxseVxuICAgICAgICBnbG9iYWxzOiB7XG4gICAgICAgICAgJ3JlYWN0JzogJ1JlYWN0JyxcbiAgICAgICAgICAncmVhY3QtZG9tJzogJ1JlYWN0RE9NJ1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgICAvLyBQcmV2ZW50IGFnZ3Jlc3NpdmUgbWluaWZpY2F0aW9uIHRoYXQgY291bGQgYnJlYWsgUmVhY3RcblxuICAgIHNvdXJjZW1hcDogZmFsc2UsXG4gICAgLy8gRW5zdXJlIGFsbCBpbXBvcnRzIGFyZSBwcm9wZXJseSByZXNvbHZlZFxuICAgIGNvbW1vbmpzT3B0aW9uczoge1xuICAgICAgaW5jbHVkZTogWy9ub2RlX21vZHVsZXMvXSxcbiAgICAgIHRyYW5zZm9ybU1peGVkRXNNb2R1bGVzOiB0cnVlXG4gICAgfVxuICB9LFxuICBcbiAgc2VydmVyOiB7XG4gICAgcG9ydDogNTE3MyxcbiAgICBzdHJpY3RQb3J0OiB0cnVlLCAvLyBGYWlsIGZhc3QgaWYgcG9ydCBpcyBidXN5IGluc3RlYWQgb2YgdHJ5aW5nIG90aGVyc1xuICAgIGhvc3Q6IHRydWUsXG4gICAgaG1yOiB7XG4gICAgICBwb3J0OiA1MTc0XG4gICAgfSxcbiAgICBwcm94eToge1xuICAgICAgJy9hcGknOiB7XG4gICAgICAgIHRhcmdldDogJ2h0dHA6Ly9sb2NhbGhvc3Q6NTAwMScsXG4gICAgICAgIGNoYW5nZU9yaWdpbjogdHJ1ZSxcbiAgICAgICAgc2VjdXJlOiBmYWxzZSxcbiAgICAgIH1cbiAgICB9XG4gIH0sXG4gIFxuICBwcmV2aWV3OiB7XG4gICAgcG9ydDogNDE3MyxcbiAgICBob3N0OiB0cnVlXG4gIH1cbn0pICJdLAogICJtYXBwaW5ncyI6ICI7QUFBeVEsT0FBTyxXQUFXO0FBQzNSLE9BQU8sVUFBVTtBQUNqQixTQUFTLG9CQUFvQjtBQUM3QixTQUFTLHdCQUF3QjtBQUNqQyxPQUFPLGtCQUFrQjtBQUN6QixPQUFPLGNBQWM7QUFDckIsU0FBUyxrQkFBa0I7QUFOM0IsSUFBTSxtQ0FBbUM7QUFVekMsSUFBTyxzQkFBUSxhQUFhO0FBQUEsRUFDMUIsTUFBTTtBQUFBLEVBQ04sU0FBUztBQUFBLEVBQ1QsTUFBTTtBQUFBO0FBQUEsRUFLTixjQUFjO0FBQUEsSUFDWixTQUFTO0FBQUEsTUFDUDtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQTtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFFQSxTQUFTO0FBQUEsSUFDUCxNQUFNO0FBQUE7QUFBQSxNQUVKLFNBQVM7QUFBQSxJQUNYLENBQUM7QUFBQTtBQUFBLElBRUQsaUJBQWlCO0FBQUEsTUFDZixLQUFLLFFBQVEsSUFBSTtBQUFBLE1BQ2pCLFNBQVMsUUFBUSxJQUFJO0FBQUEsTUFDckIsV0FBVyxRQUFRLElBQUk7QUFBQSxNQUN2QixZQUFZO0FBQUEsUUFDVixRQUFRO0FBQUEsUUFDUixRQUFRLENBQUMsaUJBQWlCO0FBQUEsTUFDNUI7QUFBQSxJQUNGLENBQUM7QUFBQTtBQUFBLElBRUQsYUFBYTtBQUFBLE1BQ1gsVUFBVSxFQUFFLG1CQUFtQixFQUFFO0FBQUEsTUFDakMsU0FBUyxFQUFFLFNBQVMsR0FBRztBQUFBLE1BQ3ZCLFVBQVUsRUFBRSxTQUFTLENBQUMsS0FBSyxHQUFHLEVBQUU7QUFBQSxNQUNoQyxNQUFNLEVBQUUsU0FBUyxHQUFHO0FBQUEsSUFDdEIsQ0FBQztBQUFBO0FBQUEsSUFFRCxTQUFTO0FBQUEsTUFDUCxTQUFTLENBQUMscUNBQXFDO0FBQUEsTUFDL0MsVUFBVTtBQUFBLFFBQ1I7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUE7QUFBQSxJQUVELEdBQUksUUFBUSxJQUFJLFlBQVksU0FBUztBQUFBLE1BQ25DLFdBQVc7QUFBQSxRQUNULFVBQVU7QUFBQSxRQUNWLE1BQU07QUFBQSxRQUNOLFVBQVU7QUFBQSxRQUNWLFlBQVk7QUFBQSxNQUNkLENBQUM7QUFBQSxJQUNILElBQUksQ0FBQztBQUFBLEVBQ1A7QUFBQSxFQUVBLFNBQVM7QUFBQSxJQUNQLE9BQU87QUFBQSxNQUNMLEtBQUssS0FBSyxRQUFRLGtDQUFXLE9BQU87QUFBQSxNQUNwQyxXQUFXLEtBQUssUUFBUSxrQ0FBVyxXQUFXO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBQUE7QUFBQSxFQUdBLE9BQU87QUFBQSxJQUNMLFFBQVE7QUFBQSxJQUNSLGFBQWE7QUFBQSxJQUNiLFFBQVE7QUFBQTtBQUFBLElBR1IsdUJBQXVCO0FBQUE7QUFBQSxJQUd2QixRQUFRO0FBQUEsSUFDUixlQUFlO0FBQUEsTUFDYixVQUFVO0FBQUEsUUFDUixjQUFjO0FBQUEsUUFDZCxlQUFlO0FBQUEsTUFDakI7QUFBQSxJQUNGO0FBQUE7QUFBQSxJQUdBLGVBQWU7QUFBQSxNQUNiLFVBQVUsQ0FBQztBQUFBLE1BQ1gsUUFBUTtBQUFBLFFBQ04sY0FBYztBQUFBLFVBQ1osZ0JBQWdCLENBQUMsU0FBUyxhQUFhLGtCQUFrQjtBQUFBLFVBQ3pELGFBQWEsQ0FBQyxpQ0FBaUMsMEJBQTBCLHVCQUF1QjtBQUFBLFVBQ2hHLGdCQUFnQixDQUFDLHlCQUF5QixRQUFRO0FBQUEsVUFDbEQsbUJBQW1CLENBQUMsdUJBQXVCO0FBQUEsVUFDM0MsZ0JBQWdCLENBQUMsbUJBQW1CLHFCQUFxQjtBQUFBLFVBQ3pELGdCQUFnQixDQUFDLFVBQVUsZUFBZTtBQUFBLFVBQzFDLGdCQUFnQixDQUFDLGNBQWM7QUFBQSxVQUMvQixlQUFlLENBQUMsUUFBUSw0QkFBNEIsZ0JBQWdCO0FBQUEsVUFDcEUscUJBQXFCLENBQUMsZUFBZTtBQUFBLFFBQ3ZDO0FBQUE7QUFBQSxRQUVBLFNBQVM7QUFBQSxVQUNQLFNBQVM7QUFBQSxVQUNULGFBQWE7QUFBQSxRQUNmO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQTtBQUFBLElBR0EsV0FBVztBQUFBO0FBQUEsSUFFWCxpQkFBaUI7QUFBQSxNQUNmLFNBQVMsQ0FBQyxjQUFjO0FBQUEsTUFDeEIseUJBQXlCO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQUEsRUFFQSxRQUFRO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixZQUFZO0FBQUE7QUFBQSxJQUNaLE1BQU07QUFBQSxJQUNOLEtBQUs7QUFBQSxNQUNILE1BQU07QUFBQSxJQUNSO0FBQUEsSUFDQSxPQUFPO0FBQUEsTUFDTCxRQUFRO0FBQUEsUUFDTixRQUFRO0FBQUEsUUFDUixjQUFjO0FBQUEsUUFDZCxRQUFRO0FBQUEsTUFDVjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFFQSxTQUFTO0FBQUEsSUFDUCxNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsRUFDUjtBQUNGLENBQUM7IiwKICAibmFtZXMiOiBbXQp9Cg==
