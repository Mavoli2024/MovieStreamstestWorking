# MadifaStream Frontend - Developer Documentation

## Architecture Overview

MadifaStream uses a modern, unified frontend architecture built on React with TypeScript, featuring centralized state management, robust routing, and comprehensive error handling.
  
## State Management

### Zustand Stores

Our application uses Zustand for client-side state management with two main stores:

#### AuthStore (`/stores/authStore.ts`)
Manages authentication state and operations:

```typescript
import { useAuthStore } from '@/stores/authStore';

const { user, login, register, logout, isLoading, error } = useAuthStore();

// Login
await login('user@example.com', 'password123');

// Register
await register('user@example.com', 'password123');

// Logout
await logout();
```

#### UIStore (`/stores/uiStore.ts`)
Manages global UI state:

```typescript
import { useUIStore } from '@/stores/uiStore';

const { 
  theme, 
  sidebar, 
  modal, 
  toast, 
  loading 
} = useUIStore();

// Theme management
setTheme('dark' | 'light');
toggleTheme();

// Sidebar control
sidebar.open();
sidebar.close();
sidebar.toggle();

// Modal management
modal.open({ title: 'Modal Title', content: 'Modal content' });
modal.close();

// Toast notifications
toast.add({ id: '1', message: 'Success!', type: 'success' });
toast.remove('1');

// Loading states
loading.setGlobal(true);
loading.setOperation('login', true);
```

### Server State Management

We use React Query for server state management with a centralized query client:

```typescript
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiService } from '@/services/api-service';

// Query example
const { data: videos, isLoading, error } = useQuery({
  queryKey: ['videos'],
  queryFn: () => apiService.get('/videos'),
});

// Mutation example
const loginMutation = useMutation({
  mutationFn: (credentials) => apiService.post('/auth/login', credentials),
});
```

## Routing & Navigation

### Route Configuration

Routes are centrally defined in `/config/routes.ts`:

```typescript
export const APP_ROUTES = [
  {
    path: '/',
    component: HomePage,
    requireAuth: false,
    title: 'Home',
  },
  {
    path: '/profile',
    component: ProfilePage,
    requireAuth: true,
    title: 'Profile',
  },
  // ... more routes
];
```

### Route Guards

Protected routes use our `RouteGuard` component:

```typescript
import { RouteGuard } from '@/components/navigation/RouteGuard';

<RouteGuard
  requireAuth={true}
  redirectTo="/auth"
  fallback={<div>Loading...</div>}
>
  <ProtectedComponent />
</RouteGuard>
```

### Navigation Utilities

Use our custom navigation hook for consistent routing:

```typescript
import { useNavigation } from '@/hooks/useNavigation';

const { 
  navigateToHome, 
  navigateToAuth, 
  navigateToProfile,
  navigateToWatch,
  goBack,
  goForward 
} = useNavigation();

// Navigate to specific pages
navigateToHome();
navigateToAuth();
navigateToProfile();
navigateToWatch('video-id');

// Browser history
goBack();
goForward();
```

## Form Management

### useForm Hook

Centralized form handling with validation:

```typescript
import { useForm } from '@/hooks/useForm';
import { z } from 'zod';

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
});

const { 
  values, 
  errors, 
  touched, 
  handleChange, 
  handleSubmit, 
  reset 
} = useForm({
  initialValues: { email: '', password: '' },
  validationSchema: schema,
  onSubmit: (data) => console.log(data),
});
```

### Form Components

Reusable form components for consistent UX:

```typescript
import { FormWrapper } from '@/components/form/form-wrapper';
import { FormInput } from '@/components/form/form-input';

<FormWrapper onSubmit={handleSubmit}>
  <FormInput
    label="Email"
    name="email"
    type="email"
    value={values.email}
    onChange={handleChange}
    error={errors.email}
  />
</FormWrapper>
```

## Error Handling

### Error Boundaries

Global error boundary catches and displays errors:

```typescript
import { ErrorBoundary } from '@/components/error/ErrorBoundary';

<ErrorBoundary fallback={<ErrorFallback />}>
  <App />
</ErrorBoundary>
```

### Error Utilities

Centralized error handling utilities:

```typescript
import { handleError } from '@/utils/errorUtils';

try {
  await apiCall();
} catch (error) {
  handleError(error, { 
    context: 'User login',
    showToast: true,
    logError: true 
  });
}
```

## Global Providers

### RootProvider

Wraps the entire app with necessary providers:

```typescript
import { RootProvider } from '@/providers/RootProvider';

function App() {
  return (
    <RootProvider>
      <Routes />
    </RootProvider>
  );
}
```

The RootProvider includes:
- QueryClientProvider (React Query)
- ToastProvider (Notifications)
- LoadingOverlay (Global loading states)
- OfflineIndicator (Network status)
- ErrorBoundary (Error handling)

## Development Patterns

### Component Structure

```
src/
├── components/          # Reusable UI components
├── pages/              # Page components
├── hooks/              # Custom hooks
├── stores/             # Zustand stores
├── services/           # API services
├── utils/              # Utility functions
├── providers/          # Context providers
├── config/             # Configuration files
└── types/              # TypeScript types
```

### Best Practices

1. **State Management**: Use Zustand for client state, React Query for server state
2. **Navigation**: Always use `useNavigation` hook for routing
3. **Forms**: Use centralized `useForm` hook with Zod validation
4. **Error Handling**: Implement proper error boundaries and error utilities
5. **Loading States**: Use UIStore for consistent loading indicators
6. **Type Safety**: Always define TypeScript interfaces for data structures

### Testing

Integration tests are located in `/tests/integration/`:

```bash
# Run navigation guard tests
npm test navigation-guards.test.tsx

# Run state slice tests
npm test state-slices.test.tsx
```

### Code Quality

- **ESLint**: Configured with strict TypeScript rules
- **Prettier**: Automatic code formatting
- **Husky**: Pre-commit hooks for code quality
- **TypeScript**: Strict mode enabled for type safety

## Development Workflow

1. **Start Development**: `npm run dev`
2. **Build**: `npm run build`
3. **Test**: `npm test`
4. **Lint**: `npm run lint`
5. **Type Check**: `npm run type-check`

## Key Files

- `src/App.tsx` - Main application component
- `src/providers/RootProvider.tsx` - Global providers wrapper
- `src/stores/authStore.ts` - Authentication state management
- `src/stores/uiStore.ts` - UI state management
- `src/config/routes.ts` - Route definitions
- `src/hooks/useNavigation.ts` - Navigation utilities
- `src/components/navigation/RouteGuard.tsx` - Route protection
- `src/services/api-service.ts` - API communication

## Migration Guide

### From Legacy useAuth to AuthStore

```typescript
// Before
import { useAuth } from '@/hooks/use-auth';
const { user, loginMutation } = useAuth();

// After
import { useAuthStore } from '@/stores/authStore';
const { user, login, isLoading } = useAuthStore();
```

### From Direct Navigation to useNavigation

```typescript
// Before
import { useLocation } from 'wouter';
const [, navigate] = useLocation();
navigate('/profile');

// After
import { useNavigation } from '@/hooks/useNavigation';
const { navigateToProfile } = useNavigation();
navigateToProfile();
```

## Performance Considerations

1. **Lazy Loading**: Components are lazy-loaded where appropriate
2. **Memoization**: Use React.memo and useMemo for expensive computations
3. **Query Optimization**: React Query provides automatic caching and deduplication
4. **Bundle Splitting**: Automatic code splitting at the route level

## Security

1. **Route Guards**: All protected routes use RouteGuard component
2. **Input Validation**: Zod schemas validate all form inputs
3. **Error Handling**: Sensitive errors are sanitized before display
4. **Token Management**: JWT tokens are handled securely in AuthStore

This architecture provides a scalable, maintainable, and type-safe foundation for the MadifaStream frontend application.
