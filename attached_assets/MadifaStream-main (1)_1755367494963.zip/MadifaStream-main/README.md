# MadifaStream - Mzansi Videos Unboxed

A premium South African streaming platform offering exclusive local content with unlimited access to videos and TV shows.

## 🎬 About MadifaStream

MadifaStream is a modern streaming application built specifically for South African audiences, featuring:

- **Exclusive South African Content** - Videos and TV shows from local creators
- **Multi-Device Support** - Watch on any device, anywhere, anytime  
- **Family Profiles** - Create profiles for the whole family
- **Premium Experience** - High-quality streaming for only R59/month
- **Modern UI/UX** - Beautiful, responsive design optimized for all screen sizes

## 🚀 Quick Start

### Prerequisites

- Node.js 20 
- npm
- Supabase account
- BunnyStream account (for video hosting)

### Environment Setup

1. Clone the repository:
```bash
git clone <repository-url>
cd MadifaStream
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables by copying `.env.example` to `.env.local`:
```bash
cp .env.example .env.local
```

4. Update `.env.local` with your actual credentials:
```env
# Supabase Configuration
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_supabase_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# Database
DATABASE_URL=your_postgresql_connection_string

# BunnyStream (Video Hosting)
BUNNY_LIBRARY_ID=your_bunny_library_id
BUNNY_API_KEY=your_bunny_api_key
BUNNY_CDN_HOSTNAME=your_bunny_cdn_hostname

# Application
APP_URL=https://www.madifa.co.za
VITE_SITE_URL=http://localhost:5000
PORT=5001
```

### Development

1. **Quick Environment Check** (optional but recommended):
```bash
node scripts/dev-setup.js
```

2. **Start the full development environment** (frontend + backend):
```bash
npm run dev
```

3. **Access your application**:
   - Frontend: [http://localhost:5173](http://localhost:5173)
   - Backend API: [http://localhost:5001](http://localhost:5001)

4. **Alternative development commands**:
```bash
# Start only frontend (if backend is running separately)
npm run dev:client-only

# Start only backend (if frontend is running separately)
npm run dev:server-only

# Clean ports and start fresh
npm run dev:fresh

# Clean ports without starting servers
npm run dev:clean
```

The development environment uses:
- **Vite** for frontend with hot module replacement
- **TSX** for backend with automatic restart on file changes  
- **Automatic port cleanup** to prevent conflicts
- **Concurrent server management** with colored output

## 🏗️ Building for Production

1. Build the application:
```bash
npm run build
```

2. Start the production server:
```bash
npm start
```

## 🧪 Testing

**Run all tests**:
```bash
npm run test:all
```

**Individual test suites**:
```bash
# Unit tests only
npm run test:unit

# Component tests only  
npm run test:components

# End-to-end tests only
npm run test:e2e

# Watch mode for development
npm run test:watch

# Coverage report
npm run test:coverage
```

## 📱 Mobile App (Android/iOS)

The project includes Capacitor configuration for building native mobile apps:

### Android Build

1. Build the web app:
```bash
npm run build
```

2. Generate Android app:
```bash
npx cap add android
npx cap sync android
npx cap build android
```

### iOS Build (macOS only)

1. Build the web app:
```bash
npm run build
```

2. Generate iOS app:
```bash
npx cap add ios
npx cap sync ios
npx cap build ios
```

## 🚀 Deployment

### Vercel Deployment

The app is configured for Vercel deployment with automatic deployments on git push:

1. Connect your repository to Vercel
2. Configure environment variables in Vercel dashboard
3. Deploy automatically on every push to main branch

### Manual Deployment

1. Build the project:
```bash
npm run build
```

2. Deploy the `dist/` directory and the built server files to your hosting platform

## 🏗️ Project Structure

```
MadifaStream/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── lib/            # Utility functions
│   │   └── styles/         # Global styles
├── supabase/               # Supabase Edge Functions and config
│   ├── functions/          # Edge Function implementations
│   └── migrations/         # Database migrations
├── shared/                 # Shared code between client/server
├── __tests__/              # Test files
├── migrations/             # Database migrations
└── supabase/               # Supabase configuration
```

## 🔧 Tech Stack

### Frontend
- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Build tool and dev server
- **Tailwind CSS** - Styling
- **Framer Motion** - Animations
- **React Query** - Data fetching
- **React Hook Form** - Form management

### Backend  
- **Supabase** - Database, authentication, and Edge Functions
- **TypeScript** - Type safety
- **Drizzle ORM** - Database ORM
- **BunnyStream** - Video hosting and streaming

### Mobile
- **Capacitor** - Native mobile app wrapper
- **Cordova plugins** - Native device features

### DevOps
- **Jest** - Testing framework
- **ESBuild** - Server bundling
- **Vercel** - Hosting and deployment
- **GitHub Actions** - CI/CD

## 🔐 Authentication

The app uses Supabase authentication with support for:
- Email/password authentication
- Google OAuth
- Session management
- Role-based access control (User/Admin)

## 🎥 Video Management

Videos are hosted on BunnyStream CDN with features:
- Adaptive bitrate streaming
- Global CDN distribution
- Thumbnail generation
- Video metadata management

## 🏪 Subscription Management

- Monthly subscription model (R59/month)
- PayFast integration for South African payments
- Subscription status tracking
- Free trial support

## 📄 API Documentation

### Authentication Endpoints
- `POST /api/register` - User registration
- `POST /api/login` - User login
- `POST /api/logout` - User logout
- `POST /api/auth/verify-user` - Verify/sync user

### Content Endpoints
- `GET /api/videos` - Get video library
- `GET /api/videos/:id` - Get specific video
- `GET /api/categories` - Get content categories

### User Endpoints
- `GET /api/user` - Get current user profile
- `PATCH /api/user` - Update user profile
- `GET /api/profiles` - Get user profiles

### Admin Endpoints
- `GET /api/admin/users` - Manage users
- `POST /api/admin/sync` - Sync content
- `GET /api/admin/analytics` - View analytics

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/amazing-feature`
3. Make your changes
4. Add tests for new functionality
5. Commit your changes: `git commit -m 'Add amazing feature'`
6. Push to the branch: `git push origin feature/amazing-feature`
7. Open a Pull Request

## 📝 License

This project is proprietary software. All rights reserved.

## 🆘 Support

For support and questions:
- Visit: [madifa.co.za](https://www.madifa.co.za)
- Email: support@madifa.co.za

## 🏆 Production Status

✅ **MVP Deployed** - Core streaming functionality is live and working
🟡 **Feature Development** - Additional features in active development (see [Feature Roadmap](./FEATURE_DEVELOPMENT_ROADMAP.md))
✅ **Mobile Ready** - Configured for Android/iOS app generation  
✅ **Scalable Architecture** - Built with modern, scalable technologies
✅ **Security Compliant** - Implements authentication, authorization, and data protection

## 🚧 Development Roadmap

See [FEATURE_DEVELOPMENT_ROADMAP.md](./FEATURE_DEVELOPMENT_ROADMAP.md) for detailed implementation plan of:
- Watchlist system completion
- Real download functionality  
- Advanced search & filtering
- Video player enhancements
- Recommendation system
- Payment & subscription improvements
- Mobile features & notifications
- Admin analytics dashboard

---

**MadifaStream** - Experience the best of South African cinema with unlimited streaming access to exclusive videos and TV shows. # Force deployment trigger
# Deploy with enhanced cache clearing
