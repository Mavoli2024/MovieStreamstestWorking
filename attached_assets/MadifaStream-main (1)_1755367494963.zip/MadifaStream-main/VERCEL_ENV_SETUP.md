# Vercel Environment Variables Setup

## Required Environment Variables

Add these in your Vercel project settings (Settings > Environment Variables):

**IMPORTANT for https://www.madifa.co.za deployment:**
- Ensure all VITE_ prefixed variables are set for production environment
- VITE_BACKEND_API_URL should be empty/unset for same-origin API calls

### Supabase Configuration
- `VITE_SUPABASE_URL` - Your Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Your Supabase anonymous/public key  
- `SUPABASE_SERVICE_ROLE_KEY` - Your Supabase service role key (server-side only)

### Database
- `DATABASE_URL` - PostgreSQL connection string from Supabase

### Bunny CDN Configuration
- `BUNNY_API_KEY` - Your Bunny CDN API key
- `BUNNY_LIBRARY_ID` - Your Bunny Stream library ID
- `BUNNY_STREAM_HOSTNAME` - Your Bunny Stream hostname (e.g., vz-123456.b-cdn.net)
- `BUNNY_STORAGE_ZONE` - Your Bunny storage zone name
- `BUNNY_STORAGE_HOSTNAME` - Your Bunny storage hostname
- `BUNNY_STORAGE_PASSWORD` - Your Bunny storage password

### PayFast Configuration
- `PAYFAST_MERCHANT_ID` - Your PayFast merchant ID
- `PAYFAST_MERCHANT_KEY` - Your PayFast merchant key
- `PAYFAST_PASSPHRASE` - Your PayFast passphrase
- `PAYFAST_SANDBOX` - Set to "true" for testing, "false" for production

### Email Configuration (optional)
- `SMTP_HOST` - SMTP server hostname
- `SMTP_PORT` - SMTP server port
- `SMTP_USER` - SMTP username
- `SMTP_PASS` - SMTP password
- `SMTP_FROM` - From email address

### Sentry (optional)
- `VITE_SENTRY_DSN` - Your Sentry DSN for error tracking

### General
- `NODE_ENV` - Set to "production"
- `VITE_BACKEND_API_URL` - Leave empty for same-origin API calls (recommended for Vercel)
- `VITE_SITE_URL` - Set to "https://www.madifa.co.za" (your production URL)

## How to Add in Vercel

1. Go to your Vercel project dashboard
2. Click on "Settings" tab
3. Navigate to "Environment Variables"
4. Add each variable with its value
5. Select which environments to apply to (Production, Preview, Development)
6. Click "Save"

## Important Notes

- Variables starting with `VITE_` are exposed to the client
- All other variables are server-side only
- After adding variables, redeploy your project for changes to take effect
- Use the Vercel CLI to pull env vars locally: `vercel env pull .env.local`

## Production Deployment Checklist for https://www.madifa.co.za

1. ✅ Domain configured in Vercel
2. ✅ Auth endpoint working: https://www.madifa.co.za/auth
3. ✅ Environment variables set (see list above)
4. ✅ Supabase authentication configured
5. ✅ Client-side auth form styling fixed
6. ✅ Vercel routing configuration updated