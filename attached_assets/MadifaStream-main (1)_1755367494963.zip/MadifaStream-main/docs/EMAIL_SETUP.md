# MadifaStream Email Configuration

## SMTP Configuration ✅
- Host: smtp.gmail.com:587
- User: noreply@madifa.co.za  
- Sender: Madifa Films
- Admin: admin@madifa.co.za

## Email Addresses
- noreply@madifa.co.za - System emails
- admin@madifa.co.za - Admin contact
- support@madifa.co.za - Customer support
- privacy@madifa.co.za - Privacy inquiries

## Environment Variables
```
MADIFA_SMTP_PASSWORD=your_gmail_app_password
```

## Next Steps
- [ ] Create email templates
- [ ] Set up DNS records (SPF, DKIM, DMARC)
- [ ] Test all email flows 