# Offline Strategy for MadifaStream PWA

## Overview
This document outlines a comprehensive offline strategy for MadifaStream to provide a seamless user experience even when connectivity is limited or unavailable.

## Core Offline Capabilities

### 1. Content Caching Strategy

#### Video Metadata Caching
```typescript
// Service Worker cache strategy for video metadata
const CACHE_NAMES = {
  STATIC: 'madifa-static-v1',
  DYNAMIC: 'madifa-dynamic-v1',
  VIDEO_META: 'madifa-video-meta-v1',
  USER_DATA: 'madifa-user-data-v1'
};

// Cache video listings and metadata
self.addEventListener('fetch', (event) => {
  if (event.request.url.includes('/api/videos')) {
    event.respondWith(
      caches.open(CACHE_NAMES.VIDEO_META).then(cache => {
        return cache.match(event.request).then(response => {
          if (response) {
            // Serve from cache, update in background
            fetch(event.request).then(fetchResponse => {
              cache.put(event.request, fetchResponse.clone());
            });
            return response;
          }
          // Fetch and cache
          return fetch(event.request).then(fetchResponse => {
            cache.put(event.request, fetchResponse.clone());
            return fetchResponse;
          });
        });
      })
    );
  }
});
```

#### Progressive Video Download
```typescript
// Client-side video caching for offline viewing
class OfflineVideoManager {
  private db: IDBDatabase;
  
  async downloadForOffline(videoId: string): Promise<void> {
    const videoBlob = await this.downloadVideoChunks(videoId);
    await this.storeVideoLocally(videoId, videoBlob);
    await this.updateOfflineStatus(videoId, true);
  }
  
  private async downloadVideoChunks(videoId: string): Promise<Blob> {
    const streamUrl = await this.getStreamUrl(videoId);
    const response = await fetch(streamUrl);
    return response.blob();
  }
  
  async getOfflineVideo(videoId: string): Promise<Blob | null> {
    return this.retrieveVideoFromStorage(videoId);
  }
}
```

### 2. Data Synchronization

#### Offline Queue System
```typescript
// Queue system for offline actions
interface OfflineAction {
  id: string;
  type: 'WATCH_PROGRESS' | 'RATING' | 'WATCHLIST_ADD' | 'WATCHLIST_REMOVE';
  payload: any;
  timestamp: number;
  retryCount: number;
}

class OfflineQueue {
  private queue: OfflineAction[] = [];
  
  async addAction(action: Omit<OfflineAction, 'id' | 'timestamp' | 'retryCount'>): Promise<void> {
    const queueItem: OfflineAction = {
      ...action,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
      retryCount: 0
    };
    
    this.queue.push(queueItem);
    await this.persistQueue();
    
    // Try to sync immediately if online
    if (navigator.onLine) {
      this.processQueue();
    }
  }
  
  async processQueue(): Promise<void> {
    const pendingActions = [...this.queue];
    
    for (const action of pendingActions) {
      try {
        await this.syncAction(action);
        this.removeFromQueue(action.id);
      } catch (error) {
        action.retryCount++;
        if (action.retryCount > 3) {
          this.removeFromQueue(action.id);
        }
      }
    }
    
    await this.persistQueue();
  }
}
```

#### Conflict Resolution
```typescript
// Handle conflicts when syncing offline changes
class ConflictResolver {
  async resolveWatchProgress(
    localProgress: WatchProgress,
    serverProgress: WatchProgress
  ): Promise<WatchProgress> {
    // Use the progress with the latest timestamp
    // and the higher progress value (user likely watched more)
    return {
      ...localProgress,
      progress_seconds: Math.max(
        localProgress.progress_seconds,
        serverProgress.progress_seconds
      ),
      updated_at: new Date().toISOString()
    };
  }
  
  async resolveWatchlist(
    localWatchlist: string[],
    serverWatchlist: string[]
  ): Promise<string[]> {
    // Merge both lists, removing duplicates
    return [...new Set([...localWatchlist, ...serverWatchlist])];
  }
}
```

### 3. Storage Management

#### IndexedDB Schema
```typescript
// IndexedDB structure for offline data
const DB_SCHEMA = {
  name: 'MadifaStreamDB',
  version: 1,
  stores: {
    videos: {
      keyPath: 'id',
      indexes: ['category', 'created_at', 'user_id']
    },
    videoBlobs: {
      keyPath: 'videoId'
    },
    watchProgress: {
      keyPath: ['user_id', 'video_id']
    },
    watchlist: {
      keyPath: ['user_id', 'video_id']
    },
    offlineQueue: {
      keyPath: 'id',
      indexes: ['timestamp', 'type']
    }
  }
};
```

#### Storage Quota Management
```typescript
class StorageManager {
  async checkStorageQuota(): Promise<{used: number, available: number}> {
    const estimate = await navigator.storage.estimate();
    return {
      used: estimate.usage || 0,
      available: estimate.quota || 0
    };
  }
  
  async cleanupOldContent(): Promise<void> {
    const quota = await this.checkStorageQuota();
    
    if (quota.used / quota.available > 0.8) {
      // Remove oldest cached videos
      await this.removeOldestVideos(5);
      // Clear old API cache entries
      await this.clearOldApiCache();
    }
  }
  
  async removeOldestVideos(count: number): Promise<void> {
    const db = await this.openDB();
    const tx = db.transaction(['videoBlobs'], 'readwrite');
    const store = tx.objectStore('videoBlobs');
    
    const videos = await store.getAll();
    const sortedVideos = videos.sort((a, b) => a.lastAccessed - b.lastAccessed);
    
    for (let i = 0; i < Math.min(count, sortedVideos.length); i++) {
      await store.delete(sortedVideos[i].videoId);
    }
  }
}
```

## Implementation Phases

### Phase 1: Basic Offline Support (Week 1-2)
- Service worker registration and basic caching
- Cache static assets (CSS, JS, images)
- Cache API responses with stale-while-revalidate strategy
- Offline page for when content isn't cached

### Phase 2: Enhanced Caching (Week 3-4)
- Video metadata caching
- User data synchronization
- Offline queue implementation
- Background sync for pending actions

### Phase 3: Video Download (Week 5-6)
- Progressive video download for offline viewing
- Storage quota management
- Download progress indicators
- Selective content caching based on user preferences

### Phase 4: Advanced Features (Week 7-8)
- Conflict resolution for data synchronization
- Predictive caching based on user behavior
- Offline analytics and usage tracking
- Performance optimization and monitoring

## User Experience Features

### Offline Indicators
```typescript
// Visual indicators for offline status
class OfflineIndicator {
  private indicator: HTMLElement;
  
  constructor() {
    this.indicator = document.createElement('div');
    this.indicator.className = 'offline-indicator';
    this.setupNetworkListeners();
  }
  
  private setupNetworkListeners(): void {
    window.addEventListener('online', () => {
      this.showStatus('Back online', 'success');
      this.syncPendingActions();
    });
    
    window.addEventListener('offline', () => {
      this.showStatus('You\'re offline', 'warning');
    });
  }
  
  showStatus(message: string, type: 'success' | 'warning' | 'error'): void {
    this.indicator.textContent = message;
    this.indicator.className = `offline-indicator ${type}`;
    document.body.appendChild(this.indicator);
    
    setTimeout(() => {
      this.indicator.remove();
    }, 3000);
  }
}
```

### Download Management UI
```typescript
// UI for managing offline downloads
class DownloadManager {
  async showDownloadDialog(videoId: string): Promise<void> {
    const video = await this.getVideoMetadata(videoId);
    const estimatedSize = await this.estimateVideoSize(videoId);
    
    const dialog = this.createDownloadDialog({
      title: video.title,
      duration: video.duration,
      estimatedSize,
      quality: 'HD' // Allow quality selection
    });
    
    dialog.show();
  }
  
  async startDownload(videoId: string, quality: string): Promise<void> {
    const progressBar = this.createProgressBar();
    
    try {
      await this.offlineVideoManager.downloadForOffline(videoId, {
        quality,
        onProgress: (progress) => {
          progressBar.update(progress);
        }
      });
      
      this.showSuccess('Video downloaded for offline viewing');
    } catch (error) {
      this.showError('Download failed. Please try again.');
    }
  }
}
```

## Performance Considerations

### Caching Strategy
- **Static Assets:** Cache-first with long TTL
- **API Responses:** Stale-while-revalidate for fresh data
- **Video Content:** On-demand caching with user control
- **User Data:** Network-first with offline fallback

### Storage Optimization
- Compress video metadata before storing
- Use efficient IndexedDB queries with proper indexing
- Implement LRU eviction for cache management
- Monitor and alert on storage quota usage

## Success Metrics
- **Offline Functionality:** 90% of core features work offline
- **Sync Success Rate:** 95% of offline actions sync successfully
- **Storage Efficiency:** Optimal use of available storage quota
- **User Engagement:** Increased session duration during poor connectivity

## Testing Strategy
- Automated testing with network throttling
- Manual testing in airplane mode
- Performance testing with large offline datasets
- User acceptance testing in low-connectivity scenarios
