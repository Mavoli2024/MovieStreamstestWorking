# RFC: State Management & Routing Architecture

## Problem Statement

The current MadifaStream frontend has scattered state management and navigation logic that creates maintainability issues:

- **Local State**: Multiple hooks each manage their own localStorage with no cross-component reactivity
- **Server State**: No centralized query cache, leading to duplicate API calls and stale data
- **Navigation**: Manual history management duplicates Wouter's built-in functionality
- **Route Guards**: No systematic auth/role protection for protected routes
- **Type Safety**: Query parameters and navigation lack proper typing

## Proposed Solution

### 1. Global State Management (Zustand)

**Why Zustand over Context/Redux:**
- Minimal boilerplate
- TypeScript-first
- Built-in persistence middleware
- No provider wrapper needed
- Excellent DevTools support

**Store Structure:**
```typescript
// stores/settingsStore.ts
interface SettingsState {
  theme: 'light' | 'dark' | 'system';
  autoplay: boolean;
  quality: 'auto' | '720p' | '1080p' | '4k';
  language: string;
  notifications: boolean;
}

// stores/authStore.ts  
interface AuthState {
  user: User | null;
  session: Session | null;
  isLoading: boolean;
  roles: string[];
}

// stores/uiStore.ts
interface UIState {
  sidebarOpen: boolean;
  searchQuery: string;
  currentToast: Toast | null;
  networkStatus: 'online' | 'offline';
}
```

### 2. Server State Management (React Query)

**Benefits:**
- Automatic background refetching
- Optimistic updates
- Request deduplication
- Offline support
- Cache invalidation

**Query Structure:**
```typescript
// queries/videoQueries.ts
export const useVideosQuery = (filters?: VideoFilters) => {
  return useQuery({
    queryKey: ['videos', filters],
    queryFn: () => videoService.getVideos(filters),
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
};

// queries/watchProgressQueries.ts
export const useWatchProgressQuery = (videoId: string) => {
  return useQuery({
    queryKey: ['watchProgress', videoId],
    queryFn: () => watchProgressService.getProgress(videoId),
    enabled: !!videoId,
  });
};
```

### 3. Enhanced Navigation & Routing

**Replace NavigationManager with Wouter-native approach:**

```typescript
// hooks/useNavigation.ts
export const useNavigation = () => {
  const [location, setLocation] = useLocation();
  
  const navigate = useCallback((path: string) => {
    setLocation(path);
  }, [setLocation]);
  
  const goBack = useCallback(() => {
    window.history.back();
  }, []);
  
  return { location, navigate, goBack };
};
```

**Route Guards:**
```typescript
// components/routing/RouteGuard.tsx
interface RouteGuardProps {
  children: React.ReactNode;
  requiresAuth?: boolean;
  roles?: string[];
  fallback?: React.ReactNode;
}

export const RouteGuard: React.FC<RouteGuardProps> = ({
  children,
  requiresAuth,
  roles,
  fallback = <Navigate to="/login" />
}) => {
  const { isAuthenticated, userRoles } = useAuthStore();
  
  if (requiresAuth && !isAuthenticated) {
    return <>{fallback}</>;
  }
  
  if (roles && !roles.some(role => userRoles.includes(role))) {
    return <Navigate to="/403" />;
  }
  
  return <>{children}</>;
};
```

### 4. Type-Safe Query Parameters

**Use Zod schemas for query validation:**
```typescript
// schemas/querySchemas.ts
export const searchQuerySchema = z.object({
  q: z.string().optional(),
  category: z.string().optional(),
  sortBy: z.enum(['relevance', 'date', 'rating']).default('relevance'),
  page: z.coerce.number().min(1).default(1),
});

// hooks/useTypedQuery.ts
export const useTypedQuery = <T>(schema: z.ZodSchema<T>) => {
  const [location] = useLocation();
  return useMemo(() => {
    const searchParams = new URLSearchParams(location.split('?')[1]);
    const params = Object.fromEntries(searchParams.entries());
    return schema.parse(params);
  }, [location, schema]);
};
```

### 5. Application Provider Structure

```typescript
// providers/AppProvider.tsx
export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ToastProvider>
          <ErrorBoundary>
            {children}
          </ErrorBoundary>
        </ToastProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
};
```

## Implementation Plan

### Phase 1: Foundation (Day 1)
1. Create store structure with Zustand
2. Set up React Query client and providers
3. Implement basic RouteGuard component
4. Create typed query parameter hooks

### Phase 2: Migration (Day 2-3)
1. Migrate settings from localStorage hooks to Zustand store
2. Convert video/auth queries to React Query
3. Replace NavigationManager with Wouter hooks
4. Add route guards to protected routes

### Phase 3: Enhancement (Day 4-5)
1. Add breadcrumb generation from route tree
2. Implement automatic page title updates
3. Add cross-tab synchronization
4. Write comprehensive tests

### Phase 4: Testing & Documentation (Day 6)
1. Integration tests for navigation guards
2. Unit tests for store slices
3. Update README with new patterns
4. Performance optimization

## Migration Strategy

**Backwards Compatibility:**
- Keep existing hooks during transition
- Gradual migration per component
- Feature flags for new state management

**Testing Strategy:**
- Mock stores in tests
- Integration tests for navigation flows
- E2E tests for critical user journeys

## Success Metrics

- **Performance**: 50% reduction in duplicate API calls
- **DX**: Faster development of new features
- **Reliability**: Consistent state across components
- **Maintainability**: Clear separation of concerns

## Risks & Mitigation

**Risk**: Store complexity grows over time
**Mitigation**: Keep stores small and focused, use selectors

**Risk**: Bundle size increase
**Mitigation**: Tree-shake unused query hooks, lazy load stores

**Risk**: Breaking existing functionality
**Mitigation**: Incremental migration, comprehensive testing

## Decision Points

1. **Global Store**: ✅ Zustand (lightweight, TypeScript-first)
2. **Server State**: ✅ React Query (industry standard)
3. **Navigation**: ✅ Enhanced Wouter (already in use)
4. **Type Safety**: ✅ Zod schemas (validation + types)

## Next Steps

1. Create foundational store and query infrastructure
2. Implement RouteGuard and basic navigation hooks
3. Migrate 2-3 critical components as proof of concept
4. Gather feedback and iterate

---

*This RFC will be updated as implementation progresses and new requirements emerge.*
