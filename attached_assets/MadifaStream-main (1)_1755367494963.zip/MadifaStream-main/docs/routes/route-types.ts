/**
 * Auto-generated Route Types
 * Generated: 2025-01-21T19:53:00.000Z
 */

// Route paths as literal types
export type RoutePath = 
  | '/'
  | '/auth'
  | '/auth/callback'
  | '/terms'
  | '/privacy'
  | '/cookies'
  | '/accessibility'
  | '/sitemap'
  | '/feedback'
  | '/home'
  | '/browse'
  | '/discover'
  | '/search'
  | '/watch/:id'
  | '/profile'
  | '/settings'
  | '/admin'
  | '/admin/library'
  | '/subscription'
  | '/downloads'
  | '/my-list'
  | '/recommendations'
  | '/payment/success'
  | '/payment/cancel';

// Component names
export type ComponentName = 
  | 'RootRoute'
  | 'AuthPage'
  | 'AuthCallback'
  | 'TermsPage'
  | 'PrivacyPage'
  | 'CookiesPage'
  | 'AccessibilityPage'
  | 'SitemapPage'
  | 'FeedbackPage'
  | 'HomePage'
  | 'BrowsePage'
  | 'DiscoverContentPage'
  | 'SearchPage'
  | 'VideoPage'
  | 'ProfilePage'
  | 'SettingsPage'
  | 'AdminPage'
  | 'VideoLibraryPage'
  | 'SubscriptionPage'
  | 'DownloadsPage'
  | 'MyListPage'
  | 'RecommendationsPage'
  | 'PaymentSuccessPage'
  | 'PaymentCancelPage';

// Route definition interface
export interface RouteDefinition {
  path: RoutePath;
  component: ComponentName;
  type: 'public' | 'protected';
  dynamic: boolean;
  params: string[];
}

// Route registry type
export type RouteRegistry = Record<RoutePath, RouteDefinition>;

// Navigation link type
export interface NavigationLink {
  href: string;
  usages: Array<{
    file: string;
    line: number;
    context: string;
  }>;
}

// Component metadata interface
export interface ComponentMetadata {
  name: string;
  file: string;
  authRequired: boolean;
  hooks: string[];
  metadata: {
    title?: string;
    description?: string;
  };
  seoTags: string[];
  lineCount: number;
  size: number;
}

// Route builder helpers
export interface RouteBuilders {
  watch: (videoId: string) => string;
  browse: (params?: { type?: string; collection?: string }) => string;
  auth: (tab?: 'login' | 'register') => string;
}

// Navigation section types
export type NavigationSection = 'MAIN' | 'USER' | 'ACCOUNT' | 'LEGAL';

export interface NavigationItem {
  label: string;
  route: RoutePath;
  icon?: string;
}

// Route validation types
export interface RouteValidationError {
  type: 'BROKEN_LINK' | 'MISSING_COMPONENT' | 'INVALID_ROUTE';
  message: string;
  severity: 'error' | 'warning';
  location?: {
    file: string;
    line: number;
  };
}

export interface RouteHealthReport {
  score: number;
  errors: RouteValidationError[];
  warnings: RouteValidationError[];
  summary: {
    totalRoutes: number;
    totalComponents: number;
    totalNavigationLinks: number;
    brokenLinks: number;
    unusedRoutes: number;
  };
}

// Utility types for route operations
export type PublicRoute = Extract<RoutePath, 
  | '/' 
  | '/auth' 
  | '/auth/callback' 
  | '/terms' 
  | '/privacy' 
  | '/cookies' 
  | '/accessibility' 
  | '/sitemap' 
  | '/feedback'
>;

export type ProtectedRoute = Exclude<RoutePath, PublicRoute>;

export type DynamicRoute = Extract<RoutePath, '/watch/:id'>;

export type StaticRoute = Exclude<RoutePath, DynamicRoute>;

// Route parameter extraction
export type RouteParams<T extends RoutePath> = 
  T extends '/watch/:id' ? { id: string } : Record<string, never>;

// Advanced type helpers
export type RoutesByType<T extends 'public' | 'protected'> = 
  T extends 'public' ? PublicRoute : ProtectedRoute;

export type ComponentForRoute<T extends RoutePath> = 
  T extends '/' ? 'RootRoute' :
  T extends '/auth' ? 'AuthPage' :
  T extends '/auth/callback' ? 'AuthCallback' :
  T extends '/terms' ? 'TermsPage' :
  T extends '/privacy' ? 'PrivacyPage' :
  T extends '/cookies' ? 'CookiesPage' :
  T extends '/accessibility' ? 'AccessibilityPage' :
  T extends '/sitemap' ? 'SitemapPage' :
  T extends '/feedback' ? 'FeedbackPage' :
  T extends '/home' ? 'HomePage' :
  T extends '/browse' ? 'BrowsePage' :
  T extends '/discover' ? 'DiscoverContentPage' :
  T extends '/search' ? 'SearchPage' :
  T extends '/watch/:id' ? 'VideoPage' :
  T extends '/profile' ? 'ProfilePage' :
  T extends '/settings' ? 'SettingsPage' :
  T extends '/admin' ? 'AdminPage' :
  T extends '/admin/library' ? 'VideoLibraryPage' :
  T extends '/subscription' ? 'SubscriptionPage' :
  T extends '/downloads' ? 'DownloadsPage' :
  T extends '/my-list' ? 'MyListPage' :
  T extends '/recommendations' ? 'RecommendationsPage' :
  T extends '/payment/success' ? 'PaymentSuccessPage' :
  T extends '/payment/cancel' ? 'PaymentCancelPage' :
  ComponentName;

// Export route registry constant
export const ROUTE_REGISTRY: RouteRegistry = {
  '/': { path: '/', component: 'RootRoute', type: 'public', dynamic: false, params: [] },
  '/auth': { path: '/auth', component: 'AuthPage', type: 'public', dynamic: false, params: [] },
  '/auth/callback': { path: '/auth/callback', component: 'AuthCallback', type: 'public', dynamic: false, params: [] },
  '/terms': { path: '/terms', component: 'TermsPage', type: 'public', dynamic: false, params: [] },
  '/privacy': { path: '/privacy', component: 'PrivacyPage', type: 'public', dynamic: false, params: [] },
  '/cookies': { path: '/cookies', component: 'CookiesPage', type: 'public', dynamic: false, params: [] },
  '/accessibility': { path: '/accessibility', component: 'AccessibilityPage', type: 'public', dynamic: false, params: [] },
  '/sitemap': { path: '/sitemap', component: 'SitemapPage', type: 'public', dynamic: false, params: [] },
  '/feedback': { path: '/feedback', component: 'FeedbackPage', type: 'public', dynamic: false, params: [] },
  '/home': { path: '/home', component: 'HomePage', type: 'protected', dynamic: false, params: [] },
  '/browse': { path: '/browse', component: 'BrowsePage', type: 'protected', dynamic: false, params: [] },
  '/discover': { path: '/discover', component: 'DiscoverContentPage', type: 'protected', dynamic: false, params: [] },
  '/search': { path: '/search', component: 'SearchPage', type: 'protected', dynamic: false, params: [] },
  '/watch/:id': { path: '/watch/:id', component: 'VideoPage', type: 'protected', dynamic: true, params: ['id'] },
  '/profile': { path: '/profile', component: 'ProfilePage', type: 'protected', dynamic: false, params: [] },
  '/settings': { path: '/settings', component: 'SettingsPage', type: 'protected', dynamic: false, params: [] },
  '/admin': { path: '/admin', component: 'AdminPage', type: 'protected', dynamic: false, params: [] },
  '/admin/library': { path: '/admin/library', component: 'VideoLibraryPage', type: 'protected', dynamic: false, params: [] },
  '/subscription': { path: '/subscription', component: 'SubscriptionPage', type: 'protected', dynamic: false, params: [] },
  '/downloads': { path: '/downloads', component: 'DownloadsPage', type: 'protected', dynamic: false, params: [] },
  '/my-list': { path: '/my-list', component: 'MyListPage', type: 'protected', dynamic: false, params: [] },
  '/recommendations': { path: '/recommendations', component: 'RecommendationsPage', type: 'protected', dynamic: false, params: [] },
  '/payment/success': { path: '/payment/success', component: 'PaymentSuccessPage', type: 'protected', dynamic: false, params: [] },
  '/payment/cancel': { path: '/payment/cancel', component: 'PaymentCancelPage', type: 'protected', dynamic: false, params: [] },
};