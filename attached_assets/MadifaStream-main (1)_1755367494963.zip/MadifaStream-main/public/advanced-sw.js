/**
 * Advanced Service Worker for MadifaStream
 * 
 * Features:
 * - Enhanced push notifications with actions
 * - Background sync for offline actions
 * - Real-time data synchronization
 * - Intelligent caching strategies
 * - Performance monitoring
 */

// Import logger (simplified for service worker)
const logger = {
  info: (message, data = {}) => console.log('[SW]', message, data),
  warn: (message, data = {}) => console.warn('[SW]', message, data),
  error: (message, data = {}) => console.error('[SW]', message, data),
  debug: (message, data = {}) => console.debug('[SW]', message, data)
};

// Service worker configuration
const SW_CONFIG = {
  CACHE_NAME: 'madifastream-v6',
  OFFLINE_CACHE: 'madifastream-offline-v6',
  DATA_CACHE: 'madifastream-data-v6',
  BACKGROUND_SYNC_TAG: 'madifa-background-sync',
  MAX_CACHE_SIZE: 50, // Maximum number of cached responses
  CACHE_EXPIRY: 24 * 60 * 60 * 1000, // 24 hours
};

// URLs to cache for offline functionality
const STATIC_CACHE_URLS = [
  '/',
  '/offline.html',
  '/manifest.json',
  '/favicon.ico',
];

// API endpoints that should be cached
const CACHEABLE_API_PATTERNS = [
  /\/api\/videos\/\w+/,
  /\/api\/categories/,
  /\/api\/recommendations/,
];

// Background sync queue
let syncQueue = [];

// Performance metrics
const metrics = {
  cacheHits: 0,
  cacheMisses: 0,
  backgroundSyncs: 0,
  pushNotifications: 0,
  errors: 0,
};

/**
 * Service Worker Installation
 */
self.addEventListener('install', (event) => {
  logger.info('Service Worker installing');
  
  event.waitUntil(
    Promise.all([
      caches.open(SW_CONFIG.CACHE_NAME).then((cache) => {
        logger.info('Caching static assets');
        return cache.addAll(STATIC_CACHE_URLS);
      }),
      caches.open(SW_CONFIG.OFFLINE_CACHE),
      caches.open(SW_CONFIG.DATA_CACHE),
    ]).then(() => {
      logger.info('Service Worker installed successfully');
      // Skip waiting to activate immediately
      self.skipWaiting();
    })
  );
});

/**
 * Service Worker Activation
 */
self.addEventListener('activate', (event) => {
  logger.info('Service Worker activating');
  
  event.waitUntil(
    Promise.all([
      // Clean up old caches
      caches.keys().then((cacheNames) => {
        return Promise.all(
          cacheNames.map((cacheName) => {
            if (cacheName !== SW_CONFIG.CACHE_NAME && 
                cacheName !== SW_CONFIG.OFFLINE_CACHE && 
                cacheName !== SW_CONFIG.DATA_CACHE) {
              logger.info('Deleting old cache', { cacheName });
              return caches.delete(cacheName);
            }
          })
        );
      }),
      
      // Claim all clients
      self.clients.claim(),
      
      // Initialize performance tracking
      initializePerformanceTracking(),
    ]).then(() => {
      logger.info('Service Worker activated successfully');
    })
  );
});

/**
 * Advanced Fetch Handling with Caching Strategies
 */
self.addEventListener('fetch', (event) => {
  const { request } = event;
  const url = new URL(request.url);
  
  // Skip non-GET requests and chrome-extension requests
  if (request.method !== 'GET' || url.protocol === 'chrome-extension:') {
    return;
  }
  
  // Handle different types of requests with appropriate strategies
  if (isStaticAsset(url)) {
    event.respondWith(handleStaticAsset(request));
  } else if (isAPIRequest(url)) {
    event.respondWith(handleAPIRequest(request));
  } else if (isVideoRequest(url)) {
    event.respondWith(handleVideoRequest(request));
  } else {
    event.respondWith(handleDefaultRequest(request));
  }
});

/**
 * Enhanced Push Notification Handling
 */
self.addEventListener('push', (event) => {
  logger.info('Push notification received');
  metrics.pushNotifications++;
  
  let notificationData = {
    title: 'MadifaStream',
    body: 'New content available!',
    icon: '/generated-icon.png',
    badge: '/generated-icon.png',
    data: { url: '/' },
    actions: [],
    requireInteraction: false,
    silent: false,
  };

  if (event.data) {
    try {
      const data = event.data.json();
      notificationData = { ...notificationData, ...data };
      
      // Add context-specific actions
      switch (data.type) {
        case 'download':
          notificationData.actions = [
            {
              action: 'view',
              title: 'View Downloads',
              icon: '/icons/download.png'
            },
            {
              action: 'dismiss',
              title: 'Dismiss'
            }
          ];
          break;
          
        case 'content':
          notificationData.actions = [
            {
              action: 'watch',
              title: 'Watch Now',
              icon: '/icons/play.png'
            },
            {
              action: 'later',
              title: 'Watch Later'
            }
          ];
          break;
          
        case 'subscription':
          notificationData.requireInteraction = true;
          notificationData.actions = [
            {
              action: 'manage',
              title: 'Manage Subscription',
              icon: '/icons/settings.png'
            }
          ];
          break;
          
        case 'system':
          notificationData.requireInteraction = true;
          break;
      }
      
      logger.info('Push notification processed', { type: data.type });
    } catch (error) {
      logger.error('Error parsing push notification data', error);
      metrics.errors++;
    }
  }

  event.waitUntil(
    Promise.all([
      self.registration.showNotification(notificationData.title, notificationData),
      trackNotificationEvent('received', notificationData)
    ])
  );
});

/**
 * Advanced Notification Click Handling
 */
self.addEventListener('notificationclick', (event) => {
  logger.info('Notification clicked', { action: event.action });
  
  event.notification.close();
  
  const notificationData = event.notification.data || {};
  const action = event.action;
  
  let targetUrl = notificationData.url || '/';
  
  // Handle different actions
  switch (action) {
    case 'view':
    case 'watch':
      // Use the URL from notification data
      break;
      
    case 'later':
      // Add to watchlist and go to watchlist page
      targetUrl = '/watchlist';
      // Queue background sync to add to watchlist
      queueBackgroundSync('addToWatchlist', notificationData);
      break;
      
    case 'manage':
      targetUrl = '/settings/subscription';
      break;
      
    case 'dismiss':
      // Just close notification, don't open window
      return;
      
    default:
      // Default action - open the notification URL
      break;
  }
  
  event.waitUntil(
    Promise.all([
      openOrFocusWindow(targetUrl),
      trackNotificationEvent('clicked', { action, targetUrl })
    ])
  );
});

/**
 * Background Sync for Offline Actions
 */
self.addEventListener('sync', (event) => {
  logger.info('Background sync triggered', { tag: event.tag });
  metrics.backgroundSyncs++;
  
  if (event.tag === SW_CONFIG.BACKGROUND_SYNC_TAG) {
    event.waitUntil(processSyncQueue());
  } else if (event.tag === 'watchlist-sync') {
    event.waitUntil(syncWatchlistChanges());
  } else if (event.tag === 'analytics-sync') {
    event.waitUntil(syncAnalyticsData());
  }
});

/**
 * Message Handling for Communication with Main Thread
 */
self.addEventListener('message', (event) => {
  const { type, data } = event.data || {};
  
  logger.debug('Message received', { type });
  
  switch (type) {
    case 'QUEUE_BACKGROUND_SYNC':
      queueBackgroundSync(data.action, data.payload);
      break;
      
    case 'GET_METRICS':
      event.ports[0]?.postMessage({ type: 'METRICS', data: metrics });
      break;
      
    case 'CLEAR_CACHE':
      clearCache(data.cacheType);
      break;
      
    case 'PRELOAD_CONTENT':
      preloadContent(data.urls);
      break;
      
    case 'UPDATE_NOTIFICATION_SETTINGS':
      updateNotificationSettings(data.settings);
      break;
      
    default:
      logger.warn('Unknown message type', { type });
  }
});

/**
 * Caching Strategies
 */

// Cache First Strategy (for static assets)
async function handleStaticAsset(request) {
  try {
    const cache = await caches.open(SW_CONFIG.CACHE_NAME);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      metrics.cacheHits++;
      return cachedResponse;
    }
    
    const networkResponse = await fetch(request);
    if (networkResponse.ok) {
      cache.put(request, networkResponse.clone());
    }
    
    metrics.cacheMisses++;
    return networkResponse;
  } catch (error) {
    logger.error('Error handling static asset', error);
    metrics.errors++;
    return caches.match('/offline.html');
  }
}

// Network First Strategy (for API requests)
async function handleAPIRequest(request) {
  try {
    const networkResponse = await fetch(request);
    
    if (networkResponse.ok) {
      // Cache successful API responses
      const cache = await caches.open(SW_CONFIG.DATA_CACHE);
      cache.put(request, networkResponse.clone());
      
      // Clean old cache entries
      cleanCache(cache);
    }
    
    metrics.cacheMisses++;
    return networkResponse;
  } catch (error) {
    logger.warn('Network failed, trying cache', error);
    
    const cache = await caches.open(SW_CONFIG.DATA_CACHE);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      metrics.cacheHits++;
      return cachedResponse;
    }
    
    metrics.errors++;
    throw error;
  }
}

// Stale While Revalidate Strategy (for video metadata)
async function handleVideoRequest(request) {
  const cache = await caches.open(SW_CONFIG.DATA_CACHE);
  const cachedResponse = await cache.match(request);
  
  // Serve from cache immediately if available
  const responsePromise = cachedResponse || fetch(request);
  
  // Update cache in background
  const updateCache = async () => {
    try {
      const networkResponse = await fetch(request);
      if (networkResponse.ok) {
        cache.put(request, networkResponse.clone());
      }
    } catch (error) {
      logger.warn('Failed to update cache', error);
    }
  };
  
  updateCache();
  
  if (cachedResponse) {
    metrics.cacheHits++;
  } else {
    metrics.cacheMisses++;
  }
  
  return responsePromise;
}

// Default Strategy (Network falling back to cache)
async function handleDefaultRequest(request) {
  try {
    const networkResponse = await fetch(request);
    metrics.cacheMisses++;
    return networkResponse;
  } catch (error) {
    const cache = await caches.open(SW_CONFIG.CACHE_NAME);
    const cachedResponse = await cache.match(request);
    
    if (cachedResponse) {
      metrics.cacheHits++;
      return cachedResponse;
    }
    
    metrics.errors++;
    return caches.match('/offline.html');
  }
}

/**
 * Utility Functions
 */

function isStaticAsset(url) {
  return url.pathname.match(/\.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2)$/) ||
         url.pathname === '/' ||
         url.pathname === '/offline.html' ||
         url.pathname === '/manifest.json';
}

function isAPIRequest(url) {
  return url.pathname.startsWith('/api/') ||
         CACHEABLE_API_PATTERNS.some(pattern => pattern.test(url.pathname));
}

function isVideoRequest(url) {
  return url.pathname.includes('/video') ||
         url.pathname.includes('/stream') ||
         url.hostname.includes('bunny');
}

async function cleanCache(cache) {
  const keys = await cache.keys();
  if (keys.length > SW_CONFIG.MAX_CACHE_SIZE) {
    const oldestKeys = keys.slice(0, keys.length - SW_CONFIG.MAX_CACHE_SIZE);
    await Promise.all(oldestKeys.map(key => cache.delete(key)));
    logger.info('Cleaned old cache entries', { count: oldestKeys.length });
  }
}

function queueBackgroundSync(action, payload) {
  syncQueue.push({
    id: `${action}_${Date.now()}`,
    action,
    payload,
    timestamp: Date.now(),
    retries: 0,
  });
  
  logger.info('Queued background sync', { action, queueLength: syncQueue.length });
}

async function processSyncQueue() {
  logger.info('Processing sync queue', { items: syncQueue.length });
  
  const processItem = async (item) => {
    try {
      switch (item.action) {
        case 'addToWatchlist':
          await syncAddToWatchlist(item.payload);
          break;
          
        case 'recordView':
          await syncRecordView(item.payload);
          break;
          
        case 'updateProgress':
          await syncUpdateProgress(item.payload);
          break;
          
        default:
          logger.warn('Unknown sync action', { action: item.action });
          return false;
      }
      
      return true;
    } catch (error) {
      logger.error('Sync item failed', { action: item.action, error });
      item.retries++;
      
      if (item.retries < 3) {
        // Keep item in queue for retry
        return false;
      }
      
      // Remove after max retries
      return true;
    }
  };
  
  const results = await Promise.allSettled(
    syncQueue.map(processItem)
  );
  
  // Remove successfully processed items
  syncQueue = syncQueue.filter((item, index) => {
    const result = results[index];
    return result.status === 'fulfilled' && !result.value;
  });
  
  logger.info('Sync queue processed', { remaining: syncQueue.length });
}

async function syncAddToWatchlist(payload) {
  const response = await fetch('/api/watchlist', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  });
  
  if (!response.ok) {
    throw new Error(`Watchlist sync failed: ${response.status}`);
  }
  
  logger.info('Watchlist item synced', payload);
}

async function openOrFocusWindow(url) {
  const clients = await self.clients.matchAll({
    type: 'window',
    includeUncontrolled: true,
  });
  
  // Try to focus existing window with same URL
  for (const client of clients) {
    if (client.url === url && 'focus' in client) {
      return client.focus();
    }
  }
  
  // Open new window
  if (self.clients.openWindow) {
    return self.clients.openWindow(url);
  }
}

async function trackNotificationEvent(event, data) {
  try {
    await fetch('/api/analytics/notification', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        event,
        data,
        timestamp: Date.now(),
      }),
    });
  } catch (error) {
    logger.error('Failed to track notification event', error);
  }
}

async function initializePerformanceTracking() {
  // Initialize performance metrics
  logger.info('Performance tracking initialized');
}

async function preloadContent(urls) {
  logger.info('Preloading content', { count: urls.length });
  
  const cache = await caches.open(SW_CONFIG.DATA_CACHE);
  const preloadPromises = urls.map(async (url) => {
    try {
      const response = await fetch(url);
      if (response.ok) {
        await cache.put(url, response);
      }
    } catch (error) {
      logger.warn('Preload failed', { url, error });
    }
  });
  
  await Promise.allSettled(preloadPromises);
}

function updateNotificationSettings(settings) {
  logger.info('Notification settings updated', settings);
  // Store settings in IndexedDB or localStorage
}

async function clearCache(cacheType) {
  const cacheName = cacheType === 'data' ? SW_CONFIG.DATA_CACHE : SW_CONFIG.CACHE_NAME;
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  
  await Promise.all(keys.map(key => cache.delete(key)));
  logger.info('Cache cleared', { type: cacheType, items: keys.length });
}

// Log service worker startup
logger.info('Advanced Service Worker loaded', {
  version: SW_CONFIG.CACHE_NAME,
  timestamp: new Date().toISOString(),
});