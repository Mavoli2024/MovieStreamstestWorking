# MadifaStream Data Flow & Architecture Audit

## Executive Summary
Comprehensive audit of database connections, data loading patterns, state management, middleware chains, routing integrity, and browsing behavior.

## 🗄️ DATABASE & DATA LOADING

### Database Connection Architecture
```
[PostgreSQL] ← Supabase → [Drizzle ORM] → [Express Server] → [API Routes]
                    ↓
            [Supabase Client] → [React Frontend]
```

#### Connection Details
- **Backend**: `server/db.ts` uses PostgreSQL via Supabase with Drizzle ORM
- **Frontend**: Direct Supabase client for auth and real-time features
- **Connection Pool**: Max 10 connections, 30s idle timeout, 5s connect timeout
- **SSL**: Required for production database connections

### Data Loading Patterns

#### 1. **React Query Configuration** (`queryClient.ts`)
```javascript
- Stale Time: 5 minutes (data fresh for 5 min)
- Cache Time: 10 minutes (cached for 10 min after last use)
- Retry: 3 attempts with exponential backoff
- Refetch: On window focus and network reconnect
- Smart retries: No retry on 4xx errors
```

#### 2. **Data Fetching Hooks**
- `useVideos()`: Fetches all videos with fallback to API
- `useVideo(id)`: Individual video with caching
- `useWatchProgress()`: User's watch progress
- `useWatchlist()`: User's saved videos
- **Optimistic Updates**: Immediate UI updates before server confirmation

#### 3. **Dual Data Sources**
```javascript
// Primary: Direct Supabase query
const { data } = await supabase.from('videos').select('*');

// Fallback: API endpoint
const response = await fetch('/api/videos/public');
```

## 🔄 STATE MANAGEMENT

### Three-Layer State Architecture

#### 1. **Zustand Stores** (Client State)
- `authStore`: User authentication, session, profile
- `uiStore`: UI state, modals, toasts, loading states
- `settingsStore`: User preferences and app settings

#### 2. **React Query** (Server State)
- Centralized cache for all API data
- Automatic background refetching
- Optimistic updates for better UX
- Query invalidation on mutations

#### 3. **Supabase Real-time** (Live Updates)
- Auth state changes across tabs
- Real-time subscriptions for notifications
- Profile updates synchronization

### State Synchronization Flow
```
Supabase Auth → onAuthStateChange → authStore → localStorage
                                  ↓
                            React Query Cache
                                  ↓
                            UI Components
```

## 🛡️ MIDDLEWARE CHAIN

### Server Middleware Stack (Express)
```javascript
1. CORS → 2. JSON Parser → 3. Rate Limiting → 4. Request ID 
→ 5. Request Logging → 6. Auth Validation → 7. Route Handler 
→ 8. Error Handler
```

### Key Middleware Components

#### Authentication Middleware (`supabase-auth.ts`)
- **Token Source**: Only accepts `Authorization: Bearer <token>` header
- **Validation**: Verifies JWT with Supabase
- **User Lookup**: Fetches profile from database
- **Security**: No cookie/query param authentication (removed for security)

#### Rate Limiting
- General rate limit on all endpoints
- Brute force protection
- IP-based tracking

#### Error Handling
- Request ID tracking for debugging
- Centralized error response format
- Logging with correlation IDs

## 🚦 ROUTING & NAVIGATION

### Routing Architecture
- **Router**: Wouter v3 (NOT React Router)
- **Configuration**: Unified routes in `config/unified-routes.ts`
- **Lazy Loading**: All pages loaded on-demand
- **Auth Guards**: Route-level authentication checks

### Navigation Guards Flow
```
Route Request → RouteGuard Component
                    ↓
              Check Authentication
                    ↓
         [Authenticated?] → [Has Permission?]
              ↓                    ↓
           Redirect            Render Page
```

### Route Categories
1. **Public Routes**: Landing, pricing, auth pages
2. **Protected Routes**: Home, browse, watch (require auth)
3. **Premium Routes**: Premium content (require subscription)
4. **Admin Routes**: Admin dashboard (require admin role)

## 📊 DATA FLOW PATTERNS

### 1. **Initial Page Load**
```
App.tsx → RootProvider → AuthSyncWrapper → useAuthSync
           ↓                                    ↓
    QueryClientProvider              Supabase.getSession()
           ↓                                    ↓
     UnifiedRouter                      Update authStore
           ↓                                    ↓
      Route Guards                    localStorage token
           ↓
      Page Component → useQuery hooks → API/Supabase
```

### 2. **API Request Flow**
```
Component → useQuery/useMutation → apiService
                                        ↓
                              Add Authorization Header
                                        ↓
                                  Axios Instance
                                        ↓
                              Retry Logic (3 attempts)
                                        ↓
                            [Success] → Update Cache
                                ↓
                            [Error] → Toast/Redirect
```

### 3. **Real-time Updates**
```
Supabase Real-time → BroadcastChannel → All Tabs
                           ↓
                    Update authStore
                           ↓
                  Invalidate Queries
                           ↓
                    Re-render UI
```

## ⚡ PERFORMANCE OPTIMIZATIONS

### Caching Strategy
- **Query Cache**: 5-min stale time, 10-min cache time
- **Optimistic Updates**: Immediate UI updates
- **Prefetching**: Video details and recommendations
- **Background Sync**: Resume paused mutations on reconnect

### Loading States
- **Global Loading**: Overlay for major operations
- **Skeleton Loaders**: Individual component loading
- **Progressive Enhancement**: Show cached data while fetching
- **Suspense Boundaries**: Lazy loading with fallbacks

### Network Optimization
- **Offline Queue**: Queue mutations when offline
- **Network Detection**: Auto-retry on reconnect
- **Request Deduplication**: Prevent duplicate requests
- **Bundle Splitting**: Manual chunks for vendors

## 🚨 CRITICAL OBSERVATIONS

### Strengths ✅
1. **Robust Error Handling**: Multiple fallback layers
2. **Good State Management**: Clear separation of concerns
3. **Security**: Proper JWT validation, no insecure auth methods
4. **Performance**: Smart caching and prefetching strategies
5. **Cross-tab Sync**: BroadcastChannel for auth state

### Potential Issues ⚠️

#### 1. **Profile Creation Race Condition**
**Location**: `use-auth-sync.tsx:131-147`
**Issue**: Creates profile on sign-in if doesn't exist
**Risk**: Potential duplicate profile attempts

#### 2. **Token Storage Redundancy**
**Location**: Multiple places store auth token
- `supabase.ts:65`: localStorage.setItem('auth_token')
- `authStore.ts:108`: localStorage.setItem('auth_token')
- `use-auth-sync.tsx:51`: localStorage.setItem('auth_token')
**Risk**: Potential sync issues

#### 3. **Fallback API Pattern**
**Location**: `supabase-api.ts:96-100`
**Issue**: Falls back to API if Supabase fails
**Risk**: Inconsistent data sources

#### 4. **Missing Error Boundaries**
**Location**: Individual route components
**Issue**: No route-specific error boundaries
**Risk**: Full app crash on component errors

## 📋 RECOMMENDATIONS

### High Priority
1. **Consolidate Token Management**: Single source for auth token storage
2. **Add Route Error Boundaries**: Wrap each route in error boundary
3. **Fix Profile Race Condition**: Use upsert or check-then-create pattern
4. **Standardize Data Source**: Choose Supabase OR API, not both

### Medium Priority
1. **Add Request Cancellation**: Cancel in-flight requests on navigation
2. **Implement Data Preloading**: Prefetch next likely pages
3. **Add Loading Progress**: Show progress for long operations
4. **Cache Invalidation Strategy**: More granular cache updates

### Low Priority
1. **Add Performance Monitoring**: Track Core Web Vitals
2. **Implement Service Worker**: For offline support
3. **Add Request Compression**: Reduce payload sizes
4. **Optimize Bundle Size**: Code split more aggressively

## 🔍 BROWSING INTEGRITY

### Navigation Flow
```
User Action → Route Change → Auth Check → Load Data → Render
                    ↓             ↓           ↓         ↓
              Save Location   Redirect    Cache    Suspense
```

### Session Persistence
- **Auth State**: Persisted in localStorage via Zustand
- **Token Refresh**: Automatic on `TOKEN_REFRESHED` event
- **Cross-tab Sync**: BroadcastChannel for logout events
- **Recovery**: Re-authenticate on app mount

### Page Transitions
- **Lazy Loading**: All pages loaded on-demand
- **Loading States**: Skeleton loaders during fetch
- **Error Recovery**: Fallback UI for failures
- **Animation**: Framer Motion for smooth transitions

## 📈 METRICS & MONITORING

### Current Monitoring
- **Request IDs**: Correlation across logs
- **Timing Logs**: Request duration tracking
- **Error Tracking**: Sentry integration ready
- **Network Status**: Online/offline detection

### Missing Monitoring
- Real User Monitoring (RUM)
- API endpoint performance metrics
- Database query performance
- Cache hit/miss rates

## ✅ CONCLUSION

The MadifaStream application has a **solid architectural foundation** with good separation of concerns, robust error handling, and performance optimizations. The main areas for improvement are:

1. **Token management consolidation**
2. **Profile creation race condition fix**
3. **Route-level error boundaries**
4. **Standardized data source pattern**

Overall system health: **8/10** - Production-ready with minor improvements needed.