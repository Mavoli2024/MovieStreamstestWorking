#!/usr/bin/env node

/**
 * Replit Development Server
 * This server runs on port 5000 (as expected by .replit config) and serves the app
 * It's a temporary adaptation that doesn't break Vercel or local development
 */

import express from 'express';
import { createProxyMiddleware } from 'http-proxy-middleware';
import { spawn } from 'child_process';

const app = express();
const PORT = 5000;

console.log('🚀 Starting Replit development server...\n');

// Start Vite in background
console.log('📦 Starting Vite on port 5173...');
const viteProcess = spawn('npx', ['vite', '--host', '0.0.0.0', '--port', '5173'], {
  stdio: 'pipe',
  cwd: process.cwd()
});

viteProcess.stdout.on('data', (data) => {
  const output = data.toString();
  if (output.includes('ready')) {
    console.log('✅ Vite is ready!');
  }
});

viteProcess.stderr.on('data', (data) => {
  console.log('Vite:', data.toString().trim());
});

// Start backend server
setTimeout(() => {
  console.log('🖥️  Starting backend server on port 5001...');
  
  const backendProcess = spawn('npm', ['run', 'build:server'], {
    stdio: 'inherit',
    cwd: process.cwd()
  });
  
  backendProcess.on('close', (code) => {
    if (code === 0) {
      // Start the actual backend
      const backend = spawn('node', ['dist/server/server/server.js'], {
        stdio: 'pipe',
        env: {
          ...process.env,
          PORT: '5001',
          NODE_ENV: 'development'
        }
      });
      
      backend.stdout.on('data', (data) => {
        console.log('Backend:', data.toString().trim());
      });
      
      backend.stderr.on('data', (data) => {
        console.log('Backend Error:', data.toString().trim());
      });
    }
  });
}, 1000);

// Simple health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'Replit development server running',
    vite: 'http://localhost:5173',
    backend: 'http://localhost:5001'
  });
});

// Proxy to Vite with fallback
app.use('/', (req, res, next) => {
  // If Vite isn't ready yet, show a simple message
  const proxy = createProxyMiddleware({
    target: 'http://localhost:5173',
    changeOrigin: true,
    ws: true,
    onError: (err, req, res) => {
      res.status(502).send(`
        <html>
          <body>
            <h1>🚀 MadifaStream is Starting...</h1>
            <p>Vite development server is starting up. Please refresh in a moment.</p>
            <p><a href="javascript:location.reload()">Refresh Page</a></p>
          </body>
        </html>
      `);
    }
  });
  
  proxy(req, res, next);
});

// Start the proxy server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n✅ Replit development server running on port ${PORT}`);
  console.log(`   Frontend (Vite): http://localhost:5173`);
  console.log(`   Backend API: http://localhost:5001`);
  console.log(`   Replit Proxy: http://localhost:${PORT}\n`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n👋 Shutting down development servers...');
  viteProcess.kill();
  process.exit(0);
});