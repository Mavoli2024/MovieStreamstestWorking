# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

MadifaStream is a premium South African streaming platform built with React/TypeScript frontend and Express/PostgreSQL backend, deployed on Vercel. The project uses Supabase for auth/database, Bunny CDN for video streaming, and PayFast for payments.

## Essential Commands

### Development
```bash
npm run dev                      # Start frontend only (localhost:5173)
npm run dev:both                 # Start both frontend and backend concurrently
npm run dev:server:build         # Build server in watch mode
npm run dev:server:run           # Run server with auto-restart
npm run build                    # Build both client and server for production
npm run build:client             # Build frontend only (Vite)
npm run build:server             # Build backend only (TypeScript compilation)
npm start                        # Start production server (node dist/server/server/server.js)
npm run serve                    # Preview production build locally
npm run typecheck                # TypeScript type checking across project
npm run lint                     # ESLint check (currently disabled with placeholder message)
```

### Testing
```bash
npm run test                        # Run client tests (Vitest) - delegates to client/test:run
npm --prefix client run test:ui     # Interactive test UI with Vitest
npm --prefix client run test:run    # Run tests once (CI mode)
npm --prefix client run test:watch  # Run tests in watch mode
npm --prefix client run coverage    # Generate test coverage report
```

### Database & Sync
```bash
node scripts/sync-bunny-content.mjs     # Sync Bunny Stream content to database
node scripts/seed-categories.js         # Seed categories data
node scripts/setup-dev-user.js          # Create development user
node scripts/dev-setup.js               # Quick environment check (recommended before first run)
node scripts/cleanup-ports.js           # Clean up ports 5001, 5173-5175 before dev
```

### Production
```bash
npm run vercel-build     # Vercel deployment build
npm run preview          # Preview production build (port 4173)
```

### Mobile Development
```bash
npx cap sync            # Sync web changes to native platforms
npx cap open android    # Open Android project in Android Studio
npx cap open ios        # Open iOS project in Xcode
npx cap build android   # Build Android app
npx cap build ios       # Build iOS app (macOS only)
```

## Architecture Overview

### Frontend (`/client`)
- **Framework**: React 18 with TypeScript, built with Vite
- **Routing**: Wouter v3 (lightweight alternative to React Router) with lazy-loaded pages in `/client/src/pages`
- **State Management**: 
  - TanStack React Query for server state
  - Zustand for client state management
- **UI Components**: shadcn/ui (Radix UI + Tailwind) in `/client/src/components/ui`, organized by feature domain
- **Styling**: Tailwind CSS with custom design tokens
- **API Layer**: Centralized in `/client/src/lib/supabase-api.ts` with Supabase auth integration
- **Error Handling**: React Error Boundaries with Sentry integration in `/client/src/components/error-boundary`
- **Entry Point**: `/client/src/main.tsx` with enhanced React initialization and global error handling
- **Performance**: Web Vitals monitoring, code splitting, lazy loading
- **Build Output**: `dist/public` for static files

### Backend (`/server` & `/api`)
- **Hybrid Architecture**: NOT serverless-first - Express server with mirrored Vercel functions
- **Server Framework**: Express.js with TypeScript in `/server/server.ts`
- **API Routes**: Organized in `/server/routes` by feature, mirrored in `/api` for Vercel deployment
- **Database**: PostgreSQL via Supabase with Drizzle ORM
- **Schema**: Database schema defined in `/shared/schema.ts` with Zod validation
- **Authentication**: JWT-based Supabase Auth middleware in `/server/middleware/supabase-auth.ts`
- **Serverless Functions**: Vercel functions in `/api` directory (must mirror server routes)
- **Rate Limiting**: Express rate limiting middleware for API protection
- **Error Handling**: Centralized in `/server/middleware/error-handler.ts` with request IDs
- **Build Output**: `dist/server` for compiled TypeScript

### Key Integration Points
- **Video Streaming**: Bunny Stream API integration in `/server/services/bunnystream/`
- **Payment Processing**: PayFast webhooks and subscription management in `/server/routes/payfast.ts`
- **File Storage**: Supabase Storage for thumbnails, Bunny Stream for video hosting
- **Real-time Features**: Supabase real-time subscriptions for notifications
- **Mobile Apps**: Capacitor configuration for Android/iOS builds

## Database Architecture

The database uses Drizzle ORM with PostgreSQL via Supabase:
- **Core Tables**: `profiles` (linked to auth.users), `videos`, `categories`, `subscriptions`, `payment_transactions`, `subscription_plans`
- **Schema Location**: `/shared/schema.ts` - single source of truth with pgEnum definitions
- **Type Safety**: Drizzle-Zod integration with createInsertSchema/createSelectSchema for validation
- **Key Patterns**: 
  - `profiles.id` references Supabase `auth.users.id` for user data
  - Video content linked to Bunny Stream via URLs and metadata
  - Subscription status derived from subscriptions table, not stored in profiles
  - RLS policies enforce row-level security
- **Migrations**: Located in `/supabase/migrations/` with comprehensive RLS policies

## Critical Development Patterns

### Hybrid Architecture (NOT Serverless-First)
- **Current State**: Express server + Supabase, deployed on Vercel as hybrid solution
- **Server Routes**: Express routes in `/server/routes` for local development
- **Serverless Functions**: Mirrored implementations in `/api` directory for Vercel deployment
- **Route Mirroring**: Each server route MUST have corresponding `/api` function for production
- **Important**: This is NOT a serverless-first architecture - maintain both Express and serverless implementations

### Single Source of Truth (SSOT) Principles
- **Database Schema**: Single source in `/shared/schema.ts` with Drizzle ORM and Zod validation
- **Type Definitions**: Shared between client/server for consistency
- **User Profiles**: Derived from `profiles` table linked to `auth.users`, not duplicated
- **Subscription Status**: Calculated from `subscriptions` table, not stored in profiles
- **Environment Config**: Validated centrally in server configuration

### Error Handling Strategy
- **Server**: Centralized error handling in `/server/middleware/error-handler.ts` with request IDs
- **Client**: Layered error boundaries in `/client/src/components/error-boundary` for different error types
- **Production**: Sentry integration for error tracking and monitoring
- **API Responses**: Consistent error format with status codes and messages

### Authentication Flow
- **Supabase Auth**: Primary authentication provider
- **JWT Tokens**: Used for API authorization
- **Token Storage**: Access tokens stored in localStorage as 'auth_token'
- **Protected Routes**: Middleware validates Bearer tokens in Authorization headers
- **Session Management**: Automatic refresh with Supabase client

### API Integration Patterns
- **Supabase**: Direct client integration via `supabase-api.ts` for auth and real-time features
- **Bunny Stream**: Server-side API calls via `/server/services/bunnystream` for video operations
- **PayFast**: Webhook verification and signature validation in payment routes
- **Error Recovery**: Retry logic with exponential backoff for external APIs

### Type Safety Architecture
- **Shared Types**: Database schema and validation in `/shared/schema.ts`
- **Client Types**: Auto-generated from Supabase in `/client/src/types/database.types.ts`
- **API Validation**: Zod schemas for request/response validation throughout
- **TypeScript Config**: Separate configs for client/server with strict mode

## Development Workflow

### Adding New Features
1. Update database schema in `/shared/schema.ts` if needed
2. Create migration in `/supabase/migrations/` if database changes
3. Create API route in `/server/routes` and corresponding `/api` function
4. Add frontend components in `/client/src/components` organized by feature
5. Create page component in `/client/src/pages` if needed
6. Update routing in `/client/src/main.tsx`
7. Add tests for new functionality
8. Update environment variables if needed

### Code Organization
- **Shared Code**: Common types and utilities in `/shared`
- **Client Structure**: Components organized by domain (auth, video, admin, etc.)
- **Server Structure**: Routes and services organized by feature
- **Configuration**: Vite config, TypeScript configs for client/server separation
- **Scripts**: Build and maintenance scripts in `/scripts`

### Testing Strategy
- **Unit Tests**: Vitest with React Testing Library for components
- **Test Configuration**: `client/vitest.config.ts` with jsdom environment
- **Test Setup**: Comprehensive mocks in `client/src/test/setup.ts`
- **E2E Tests**: Playwright for critical user flows in `/tests/e2e`
- **Coverage**: HTML, JSON, and text reporters with config exclusions

## Environment Configuration

### Required Server Environment Variables
```bash
# Supabase (MANDATORY)
SUPABASE_URL=your_supabase_project_url
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

# Database (MANDATORY - server fails without this)
DATABASE_URL=postgres://user:password@host:5432/dbname?sslmode=require

# Application URLs
FRONTEND_URL=http://localhost:5173
BACKEND_URL=http://localhost:5001
PORT=5001

# Bunny Stream (Required for video features)
BUNNY_API_KEY=your_bunny_api_key
BUNNY_LIBRARY_ID=your_library_id
BUNNY_STREAM_LIBRARY_ID=your_stream_library_id
BUNNY_TOKEN_SECRET=your_token_secret
BUNNY_CDN_HOSTNAME=your_cdn_hostname

# PayFast (Required for payments)
PAYFAST_MERCHANT_ID=your_merchant_id
PAYFAST_MERCHANT_KEY=your_merchant_key
PAYFAST_PASSPHRASE=your_passphrase
PAYFAST_ITN_URL=https://yourdomain.com/api/payfast/itn-webhook
```

### Required Client Environment Variables (VITE_ prefix mandatory)
```bash
# Supabase (Client)
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_anon_key

# Application
VITE_SITE_URL=http://localhost:5173

# Bunny Stream (Client)
VITE_BUNNY_STREAM_LIBRARY_ID=your_stream_library_id
VITE_BUNNY_CDN_HOSTNAME=your_cdn_hostname
```

## Code Quality Standards

The project enforces strict ESLint rules defined in `eslint.config.js`:
- **TypeScript**: No explicit `any`, consistent imports, strict type checking
- **Console Statements**: Prohibited in production code (use logger utilities instead)
- **React**: Strict hooks rules and React 18 patterns
- **Security**: No eval, implied eval, or dynamic function creation
- **Performance**: Warnings for async/await in loops and promise patterns
- **Code Style**: Prefer const, no var, no duplicate imports, consistent formatting
- **Testing**: Console statements allowed only in test files

## Deployment Configuration

### Vercel Deployment
- **Platform**: Vercel with automatic deployments from main branch
- **Build Command**: `npm run vercel-build` (builds client for static deployment)
- **Output Directory**: `dist/public` for static files
- **API Routes**: Serverless functions in `/api` directory
- **Environment**: Set all required variables in Vercel dashboard
- **CORS**: Configured for `madifa.co.za` and `madifa-stream.vercel.app`

### Vercel Configuration (`vercel.json`)
- API routes handled by catch-all function `api/[[...route]].js`
- Static files served with filesystem handler
- SPA routing with catch-all to `/index.html`
- Serverless functions with default timeout

### Mobile Deployment
- **Platform**: Capacitor for iOS/Android
- **App ID**: `co.za.madifa.app`
- **Build Output**: `dist/public` for mobile compilation
- **Sync Command**: `npx cap sync` after web build

## Common Issues & Solutions

### Authentication Issues
- **Problem**: 401 errors on protected endpoints
- **Solution**: Ensure Authorization header includes Bearer token from localStorage 'auth_token'

### Environment Variable Issues
- **Problem**: Missing VITE_ prefix for client variables
- **Solution**: All client env vars must start with VITE_ for Vite to inject them

### Database Connection Issues
- **Problem**: Server fails to start without DATABASE_URL
- **Solution**: Ensure DATABASE_URL is set in environment with proper SSL mode

### Build Issues
- **Problem**: Vercel build fails
- **Solution**: Check that all dependencies are in package.json, not devDependencies

### CORS Issues
- **Problem**: Cross-origin requests blocked
- **Solution**: Verify CORS configuration includes your domain in server middleware

### Port Conflicts
- **Problem**: Development servers fail to start
- **Solution**: Run `node scripts/cleanup-ports.js` to free ports 5001, 5173-5175

## Validation Commands

After making changes, validate your setup:

```bash
# 1. Type checking
npm run typecheck

# 2. Build verification
npm run build
ls dist/server/server/server.js  # Should exist
ls dist/public/index.html  # Should exist

# 3. API health check
curl http://localhost:5001/api/health

# 4. Auth verification (replace <token> with actual JWT)
curl -H "Authorization: Bearer <token>" http://localhost:5001/api/auth/session

# 5. Test suite
npm run test
```

## Security Considerations

- **Never commit**: API keys, tokens, or secrets to the repository
- **Use environment variables**: For all sensitive configuration
- **Validate inputs**: Use Zod schemas for all API inputs
- **Sanitize outputs**: Prevent XSS by sanitizing user content
- **Rate limiting**: Applied to all API endpoints
- **CORS**: Strictly configured for production domains only
- **RLS policies**: Database-level security with Supabase RLS

## Performance Optimization

- **Code splitting**: Lazy load routes and heavy components
- **Image optimization**: Use Bunny CDN for video thumbnails
- **Bundle size**: Monitor with `npm run build` output
- **Caching**: Implement proper cache headers for static assets
- **Database queries**: Use indexes and optimize N+1 queries
- **API responses**: Paginate large datasets
- **Web Vitals**: Monitor CLS, FID, and LCP metrics
- **Vite optimizations**: Pre-bundled dependencies in `optimizeDeps` config