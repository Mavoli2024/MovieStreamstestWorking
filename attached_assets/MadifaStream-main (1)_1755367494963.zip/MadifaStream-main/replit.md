# MadifaStream - Replit.md

## Overview

MadifaStream is a premium South African streaming platform built with modern web technologies. It's a full-stack application featuring video streaming, user management, subscription handling, and content management capabilities. The application is designed to provide authentic South African content with a focus on performance, scalability, and user experience.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized production builds
- **Routing**: Wouter (lightweight alternative to React Router)
- **State Management**: TanStack React Query for server state management
- **UI Library**: Radix UI primitives with shadcn/ui components
- **Styling**: Tailwind CSS with custom design system
- **Video Player**: HLS.js for adaptive streaming
- **Mobile Support**: Capacitor for native mobile app capabilities

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript for type safety
- **Database**: PostgreSQL via Supabase
- **ORM**: Drizzle ORM for database operations
- **Authentication**: Supabase Auth with social login support
- **File Storage**: Supabase Storage for user-generated content
- **Video CDN**: Bunny CDN for video streaming and delivery

### Database Design
- **Users & Profiles**: User authentication and profile management
- **Videos**: Content metadata with categorization and ratings
- **Subscriptions**: PayFast integration for R59/month premium plans
- **Watch Progress**: User viewing history and progress tracking
- **Categories**: Content organization and filtering
- **Ratings**: User feedback and content scoring

## Key Components

### Authentication System
- Email/password authentication via Supabase Auth
- Google OAuth integration
- Session management with automatic token refresh
- Role-based access control (user, admin)

### Video Streaming
- HLS adaptive streaming through Bunny CDN
- Multiple resolution support (SD, HD)
- Offline download capabilities for premium users
- Progress tracking and resume functionality

### Payment Integration
- PayFast payment gateway for South African market
- Subscription management with automatic renewals
- Free tier with limited content access
- Premium tier (R59/month) with full library access

### Content Management
- Admin dashboard for content upload and management
- Video encoding and transcoding pipeline
- Category-based content organization
- Featured content and trending algorithms

### Performance Optimizations
- Code splitting and lazy loading
- Bundle optimization with strategic chunking
- Icon optimization system to reduce bundle size
- Lighthouse performance monitoring
- Service worker for offline capabilities

## Data Flow

1. **User Registration/Login**: Supabase Auth handles authentication and creates user profiles
2. **Content Discovery**: API endpoints serve video metadata with filtering and search
3. **Video Playback**: Bunny CDN delivers video streams with progress tracking
4. **Subscription Flow**: PayFast handles payments and updates user subscription status
5. **Content Management**: Admin users can upload and manage video content through the dashboard

## External Dependencies

### Core Services
- **Supabase**: Database, authentication, and file storage
- **Bunny CDN**: Video streaming and content delivery
- **PayFast**: Payment processing for South African market
- **Vercel**: Production deployment and hosting

### Development Tools
- **Vite**: Build tool and development server
- **TypeScript**: Type safety and development experience
- **Tailwind CSS**: Styling framework
- **Jest**: Unit testing framework
- **Playwright**: End-to-end testing

## Deployment Strategy

### Development Environment
- Frontend: Vite dev server on port 5173
- Backend: Express server on port 5001
- Database: Supabase cloud instance
- Port cleanup scripts for clean development starts

### Production Deployment
- **Platform**: Vercel for frontend and API routes
- **Build Process**: Vite builds static assets to `dist/public`
- **API Routes**: Serverless functions in `api/` directory
- **Environment Variables**: All secrets managed through Vercel environment variables
- **Performance**: Lighthouse CI for continuous performance monitoring

### Mobile Deployment
- **Capacitor**: Native mobile app builds for iOS and Android
- **Web App**: Progressive Web App capabilities for mobile web
- **Offline Support**: Service worker for offline functionality

### Security Considerations
- All API keys and secrets stored as environment variables
- Row Level Security (RLS) policies in Supabase
- CORS configuration for API endpoints
- Input validation and sanitization
- Rate limiting for API endpoints

### Performance Monitoring
- Lighthouse CI for automated performance audits
- Bundle size monitoring and optimization
- Web Vitals tracking
- Error tracking and reporting

The application follows modern web development best practices with a focus on performance, security, and user experience. It's designed to scale with growing user base and content library while maintaining excellent performance metrics.