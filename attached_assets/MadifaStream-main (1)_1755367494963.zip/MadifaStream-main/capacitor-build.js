/**
 * Madifa Capacitor Build Script
 * This script helps manage the build process for mobile applications
 */
import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  red: '\x1b[31m',
  cyan: '\x1b[36m'
};

// Helper to log with colors
function log(message, type = 'info') {
  const timestamp = new Date().toLocaleTimeString();
  let color = colors.reset;
  
  switch (type) {
    case 'success':
      color = colors.green;
      break;
    case 'warning':
      color = colors.yellow;
      break;
    case 'error':
      color = colors.red;
      break;
    case 'info':
      color = colors.cyan;
      break;
  }
  
  console.log(`${colors.bright}[${timestamp}]${colors.reset} ${color}${message}${colors.reset}`);
}

// Execute a command and return the output
function executeCommand(command, silent = false) {
  try {
    if (!silent) log(`Executing: ${command}`);
    return execSync(command, { stdio: silent ? 'pipe' : 'inherit' });
  } catch (error) {
    log(`Error executing command: ${command}`, 'error');
    log(error.message, 'error');
    if (!silent) process.exit(1);
    return null;
  }
}

// Check if Capacitor has been initialized
function isCapacitorInitialized() {
  return fs.existsSync('capacitor.config.ts') || fs.existsSync('capacitor.config.js');
}

// Build the web app
function buildWebApp() {
  log('Building web application...', 'info');
  executeCommand('npm run build');
  log('Web build completed successfully!', 'success');
}

// Add native platforms
function addPlatform(platform) {
  if (!['android', 'ios'].includes(platform)) {
    log(`Invalid platform: ${platform}. Must be 'android' or 'ios'.`, 'error');
    return;
  }
  
  log(`Adding ${platform} platform...`, 'info');
  executeCommand(`npx cap add ${platform}`);
  log(`${platform} platform added successfully!`, 'success');
}

// Copy web assets to native projects
function copyAssets() {
  log('Copying web assets to native projects...', 'info');
  executeCommand('npx cap copy');
  log('Assets copied successfully!', 'success');
}

// Sync web code with native projects
function syncNative() {
  log('Syncing web code with native projects...', 'info');
  executeCommand('npx cap sync');
  log('Sync completed successfully!', 'success');
}

// Open native IDE
function openNative(platform) {
  if (!['android', 'ios'].includes(platform)) {
    log(`Invalid platform: ${platform}. Must be 'android' or 'ios'.`, 'error');
    return;
  }
  
  log(`Opening ${platform} project in native IDE...`, 'info');
  executeCommand(`npx cap open ${platform}`);
}

// Main function to process command line arguments
function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  if (!isCapacitorInitialized()) {
    log('Capacitor has not been initialized yet. Run "npx cap init" first.', 'error');
    process.exit(1);
  }
  
  switch (command) {
    case 'build':
      buildWebApp();
      copyAssets();
      syncNative();
      break;
    
    case 'add':
      const platform = args[1];
      addPlatform(platform);
      break;
    
    case 'copy':
      copyAssets();
      break;
    
    case 'sync':
      syncNative();
      break;
    
    case 'open':
      const platformToOpen = args[1];
      openNative(platformToOpen);
      break;
    
    case 'full':
      buildWebApp();
      
      // Add platforms if they don't exist
      if (!fs.existsSync('android')) {
        addPlatform('android');
      }
      
      if (!fs.existsSync('ios') && process.platform === 'darwin') {
        addPlatform('ios');
      }
      
      syncNative();
      break;
    
    default:
      log('Usage:', 'info');
      log('  node capacitor-build.js build  - Build web app and copy to native', 'info');
      log('  node capacitor-build.js add [android|ios] - Add platform', 'info');
      log('  node capacitor-build.js copy - Copy web assets to native', 'info');
      log('  node capacitor-build.js sync - Sync web code with native', 'info');
      log('  node capacitor-build.js open [android|ios] - Open in native IDE', 'info');
      log('  node capacitor-build.js full - Full build process', 'info');
      break;
  }
}

// Run the script
main();