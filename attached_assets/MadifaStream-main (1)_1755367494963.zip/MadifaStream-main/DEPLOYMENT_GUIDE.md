# MadifaStream Production Deployment Guide

This guide provides the steps to securely deploy the MadifaStream application to a production environment on Vercel. This follows a comprehensive cleanup and security review of the project.

## Phase 1: Code & File Cleanup (Complete)

The project has undergone a significant cleanup:
- **Scripts Organized:** All single-use and test scripts from the root directory have been moved to `scripts/cleanup/`.
- **Temporary Files Removed:** Test artifacts, logs, and other temporary files have been deleted.
- **Documentation Archived:** Old and non-essential markdown files have been moved to `docs/archive/`. `README.md` and `DEVELOPER_GUIDE.md` remain in the root.

## Phase 2: Configuration & Security (Complete)

Key configuration files have been reviewed and updated for production:
- **Secrets Removed:** Hardcoded API keys and other secrets have been removed from the codebase.
- **Environment Variables:** All secrets are now managed through `server/.env`. This file is ignored by Git.
- **Vercel & Playwright Configured:** `vercel.json` and `playwright.config.ts` have been updated to follow best practices for production deployments.

---

## 🚨 CRITICAL: Rotate Leaked API Keys

**This is the most important step.** Before you deploy, you must rotate all API keys that were previously exposed in the code.

1.  **Supabase:**
    *   Go to your Supabase Project > Settings > API.
    *   Under **Project API keys**, find your `anon` and `service_role` keys.
    *   Click "Change key" for both. This will invalidate the old keys.
2.  **Bunny.net:**
    *   Log in to your Bunny.net dashboard.
    *   Navigate to your Stream Library settings.
    *   Generate a new **API Key** and a new **Security Key** (for token authentication).
3.  **Resend:**
    *   Go to your Resend Dashboard > API Keys.
    *   Create a new API key and delete the old one.

## Production Deployment Steps

Your project is configured for automatic deployments to Vercel via the official GitHub integration.

### 1. Set Production Environment Variables

In your Vercel project dashboard, navigate to **Settings > Environment Variables** and add the following keys with their new, rotated values:

| Variable Name                 | Description                                    |
| ----------------------------- | ---------------------------------------------- |
| `SUPABASE_URL`                | Your Supabase project URL.                     |
| `SUPABASE_ANON_KEY`           | Your new, rotated Supabase `anon` key.         |
| `SUPABASE_SERVICE_ROLE_KEY`   | Your new, rotated Supabase `service_role` key. |
| `DATABASE_URL`                | Your Supabase database connection string.      |
| `BUNNY_API_KEY`               | Your new, rotated Bunny.net API key.           |
| `BUNNY_STREAM_LIBRARY_ID`     | Your Bunny.net Stream Library ID.              |
| `BUNNY_STREAM_SECURITY_KEY`   | Your new, rotated Bunny.net Stream Security Key. |
| `PAYFAST_MERCHANT_ID`         | Your PayFast Merchant ID.                      |
| `PAYFAST_MERCHANT_KEY`        | Your PayFast Merchant Key.                     |
| `PAYFAST_PASSPHRASE`          | Your PayFast passphrase.                       |
| `RESEND_API_KEY`              | Your new, rotated Resend API key.              |
| `PLAYWRIGHT_BASE_URL`         | The production URL of your application.        |

### 2. Deploy the Application

Because you have the Vercel GitHub integration set up, deployment is automatic:

1.  **Commit and Push:** Commit all the changes we've made to your `main` branch and push them to GitHub.
    ```bash
    git add .
    git commit -m "feat: production cleanup and security hardening"
    git push origin main
    ```
2.  **Monitor Deployment:** Vercel will automatically detect the push and start a new deployment. You can monitor the progress in your Vercel dashboard.

### 3. Post-Deployment Checks

Once the deployment is complete, perform these checks:

-   **Visit the URL:** Ensure your application loads correctly at its production URL.
-   **Test Core Features:** Manually test key user flows like registration, login, and video browsing.
-   **Check API Health:** Visit `https://<your-production-url>/api/health` to confirm the backend is running.

---

## Next Steps & Recommendations

-   **Restore Test Files (Optional):** Some test scripts were deleted due to tooling issues. If you need them, you can restore `functional-auth-test.mjs`, `investigate-video-playback.mjs`, and others from your Git history and move them to the `scripts/cleanup` directory.
-   **Address `npm audit`:** There are several vulnerabilities reported by `npm audit`. It's recommended to address these by running `npm audit fix`.
-   **Review CI/CD:** Your `vercel-deploy.yml` runs the build but doesn't handle the Playwright tests. Consider adding a step to your CI/CD pipeline to run the E2E tests against a preview or production environment to catch regressions automatically.

This completes the deployment preparation. Your application is now in a much more secure and maintainable state, ready for production. 