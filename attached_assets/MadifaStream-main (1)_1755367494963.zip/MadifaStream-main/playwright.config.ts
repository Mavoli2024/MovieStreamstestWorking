import { defineConfig, devices } from '@playwright/test';
import path from 'path';

export default defineConfig({
  // Look for test files in the "tests" directory, relative to this configuration file.
  testDir: './tests/e2e',

  // General timeout for each test
  timeout: 60 * 1000, // 60 seconds

  // Expectations timeout
  expect: {
    timeout: 10 * 1000, // 10 seconds
  },

  // Shared settings for all the projects below.
  use: {
    // Base URL to use in actions like `await page.goto('/')`.
    baseURL: 'http://localhost:5173',

    // Action timeout for individual actions like click() or fill()
    actionTimeout: 15 * 1000, // 15 seconds

    // Collect trace when retrying the failed test.
    trace: 'on-first-retry',
  },

  // Configure projects for major browsers.
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
  ],

  // Run your local dev server before starting the tests.
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:5173',
    reuseExistingServer: true,
    timeout: 120 * 1000, // 2 minutes
  },
}); 