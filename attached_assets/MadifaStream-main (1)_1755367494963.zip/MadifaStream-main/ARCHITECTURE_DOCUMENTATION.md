# MadifaStream - Complete Architecture Documentation

## 🏗️ System Overview

MadifaStream is a professional video streaming platform built with modern web technologies, designed for scalability, performance, and user experience. This documentation provides a complete reference to prevent architectural issues and maintain consistency.

## 📋 Table of Contents

1. [Technology Stack](#technology-stack)
2. [Project Structure](#project-structure)
3. [Backend Architecture](#backend-architecture)
4. [Frontend Architecture](#frontend-architecture)
5. [Database Schema](#database-schema)
6. [API Architecture](#api-architecture)
7. [Authentication & Authorization](#authentication--authorization)
8. [Payment Integration](#payment-integration)
9. [Video Streaming](#video-streaming)
10. [Deployment Architecture](#deployment-architecture)
11. [Common Issues & Solutions](#common-issues--solutions)
12. [Best Practices](#best-practices)
13. [Troubleshooting Guide](#troubleshooting-guide)

---

## 🛠️ Technology Stack

### Backend
- **Runtime**: Node.js 18+
- **Framework**: Express.js
- **Language**: TypeScript
- **Database**: PostgreSQL (via Supabase)
- **ORM**: Drizzle ORM
- **Authentication**: Supabase Auth
- **File Storage**: Supabase Storage
- **CDN**: Bunny CDN
- **Payment**: PayFast (South African)
- **Email**: Supabase Auth (built-in)

### Frontend
- **Framework**: React 18
- **Language**: TypeScript
- **Build Tool**: Vite
- **Routing**: Wouter
- **State Management**: TanStack Query (React Query)
- **Styling**: Tailwind CSS
- **UI Components**: Radix UI + shadcn/ui
- **Forms**: React Hook Form + Zod
- **Video Player**: HLS.js
- **Animations**: Framer Motion

### Development & Deployment
- **Package Manager**: npm
- **Development**: Concurrently (frontend + backend)
- **Testing**: Jest + Playwright
- **Deployment**: Vercel (frontend + API routes)
- **CI/CD**: GitHub Actions
- **Monitoring**: Supabase Dashboard

---

## 📁 Project Structure

```
MadifaStream/
├── client/                     # Frontend React application
│   ├── src/
│   │   ├── components/         # Reusable UI components
│   │   │   ├── ui/            # Base UI components (shadcn/ui)
│   │   │   ├── auth/          # Authentication components
│   │   │   ├── video/         # Video-related components
│   │   │   ├── admin/         # Admin panel components
│   │   │   └── layouts/       # Layout components
│   │   ├── hooks/             # Custom React hooks
│   │   ├── lib/               # Utility functions
│   │   ├── pages/             # Route components
│   │   ├── services/          # API services
│   │   ├── types/             # TypeScript definitions
│   │   └── styles/            # Global styles
│   ├── public/                # Static assets
│   └── vite.config.ts         # Vite configuration
├── server/                     # Backend Express server
│   ├── routes/                # API route handlers
│   ├── middleware/            # Express middleware
│   ├── services/              # Business logic
│   ├── config/                # Configuration files
│   ├── utils/                 # Utility functions
│   └── server.ts              # Server entry point
├── shared/                     # Shared code (frontend + backend)
│   ├── schema.ts              # Database schema (Drizzle)
│   ├── logger.ts              # Logging utilities
│   └── constants/             # Shared constants
├── api/                        # Vercel API routes (production)
├── supabase/                   # Supabase configuration
│   ├── migrations/            # Database migrations
│   └── functions/             # Edge functions
├── scripts/                    # Development scripts
├── tests/                      # Test files
└── docs/                       # Documentation
```

---

## 🔧 Backend Architecture

### Core Components

#### 1. Server Configuration (`server/server.ts`)
```typescript
// Key features:
- Environment validation
- CORS configuration
- Rate limiting
- Authentication middleware
- Error handling
- Request logging
- API route mounting
```

#### 2. Route Architecture (`server/routes/`)
```typescript
// Centralized routing system:
server/routes/index.ts          # Route aggregator
server/routes/videos.ts         # Video management
server/routes/auth.ts           # Authentication
server/routes/payfast.ts        # Payment processing
server/routes/subscriptions.ts  # Subscription management
server/routes/health.ts         # Health checks
```

#### 3. Middleware Stack
```typescript
// Applied in order:
1. Environment validation
2. CORS configuration
3. Rate limiting
4. Request ID tracking
5. Request logging
6. Authentication (selective)
7. Route handlers
8. Error handling
```

#### 4. Database Integration
```typescript
// Supabase + Drizzle ORM:
- Connection: Supabase PostgreSQL
- Schema: shared/schema.ts
- Migrations: supabase/migrations/
- Types: Auto-generated from schema
```

### Critical Fixes Applied

#### Issue 1: Conflicting Video Routes
**Problem**: Multiple endpoints handling video requests with different ID formats
```typescript
// ❌ WRONG - Had conflicts:
/server/routes/videos.ts        # Expected UUID strings
/server/api/content-routes.ts   # Expected integer IDs
```

**Solution**: Removed conflicting routes, standardized on UUID format
```typescript
// ✅ CORRECT - Single source of truth:
/server/routes/videos.ts        # UUID format only
router.get('/:id', getVideoById) # Handles UUID strings
```

#### Issue 2: Incorrect Supabase Queries
**Problem**: Using wrong query syntax
```typescript
// ❌ WRONG:
.then(results => results[0])

// ✅ CORRECT:
.single()
```

#### Issue 3: Missing Route Registration
**Problem**: Routes defined but not registered in main router
```typescript
// ✅ SOLUTION in server/routes/index.ts:
export function createApiRouter() {
  const router = express.Router();
  router.use('/videos', videoRoutes);
  router.use('/auth', authRoutes);
  // ... all routes properly mounted
  return router;
}
```

---

## 🎨 Frontend Architecture

### Core Components

#### 1. Application Entry (`client/src/App.tsx`)
```typescript
// Production routing structure:
- Landing page (/)
- Authentication (/auth)
- Browse content (/browse)
- Video player (/watch/:id)
- User profile (/profile)
- Admin panel (/admin)
- Subscription management (/subscription)
- Payment flows (/payment/*)
- 404 handling (*)
```

#### 2. State Management
```typescript
// TanStack Query for server state:
- Caching with 5-minute stale time
- Automatic retry on failure
- Background refetching disabled
- Optimistic updates for mutations
```

#### 3. Authentication Flow
```typescript
// Supabase Auth integration:
1. Login/Register via AuthPage
2. Token stored in localStorage
3. Protected routes check authentication
4. Automatic token refresh
5. User context via AuthProvider
```

#### 4. Component Architecture
```typescript
// Hierarchical structure:
Pages/                 # Route components
├── Layouts/          # Page layouts
├── Components/       # Feature components
├── UI/              # Base UI components
└── Hooks/           # Custom hooks
```

### Critical Fixes Applied

#### Issue 1: Missing Authentication Routes
**Problem**: Routes defined in routes.tsx but not used in App.tsx
```typescript
// ❌ WRONG - App.tsx had inline routing only
<Route path="/auth" /> // Missing!

// ✅ CORRECT - All routes properly defined:
<Route path="/auth">
  {() => {
    const AuthPage = React.lazy(() => import('@/pages/auth-page'));
    return (
      <Suspense fallback={<LoadingSpinner message="Loading Auth..." />}>
        <AuthPage />
      </Suspense>
    );
  }}
</Route>
```

#### Issue 2: Test Components in Production
**Problem**: TestPage and TestVideosPage components in App.tsx
```typescript
// ❌ WRONG - Test components:
const TestPage = () => (/* test content */);
const TestVideosPage = () => (/* test content */);

// ✅ CORRECT - Real components:
const LandingPage = React.lazy(() => import('@/pages/landing-page'));
```

---

## 🗄️ Database Schema

### Core Tables

#### Videos Table
```sql
videos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title VARCHAR NOT NULL,
  description TEXT,
  video_url VARCHAR,
  thumbnail_url VARCHAR,
  duration_minutes INTEGER,
  release_year INTEGER,
  genres TEXT[],
  is_premium BOOLEAN DEFAULT false,
  is_trailer BOOLEAN DEFAULT false,
  view_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
)
```

#### User Profiles Table
```sql
profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id),
  username VARCHAR UNIQUE,
  full_name VARCHAR,
  avatar_url VARCHAR,
  subscription_status VARCHAR DEFAULT 'free',
  subscription_expires_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
)
```

#### Subscriptions Table
```sql
subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES profiles(id),
  plan_id VARCHAR NOT NULL,
  status VARCHAR DEFAULT 'active',
  current_period_start TIMESTAMP,
  current_period_end TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
)
```

### Key Relationships
- Users → Profiles (1:1)
- Users → Subscriptions (1:many)
- Users → Watchlist (many:many via junction table)
- Videos → Categories (many:many)

---

## 🔌 API Architecture

### Endpoint Structure

#### Public Endpoints (No Authentication)
```typescript
GET  /api/health              # Health check
GET  /api/videos/public       # Public video list
GET  /api/content/featured    # Featured content
GET  /api/content/categories  # Content categories
POST /api/payfast/itn-webhook # Payment webhooks
```

#### Protected Endpoints (Authentication Required)
```typescript
GET    /api/videos           # All videos
GET    /api/videos/:id       # Single video
GET    /api/user/profile     # User profile
POST   /api/user/watchlist   # Add to watchlist
DELETE /api/user/watchlist   # Remove from watchlist
POST   /api/payfast/initiate-payment # Start payment
```

#### Admin Endpoints (Admin Role Required)
```typescript
GET  /api/admin/users        # User management
GET  /api/admin/analytics    # Analytics data
POST /api/admin/sync         # Content sync
```

### Response Format
```typescript
// Success Response:
{
  "success": true,
  "data": { /* response data */ },
  "timestamp": "2024-01-01T00:00:00Z"
}

// Error Response:
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human readable message",
    "type": "error_type",
    "details": { /* additional details */ }
  }
}
```

---

## 🔐 Authentication & Authorization

### Authentication Flow

#### 1. User Registration
```typescript
1. User fills registration form
2. Form validated with Zod schema
3. Supabase Auth creates user
4. Profile created in profiles table
5. JWT token returned
6. User redirected to dashboard
```

#### 2. User Login
```typescript
1. User submits credentials
2. Supabase Auth validates
3. JWT token returned and stored
4. User context updated
5. Protected routes accessible
```

#### 3. Token Management
```typescript
// Automatic token refresh:
- Supabase handles refresh automatically
- Tokens stored in localStorage
- Expired tokens trigger re-authentication
- Logout clears all tokens
```

### Authorization Levels

#### 1. Public Access
- Landing page
- Video trailers
- Content browsing (limited)

#### 2. Authenticated User
- Full video library
- Personal watchlist
- Profile management
- Free content streaming

#### 3. Premium Subscriber
- Premium content access
- HD streaming
- Download capabilities
- Ad-free experience

#### 4. Admin User
- User management
- Content management
- Analytics dashboard
- System configuration

---

## 💳 Payment Integration

### PayFast Integration

#### 1. Payment Flow
```typescript
1. User selects subscription plan
2. Payment form generated with signature
3. User redirected to PayFast
4. PayFast processes payment
5. ITN webhook received
6. Subscription status updated
7. User redirected to success page
```

#### 2. Signature Generation
```typescript
// PayFast signature requirements:
function generatePayFastSignature(data, passphrase) {
  const queryString = Object.keys(data)
    .sort()
    .map(key => `${key}=${encodeURIComponent(data[key])}`)
    .join('&');
  
  const signatureString = `${queryString}&passphrase=${passphrase}`;
  return crypto.createHash('md5').update(signatureString).digest('hex');
}
```

#### 3. Webhook Handling
```typescript
// ITN webhook processing:
POST /api/payfast/itn-webhook
- Verify signature
- Update subscription status
- Send confirmation email
- Log transaction
```

### Subscription Management

#### 1. Plans Available
```typescript
const plans = {
  '1': { name: 'Free Plan', price: '0.00' },
  '2': { name: 'Premium Plan', price: '59.00' }
};
```

#### 2. Status Tracking
```typescript
// Subscription statuses:
- 'free': Default status
- 'active': Paid subscription active
- 'expired': Subscription expired
- 'cancelled': User cancelled
- 'suspended': Payment failed
```

---

## 📺 Video Streaming

### Bunny CDN Integration

#### 1. Video Storage
```typescript
// Bunny CDN configuration:
- Library ID: Process.env.BUNNY_LIBRARY_ID
- Stream Library: Process.env.BUNNY_STREAM_LIBRARY_ID
- CDN Hostname: vz-685277f9-aa1.b-cdn.net
- API Key: Process.env.BUNNY_API_KEY
```

#### 2. Video Delivery
```typescript
// Adaptive bitrate streaming:
- HLS format for compatibility
- Multiple quality levels
- Automatic quality switching
- Mobile optimization
```

#### 3. Thumbnail Generation
```typescript
// Automatic thumbnail creation:
- Generated on video upload
- Multiple sizes available
- Optimized for different devices
- Cached for performance
```

### Video Player Implementation

#### 1. HLS.js Integration
```typescript
// Video player features:
- Adaptive bitrate streaming
- Subtitle support
- Playback speed control
- Fullscreen support
- Mobile touch controls
```

#### 2. Premium Content Protection
```typescript
// Access control:
- JWT token validation
- Subscription status check
- Signed URL generation
- Time-limited access
```

---

## 🚀 Deployment Architecture

### Vercel Deployment

#### 1. Frontend Deployment
```typescript
// Automatic deployment:
- Git push triggers build
- Vite builds static assets
- Assets deployed to CDN
- Environment variables configured
```

#### 2. API Routes
```typescript
// Serverless functions:
api/index.js           # Main API handler
api/health.js          # Health check
api/[...path].js       # Catch-all handler
```

#### 3. Environment Configuration
```typescript
// Production environment variables:
SUPABASE_URL=https://project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJ...
FRONTEND_URL=https://madifa.vercel.app
BUNNY_API_KEY=...
PAYFAST_MERCHANT_ID=...
```

### Development Environment

#### 1. Local Development
```bash
# Start development servers:
npm run dev                 # Both frontend and backend
npm run dev:client-only     # Frontend only
npm run dev:server-only     # Backend only
npm run dev:fresh          # Clean start
```

#### 2. Port Configuration
```typescript
// Default ports:
Frontend: 5173
Backend: 5001
HMR: 5174
```

#### 3. Database Setup
```bash
# Database operations:
npm run db:generate        # Generate migrations
npm run db:migrate         # Apply migrations
npm run db:studio          # Open database studio
```

---

## 🚨 Common Issues & Solutions

### Issue 1: Individual Video API Returns 500 Error

#### Problem
```typescript
// API endpoint returns internal server error
curl "http://localhost:5001/api/videos/[uuid]"
// Returns: {"error":"Internal server error"}
```

#### Root Causes
1. **Conflicting Routes**: Multiple endpoints handling same path
2. **Wrong Query Syntax**: Using `.then(results => results[0])` instead of `.single()`
3. **UUID Format Issues**: Expecting integer IDs instead of UUID strings

#### Solution
```typescript
// 1. Remove conflicting routes
// Keep only: server/routes/videos.ts
// Remove: server/api/content-routes.ts (video endpoints)

// 2. Fix Supabase queries
// ❌ Wrong:
.then(results => results[0])

// ✅ Correct:
.single()

// 3. Ensure UUID format
router.get('/:id', async (req, res) => {
  const { id } = req.params;
  // id should be UUID format: "d39e1325-add3-41cc-b134-881c4dbc61d7"
});
```

### Issue 2: Authentication Routes Return 404

#### Problem
```typescript
// Auth routes not accessible
curl "http://localhost:5173/auth"
// Returns: 404 Page Not Found
```

#### Root Cause
Routes defined in `config/routes.tsx` but not used in `App.tsx`

#### Solution
```typescript
// Add all routes to App.tsx with proper lazy loading:
<Route path="/auth">
  {() => {
    const AuthPage = React.lazy(() => import('@/pages/auth-page'));
    return (
      <Suspense fallback={<LoadingSpinner message="Loading Auth..." />}>
        <AuthPage />
      </Suspense>
    );
  }}
</Route>
```

### Issue 3: Environment Variables Not Loading

#### Problem
```typescript
// Environment variables undefined
console.log(process.env.SUPABASE_URL); // undefined
```

#### Solution
```typescript
// 1. Check .env file exists and is properly formatted
SUPABASE_URL=https://project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=eyJ...

// 2. Verify environment validation
const envValidation = validateEnvironment();
if (!envValidation.isValid) {
  console.error('Missing:', envValidation.missing);
}

// 3. Check Vercel environment variables
// Vercel Dashboard > Project > Settings > Environment Variables
```

### Issue 4: CORS Errors in Development

#### Problem
```typescript
// CORS errors when calling API from frontend
Access to fetch at 'http://localhost:5001/api/videos' from origin 'http://localhost:5173' has been blocked by CORS policy
```

#### Solution
```typescript
// 1. Verify CORS configuration in server.ts
const allowedOrigins = [
  'http://localhost:5173',  // Development frontend
  'http://localhost:5174',  // HMR port
  'https://madifa.vercel.app' // Production
];

// 2. Check Vite proxy configuration
// vite.config.ts
server: {
  proxy: {
    '/api': {
      target: 'http://localhost:5001',
      changeOrigin: true,
      secure: false,
    }
  }
}
```

---

## 📋 Best Practices

### 1. Code Organization

#### Backend Structure
```typescript
// Follow this pattern:
server/
├── routes/           # One file per domain (videos, auth, etc.)
├── middleware/       # Reusable middleware
├── services/         # Business logic
├── utils/           # Helper functions
└── config/          # Configuration files
```

#### Frontend Structure
```typescript
// Component hierarchy:
src/
├── pages/           # Route components
├── components/      # Feature components
│   ├── ui/         # Base UI components
│   ├── auth/       # Domain-specific components
│   └── layouts/    # Layout components
├── hooks/          # Custom hooks
├── lib/            # Utilities
└── services/       # API services
```

### 2. Error Handling

#### Backend Error Handling
```typescript
// Use centralized error handling:
import { ApiError, asyncHandler } from '../middleware/error-handler.js';

router.get('/videos/:id', asyncHandler(async (req, res) => {
  const video = await getVideoById(req.params.id);
  if (!video) {
    throw ApiError.notFound('Video');
  }
  res.json(video);
}));
```

#### Frontend Error Handling
```typescript
// Use error boundaries and proper error states:
const { data, error, isLoading } = useQuery({
  queryKey: ['video', id],
  queryFn: () => fetchVideo(id),
  retry: 1,
});

if (error) {
  return <ErrorMessage error={error} />;
}
```

### 3. Type Safety

#### Shared Types
```typescript
// Define types in shared location:
// shared/types.ts
export interface Video {
  id: string;
  title: string;
  description?: string;
  // ... other fields
}

// Use in both frontend and backend
```

#### API Response Types
```typescript
// Consistent API response format:
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
}
```

### 4. Performance Optimization

#### Database Queries
```typescript
// Use proper indexing:
CREATE INDEX idx_videos_premium ON videos(is_premium);
CREATE INDEX idx_videos_genre ON videos USING GIN(genres);

// Optimize queries:
.select('id, title, thumbnail_url') // Only select needed fields
.limit(20) // Paginate results
.single() // Use for single record queries
```

#### Frontend Optimization
```typescript
// Lazy load components:
const VideoPlayer = React.lazy(() => import('./VideoPlayer'));

// Optimize images:
<img 
  src={thumbnailUrl} 
  loading="lazy" 
  alt={title}
  onError={handleImageError}
/>

// Use React Query for caching:
const { data } = useQuery({
  queryKey: ['videos'],
  queryFn: fetchVideos,
  staleTime: 5 * 60 * 1000, // 5 minutes
});
```

### 5. Security

#### Authentication
```typescript
// Always validate tokens:
const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'Token required' });
  }
  // Verify token with Supabase
};
```

#### Input Validation
```typescript
// Use Zod for validation:
const videoSchema = z.object({
  title: z.string().min(1).max(255),
  description: z.string().optional(),
  duration: z.number().positive(),
});

// Validate before processing:
const validatedData = videoSchema.parse(req.body);
```

#### Environment Variables
```typescript
// Never commit sensitive data:
// .env (local development only)
SUPABASE_SERVICE_ROLE_KEY=your-key-here

// Use environment validation:
const requiredEnvVars = [
  'SUPABASE_URL',
  'SUPABASE_SERVICE_ROLE_KEY',
  'BUNNY_API_KEY'
];
```

---

## 🔧 Troubleshooting Guide

### Development Issues

#### 1. Servers Won't Start
```bash
# Check if ports are in use:
netstat -ano | grep :5001
netstat -ano | grep :5173

# Clean up ports:
npm run dev:clean

# Start fresh:
npm run dev:fresh
```

#### 2. Database Connection Issues
```bash
# Check environment variables:
echo $SUPABASE_URL
echo $DATABASE_URL

# Test connection:
npm run db:studio

# Check migrations:
npm run db:generate
npm run db:migrate
```

#### 3. Build Failures
```bash
# Clear cache:
rm -rf node_modules
rm -rf dist
npm install

# Check TypeScript errors:
npm run typecheck

# Build step by step:
npm run build:client
npm run build:server
```

### Production Issues

#### 1. Deployment Failures
```bash
# Check Vercel logs:
vercel logs

# Verify environment variables:
vercel env ls

# Check build output:
vercel build
```

#### 2. API Errors
```bash
# Check server logs:
# Vercel Functions > Function logs

# Verify environment variables:
# Vercel Dashboard > Project > Settings > Environment Variables

# Test API endpoints:
curl https://your-domain.vercel.app/api/health
```

#### 3. Authentication Issues
```bash
# Check Supabase dashboard:
# Authentication > Users
# Authentication > Settings

# Verify JWT tokens:
# Use jwt.io to decode tokens

# Check CORS settings:
# Supabase > Settings > API > CORS
```

### Performance Issues

#### 1. Slow API Responses
```typescript
// Add query optimization:
.select('id, title, thumbnail_url') // Only needed fields
.limit(20) // Pagination
.order('created_at', { ascending: false }) // Proper indexing

// Check database performance:
// Supabase > Database > Query Performance
```

#### 2. Frontend Performance
```typescript
// Use React DevTools Profiler
// Check bundle size:
npm run build
npx vite-bundle-analyzer dist

// Optimize images:
// Use WebP format
// Add lazy loading
// Implement proper caching
```

---

## 📚 Additional Resources

### Documentation Links
- [Supabase Documentation](https://supabase.com/docs)
- [Drizzle ORM Documentation](https://orm.drizzle.team)
- [Vite Documentation](https://vitejs.dev)
- [React Query Documentation](https://tanstack.com/query)
- [PayFast API Documentation](https://developers.payfast.co.za)

### Development Tools
- [Supabase CLI](https://supabase.com/docs/reference/cli)
- [Drizzle Studio](https://orm.drizzle.team/drizzle-studio/overview)
- [React DevTools](https://react.dev/learn/react-developer-tools)
- [Vercel CLI](https://vercel.com/docs/cli)

### Monitoring & Analytics
- [Supabase Dashboard](https://supabase.com/dashboard)
- [Vercel Analytics](https://vercel.com/analytics)
- [Bunny CDN Dashboard](https://bunny.net)

---

## 🎯 Summary

This architecture documentation provides a complete reference for the MadifaStream platform. Key takeaways:

1. **Always use UUID format** for video IDs in API endpoints
2. **Centralize route registration** in `server/routes/index.ts`
3. **Use proper Supabase query syntax** (`.single()` not `.then(results => results[0])`)
4. **Include all routes in App.tsx** with proper lazy loading
5. **Validate environment variables** before server startup
6. **Follow consistent error handling** patterns
7. **Implement proper type safety** throughout the application

By following this documentation, future development should avoid the common pitfalls that were encountered and resolved during the debugging process.

---

**Last Updated**: January 2025
**Version**: 1.0.0
**Maintained By**: MadifaStream Development Team 