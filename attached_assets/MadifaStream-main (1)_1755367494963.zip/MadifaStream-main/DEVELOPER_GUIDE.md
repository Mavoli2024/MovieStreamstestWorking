# MadifaStream Developer Guide

## Table of Contents
1. [Architecture Overview](#architecture-overview)
2. [Getting Started](#getting-started)
3. [Development Workflow](#development-workflow)
4. [Database Management](#database-management)
5. [Performance Monitoring](#performance-monitoring)
6. [Deployment](#deployment)
7. [Best Practices](#best-practices)

## Architecture Overview

MadifaStream follows a Single Source of Truth (SSOT) architecture:

### Frontend
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite
- **Routing**: Wouter (lightweight alternative to React Router)
- **State Management**: TanStack React Query for server state
- **UI Components**: Radix UI with Tailwind CSS
- **Performance**: Web Vitals monitoring, lazy loading, code splitting

### Backend
- **Server**: Express.js with TypeScript
- **Database**: PostgreSQL via Supabase
- **ORM**: Drizzle ORM (single source of truth for schema)
- **Authentication**: Supabase Auth
- **Video Streaming**: Bunny.net CDN
- **Payments**: PayFast integration

### Key Principles
1. **Single Backend**: Express server used in both development and production
2. **Type Safety**: TypeScript throughout with generated types from Drizzle
3. **Performance First**: Core Web Vitals monitoring, optimized bundles
4. **Mobile Ready**: Capacitor integration for native apps

## Getting Started

### Prerequisites
- Node.js 20.x
- npm or pnpm
- Git
- Supabase account
- Bunny.net account (for video streaming)

### Initial Setup

1. Clone the repository:
```bash
git clone https://github.com/your-org/madifastream.git
cd madifastream
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
```

4. Configure your `.env` file with:
- Supabase credentials
- Bunny.net API keys
- PayFast merchant details
- Backend URL (defaults to http://localhost:5001)

5. Set up the database:
```bash
# Generate Drizzle migrations
npm run db:generate

# Apply migrations locally
npm run db:migrate

# Sync to Supabase
npm run sync:drizzle
```

6. **Validate your setup** (recommended):
```bash
node scripts/dev-setup.js
```

7. **Start development servers**:
```bash
npm run dev
```

This automatically:
- Cleans any occupied development ports
- Starts both frontend and backend concurrently
- Provides colored output for easy debugging
- Enables hot module replacement for frontend
- Enables automatic restart for backend changes

**Development URLs**:
- Frontend: http://localhost:5173
- Backend: http://localhost:5001
- API endpoints: http://localhost:5001/api/*

**Alternative development commands**:
```bash
npm run dev:fresh        # Clean start (recommended for troubleshooting)
npm run dev:client-only  # Frontend only
npm run dev:server-only  # Backend only
npm run dev:clean        # Just clean ports
```

## Development Workflow

### Code Structure
```
madifastream/
├── client/              # Frontend React application
│   ├── src/
│   │   ├── components/  # Reusable UI components
│   │   ├── hooks/       # Custom React hooks
│   │   ├── lib/         # Utilities and helpers
│   │   ├── pages/       # Route components
│   │   └── types/       # TypeScript definitions
│   └── vite.config.ts   # Vite configuration
├── server/              # Backend Express server
│   ├── routes/          # API endpoints
│   ├── services/        # Business logic
│   ├── middleware/      # Express middleware
│   └── server.ts        # Server entry point
├── shared/              # Shared code between frontend/backend
│   └── schema.ts        # Drizzle database schema
└── scripts/             # Utility scripts
```

### Making Changes

#### Frontend Development
1. Components go in `client/src/components/`
2. Use the UI library components from `client/src/components/ui/`
3. Create custom hooks in `client/src/hooks/`
4. Add new pages in `client/src/pages/`

#### Backend Development
1. API routes go in `server/routes/` with centralized mounting
2. Business logic in `server/services/`
3. Middleware in `server/middleware/`
4. Always use TypeScript for type safety

#### API Routing Architecture
The backend uses a **centralized routing system** for clean organization:

- **Central Aggregator**: `server/routes/index.ts` mounts all route modules
- **Route Modules**: Each route file exports a default Express router
- **Server Integration**: `server/server.ts` imports the aggregated router
- **Vercel Compatibility**: API routes in `/api` forward to Express server

Example route structure:
```typescript
// server/routes/videos.ts
import express from 'express';
const router = express.Router();

router.get('/', getAllVideos);
router.get('/:id', getVideoById);

export default router;

// server/routes/index.ts
import videosRouter from './videos.js';
import authRouter from './auth.js';

const createApiRouter = () => {
  const router = express.Router();
  router.use('/videos', videosRouter);
  router.use('/auth', authRouter);
  return router;
};

export { createApiRouter };
export default createApiRouter;
```

**Adding New Routes**:
1. Create route file in `server/routes/` with default export
2. Add import and mount to `server/routes/index.ts`
3. Routes automatically available via centralized system

#### Database Changes
**IMPORTANT**: Always use Drizzle for schema changes. Never modify the database directly.

1. Edit `shared/schema.ts`
2. Generate migration:
   ```bash
   npm run db:generate
   ```
3. Apply locally:
   ```bash
   npm run db:migrate
   ```
4. Sync to Supabase:
   ```bash
   npm run sync:drizzle
   ```

### Testing

Run the test suite:
```bash
# Unit tests
npm run test:unit

# Component tests
npm run test:components

# E2E tests
npm run test:e2e

# All tests
npm run test:all
```

## Database Management

### Schema Management
- **Single Source of Truth**: Drizzle ORM in `shared/schema.ts`
- **Migrations**: Auto-generated in `migrations/` directory
- **Type Safety**: Types generated from schema

### Common Tasks

#### Adding a New Table
1. Define in `shared/schema.ts`:
   ```typescript
   export const newTable = pgTable("new_table", {
     id: uuid("id").primaryKey().defaultRandom(),
     name: text("name").notNull(),
     created_at: timestamp("created_at").defaultNow()
   });
   ```

2. Generate and apply migration:
   ```bash
   npm run db:generate
   npm run db:migrate
   npm run sync:drizzle
   ```

#### Adding an Index
```typescript
export const userIdIndex = index("user_id_idx").on(videos.user_id);
```

### Database Best Practices
- Always add appropriate indexes for frequently queried columns
- Use Row Level Security (RLS) policies in Supabase
- Keep migrations small and focused
- Test migrations in development before production

## Performance Monitoring

### Core Web Vitals
The application automatically tracks:
- **LCP** (Largest Contentful Paint): < 2.5s is good
- **INP** (Interaction to Next Paint): < 200ms is good
- **CLS** (Cumulative Layout Shift): < 0.1 is good
- **FCP** (First Contentful Paint): < 1.8s is good
- **TTFB** (Time to First Byte): < 800ms is good

### Viewing Performance Data

In development, open the browser console to see performance metrics.

To get a summary:
```javascript
// In browser console
window.getPerformanceSummary()
```

To clear metrics:
```javascript
window.clearPerformanceMetrics()
```

### Performance Best Practices
1. Use lazy loading for routes and heavy components
2. Optimize images with Bunny.net transformations
3. Implement proper caching headers
4. Use React Query for efficient data fetching
5. Monitor bundle size with `npm run build`

## Deployment

### Environment Configuration
Ensure all environment variables are set in your deployment platform:
- Vercel: Add via dashboard or CLI
- Netlify: Add via dashboard
- Custom: Use `.env.production`

### Build Process
```bash
# Full build (includes server compilation)
npm run build:full
```

### Deployment Platforms

#### Vercel
The project is configured for Vercel deployment:
1. Push to main branch
2. Vercel automatically builds and deploys
3. Express server runs as a serverless function

#### Netlify
Similar to Vercel:
1. Push to main branch
2. Netlify builds and deploys
3. API calls are proxied to the Express server

#### Custom Deployment
1. Build the application:
   ```bash
   npm run build:full
   ```
2. Start the production server:
   ```bash
   npm start
   ```
3. Serve static files from `dist/public/`
4. Ensure the Express server is accessible

## Best Practices

### Code Quality
1. **TypeScript**: Always use proper types, avoid `any`
2. **Components**: Keep them small and focused
3. **Hooks**: Extract complex logic into custom hooks
4. **Error Handling**: Use error boundaries and proper try-catch blocks

### Security
1. **Environment Variables**: Never commit sensitive data
2. **API Keys**: Keep server-side only (use VITE_ prefix for client)
3. **Authentication**: Always validate on the server
4. **Input Validation**: Sanitize all user inputs

### Performance
1. **Bundle Size**: Monitor with webpack-bundle-analyzer
2. **Images**: Use appropriate formats and sizes
3. **Caching**: Implement proper cache headers
4. **Database**: Add indexes for frequently queried columns

### Git Workflow
1. **Branches**: Use feature branches
2. **Commits**: Write clear, descriptive messages
3. **Pull Requests**: Include description and testing steps
4. **Code Review**: Required before merging

### Common Issues

#### Build Failures
- Check for TypeScript errors: `npm run typecheck`
- Ensure all dependencies are installed
- Verify environment variables are set

#### API Route Issues
- Ensure new routes are added to `server/routes/index.ts`
- Check route modules export default Express router
- Use `ApiError` class for consistent error handling
- Wrap async routes with `asyncHandler` to catch unhandled promises
- Verify Express server builds correctly: `cd server && npm run build`
- Test API endpoints in development before production

#### Error Handling Best Practices
- Use `ApiError` static methods for common errors (e.g., `ApiError.notFound()`)
- Wrap all async route handlers with `asyncHandler()`
- Use `validateRequest()` middleware for input validation with Zod schemas
- Leverage request IDs (`X-Request-ID` header) for tracing errors
- Check error logs with full context in both development and production

#### Database Issues
- Ensure migrations are synced: `npm run sync:drizzle`
- Check Supabase connection settings
- Verify RLS policies aren't blocking queries

#### Performance Issues
- Check Core Web Vitals in performance monitor
- Analyze bundle size
- Look for unnecessary re-renders
- Optimize database queries

## Additional Resources

- [Supabase Documentation](https://supabase.com/docs)
- [Drizzle ORM Documentation](https://orm.drizzle.team/)
- [Wouter Documentation](https://github.com/molefrog/wouter)
- [TanStack Query Documentation](https://tanstack.com/query)
- [Web Vitals Documentation](https://web.dev/vitals/)

## Support

For issues or questions:
1. Check existing issues on GitHub
2. Review this documentation
3. Contact the development team

Remember: Always follow the Single Source of Truth principles established in the architecture! 